$(document).ready(()=>{
    $(window).on('load',()=>{
        const currentHash = new URLSearchParams(window.location.search).get('page');
        if(currentHash)
            x = $(`.documentation-subsection-item[href="?page=${currentHash}"]`);
        else
            x = $('.documentation-subsection-item')[0];
        $(x).addClass('focus');

        $(`.documentation .documentation-content`).each((_,e)=>{
            const id = currentHash ? currentHash.replace(/\|/g,'_') : $($('.documentation-subsection-item')[0])?.attr('href')?.replace(/\?page=/,'').replace(/\|/g,'_');
            if($(e).attr('id') === id)
                $(e).css('display','block');
            else
                $(e).css('display','none');
        });


        $('.documentation .collapse').each((i,e)=>{
            $(e).children('.collapse-title').on('click',function(){
                $(this).parent().toggleClass('active');
                const content = $(this).parent().children('.collapse-body');
                if(!$(this).parent().hasClass('active'))
                    $(content).css('max-height','');
                else
                    $(content).css('max-height',$(content).prop('scrollHeight')+`px`);
            });
            if($(e).find('.documentation-subsection-item.focus').length>0){
                $(e).toggleClass('active');
                const content = $(e).find('.collapse-body');
                if(!$(e).hasClass('active'))
                    $(content).css('max-height','');
                else
                    $(content).css('max-height',$(content).prop('scrollHeight')+`px`);
            }
        });

        $('.documentation .documentation-codeblock').each((i,e)=>{
            $(e).find('[data-command]').each((j,el)=>{
                $(el).on('click',function(){
                    $(this).parent().find('[data-command]').removeAttr('selected');
                    $(this).attr('selected',true);
                    const code = $(this).parent().parent().parent().find('.code-content');
                    if(code.length>0){
                        code.text($(this).attr('data-command'));
                        $(code).removeClass(function(index, className) {
                            return (className.match(/(^|\s)language-\S+/g) || []).join(' ');
                        }).addClass(`language-${$(this).attr('data-lang')}`);
                        Prism.highlightElement(code[0]);
                    }
                });
            });
        });
        $('.documentation .documentation-codeblock [data-copy]').on('click',function(){
            const code = $(this).parent().parent().parent().find('.code-content');
            if(code.length>0){
                const text = code.text();
                navigator.clipboard.writeText(text).then(()=>{
                    alert('Code copied to clipboard!');
                }).catch(err=>{
                    console.error('Failed to copy text: ', err);
                });
            }
        });
        setTimeout(()=>{
            const params = new URLSearchParams(window.location.search);
            const content = $(`.documentation .documentation-content#${(params.get('page') ? params.get('page').replace(/\|/g, '_') : `${$('.documentation-section-item:first p').text().toLowerCase()}_${$('.documentation-section-item:first .documentation-subsection-item:first li').text().trim().toLowerCase().replace(' ','_')}`)}`)[0];
            scrollnav.init(content,{
                insertTarget: $('.documentation .page-nav .page-nav-scroll')[0]
            });
            $('.documentation .page-nav .page-nav-scroll').remove();
        },100);
    });
    let ListedItems = [];
    let noRecentSearchesMsg = $('.modal-body').html();
    function setHistoryView(){
        if(getHistory()&&getHistory().length>0){
            const history = getHistory();
            let obj = `<ul class="list-group">`;
                $(history.sort((a, b) => b.id - a.id)).each((_,h)=>{
                    obj+=`<a history-id="${h.id}" class="text-decoration-none search-link" href="${h.reference}"><li class="list-group-item d-flex align-items-center justify-content-between"><div><i class="fa-solid fa-clock-rotate-left"></i> ${h.label}</div> <i class="fa-solid fa-x"></i></li></a>`
                });
            obj+=`</ul>`;
            $('.modal-body').html(obj);
        }
        $('.search-link li').each((_,e)=>{
                $(this).removeClass('active');
                $(e).on('mouseover focus',function(){
                    $('.search-link li').each((_,i)=>$(i).removeClass('active'));
                    $(this).addClass('active');
                });
                $(e).on('mouseout focusout',function(){
                    $(this).removeClass('active');
                });
            });
            $('.search-link').on('click',function(e){
                e.preventDefault();
                const history = getHistory()??[];
                const x = $('.modal.show').find('.list-group-item.active'),
                y = x.parent().parent().parent();
                if(e.target.tagName!=='I'){
                    history.push({
                        reference: x.parent().attr('href'),
                        label: x.text(),
                        path: [y.parent().find('h4').text().trim(), y.find('h6').text().trim()],
                        id: history.length++
                    });
                    const href = $(this).attr('href');
                    $('.modal input').val('');
                    $('.modal').modal('toggle');
                    window.open(href,'_self');
                    setHistory(history);
                }else{
                    removeHistory($(this).attr('history-id'));
                    this.remove();
                }
        });
    }
    setHistoryView();


    $('#documentation-searchbar').on('focus',function(){$(this).blur();});
    $(window).on('keydown',function(e){
        const key = e.key||e.keyCode||e.which;
        if(e.ctrlKey&&key=='k'&&$('.modal.show').length==0){
            e.preventDefault();
            $('#documentation-searchbar').click();
        }
    });
    $('.documentation-section > li').each((i,e)=>{
            ListedItems.push({
                sectionLabel: $(e).find('.documentation-section-label').text(),
                subsections:[],
            });
            $(e).find('.documentation-subsection > a').each((f,s)=>{
                ListedItems[i]['subsections'].push({
                    name: $(s).find('li').text(),
                    reference: $(s).attr('href'),
                    headers: []
                });
                const normalize = `${$(e).find('.documentation-section-label').text().toLowerCase().trim()}_${$(s).find('li').text().toLowerCase().trim()}`.replace(/ /g,'_');
                $(`.documentation-content#${normalize} h2`).each((_,h)=>{
                    ListedItems[i]['subsections'][f]['headers'].push({
                        headingType: $(h)[0].tagName,
                        text: $(h).text(),
                        path: [$(e).find('.documentation-section-label').text(),$(s).find('li').text()],
                        reference: `${$(s).attr('href')}${$(h).attr('id') ? `#${$(h).attr('id')}` : ''}`
                    });
                });
            });
    });
    $('#documentation-modal-search').on('input',function(){

        const results = filterArrayByText($(this).val().trim());
        if(Array.isArray(results)&&results.length>=1){
            let obj = '';
            $(results).each((_,e)=>{
                obj+=`<div><h4>${e['sectionLabel'].trim()}</h4>`;
                $(e.subsections).each((_,i)=>{
                    if(getMatchingHeaders(i.headers,$(this).val().trim()).length>0){
                        obj+=`<div><h6>${i.name.trim()}</h6>
                        <ul class="list-group">`;
                    $(getMatchingHeaders(i.headers,$(this).val().trim())).each((_,k)=>{
                        
                        $(k).each((_,i)=>{
                            obj+=`<a class="text-decoration-none search-link" href="${i.reference}"><li class="list-group-item">${i.text}</li></a>`;
                        });
                    });
                    obj+=`</ul></div>`;
                }
                })
                obj+=`</div>`;
            });
            $('.modal-body').html(obj);
            
        }else $('.modal-body').html(defaultNull);
        $('.search-link li').each((_,e)=>{
                $(this).removeClass('active');
                $(e).on('mouseover focus',function(){
                    $('.search-link li').each((_,i)=>$(i).removeClass('active'));
                    $(this).addClass('active');
                });
                $(e).on('mouseout focusout',function(){
                    $(this).removeClass('active');
                });
            });
            $('.search-link').on('click',function(e){
                e.preventDefault();
                const history = getHistory()??[];
                const x = $('.modal.show').find('.list-group-item.active'),
                y = x.parent().parent().parent();
                if(e.target.tagName!=='I'){
                    history.push({
                        reference: x.parent().attr('href'),
                        label: x.text(),
                        path: [y.parent().find('h4').text().trim(), y.find('h6').text().trim()],
                        id: history.length++
                    });
                    const href = $(this).attr('href');
                    $('.modal input').val('');
                    $('.modal').modal('toggle');
                    window.open(href,'_self');
                    setHistory(history);
                }else{
                    removeHistory($(this).attr('history-id'));
                    this.remove();
                }
        });
    });


    $('.search-link li').each((_,e)=>{
                $(this).removeClass('active');
                $(e).on('mouseover focus',function(){
                    $('.search-link li').each((_,i)=>$(i).removeClass('active'));
                    $(this).addClass('active');
                });
                $(e).on('mouseout focusout',function(){
                    $(this).removeClass('active');
                });
            });
            $('.search-link').on('click',function(e){
                e.preventDefault();
                const history = getHistory()??[];
                const x = $('.modal.show').find('.list-group-item.active'),
                y = x.parent().parent().parent();
                if(e.target.tagName!=='I'){
                    history.push({
                        reference: x.parent().attr('href'),
                        label: x.text(),
                        path: [y.parent().find('h4').text().trim(), y.find('h6').text().trim()],
                        id: history.length++
                    });
                    const href = $(this).attr('href');
                    $('.modal input').val('');
                    $('.modal').modal('toggle');
                    window.open(href,'_self');
                    setHistory(history);
                }else{
                    removeHistory($(this).attr('history-id'));
                    this.remove();
                }
            });
    const defaultNull = $('.modal-body').html();
    function getMatchingHeaders(data, inputText) {
        const lowerCaseInput = inputText.toLowerCase();
        const matchingHeaders = [];
        data.forEach(header => {
            if (header.text.toLowerCase().includes(lowerCaseInput)) {
                matchingHeaders.push(header);
            }
        });
        return matchingHeaders;
    }
    function filterArrayByText(inputText) {
        const lowerCaseInput = inputText.toLowerCase();
        return ListedItems.filter(section => {
            if (section.sectionLabel.toLowerCase().includes(lowerCaseInput)) return true;
            // Check subsections
            if (section.subsections) {
                return section.subsections.some(subsection => {
                // Check subsection name
                if (subsection.name.toLowerCase().includes(lowerCaseInput)) return true;
                // Check headers
                if (subsection.headers) 
                    return subsection.headers.some(header =>header.text.toLowerCase().includes(lowerCaseInput));
                return false;
                });
            }
            return false;
        })??defaultNull;
    }
    $('.modal').on('keydown',function(e){
        if ($(this).hasClass('show')) {
            const key = e.keyCode || e.which;
            const list = $(this).find('.list-group-item');
            const activeItem = list.filter('.active');
            const activeIndex = list.index(activeItem);
            if (key == 38) { // Up arrow
                // Remove active from current
                activeItem.removeClass('active');
                // Calculate new index, wrapping around if needed
                const newIndex = activeIndex <= 0 ? list.length - 1 : activeIndex - 1;
                // Add active to the new item
                list.eq(newIndex).addClass('active');
            }
            if (key == 40) { // Down arrow
                // Remove active from current
                activeItem.removeClass('active');
                // Calculate new index, wrapping around if needed
                const newIndex = activeIndex >= list.length - 1 ? 0 : activeIndex + 1;
                // Add active to the new item
                list.eq(newIndex).addClass('active');
            }
        }
    });
    $('.documentation-searchbar').on('keydown',function(e){
        const k = e.keyCode||e.which;
        if(k==13){
            const history = getHistory()??[];
            $('.modal input').val('');
            const x = $('.modal.show').find('.list-group-item.active'),
            y = x.parent().parent().parent();
            history.push({
                reference: x.parent().attr('href'),
                label: x.text(),
                path: [y.parent().find('h4').text().trim(), y.find('h6').text().trim()],
                id: history.length++
            });
            $('.modal').modal('toggle');
            $('.modal .modal-body').html(defaultNull);
            setHistory(history);
            setHistoryView();
            window.open($(x).parent().attr('href'),'_self');
        }
    });
    
    /**
     * Sets the data to docs history
     *
     * @param {Object} data Object to return
     */
    function setHistory(data){
        data = data.filter(i=>i.label!=='');
        localStorage.setItem('wo_docs_history',JSON.stringify(data));
    }
    
    /**
     * Returns the docs history
     *
     * @returns {Object} 
     */
    function getHistory(){
        return JSON.parse(localStorage.getItem('wo_docs_history'));
    }
    
    /**
     * Remove a history index
     *
     * @param {Number} index Array index
     */
    function removeHistory(id) {
        const history = getHistory() || [];
        const index = history.findIndex(item => item.id === parseInt(id));
        if (index !== -1) {
            history.splice(index, 1);
            setHistory(history);
        }
        if (history.length === 0) {
            $('.modal-body').html(noRecentSearchesMsg);
        }
    }
});