<?php
include_once 'init.php';
include_once 'office/dashboard.php';