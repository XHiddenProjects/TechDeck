# WebOffice Documentation

Welcome to the WebOffice platform — your comprehensive solution for managing organizational data, devices, servers, and networks with ease and efficiency. This guide will help you get started quickly and make the most of WebOffice's features.

---

## Getting Started {#getting-started}

Begin your journey with WebOffice by setting up your administrator account, configuring essential components, and managing your organization's infrastructure.

### Step 1: Create an Account
Reminder that account privileges go by _First Come First Server (FCFS)_ meaning the first account create will automatically become the administrator.

- Go to [**Authorization**](http://localhost/WebOffice/auth)
- Under *Sign Up* fill out the valid credentials.
- Once done, click the **blue** button that says _"Register Device"_
- Fill that out and click **save**