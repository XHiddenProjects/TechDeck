import os
output = os.popen('who').read().split(' ')
print(output[0].strip())