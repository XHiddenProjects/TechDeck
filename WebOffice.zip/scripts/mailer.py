import smtplib
import sys
import json
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

def main():
    # Check if payload argument is provided
    if len(sys.argv) != 2:
        print("Usage: python3 mailer.py '<json_payload>'")
        sys.exit(1)

    # Get the JSON payload from the command-line argument
    json_payload = sys.argv[1]

    try:
        # Parse JSON payload
        email_data = json.loads(json_payload)

        # Access email components
        sender = email_data.get('from', '')
        recipients = email_data.get('to', '')
        subject = email_data.get('subject', '')
        body = email_data.get('body', '')
        headers = email_data.get('headers', '')
        attachments = email_data.get('attachments', [])
        host = email_data.get('host', '')
        username = email_data.get('username', '')
        password = email_data.get('password', '')
        port = email_data.get('port', 0)
        encryption = email_data.get('encryption', '').lower()

        # Handle recipients: list or comma-separated string
        

        # Create message container
        msg = MIMEMultipart()
        msg['From'] = sender
        msg['To'] = recipients
        msg['Subject'] = subject

        # Add custom headers if any
        if headers:
            if isinstance(headers, dict):
                for key, value in headers.items():
                    msg[key] = value
            elif isinstance(headers, str):
                pass

        # Attach email body
        msg.attach(MIMEText(body, 'html' if email_data.get('isHTML',False) else 'plain', email_data.get('charset','UTF-8')))

        # Attach files
        for attach_dict in attachments:
            if isinstance(attach_dict, dict):
                file_path = attach_dict.get('path')
                filename = attach_dict.get('name', os.path.basename(file_path))
                if file_path and os.path.isfile(file_path):
                    with open(file_path, 'rb') as f:
                        part = MIMEBase('application', 'octet-stream')
                        part.set_payload(f.read())
                        encoders.encode_base64(part)
                        part.add_header('Content-Disposition', f'attachment; filename="{filename}"')
                        msg.attach(part)

        # Establish SMTP connection with explicit connect()
        try:
            if encryption == 'ssl':
                # For SSL, connection is established in the constructor
                server = smtplib.SMTP_SSL(host, port)
            else:
                # For STARTTLS
                server = smtplib.SMTP(host, port)
                server.ehlo()
                if encryption == 'starttls':
                    server.starttls()
                    server.ehlo()  # Re-identify after STARTTLS
            server.set_debuglevel(1)
        except Exception as e:
            print(f"Failed to connect to SMTP server: {e}")
            sys.exit(1)

        # Login if credentials provided
        if username and password:
            try:
                server.login(username, password)
            except smtplib.SMTPException as e:
                print(f"Login failed: {e}")
                server.quit()
                sys.exit(1)

        # Send email
        try:
            server.sendmail(sender, recipients, msg.as_string())
            print("Email sent successfully.")
        except smtplib.SMTPException as e:
            print(f"Failed to send email: {e}")
        finally:
            server.quit()

    except json.JSONDecodeError:
        print("Invalid JSON payload")
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()