<?php
use WebOffice\Security,
WebOffice\Locales,
WebOffice\Config;
header('Content-Type: application/json; charset=utf-8');
$p = dirname(__DIR__).'/libs';
foreach(array_diff(scandir($p),['.','..']) as $f) if(is_file("$p/$f")) include_once "$p/$f";

$security = new Security();
$lang = new Locales(implode('-',LANGUAGE));
$csrf = $_POST['token'] ?? '';
if(!$security->CSRF('verify',$csrf)){
    echo json_encode(['status'=>'error','msg'=>$lang->load(['errors','invalid_csrf'])]);
}else{
    $config = new Config('config');
    foreach($_POST as $key => $value){
        switch($key){
            case 'config_charset':
                $value = $security->preventXSS($value);
                $config->update(['settings'=>['charset'=>$value]]);
                break;
            case 'config_theme':
                $value = $security->preventXSS($value);
                $config->update(['settings'=>['theme'=>$value]]);
                break;
            case 'mail_host':
                $value = $security->preventXSS($value);
                $config->update(['mail'=>['host'=>$value]]);
                break;
            case 'mail_username':
                $value = $security->preventXSS($value);
                $config->update(['mail'=>['username'=>$value]]);
                break;
            case 'mail_password':
                $value = $security->preventXSS($value);
                $config->update(['mail'=>['password'=>base64_encode($value)]]);
                break;
            case 'mail_encryption':
                $value = $security->preventXSS($value);
                $config->update(['mail'=>['encryption'=>$value]]);
                break;
            case 'mail_port':
                $config->update(['mail'=>['port'=>$security->filter($value,Security::FILTER_INT)]]);
                break;
            case 'mail_domain':
                $value = $security->preventXSS($value);
                $config->update(['mail'=>['domain'=>ltrim($value,'@')]]);
                break;
        }
    }
    echo json_encode(['status'=>'success','msg'=>$lang->load(['success','config_saved'])]);
}