<?php
use WebOffice\Security,
WebOffice\Locales,
WebOffice\Device,
WebOffice\Network,
WebOffice\SSH2;
header('Content-Type: application/json; charset=utf-8');
$p = dirname(__DIR__).'/libs';
foreach(array_diff(scandir($p),['.','..']) as $f) if(is_file("$p/$f")) include_once "$p/$f";

$devices = new Device();
$locales = new Locales(implode('-',LANGUAGE));
$security = new Security();
$network = new Network();
$ssh2 = new SSH2();

if(isset($_GET['action'])){
    switch(strtolower($_GET['action'])){
        case 'add':
            if($security->CSRF('verify',$_POST['token'])){
                $insertDevice = $devices->addDevice($_POST['deviceName'],
            $_POST['deviceType'],
        $_POST['deviceBrand'],
    $_POST['deviceModel'],
$_POST['deviceOS'],
$_POST['deviceOSPlatform'],
$_POST['deviceSerial'],
$_POST['deviceManufacturer'],
$_POST['deviceLocation'],
$_POST['deviceIP'],
strtotime($_POST['purchaseDate']),
strtotime($_POST['warrantyExpiry']),
'deactivate',
$_POST['deviceAsset']);
                if($insertDevice){
                    $security->CSRF(action: 'generate', forceGenerate: true);
                    echo json_encode(['success'=>true],JSON_UNESCAPED_SLASHES);
                }else echo json_encode(['success'=>false, 'msg'=>$locales->load(['errors','deviceExists'])],JSON_UNESCAPED_SLASHES);
            }else echo json_encode(['success'=>false, 'msg'=>$locales->load(['errors','csrfInvalid'])],JSON_UNESCAPED_SLASHES);
        break;
    }
}
// Read the raw POST data
$input = file_get_contents('php://input');
if(isset($input)&&$input){
    $data = json_decode($input, true);
    if(strtolower($data['action'])==='activate'||strtolower($data['action'])==='deactivate'){
        $deviceName = base64_decode($data['info']);
        $info = $devices->getRegisterDevices(['name'=>$deviceName]);
        $deviceExists = $network->ping($info['ip_address']);
        if((int)$deviceExists['received']>0){
            if($network->isSshActive()){
                $results = match(strtolower($data['action'])){
                    'activate'=>$devices->updateStatus('activated',$security->preventXSS($deviceName)),
                    'deactivate'=>$results = $devices->updateStatus('deactivate',$security->preventXSS($deviceName)),
                    default=>false
                };
                if($results) echo json_encode(['success'=>true, 'msg'=>(strtolower($data['action'])==='activate' ? $locales->load(['success','device_activated']) : $locales->load(['success','device_deactivated']))],JSON_UNESCAPED_SLASHES);
                else echo json_encode(['success'=>false,'msg'=>$locales->load(['errors','somethingWentWrong'])],JSON_UNESCAPED_SLASHES);
            }else echo json_encode(['success'=>false,'msg'=>$locales->load(['errors','SSHNotActive'])],JSON_UNESCAPED_SLASHES);
        }else echo json_encode(['success'=>false,'msg'=>$locales->load(['errors','deviceNotFound'])],JSON_UNESCAPED_SLASHES);
    }
    if(strtolower($data['action'])==='poweroff'||strtolower($data['action'])==='reboot'){
        $psw = base64_decode($data['connect']);
        $deviceName = base64_decode($data['name']);
        $info = $devices->getRegisterDevices(['name'=>$deviceName]);
        $user = trim($info['device_username']);
        $ip = $info['ip_address'];
        $ssh2->connect($ip,$user,$psw);
        $deviceExists = $network->ping($ip);
        if((int)$deviceExists['received']>0){
            if(strtolower($data['action'])==='poweroff')
                echo json_encode(['success'=>true,'msg'=>$ssh2->shutdown()],JSON_UNESCAPED_SLASHES);
            elseif(strtolower($data['action'])==='reboot')
                echo json_encode(['success'=>true,'msg'=>$ssh2->reboot()], JSON_UNESCAPED_SLASHES);
            else echo json_encode(['success'=>false,'msg'=>$locales->load(['errors','deviceActionNotFound'])]);
        }else echo json_encode(['success'=>false,'msg'=>$locales->load(['errors','deviceNotFound'])],JSON_UNESCAPED_SLASHES);
        $ssh2->close();
    }
    if(strtolower($data['action'])==='ping'){
        $deviceName = base64_decode($data['name']);
        $info = $devices->getRegisterDevices(['name'=>$deviceName]);
        echo json_encode(['success'=>true, 'results'=>$network->ping($info['ip_address'],(int)$data['connect']??3,(int)$data['packets']??1)],JSON_UNESCAPED_SLASHES);
    }
}