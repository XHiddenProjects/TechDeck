<?php
use WebOffice\Security,
WebOffice\Users,
WebOffice\Locales;
header('Content-Type: application/json; charset=utf-8');
$p = dirname(__DIR__).'/libs';
foreach(array_diff(scandir($p),['.','..']) as $f) if(is_file("$p/$f")) include_once "$p/$f";

$users = new Users();
$security = new Security();
$locales = new Locales(implode('-',LANGUAGE));
if($security->CSRF('verify',$_POST['token'])){
    $fname = $security->preventXSS($_POST['fname']!==''?$_POST['fname']:$users->getFullName()['first_name']);
    $mname = $security->preventXSS($_POST['mname']!==''?$_POST['mname']:$users->getFullName()['middle_name']);
    $lname = $security->preventXSS($_POST['lname']!==''?$_POST['lname']:$users->getFullName()['last_name']);
    $phone = $security->filter($_POST['phone']!==''?$_POST['phone']:$users->getPhone(),Security::FILTER_PHONE);
    $bio = $security->preventXSS($_POST['bio']!==''?$_POST['bio']:$users->getBio());
    $users->updateProfile([
        'first_name'=>$fname,
        'middle_name'=>$mname,
        'last_name'=>$lname,
        'phone'=>$phone,
        'bio'=>$bio
    ]);
    echo json_encode(['success'=>true, 'msg'=>$locales->load(['success','profile_changed'])]);
}else echo json_encode(['success'=>false, 'msg'=>$locales->load(['errors','csrfInvalid'])],JSON_UNESCAPED_SLASHES);