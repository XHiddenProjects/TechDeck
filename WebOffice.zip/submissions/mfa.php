<?php
use WebOffice\Security, WebOffice\Locales, WebOffice\Storage, WebOffice\Database;
use WebOffice\Config;
header('Content-Type: application/json; charset=utf-8');
$p = dirname(__DIR__).'/libs';
foreach(array_diff(scandir($p),['.','..']) as $f) if(is_file("$p/$f")) include_once "$p/$f";


$security = new Security();
$lang= new Locales(implode('-',LANGUAGE));
$storage = new Storage();
$config = new Config();

$main = $security->preventXSS($security->sanitize(base64_decode($_POST['main']),$security::SANITIZE_URL));

if(!isset($_SESSION['temp_user'])) echo json_encode(['status'=>'error', 'msg'=>$lang->load(['errors','noAttemptLogin'])],JSON_UNESCAPED_SLASHES);
else{
    if(!$security->CSRF('verify',$_POST['token'])){
        echo json_encode(['success'=>false,'msg'=>$lang->load(['errors','csrfInvalid'])],JSON_UNESCAPED_SLASHES);
        exit();
    }
    $remember = $_SESSION['temp_remember']??false;
    $tempUser = $_SESSION['temp_user'];

    $code = $security->sanitize($_POST['mfa_code'], $security::SANITIZE_INT);

    $db = new Database(
        $config->read('mysql','host'),
        $config->read('mysql','user'),
        $config->read('mysql','psw'),
        $config->read('mysql','db')
    );
    $secret = $db->fetch("SELECT 2fa_secret FROM mfa WHERE username=:user",['user'=>$tempUser]);

    if($security->MFA($secret['2fa_secret'],$code, 'VERIFY')){
        if($remember) $storage->cookie('weboffice_auth',$security->JWT('a-string-secret-at-least-256-bits-long',['username'=>$tempUser]),'store',720);    
        else $storage->session('weboffice_auth',$security->JWT('a-string-secret-at-least-256-bits-long',['username'=>$tempUser]));
        $url = "$main/api/users?username={$tempUser}&status=active&last_login=".date('Y-m-d H:i:s',time())."&last_activity=".date('Y-m-d H:i:s',time());
                        $api = curl_init();
                        curl_setopt($api,CURLOPT_URL,$url);
                        curl_setopt($api,CURLOPT_CUSTOMREQUEST,'PUT');
                        curl_setopt($api, CURLOPT_RETURNTRANSFER, true);
                        $result = curl_exec($api);
                        if(curl_errno($api)) echo json_encode(['status'=>'error','msg'=>'cURL Error: ' . curl_error($api)],JSON_UNESCAPED_SLASHES);
                        curl_close($api);
        echo json_encode(['status'=>'success']);
    }else echo json_encode(['status'=>'error','msg'=>$lang->load(['errors','invalidMFA'])],JSON_UNESCAPED_SLASHES);
}