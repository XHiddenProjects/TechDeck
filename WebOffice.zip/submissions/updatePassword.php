<?php
use WebOffice\Security, WebOffice\Users, WebOffice\Locales, WebOffice\Config, WebOffice\Database;
header('Content-Type: application/json; charset=utf-8');
$p = dirname(__DIR__).'/libs';
foreach(array_diff(scandir($p),['.','..']) as $f) if(is_file("$p/$f")) include_once "$p/$f";

$security = new Security();
$users = new Users();
$lang= new Locales(implode('-',LANGUAGE));
$config = new Config();
$db = new Database(
    $config->read('mysql','host'),
    $config->read('mysql','user'),
    $config->read('mysql','psw'),
    $config->read('mysql','db')
);
if($security->CSRF('verify',$_POST['token'])){
    if(hash_equals($_POST['new_password'],$_POST['confirm_new_password'])){
        $og = $db->fetch("SELECT * FROM users WHERE username=:username",['username'=>$users->getUsername()],PDO::FETCH_ASSOC);
        if($security->verify($_POST['new_password'],$og['password']))
            echo json_encode(['success'=>false,'msg'=>$lang->load(['errors','no_og_psw'])]);
        else{
            $db->update('users',[
                'password'=>$security->hashPsw($_POST['new_password'],PASSWORD_BCRYPT, ['cost'=>14])
            ],['username'=>$users->getUsername()]);
            echo json_encode(['success'=>true,'msg'=>null]);
        }
    }else echo json_encode(['success'=>false,'msg'=>$lang->load(['errors','mismatch_psw'])]);
}else echo json_encode(['success'=>false, 'msg'=>$lang->load(['errors','csrfInvalid'])],JSON_UNESCAPED_SLASHES);;