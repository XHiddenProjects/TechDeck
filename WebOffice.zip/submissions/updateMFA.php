<?php
use WebOffice\Security, WebOffice\Users, WebOffice\Config, WebOffice\Database;
header('Content-Type: application/json; charset=utf-8');
$p = dirname(__DIR__).'/libs';
foreach(array_diff(scandir($p),['.','..']) as $f) if(is_file("$p/$f")) include_once "$p/$f";

$security = new Security();
$users = new Users();
$config = new Config();
$db = new Database(
    $config->read('mysql','host'),
    $config->read('mysql','user'),
    $config->read('mysql','psw'),
    $config->read('mysql','db')
);

if(isset($_POST['selection'])){
    if($security->CSRF('verify',$_POST['token'])){
        $r = $db->update('mfa',[
            '2fa_enabled'=>$security->filter($_POST['selection'],Security::FILTER_INT),
            '2fa_method'=>$security->preventXSS($_POST['method'])
        ],[
            'username'=>$users->getCurrentSession()
        ]);
        echo $r ? json_encode(['success'=>true],JSON_UNESCAPED_SLASHES) : json_encode(['success'=>false],JSON_UNESCAPED_SLASHES);
    }else echo json_encode(['success'=>false],JSON_UNESCAPED_SLASHES);
}