<?php
use WebOffice\Security,
WebOffice\Users;
header('Content-Type: application/json; charset=utf-8');
$p = dirname(__DIR__).'/libs';
foreach(array_diff(scandir($p),['.','..']) as $f) if(is_file("$p/$f")) include_once "$p/$f";


$users = new Users();
$security = new Security();

if(isset($_FILES['pfp'])){
    $r = $security->upload($_FILES['pfp'],[
        'maxFileSize'=>2000000,
        'allowedMimeTypes'=>['image/jpeg', 'image/png']
    ]);
    if($r[0]['status'])
        $users->setPfP($security->filter($r[0]['destination'],Security::FILTER_URL));
    echo json_encode(['success'=>$r[0]['status'],'msg'=>$r[0]['msg']],JSON_UNESCAPED_SLASHES);
}