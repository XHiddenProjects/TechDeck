<?php
namespace WebOffice\Security;
use WebOffice\Storage, GdImage, resource, WebOffice\Security;
include_once 'security.lib.php';
(new Security())->sessionStart();
class Captcha{
    private Storage $s;
    private int $width, $height, $length;
    private string $font;
    public string $code;
    /**
     * Summary of __construct
     * @param int $width Width of the captcha
     * @param int $height Height of the captcha
     * @param int $length Length of the captcha
     * @param string $font Font of the captcha
     */
    public function __construct(int $width = 200, int $height = 50, int $length = 8, string $font = ASSETS_PATH.DS.'fonts'.DS. '/arial.ttf') {
        $this->s = new Storage();
        $this->width = $width;
        $this->height = $height;
        $this->length = $length;
        $this->font = $font;
    }
    /**
     * Generates captcha code
     * @return void
     */
    private function generateCode(): void{
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $this->code = '';
        for($i=0;$i<$this->length;$i++)
            $this->code.=$chars[random_int(0,\strlen($chars)-1)];
        $_SESSION['captcha'] = $this->code;
    }
    /**
     * Creates the image
     * @param array<number, number, number> $bg RGB for background
     * @param array<number, number, number> $color RGB for text color
     * @param int $noiseDots Number of dots
     * @param int $noiseLines Number of lines
     * @param array<number, number, number> $noiseColor RGB for noise color
     * @param int $fontSize Font size
     * @param int $spacing Text spacing
     * @return void
     */
    public function create(array $bg=[255,255,255], array $color=[0,0,0], int $noiseDots=1000, int $noiseLines=10, array $noiseColor = [100,100,100], int $fontSize=18, int $spacing=20): void{
        $this->generateCode();
        //Create image
        $img = imagecreatetruecolor($this->width,$this->height);
        $bColor = imagecolorallocate($img,$bg[0],$bg[1],$bg[2]);
        $tColor = imagecolorallocate($img,$color[0],$color[1],$color[2]);
        $nColor = imagecolorallocate($img,$noiseColor[0],$noiseColor[1],$noiseColor[2]);
        imagefilledrectangle($img,0,0,$this->width,$this->height, $bColor);
        //Noise (dots)
        for($i=0;$i<$noiseDots;$i++)
            imagesetpixel($img,rand(0,$this->width), rand(0,$this->height), $nColor);
        //Noise (lines)
        for($i=0;$i<$noiseLines;$i++)
            imageline($img,rand(0,$this->width),rand(0,$this->height),rand(0,$this->width),rand(0,$this->height),$nColor);
        //Add text with distortion
        $angle = rand(-10,10);
        $x = 20;
        $y = $this->height/2 + $fontSize/2;
        // Draw each character with random position and rotation for distortion
        for ($i = 0; $i < \strlen($this->code); $i++) {
            $letter = $this->code[$i];
            $offsetX = $x + $i * $spacing + rand(-5, 5);
            $offsetY = $y + $angle;
            imagettftext($img, $fontSize, $angle, $offsetX, $offsetY, $tColor, $this->font, $letter);
        }
        $distorted = $this->waveDistortion($img, $bg[0], $bg[1], $bg[2]);
        // Output image
        imagepng($distorted,dirname(__DIR__).'/temp/captcha.png');
        imagedestroy($distorted);
        imagedestroy($img);
    }
    private function waveDistortion(bool|GdImage|resource $img, int $r,int $g,int $b): bool|GdImage|resource {
        $w = imagesx($img);
        $h = imagesy($img);
        $dest = imagecreatetruecolor($w, $h);
        // Fill transparent
        imagefill($dest, 0, 0, imagecolorallocate($dest, $r, $g, $b));

        $amplitude = 5;
        $frequency = 0.05;
        for ($x = 0; $x < $w; $x++) {
            $offsetY = (int)($amplitude * sin($x * $frequency));
            for ($y = 0; $y < $h; $y++) {
                $newY = $y + $offsetY;
                if ($newY >= 0 && $newY < $h) {
                    $color = imagecolorat($img, $x, $y);
                    imagesetpixel($dest, $x, $newY, $color);
                }
            }
        }
        return $dest;
    }
    /**
     * Validates the input
     * @param string $input Captcha Input
     * @return bool TRUE if the input matches, else FALSE
     */
    public function validate(string $input): bool {
        $v = $input===$_SESSION['captcha'];
        if($v) return true;
        else return false;
    }
}