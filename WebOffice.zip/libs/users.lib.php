<?php
namespace WebOffice;
use WebOffice\Security, WebOffice\Server, WebOffice\Database, WebOffice\Config, WebOffice\Storage;
use PDO;
class Users{
    private string $user;
    private Security $security;
    private Server $server;
    private Database $database;
    private Storage $storage;
    /**
     * Select the user to get information, else uses the current user
     * @param string $username Username (optional)
     */
    public function __construct(?string $username='') {
        $this->security = new Security();
        $config = new Config();
        $this->database = new Database($config->read('mysql','host'),
    $config->read('mysql','user'),
    $config->read('mysql','psw'),
    $config->read('mysql','db'));
        $this->user = $this->usernameByEmail($username);
        $this->server = new Server();
        $this->storage = new Storage();
    }
    // Get username
    private function usernameByEmail(string $email): string{
        if($this->security->filter($email,Security::FILTER_EMAIL)){
            $u = $this->database->fetch("SELECT * FROM users WHERE email=:email",['email'=>$email],PDO::FETCH_ASSOC);
            return $u['username'];
        }else return $email;
    }
    /**
     * Returns the users IP address
     * @return string IP Address
     */
    public function getIP(): string {
        if ($this->user) {
            $r = $this->database->fetch("SELECT ip_address FROM users WHERE username=:username",['username'=>$this->user],PDO::FETCH_ASSOC);
            return $r['ip_address'];
        } else {
            if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
                // IP from shared internet
                return $this->security->filter($_SERVER['HTTP_CLIENT_IP'], SECURITY::FILTER_IPV4);
            } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                // IP passed through proxies
                $ipList = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
                return $this->security->filter(trim($ipList[0]), SECURITY::FILTER_IPV4); // First IP in the list
            } elseif (!empty($_SERVER['REMOTE_ADDR'])) {
                // Remote IP address
                $remoteIp = $_SERVER['REMOTE_ADDR'];

                // Check if the IP is localhost
                if ($remoteIp === '127.0.0.1' || $remoteIp === '::1') {
                    if (strncasecmp(PHP_OS, 'WIN', 3) === 0) {
                        // Windows
                        $remoteIp = shell_exec('ipconfig');
                        if (preg_match('/IPv4 Address[.\s]*:\s*([\d.]+)/i', $remoteIp, $matches)) {
                            $remoteIp = $matches[1];
                        }
                    } elseif (strncasecmp(PHP_OS, 'DARWIN', 6) === 0 || strncasecmp(PHP_OS, 'Linux', 5) === 0) {
                        // macOS or Linux
                        $remoteIp = shell_exec("ifconfig");
                        if (!$remoteIp) {
                            // fallback for Linux with ip command
                            $remoteIp = shell_exec('ip addr');
                        }
                        ;
                        if (preg_match_all('/inet\s+([\d.]+)\s/', $remoteIp, $matches)) {
                            $remoteIp = preg_replace('/inet\s+/','',$matches[0][count($matches[0])-1]);
                        }
                    }
                    $remoteIp = trim($remoteIp);
                    return $this->security->filter($remoteIp, SECURITY::FILTER_IPV4);
                }
                
                return $this->security->filter($remoteIp, SECURITY::FILTER_IPV4);
            } else {
                return 'UNKNOWN';
            }
        }
    }
    /**
     * Returns the username
     * @return string|null Current or searched username
     */
    public function getUsername(): ?string{
        if($this->user===''){
            if($this->storage->session(name: 'weboffice_auth',action: 'get')||$this->storage->cookie(name: 'weboffice_auth',action:'load'))
                return $this->security->JWT('a-string-secret-at-least-256-bits-long',[],$this->storage->session(name: 'weboffice_auth',action: 'get')??$this->storage->cookie(name: 'weboffice_auth',action:'load'),'decode')['username'];
            else return '';
        }else {
            return $this->database->fetch("SELECT * FROM users WHERE username = :user",['user'=>$this->user])['username']??'';
        }
    }
    /**
     * Returns the users language
     * @param bool $showRegion Shows the region as well
     * @return string
     */
    public function getLanguage(bool $showRegion=false):string{
        if($this->user===''){
            $langs = explode(',', $_SERVER['HTTP_ACCEPT_LANGUAGE']);
            $primary_lang = $langs[0];
            $lang_code = !$showRegion ? substr($primary_lang, 0, 2) : $primary_lang;
            return $lang_code??'';
        }else{
            $r = $this->database->fetch("SELECT * FROM users WHERE username=:username",['username'=>$this->user],PDO::FETCH_ASSOC);
            return $r['language'];
        }
        
    }
    /**
     * Checks if user is admin
     * @return bool TRUE if admin, else FALSE
     */
    public function isAdmin(): bool{
        if($this->user==='')
            return $this->database->fetch("SELECT * FROM users WHERE username='{$this->getUsername()}'")['permissions']==='admin'??false;
        else
            return $this->database->fetch("SELECT * FROM users WHERE username='{$this->user}'")['permissions']==='admin'??false;
    }
    /**
     * Checks if user is member
     * @return bool TRUE if Member, else FALSE
     */
    public function isMember(): bool{
        if($this->user===''){
            return $this->database->fetch("SELECT * FROM users WHERE username='{$this->getUsername()}'")['permissions']==='member'??false;
        }else
            return $this->database->fetch("SELECT * FROM users WHERE username='{$this->user}'")['permissions']==='member'??false;
    }
    /**
     * Checks if user is moderator
     * @return bool TRUE if moderator, else FALSE
     */
    public function isModerator(): bool{
        if($this->user==='')
            return $this->database->fetch("SELECT * FROM users WHERE username='{$this->getUsername()}'")['permissions']==='moderator'??false;
        else
            return $this->database->fetch("SELECT * FROM users WHERE username='{$this->user}'")['permissions']==='moderator'??false;
    }
    /**
     * Lists all users
     * @return array List of users
     */
    public function list():array{
        return $this->database->fetchAll("SELECT username FROM users",[],PDO::FETCH_ASSOC);
    }
    /**
     * Updates the last activity timestamp for a user
     * @param string $username Username
     * @param int $timestamp Unix timestamp
     * @return bool TRUE if updated, else FALSE
     */
    public function getLastActivity(string $username): ?int{
        $result = $this->database->fetch("SELECT last_activity FROM users WHERE username = :username", ['username' => $username], PDO::FETCH_ASSOC);
        return strtotime($result['last_activity']) ?? null;
    }
    /**
     * Returns the location based on IP address
     * @return string[] Location data
     */
    public function getLocation(): array{
        $api = "https://api.findip.net/{$this->getIP()}/?token=f788c0ac0ef548468e060c5eab78dd0a";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $api);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($ch);
        curl_close($ch);
        return json_decode($response, true)??[];
    }
    /**
     * Returns the users ID
     * @return int Users ID
     */
    public function getID(): int{
        $result = $this->database->fetch("SELECT id FROM users WHERE username=:username",['username'=>$this->getUsername()],PDO::FETCH_ASSOC);
        return $result['id']??0;
    }
    /**
     * Returns the user by ID
     * @param int $id Users ID
     * @return string[] users information
     */
    public function getUserByID(int $id): array{
        $result = $this->database->fetch("SELECT id,username,first_name,middle_name,last_name,email,profile_picture,bio,`permissions`,ip_address FROM users WHERE id=:id",['id'=>$id],PDO::FETCH_ASSOC);
        return $result;
    }
    /**
     * Checks if the user has a certain permission
     * @param string $permission Permission to check
     * @return bool TRUE if user has permission, else FALSE
     */
    public function hasPermission(string $permission): bool{
        $userData = $this->database->fetch("SELECT permissions FROM users WHERE username=:username", ['username' => $this->getUsername()], PDO::FETCH_ASSOC);
        if (!$userData) return false;
        $permissions = explode(',', $userData['permissions']);
        return \in_array($permission, $permissions);
    }
    /**
     * Get Users email address
     * @return string Email address
     */
    public function getEmail(): string{
        $result = $this->database->fetch("SELECT email FROM users WHERE username=:username",['username'=>$this->getUsername()],PDO::FETCH_ASSOC);
        return $this->security->filter($result['email'],Security::FILTER_EMAIL);
    }
    /**
     * Returns the users profile picture link
     * @return string pfp URL
     */
    public function getProfilePicture(): string{
        $pfp = $this->database->fetch("SELECT profile_picture FROM users WHERE username=:username",['username'=>$this->getUsername()],PDO::FETCH_ASSOC);
        return $pfp['profile_picture']??ASSETS_URL.DS.'images'.DS.'icons'.DS.'pfp_placeholder.png';
    }
    /**
     * Returns the users phone number
     * @return string Phone number
     */
    public function getPhone(): string{
        $result = $this->database->fetch("SELECT phone FROM users WHERE username=:username",['username'=>$this->getUsername()],PDO::FETCH_ASSOC);
        return $this->security->filter($result['phone']??'',Security::FILTER_PHONE);
    }
    /**
     * Returns the full name
     * @return array{first_name: string, last_name: string, middle_name: string} Parts of the name
     */
    public function getFullName(): array{
        $result = $this->database->fetch("SELECT * FROM users WHERE username=:username",['username'=>$this->getUsername()],PDO::FETCH_ASSOC);
        return ['first_name'=>$result['first_name'],'middle_name'=>$result['middle_name'],'last_name'=>$result['last_name']];
    }
    /**
     * Returns the users online status
     * @return string Online or Offline
     */
    public function getStatus(): string{
        $result = $this->database->fetch("SELECT * FROM users WHERE username=:username",['username'=>$this->getUsername()],PDO::FETCH_ASSOC);
        return $result['status']==='active' ? 'online' : 'offline';
    }
    /**
     * Return the user created account date
     * @return string Date to joined account
     */
    public function joined(): string{
        $result = $this->database->fetch("SELECT * FROM users WHERE username=:username",['username'=>$this->getUsername()],PDO::FETCH_ASSOC);
        return $result['created_at'];
    }
    /**
     * Returns the users last activity
     * @return string Datetime of last activity
     */
    public function lastActive(): string{
        $result = $this->database->fetch("SELECT * FROM users WHERE username=:username",['username'=>$this->getUsername()],PDO::FETCH_ASSOC);
        return $result['last_activity'];
    }
    /**
     * Returns the users Biography
     * @return string
     */
    public function getBio(): string{
        $result = $this->database->fetch("SELECT * FROM users WHERE username=:username",['username'=>$this->getUsername()],PDO::FETCH_ASSOC);
        return $result['bio']??'';
    }
    /**
     * Sets the users profile picture
     * @param string $url Image URL
     * @return void
     */
    public function setPfP(string $url): void{
        $this->database->update('users',[
            'profile_picture'=>$url
        ],['username'=>$this->getUsername()]);
    }
    /**
     * Update a index base on the column name
     * @param array $updates Update array
     * @return int|string
     */
    public function updateProfile(array $updates): int|string{
        return $this->database->update('users',$updates, ['username'=>$this->getUsername()]);
    }
    /**
     * Checks if 2FA has been configured
     * @return bool TRUE if it has been configured, else FALSE
     */
    public function has2FA(): bool{
        $results = $this->database->fetch("SELECT * FROM mfa WHERE username=:username",['username'=>$this->getUsername()],PDO::FETCH_ASSOC);
        if(isset($results)&&$results){
            if(trim($results['2fa_secret'])) return true;
            else return false;
        }else return false;
    }
    /**
     * Verifies the users password
     * @param string $password Password to input
     * @return bool TRUE if the password is matched, else FALSE
     */
    public function checkPassword(string $password): bool{
        $result = $this->database->fetch("SELECT * FROM users WHERE username=:username",['username'=>$this->getUsername()],PDO::FETCH_ASSOC);
        if($result){
            if($this->security->verify($password,$result['password'])) return true;
            else return false;
        }else return false;
    }
    /**
     * Add user to the multi-authentication list
     * @param string $secret Users secret
     * @return void
     */
    public function addMFA(string $secret): void{
        $result = $this->database->fetch("SELECT * FROM mfa WHERE username=:username",['username'=>$this->getUsername()],PDO::FETCH_ASSOC);
        if($result) return;
        else{
            $this->database->insert('mfa',[
                'username'=>$this->getUsername(),
                '2fa_secret'=>$this->security->preventXSS($secret),
                '2fa_enabled'=>0,
                '2fa_method'=>'mail'
            ]);
        }
    }
    /**
     * Get the current session of the user
     * @return mixed|string Current user on sessions
     */
    public function getCurrentSession(): mixed{
        if($this->storage->session(name: 'weboffice_auth',action: 'get')||$this->storage->cookie(name: 'weboffice_auth',action:'load'))
            return $this->security->JWT('a-string-secret-at-least-256-bits-long',[],$this->storage->session(name: 'weboffice_auth',action: 'get')??$this->storage->cookie(name: 'weboffice_auth',action:'load'),'decode')['username'];
        else return '';
    }
    /**
     * Checks if Multi-authentication factor is enabled. This can only be access on the users session
     * @return bool TRUE if MFA is enabled, else false
     */
    public function mfaEnabled(): bool{
        if(hash_equals($this->getCurrentSession(),$this->getUsername())){
            $result = $this->database->fetch("SELECT * FROM mfa WHERE username=:username",['username'=>$this->getUsername()],PDO::FETCH_ASSOC);
            if($result){
                if($result['2fa_enabled']) return true;
                else return false;
            }else return false;
        }return false;
    }
    /**
     * List all the recovery keys
     * @return array
     */
    public function listRecoveryKeys(): array{
        if(hash_equals($this->getCurrentSession(),$this->getUsername())){
            $recovery = $this->database->fetchAll("SELECT * FROM recovery_codes WHERE userId=:userId",['userId'=>$this->getID()],PDO::FETCH_ASSOC);
            return $recovery;
        }else return [];
    }
    /**
     * Reutrns the users Multi-authentication factor method
     * @return string
     */
    public function getMFAMethod():string{
        if(hash_equals($this->getCurrentSession(),$this->getUsername())){
            $method = $this->database->fetch("SELECT * FROM mfa WHERE username=:username",['username'=>$this->getUsername()],PDO::FETCH_ASSOC);
            return $method['2fa_method'];
        }else return 'mail';
    }
    /**
     * List all the enabled methods
     * @return string[]
     */
    public function list2FAMethods(): array{
        if(hash_equals($this->getCurrentSession(),$this->getUsername())){
            $methods = $this->database->fetch("SELECT * FROM mfa WHERE username=:username",['username'=>$this->getUsername()],PDO::FETCH_ASSOC);
            return $methods['methods']?array_filter(explode(',',$methods['methods']),fn($e): bool=>$e!==''):[];
        }else return [];
    }
    /**
     * Checks if user has the method enabled
     * @param string $method Method name
     * @return bool TRUE if it is, else FALSE
     */
    public function has2FAMethodEnabled(string $method): bool{
        if(hash_equals($this->getCurrentSession(),$this->getUsername())){
            $methods = $this->database->fetch("SELECT * FROM mfa WHERE username=:username",['username'=>$this->getUsername()],PDO::FETCH_ASSOC);
            $x = $methods['methods'] ? explode(',',$methods['methods']) : [];
            return \in_array($method,$x);
        }return false;
    }
    /**
     * Adds 2FA method
     * @param string $method 2FA Method
     * @return void
     */
    public function add2FAMethod(string $method): void{
        if(hash_equals($this->getCurrentSession(),$this->getUsername())){
            $results = $this->database->fetch("SELECT * FROM mfa WHERE username=:username",['username'=>$this->getUsername()],PDO::FETCH_ASSOC);
            $currentMethod = $results['2fa_method'];
            $methods = $results['methods'] ? explode(',',$results['methods']):[];
            if(!\in_array($method,$methods)){
                $method = $method ? trim($method) : $method;
                array_push($methods,$method);
                if($currentMethod===''){
                    $this->database->update('mfa',[
                        '2fa_method'=>$method
                    ],['username'=>$this->getUsername()]);
                }
                $this->database->update('mfa',[
                    'methods'=>implode(',',array_filter($methods,fn($e): bool=>$e!=''))
                ],['username'=>$this->getUsername()]);
                return;
            }else return;
        }else return;
    }
    /**
     * Returns the users 2FA Secret
     * @return string
     */
    public function get2FASecret(): string{
        if(hash_equals($this->getCurrentSession(),$this->getUsername())){
            $results = $this->database->fetch("SELECT * FROM mfa WHERE username=:username",['username'=>$this->getUsername()],PDO::FETCH_ASSOC);
            return $results['2fa_secret'];
        }else return '';
    }

}   