<?php
namespace WebOffice;
use DeviceDetector\ClientHints,
DeviceDetector\DeviceDetector,
DeviceDetector\Parser\Device\AbstractDeviceParser,
WebOffice\Utils,
WebOffice\Database,
WebOffice\Config,
WebOffice\Security;
use PDO;
class Device {
    private DeviceDetector $dd;
    private Utils $utils;
    private Database $db;
    private Security $security;
    /**
     * Constructor to initialize DeviceDetector with ClientHints
     * @param string $userAgent User agent string, defaults to $_SERVER['HTTP_USER_AGENT']
     */
    public function __construct(string|null $userAgent = null) {
        $userAgent ??= $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
        AbstractDeviceParser::setVersionTruncation(-1);
        // Initialize DeviceDetector with ClientHints
        $this->dd = new DeviceDetector($userAgent,ClientHints::factory($_SERVER));
        $this->dd->parse();
        $this->utils = new Utils();
        $config = new Config();
        $this->db = new Database(
            $config->read('mysql','host'),
            $config->read('mysql','user'),
            $config->read('mysql','psw'),
            $config->read('mysql','db')
        );
        $this->security = new Security();
    }
    /**
     * Get the device brand
     * @return string Returns the device brand name or an empty string if not detected
     */
    public function deviceBrand(): string {
        return $this->dd->getBrandName();
    }
    /**
     * Get the device model
     * @return string Returns the device model name or an empty string if not detected
     */
    public function deviceModel(): string {
        return $this->dd->getModel();
    }
    /**
     * Check if the device is a specific type (e.g., mobile, tablet, desktop, etc.)
     * @param string $type Type of device to check (default is 'mobile')
     * @return bool Returns true if the device matches the specified type, false otherwise
     */
    public function is(string $type='mobile'): bool {
        $methodName = "is" . ucfirst(strtolower($type));
        return $this->dd->{$methodName}() ?? false;
    }
    /**
     * Get the user agent string
     * @return string Returns the user agent string
     */
    public function getUserAgent(): string {
        return $this->dd->getUserAgent();
    }
    /**
     * Get the client information
     * @param string $attr Attribute to retrieve from the client information (default is empty)
     * @return array|string|null Returns an array containing client information such as browser, version, and type
     */
    public function getClient(string $attr=''): array|string|null {
        return $this->dd->getClient($attr);
    }
    /**
     * Get the operating system information
     * @param string $attr Attribute to retrieve from the operating system information (default is empty)
     * @return array|string|null Returns an array containing OS information such as name, version, and platform
     */
    public function getOs(string $attr=''): array|string|null {
        return $this->dd->getOs($attr);
    }
    /**
     * Returns the users devices manufacturer
     * @return string Manufacturers name
     */
    public function getManufacturer(): string{
        $manufacturer = 'Unknown';
        // Detect OS
        $os = strtoupper($this->getOs('short_name'));

        if (stripos($os, 'LIN') !== false) {
            // Linux - try to read from DMI data
            $output = shell_exec('cat /sys/class/dmi/id/sys_vendor 2>/dev/null');
            if ($output) {
                $manufacturer = trim($output);
            }
        } elseif (stripos($os, 'DAR') !== false) {
            // macOS - no straightforward way, but system_profiler can help
            $output = shell_exec('system_profiler SPHardwareDataType | grep "Manufacturer"');
            $manufacturer = $output ? trim($output) : 'Apple';
        } elseif (stripos($os, 'WIN') !== false) {
            // Windows - use wmic command
            $output = shell_exec('wmic computersystem get manufacturer');
            if ($output) {
                // Parse output
                $lines = preg_split('/\r?\n/', trim($output));
                if (isset($lines[1])) {
                    $manufacturer = trim($lines[1]);
                }
            }
        }
        return $manufacturer;
    }
    /**
     * Get the serial number of the device
     * @param string $device_name Device name
     * @return string Serial Number
     */
    public function getSerial(string $device_name=''): string {
        if($device_name){
            $r = $this->db->fetch("SELECT * FROM devices WHERE name=:name",['name'=>$device_name],PDO::FETCH_ASSOC);
            $serial = $r['serial_number'];
        }else{
            $os = $this->dd->getOs('short_name');
            $serial = null;
            $password = USERS_DESKTOP_PSW; // or get this from a secure place

            if ($os === 'WIN') {
                // Use WMIC command on Windows
                $command = 'wmic bios get serialnumber';
                $output = $this->utils->executeCommand($command, $password);
                if ($output) {
                    // Parse the output
                    $lines = preg_split('/\r?\n/', trim($output));
                    if (isset($lines[1])) {
                        $serial = trim($lines[1]);
                    }
                }
            } elseif ($os === 'DAR') {
                // macOS
                $command = 'system_profiler SPHardwareDataType | grep "Serial Number"';
                $output = $this->utils->executeCommand($command, $password);
                if ($output) {
                    // Output format: "Serial Number (system): XYZ"
                    if (preg_match('/Serial Number.*: (.+)$/', $output, $matches)) {
                        $serial = trim($matches[1]);
                    }
                }
            } elseif ($os === 'LIN') {
                // Linux - try dmidecode (requires root)
                $command = 'dmidecode -s system-serial-number';
                $output = $this->utils->executeCommand($command, $password);
                if ($output) {
                    $serial = trim($output);
                    if (strpos($serial, 'Permission denied') !== false) {
                        $serial = 'Permission denied. Run as root or check permissions.';
                    }
                }
            } else 
                $serial = 'Unsupported OS';
        }
        return $serial ?? 'Serial number not found';
    }
    /**
     * Returns the information of the virtual machine
     * @return array
     */
    public function VM(): array|null {
        $os = PHP_OS_FAMILY; // 'Windows', 'Linux', or 'Darwin' (macOS)
        $vms = [];

        if ($os === 'Windows') {
            // Check if running on Windows
            $vms = array_merge(
                $this->getWindowsVMs(),
                $this->getHyperVVMs()
            );
        } elseif ($os === 'Linux') {
            // Linux platforms
            $vms = array_merge(
                $this->getVirtualBoxVMs(),
                $this->getKVMQEMUVMs(),
            );
        } elseif ($os === 'Darwin') {
            // macOS
            $vms = array_merge(
                $this->getVirtualBoxVMs(),
                $this->getParallelsVMs()
            );
        }

        return $vms;
    }

    /**
     * Get VMs on Windows via PowerShell
     */
    private function getWindowsVMs(): array|null {
        $output = [];
        // Use PowerShell to get Hyper-V VMs
        $cmd = 'powershell -Command "Get-VM | Select-Object Name, State, CPUUsage, MemoryAssigned"';
        exec($cmd, $output);
        return $output;
    }

    /**
     * Get VirtualBox VMs on Linux/Mac
     */
    private function getVirtualBoxVMs(): array {
        $output = [];
        exec('VBoxManage list vms',$output);
        $vms = [];
        foreach ($output as $line) {
            if (preg_match('/^"(.+)" {(.+)}$/', $line, $matches)) {
                $vms[] = [
                    'name' => $matches[1],
                    'uuid' => $matches[2],
                    'platform' => 'VirtualBox'
                ];
            }
        }
        return $vms;
    }

    /**
     * Get KVM/QEMU VMs on Linux
     */
    private function getKVMQEMUVMs(): array {
        $output = [];
        exec('virsh list --all', $output);
        $vms = [];
        foreach ($output as $line) {
            if (preg_match('/^\s*(\d+)?\s*(\S+)\s+(.*?)$/', $line, $matches)) {
                if (is_numeric($matches[1])) {
                    $name = trim($matches[3]);
                    $vms[] = [
                        'name' => $name,
                        'platform' => 'KVM/QEMU'
                    ];
                }
            }
        }
        return $vms;
    }

    /**
     * Get Hyper-V VMs on Windows
     */
    private function getHyperVVMs(): array|null {
        $output = [];
        $cmd = 'powershell -Command "Get-VM | Select-Object Name, State"';
        exec($cmd, $output);
        return $output;
    }

    /**
     * Get Parallels VMs on Mac
     */
    private function getParallelsVMs(): array {
        $output = [];
        exec('prlctl list --all', $output);
        $vms = [];
        foreach ($output as $line) {
            if (!empty($line)) {
                $vms[] = [
                    'name' => trim($line),
                    'platform' => 'Parallels Desktop'
                ];
            }
        }
        return $vms;
    }
    /**
     * Returns the devices name
     * @return string Device name
     */
    public function deviceName(): string {
        $os = strtoupper($this->dd->getOs('short_name'));
        $name = 'Unknown';

        if (stripos($os, 'WIN') !== false) {
            // Windows
            $output = shell_exec('hostname');
            if ($output) {
                $name = trim($output);
            }
        } elseif (stripos($os, 'DAR') !== false) {
            // macOS
            $output = shell_exec('scutil --get ComputerName');
            if ($output) {
                $name = trim($output);
            }
        } elseif (stripos($os, 'LIN') !== false) {
            // Linux
            $output = shell_exec('hostname');
            if ($output) {
                $name = trim($output);
            }
        }

        return $name;
    }
    /**
     * Returns the MAC address of the device
     * @return string MAC address
     */
    public function macAddress(): string {
        $os = strtoupper($this->dd->getOs('short_name'));
        $mac = 'Unknown';
        if (stripos($os, 'WIN') !== false) {
                // Windows
            $output = shell_exec('getmac');
            if ($output) {
                // Extract MAC address from output
                if (preg_match_all('/([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})/', $output, $matches)) {
                    $mac = end($matches[0]);
                }
            }
        } elseif (stripos($os, 'DAR') !== false || stripos($os, 'LIN') !== false) {
            // macOS or Linux
            $output = shell_exec('ifconfig -a');
            if ($output) {
                if (preg_match_all('/([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})/', $output, $matches)) {
                    $mac = end($matches[0]);
                }
            }
        }
        return $mac;
    }
    public function addDevice(string $name='', string $type='', string $brand='', string $model='', string $os='', string $platform='',string $serial='', string $manufacturer='', string $location='', string $ip='', int $purchase_date=0, int $warranty_expiry=0, string $status='', string $asset_tag='', array $history=[], string $notes=''): bool{
        $results = $this->db->fetch('SELECT * FROM devices WHERE serial_number=:serial_number OR asset_tag=:asset_tag',['serial_number'=>$serial, 'asset_tag'=>$asset_tag],PDO::FETCH_ASSOC);
        if(empty($results)){
            $this->db->insert('devices',[
                'name'=>$this->security->preventXSS($name)??$this->deviceName(),
                'type'=>$this->security->preventXSS($type)??($this->is('mobile') ? 'mobile' : ($this->is('tablet') ? 'tablet' : ($this->is('desktop') ? 'desktop' : 'unknown'))),
                'brand'=>$this->security->preventXSS($brand)??$this->deviceBrand(),
                'model'=>$this->security->preventXSS($model)??$this->deviceModel(),
                'os'=>$this->security->preventXSS($os)??$this->getOs('name'),
                'os_platform'=>$this->security->preventXSS($platform)??$this->getOs('platform'),
                'serial_number'=>$this->security->preventXSS($serial)??$this->getSerial(),
                'manufacturer'=>$this->security->preventXSS($manufacturer)??$this->getManufacturer(),
                'device_username'=>$this->getDeviceUsername(),
                'status'=>$this->security->preventXSS($status),
                'purchase_date'=>$purchase_date ? date('Y-m-d H:i:s',$purchase_date) : null,
                'warranty_expiry'=>$warranty_expiry ? date('Y-m-d H:i:s',$warranty_expiry) : null,
                'asset_tag'=>$this->security->sanitize($asset_tag,Security::SANITIZE_STRING),
                'history'=>json_encode($history,JSON_UNESCAPED_SLASHES),
                'notes'=>$this->security->filter(htmlspecialchars($notes),$this->security::FILTER_DEFAULT),
                'ip_address'=>$this->security->filter($ip,Security::FILTER_IPV4),
                'mac_address'=>$this->macAddress(),
                'location'=>htmlspecialchars($location)
            ]);
            return true;
        }else return false;
    }
    /**
     * Fetches the devices information
     * @param array $searchBy Devices base on column name and value
     * @return array|bool Device(s) information
     */
    public function getRegisterDevices(array $searchBy=[]): array|bool{
        if($searchBy&&!empty($searchBy)){
            $conditions = [];
            foreach ($searchBy as $key => $value) $conditions[] = "$key = :$key";
            $whereClause = implode(' OR ', $conditions);
            $query = "SELECT * FROM devices WHERE {$whereClause}";
            return $this->db->fetch($query, $searchBy, PDO::FETCH_ASSOC);
        }else{
            return $this->db->fetchAll("SELECT * FROM devices",[],PDO::FETCH_ASSOC);
        }
    }
    /**
     * Updates the device status
     * @param string $status Status
     * @param string $deviceName Device name
     * @return int|string updated device status
     */
    public function updateStatus(string $status, string $deviceName): int|string{
        return $this->db->update('devices',['status'=>$status],['name'=>$deviceName]);
    }
    /**
     * Checks if the device is activated
     * @param string $name Device Name
     * @return bool TRUE if activated, else FALSE
     */
    public function isActivated(string $name): bool{
        $results = $this->db->fetch("SELECT * FROM devices WHERE name=:name",['name'=>$name],PDO::FETCH_ASSOC);
        return $results['status']==='activated';
    }
    /**
     * Returns the current device username
     * @return bool|string|null
     */
    public function getDeviceUsername(): bool|string|null{
        return shell_exec("python3 ".escapeshellarg(dirname(__DIR__)."/scripts/getDeviceUser.py"));
    }
    /**
     * Checks if the device is registered
     * @param string $device_name Device name
     * @return bool TRUE if the device is registered, else FALSE
     */
    public function isRegistered(string $device_name): bool{
        return $this->db->fetch("SELECT * FROM devices WHERE name=:name",['name'=>$device_name], PDO::FETCH_ASSOC) ? true : false;
    }
}

