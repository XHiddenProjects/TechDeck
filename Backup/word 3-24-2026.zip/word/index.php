<?php
include_once dirname(__DIR__,2).'/init.php';
use TechDeck\Addons;
$addons = new Addons();
?>
<html>
    <head>
        <link rel="stylesheet" href="Word.css">
        
        
        <?=$addons->hook('css');?>
        <title>Word Editor</title>
        <header><h1>Word Editor</h1>
        <form action="/submit_page" method="POST">
            <input type="text" id="docname" name="docname" placeholder="Doc Name" required>
        </form></header>
        <nav class="horizontal" id="options">
            <ul>
                <!--File-->
               <li><div class="dropdown">
                    <button class="dropbtn">File</button>
                    <div class="dropdown-content">
                        <button class="save">Save</button>
                        <button class="save_as">Save As</button>
                        <button class="open">Open</button>
                        <button class="delete">Delete</button>
                        <button class="new">New</button>
                    </div>
                    </div>
                </li>
                <!--Insert-->
               <li><div class="dropdown">
                    <button class="dropbtn">Insert</button>
                    <div class="dropdown-content">
                        <button class="picture">Pictures</button>
                        <button class="tables">Tables</button>
                        <button class="link">Link</button>
                        <button class="symbol">Symbol</button>
                    </div>
                    </div></li>
                <!--Layout-->
               <li><div class="dropdown">
                    <button class="dropbtn">Layout</button>
                    <div class="dropdown-content">
                        <button class="indent">Indent</button>
                        <button class="columns">Columns</button>
                        <button class="size">Size</button>

                    </div>
                    </div></li>
                <!--View-->
               <li><div class="dropdown">
                    <button class="dropbtn">View</button>
                    <div class="dropdown-content">
                        <button class="zoom">Zoom</button>
                        <button class="ruler">Ruler</button>
                    </div>
                    </div></li>
                <!--Example-->
               <!--<li><div class="dropdown">
                    <button class="dropbtn">Title</button>
                    <div class="dropdown-content">
                        <button class="#">X</button>
                        <button class="#">Y</button>
                        <button class="#">Z</button>
                    </div>
                    </div></li>-->
                
            </ul>
        </nav>
    </head>
    <body>
        <div id="editor">
                <!-- Your document content goes here (paragraphs, headings, tables, etc.) -->
                <div class="page" contenteditable="true">
                    <!-- User can type here -->
                </div>

        </div>
        <script src="pagination.js"></script>
    </body>
    <footer><?=$addons->hook('footer');?></footer>
    <?=$addons->hook('scripts');?>
</html>