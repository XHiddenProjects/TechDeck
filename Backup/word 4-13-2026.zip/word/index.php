<?php
include_once dirname(__DIR__,2).'/init.php';
include_once("C:\wamp64\www\TechDeck\libs\data.lib.php");
use TechDeck\Addons;
$addons = new Addons();
?>
<html>
    <head>
        <link rel="stylesheet" href="Word.css">
        
        
        <?=$addons->hook('css');?>
        <title>Word Editor</title>
        <header><h1>Word Editor</h1>
        <form action="/submit_page" method="POST" id="Doc">
            <input type="text" id="docname" name="docname" placeholder="Doc Name" required>
        </form></header>
        <nav class="horizontal" id="options">
            <ul>
                <!--File-->
               <li><div class="dropdown">
                    <button class="dropbtn">File</button>
                    <div class="dropdown-content">
                        <button id="save" form="Doc">Save</button>
                        <button id="save_as" form="Doc">Save As</button>
                        <button id="open" form="Doc">Open</button>
                        <button id="delete" form="Doc">Delete</button>
                        <button id="new" form="Doc">New</button>
                    </div>
                    </div>
                </li>
                <!--Insert-->
               <li><div class="dropdown">
                    <button class="dropbtn">Insert</button>
                    <div class="dropdown-content">
                        <button id="picture">Pictures</button>
                        <button id="tables">Tables</button>
                        <button id="link">Link</button>
                        <button id="symbol">Symbol</button>
                    </div>
                    </div></li>
                <!--Layout-->
               <li><div class="dropdown">
                    <button class="dropbtn">Layout</button>
                    <div class="dropdown-content">
                        <button id="indent">Indent</button>
                        <button id="columns" onclick="document.getElementById('colDialog').showModal()">Columns</button>
                            <dialog id="colDialog">
                                <label>Number of Columns:</label>
                                <select id="Columns">
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    </select>
                                    <br><br>
                                <button id="applyBtn" type="button">Apply</button>
                                <button type="button" id="closeBtn">Cancel</button>
                            </dialog>
                        <button id="size">Size</button>

                    </div>
                    </div></li>
                <!--View-->
               <li><div class="dropdown">
                    <button class="dropbtn">View</button>
                    <div class="dropdown-content">
                        <button id="zoom">Zoom</button>
                        <button id="ruler">Ruler</button>
                    </div>
                    </div></li>
                <!--Example-->
               <!--<li><div class="dropdown">
                    <button class="dropbtn">Title</button>
                    <div class="dropdown-content">
                        <button id="#">X</button>
                        <button id="#">Y</button>
                        <button id="#">Z</button>
                    </div>
                    </div></li>-->
                
            </ul>
        </nav>
    </head>
    <body>
        <div id="editor">
                <!-- Your document content goes here (paragraphs, headings, tables, etc.) -->
                <div class="page" contenteditable="true" form="Doc">
                    <!-- User can type here -->
                </div>

        </div>
        <script src="pagination.js"></script>
        <script src="col.js"></script>
        <script>
            document.addEventListener("keydown", (e) => {
              if (e.key !== "ArrowDown" && e.key !== "ArrowUp") return;

              const selection = window.getSelection();
              if (!selection.rangeCount) return;

              const range = selection.getRangeAt(0);
              const currentPage = range.startContainer.closest(".page");
              if (!currentPage) return;

              // Check if cursor is at top or bottom
              const isAtTop = range.startOffset === 0;
              const isAtBottom = range.endOffset === range.endContainer.length;

              if (e.key === "ArrowDown" && isAtBottom) {
                const nextPage = currentPage.nextElementSibling;
                if (nextPage) {
                  e.preventDefault();
                  moveCursorToStart(nextPage);
                }
              }

              if (e.key === "ArrowUp" && isAtTop) {
                const prevPage = currentPage.previousElementSibling;
                if (prevPage) {
                  e.preventDefault();
                  moveCursorToEnd(prevPage);
                }
              }
            });

            function moveCursorToStart(el) {
              el.focus();
              const range = document.createRange();
              range.selectNodeContents(el);
              range.collapse(true);

          const sel = window.getSelection();
              sel.removeAllRanges();
              sel.addRange(range);
            }

            function moveCursorToEnd(el) {
          el.focus();
          const range = document.createRange();
          range.selectNodeContents(el);
          range.collapse(false);

          const sel = window.getSelection();
          sel.removeAllRanges();
          sel.addRange(range);
            }
        </script>
    </body>
    <footer><?=$addons->hook('footer');?></footer>
    <?=$addons->hook('scripts');?>
</html>