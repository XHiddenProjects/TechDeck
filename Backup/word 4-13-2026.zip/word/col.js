// Get elements
const colDialog = document.getElementById("colDialog");
const applyBtn = document.getElementById("applyBtn");
const closeBtn = document.getElementById("closeBtn");
const columnsSelect = document.getElementById("Columns");
const pages = document.querySelectorAll(".page");

// Apply selected columns to all pages
applyBtn.addEventListener("click", () => {
    const numCols = columnsSelect.value;
    pages.forEach(page => {
        page.style.columnCount = numCols;
        page.style.columnGap = "20px"; // optional: gap between columns
    });
    colDialog.close();
});

// Close dialog without changes
closeBtn.addEventListener("click", () => {
    colDialog.close();
});