document.addEventListener("DOMContentLoaded", () => {
  const editor = document.getElementById("editor");

  function createPage() {
    const page = document.createElement("div");
    page.className = "page";
    page.contentEditable = true;
    editor.appendChild(page);
    return page;
  }

  function isEmpty(page) {
    return page.innerText.trim() === "";
  }

  function checkOverflow(page) {
    // small tolerance fixes false overflow
    const OVERFLOW_BUFFER = 2;

    if (page.scrollHeight <= page.clientHeight + OVERFLOW_BUFFER) return;

    // Only create next page if there's real content
    if (isEmpty(page)) return;

    let next = page.nextElementSibling;
    if (!next) next = createPage();

    while (page.scrollHeight > page.clientHeight + OVERFLOW_BUFFER) {
      let text = page.innerText;
      if (!text.length) break;

      const lastChar = text.slice(-1);
      page.innerText = text.slice(0, -1);
      next.innerText = lastChar + next.innerText;
    }

    checkOverflow(next);
  }

  function cleanupPages() {
    const pages = document.querySelectorAll(".page");

    pages.forEach((page, index) => {
      // Keep first page always
      if (index === 0) return;

      // Remove empty pages
      if (isEmpty(page)) {
        page.remove();
      }
    });
  }

  editor.addEventListener("input", () => {
    requestAnimationFrame(() => {
      const pages = document.querySelectorAll(".page");

      pages.forEach(page => checkOverflow(page));

      // Clean empty pages AFTER overflow handling
      cleanupPages();
    });
  });
});