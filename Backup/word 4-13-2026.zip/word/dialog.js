const openDialogBtn = document.getElementById('column');
const selectionDialog = document.getElementById('selection-dialog');
const cancelBtn = document.getElementById('cancel-btn');
const selectionForm = document.getElementById('selection-form');
const outputMessage = document.getElementById('output-message');

// Function to open the modal dialog
openDialogBtn.addEventListener('click', () => {
    // showModal() makes the dialog modal (prevents interaction with the rest of the page)
    selectionDialog.showModal();
});

// Function to close the dialog via the "Cancel" button
cancelBtn.addEventListener('click', () => {
    selectionDialog.close();
});

// Handle the form submission when the "Submit" button is clicked
selectionForm.addEventListener('submit', (event) => {
    // The 'submit' event fires when the form's submit button is clicked.
    // The 'method="dialog"' attribute handles closing the dialog automatically.

    const dropdown = document.getElementById('options-dropdown');
    const selectedValue = dropdown.value;
    const selectedText = dropdown.options[dropdown.selectedIndex].text;

    outputMessage.textContent = `Submitted value: ${selectedValue} (Text: ${selectedText})`;
});

// Optional: Close the dialog if the backdrop is clicked
selectionDialog.addEventListener('click', (event) => {
    const dialogDimensions = selectionDialog.getBoundingClientRect();
    if (
        event.clientX < dialogDimensions.left ||
        event.clientX > dialogDimensions.right ||
        event.clientY < dialogDimensions.top ||
        event.clientY > dialogDimensions.bottom
    ) {
        selectionDialog.close();
    }
});
