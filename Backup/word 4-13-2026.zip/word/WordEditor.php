<html>
    <head>
        <link rel="stylesheet" href="Word.css">
        <title>Word Editor</title>
        <header><h1>Word Editor</h1></header>
        <nav class="horizontal" id="options">
            <ul>
               <li>File</li>
                
                
               <li>Insert</li>
               <li>Layout</li>
               <li>View</li>
               <li>e</li>
               <li>f</li>
               <li>g</li>
            </ul>
        </nav>
    </head>
    <body>
        <div class="container">
            <textarea rows="100" cols="80"></textarea>
        </div>
    </body>
    <footer>
        WIP
    </footer>
</html>