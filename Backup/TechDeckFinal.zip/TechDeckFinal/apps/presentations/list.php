<?php
ob_start();
if (session_status() === PHP_SESSION_NONE) session_start();
ob_end_clean();
 
header('Content-Type: application/json');
 
$dir = __DIR__ . '/presentations/';
if (!is_dir($dir)) {
    echo json_encode([]);
    exit;
}
 
$presentations = [];
foreach (glob($dir . '*.json') as $file) {
    $meta = json_decode(file_get_contents($file), true);
    if ($meta && isset($meta['id'], $meta['name'], $meta['updated'])) {
        $presentations[] = $meta;
    }
}
 
usort($presentations, function($a, $b) {
    return strcmp($b['updated'], $a['updated']);
});
 
echo json_encode($presentations);
