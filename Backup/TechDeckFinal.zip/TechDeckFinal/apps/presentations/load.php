<?php
ob_start();
if (session_status() === PHP_SESSION_NONE) session_start();
ob_end_clean();
 
$id   = preg_replace('/[^a-z0-9_-]/i', '', $_GET['id'] ?? '');
$file = __DIR__ . '/presentations/' . $id . '.xml';
 
if (!$id || !file_exists($file)) {
    http_response_code(404);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Presentation not found']);
    exit;
}
 
header('Content-Type: application/xml; charset=UTF-8');
readfile($file);