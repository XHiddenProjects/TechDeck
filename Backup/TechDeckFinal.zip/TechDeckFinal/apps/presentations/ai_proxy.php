<?php
ob_start();
if (session_status() === PHP_SESSION_NONE) session_start();
include_once dirname(__DIR__, 2).'/init.php';
ob_end_clean();

header('Content-Type: application/json');

$body = file_get_contents('php://input');

$ch = curl_init('https://api.groq.com/openai/v1/chat/completions');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . AI_API_KEY
]);

$response = curl_exec($ch);

if (curl_errno($ch)) {
    http_response_code(500);
    echo json_encode(['error' => ['message' => curl_error($ch)]]);
} else {
    echo $response;
}

curl_close($ch);