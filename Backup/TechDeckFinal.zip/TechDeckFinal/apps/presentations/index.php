<?php
include_once dirname(__DIR__, 2).'/init.php';
?>

<!doctype = "html">
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Presentations</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
        <link href="gui.css" rel="stylesheet">
    </head>
<body>
    <script src="https://unpkg.com/jspdf@latest/dist/jspdf.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/pptxgenjs@3.12.0/dist/pptxgen.bundle.js"></script>

<script>

var slideData = [];
var slideDataIndex = 0;
var currentSlide = null;
var currentItem = null;
var currentItemData = null;
var currentPresentationId   = null;
var currentPresentationName = 'Untitled';

var defaultFontSize = {
    title: 32,
    body:  16,
    text:  16,
    video: 0
};

var layouts = {
    "title-only": function(w, h) {
        return [{ type: "title", text: "", x: 80, y: 150, width: w - 160 }];
    },
    "title-body": function(w, h) {
        return [
            { type: "title", text: "", x: 80, y: 40,  width: w - 160 },
            { type: "body",  text: "", x: 80, y: 150, width: w - 160, height: h - 190 }
        ];
    },
    "title-two-col": function(w, h) {
        var colW = Math.round((w - 200) / 2);
        return [
            { type: "title", text: "", x: 80, y: 40,  width: w - 160 },
            { type: "body",  text: "", x: 80, y: 150, width: colW, height: h - 190 },
            { type: "body",  text: "", x: 100 + colW,  y: 150, width: colW, height: h - 190 }
        ];
    },
    "blank": function() {
        return [];
    }
};

function applyLayout(layoutKey) {
    var mainSlide = document.getElementById("mainSlide");
    var w = mainSlide.offsetWidth  || 800;
    var h = mainSlide.offsetHeight || Math.round(w * 9/16);
    var factory = layouts[layoutKey];
    if (!factory) return;
    slideData[slideDataIndex].items = factory(w, h);
    renderSlide(slideDataIndex);
    updatePreview(slideDataIndex);
    saveSlideData();
}

document.addEventListener("DOMContentLoaded", function() {
    var startCon = document.getElementById("slidesList");
    var startBox = document.createElement("div");
    startBox.id = "preview" + slideDataIndex;
    startBox.className = "preview ratio ratio-16x9 w-75 bg-light shadow";
    startBox.style.maxWidth = "400px";
    startBox.dataset.index = slideDataIndex;
    startBox.oncontextmenu = function(e) { showSlideMenu(e, this); };
    startCon.appendChild(startBox);

    var urlId = new URLSearchParams(location.search).get('id');
    if (urlId) {
        loadFromXML(urlId, '');
    } else {
        var saved = null;
        try { saved = JSON.parse(localStorage.getItem('slideData')); } catch(e) {}
        if (saved && Array.isArray(saved) && saved.length > 0) {
            slideData = saved;
            currentPresentationId   = localStorage.getItem('presId')   || null;
            currentPresentationName = localStorage.getItem('presName') || 'Untitled';
            updatePresName(currentPresentationName);
            var container = document.getElementById('slidesList');
            slideData.forEach(function(_, i) {
                if (i === 0) {
                    startBox.dataset.index = 0;
                } else {
                    var s = startBox.cloneNode(true);
                    s.id = 'preview' + i;
                    s.dataset.index = i;
                    s.innerHTML = '';
                    s.oncontextmenu = function(e) { showSlideMenu(e, this); };
                    container.appendChild(s);
                }
            });
            slideDataIndex = 0;
            renderSlide(0);
            slideData.forEach(function(_, i) { updatePreview(i); });
        } else {
            slideData[slideDataIndex] = { items: [], background: '' };
            createSlideLayout();
        }
    }

    slideNum();

    document.getElementById("addslide").addEventListener("click", function() {
        var container = document.getElementById("slidesList");
        var newSlide = startBox.cloneNode(true);
        newSlide.id = "preview" + slideData.length;
        var index = slideData.length;
        newSlide.dataset.index = index;
        newSlide.oncontextmenu = function(e) { showSlideMenu(e, this); };
        newSlide.innerHTML = "";
        container.appendChild(newSlide);
        slideData.push({items: [], background: ''});
        slideDataIndex = index;
        container.scrollTo(0, container.scrollHeight);
        slideNum();
        createSlideLayout();
        saveSlideData();
    });

    document.getElementById('mainSlide').addEventListener('pointerdown', function(e) {
        if (e.target === this) {
            document.querySelectorAll('#mainSlide .slide-item-selected')
                .forEach(function(el) { el.classList.remove('slide-item-selected'); });
        }
    });

    var slidesList = document.getElementById('slidesList');
    slidesList.addEventListener('click', function(e) {
        var preview = e.target.closest('.preview');
        if (!preview) return;
        var index = parseInt(preview.dataset.index, 10);
        if (isNaN(index)) return;
        saveSlideData();
        slideDataIndex = index;
        loadSlide(index);
        selectPreview(index);
    });

    var colorChoice = document.getElementById('colorChoice');
    if (colorChoice) {
        colorChoice.addEventListener('input', function() {
            if (!currentItem) return;
            var col = this.value;
            var textEl = currentItem.querySelector('.slide-input, .slide-textarea');
            if (textEl) textEl.style.color = col;
            if (currentItemData) currentItemData.color = col;
            updatePreview(slideDataIndex);
            saveSlideData();
        });
    }

    var bgInput = document.getElementById('bgcolor');
    if (bgInput) {
        bgInput.addEventListener('input', function() {
            changeBackgroundColor(this.value);
        });
        var mainSlideEl = document.getElementById('mainSlide');
        if (mainSlideEl && bgInput.value) mainSlideEl.style.backgroundColor = bgInput.value;
    }
});

function createSlideLayout() {
    var slide = slideData[slideDataIndex];
    slide.items = [];
    var mainSlide = document.getElementById('mainSlide');
    mainSlide.style.removeProperty('background-color');
    var bgInput = document.getElementById('bgcolor');
    if (bgInput) bgInput.value = '#ffffff';
    if (slideDataIndex === 0) {
        slide.items.push({ type: "title", text: "", x: 100, y: 150, width: 600 });
    } else {
        slide.items.push({ type: "title", text: "", x: 80, y: 40, width: 600 });
        slide.items.push({ type: "body",  text: "", x: 80, y: 150, width: 600 });
    }
    renderSlide(slideDataIndex);
    updatePreview(slideDataIndex);
}

function selectPreview(index) {
    var previews = document.querySelectorAll('#slidesList .preview');
    previews.forEach(function(p) { p.classList.remove('selected'); });
    var target = document.querySelector("#slidesList .preview[data-index='" + index + "']");
    if (target) target.classList.add('selected');
    saveSlideData();
}

function changeBackgroundColor(color) {
    var mainSlide = document.getElementById("mainSlide");
    if (mainSlide) mainSlide.style.setProperty('background-color', color, 'important');
    try { if (slideData[slideDataIndex]) slideData[slideDataIndex].background = color; } catch (err) {}
    renderSlide(slideDataIndex);
    updatePreview(slideDataIndex);
    saveSlideData();
}

function slideNum() {
    document.querySelectorAll("#slidesList .preview").forEach(function(slide, num) {
        slide.setAttribute("count", num + 1);
    });
}

function createTextBox() {
    var item = { type: "body", text: "", x: 50, y: 50, width: 300, height: 50 };
    slideData[slideDataIndex].items.push(item);
    renderSlide(slideDataIndex);
    updatePreview(slideDataIndex);
}

var _insertCallback = null;

function openMediaModal(callback) {
    _insertCallback = callback;
    document.getElementById('mediaModal').style.display = 'flex';
    document.getElementById('mediaUrlInput').value = '';
    document.getElementById('mediaFileInput').value = '';
    document.getElementById('mediaUrlPreview').textContent = '';
    switchMediaTab('link');
}

function closeMediaModal() {
    document.getElementById('mediaModal').style.display = 'none';
    _insertCallback = null;
}

function switchMediaTab(tab) {
    ['link','file'].forEach(function(t) {
        document.getElementById('mediaTab-' + t).classList.toggle('active', t === tab);
        document.getElementById('mediaPanel-' + t).classList.toggle('d-none', t !== tab);
    });
}

function confirmMediaInsert() {
    var activeTab = document.querySelector('#mediaModal .media-tab.active').dataset.tab;
    if (activeTab === 'link') {
        var url = document.getElementById('mediaUrlInput').value.trim();
        if (!url) return;
        if (!/^https?:\/\//i.test(url)) { alert('Please enter a full URL starting with https://'); return; }
        if (_insertCallback) _insertCallback({ type: 'url', src: url });
    } else {
        var file = document.getElementById('mediaFileInput').files[0];
        if (!file) return;
        var reader = new FileReader();
        reader.onload = function(e) {
            if (_insertCallback) _insertCallback({ type: 'local', src: e.target.result, mime: file.type });
        };
        reader.readAsDataURL(file);
        closeMediaModal();
        return;
    }
    closeMediaModal();
}

window._localMediaStore = window._localMediaStore || {};
var _localMediaCounter = 0;

function insertVideo() {
    openMediaModal(function(result) {
        var src = result.src;
        if (result.type === 'local') {
            var key = 'local:' + (++_localMediaCounter);
            window._localMediaStore[key] = src;
            src = key;
        }
        var item = { type: 'video', src: src, mime: result.mime || null, x: 50, y: 50, width: 320, height: 180 };
        slideData[slideDataIndex].items.push(item);
        renderSlide(slideDataIndex);
        updatePreview(slideDataIndex);
        saveSlideData();
    });
}

function saveSlideData() {
    updatePreview(slideDataIndex);
    try {
        localStorage.setItem('slideData', JSON.stringify(slideData));
    } catch (err) {
        console.warn('Could not save to localStorage:', err);
    }
}

function showSlideMenu(event, slide) {
    event.preventDefault();
    currentSlide = slide;
    var menu = document.getElementById("slideMenu");
    menu.style.top = event.pageY + "px";
    menu.style.left = event.pageX + "px";
    menu.classList.remove("d-none");
}

function showItemMenu(event, item) {
    event.preventDefault();
    currentItem = item;
    currentItemData = null;
    var menu = document.getElementById("itemMenu");
    menu.style.top = event.pageY + "px";
    menu.style.left = event.pageX + "px";
    menu.classList.remove("d-none");
}

function showTextMenu(event, text) {
    event.preventDefault();
    currentItem = text;
    var menu = document.getElementById("textMenu");
    menu.style.zIndex = 20;
    menu.style.top = event.pageY + "px";
    menu.style.left = event.pageX + "px";
    menu.classList.remove("d-none");
    var picker = document.getElementById('colorChoice');
    if (picker) picker.value = (currentItemData && currentItemData.color) ? currentItemData.color : '#000000';
    var fontSelect = document.getElementById('fontSelect');
    if (fontSelect) {
        fontSelect.value = (currentItemData && currentItemData.font) ? currentItemData.font : fontSelect.value;
        fontSelect.onchange = function() {
            var f = this.value;
            if (currentItemData) currentItemData.font = f;
            var textEl = currentItem.querySelector('.slide-input, .slide-textarea');
            if (textEl) textEl.style.fontFamily = f;
            updatePreview(slideDataIndex);
            saveSlideData();
        };
    }
    var sizeSelect = document.getElementById('sizeSelect');
    if (sizeSelect) {
        var storedSize = currentItemData && currentItemData.fontSize;
        if (storedSize) {
            sizeSelect.value = (String(storedSize).includes("px")) ? storedSize : storedSize + "px";
        } else {
            sizeSelect.value = (defaultFontSize[currentItemData && currentItemData.type] || 16) + "px";
        }
        sizeSelect.onchange = function() {
            var s = this.value;
            if (currentItemData) currentItemData.fontSize = s;
            var textEl = currentItem.querySelector('.slide-input, .slide-textarea');
            if (textEl) textEl.style.fontSize = s;
            updatePreview(slideDataIndex);
            saveSlideData();
        };
    }
    var alignSelect = document.getElementById('alignSelect');
    if (alignSelect) {
        alignSelect.value = (currentItemData && currentItemData.alignment) ? currentItemData.alignment : alignSelect.value;
        alignSelect.onchange = function() {
            var a = this.value;
            if (currentItemData) currentItemData.alignment = a;
            var textEl = currentItem.querySelector('.slide-input, .slide-textarea');
            if (textEl) textEl.style.textAlign = a;
            updatePreview(slideDataIndex);
            saveSlideData();
        };
    }
}

document.addEventListener("click", function(e) {
    var slideMenu = document.getElementById("slideMenu");
    var itemMenu  = document.getElementById("itemMenu");
    var textMenu  = document.getElementById("textMenu");
    if ((slideMenu && slideMenu.contains(e.target)) ||
        (itemMenu  && itemMenu.contains(e.target))  ||
        (textMenu  && textMenu.contains(e.target))) return;
    if (slideMenu) slideMenu.classList.add("d-none");
    if (itemMenu)  itemMenu.classList.add("d-none");
    if (textMenu)  textMenu.classList.add("d-none");
});

function deleteSlide() {
    var index = parseInt(currentSlide.dataset.index, 10);
    slideData.splice(index, 1);
    currentSlide.remove();
    document.querySelectorAll("#slidesList .preview").forEach(function(element, i) {
        element.dataset.index = i;
        element.id = "preview" + i;
    });
    slideDataIndex = Math.min(index, slideData.length - 1);
    loadSlide(slideDataIndex);
    slideNum();
    saveSlideData();
}

function deleteItem() {
    var items = slideData[slideDataIndex].items;
    var index = parseInt(currentItem.dataset.itemIndex, 10);
    if (!isNaN(index)) items.splice(index, 1);
    currentItem.remove();
    currentItem = null;
    renderSlide(slideDataIndex);
    updatePreview(slideDataIndex);
    saveSlideData();
    document.getElementById('itemMenu').classList.add('d-none');
    document.getElementById('textMenu').classList.add('d-none');
}

function duplicateItem() {
    var box = currentItem;
    var items = slideData[slideDataIndex].items;
    var srcItem = null;
    if (box.__itemRef) srcItem = box.__itemRef;
    else if (box.dataset && box.dataset.itemIndex !== undefined) {
        var digit = parseInt(box.dataset.itemIndex, 10);
        if (!isNaN(digit)) srcItem = items[digit];
    }
    if (srcItem) {
        var newItem = JSON.parse(JSON.stringify(srcItem));
        newItem.x = (newItem.x || 0) + 10;
        newItem.y = (newItem.y || 0) + 10;
        items.splice(items.indexOf(srcItem) + 1, 0, newItem);
    }
    document.getElementById('itemMenu').classList.add('d-none');
    document.getElementById('textMenu').classList.add('d-none');
    currentItem = null;
    renderSlide(slideDataIndex);
    updatePreview(slideDataIndex);
    saveSlideData();
}

function loadSlide(index) {
    slideDataIndex = index;
    renderSlide(index);
    selectPreview(index);
}

function duplicateSlide() {
    if (!currentSlide) return;
    var container = document.getElementById("slidesList");
    var sourceIndex = parseInt(currentSlide.dataset.index);
    var newIndex = slideData.length;
    var clone = currentSlide.cloneNode(true);
    clone.id = "preview" + newIndex;
    clone.dataset.index = newIndex;
    clone.oncontextmenu = function(e) { showSlideMenu(e, this); };
    clone.addEventListener('click', function() {
        saveSlideData();
        slideDataIndex = newIndex;
        renderSlide(newIndex);
        selectPreview(newIndex);
    });
    container.appendChild(clone);
    slideData.push(JSON.parse(JSON.stringify(slideData[sourceIndex])));
    slideDataIndex = newIndex;
    container.scrollTo(0, container.scrollHeight);
    slideNum();
    selectPreview(newIndex);
}

function snap(position, gridSize) {
    gridSize = gridSize || 5;
    return Math.round(position / gridSize) * gridSize;
}

function dragElement(element, head, container) {
    var posX = 0, posY = 0, pointerId = null;

    function getClientCoords(e) {
        if (e.clientX !== undefined) return { x: e.clientX, y: e.clientY };
        if (e.touches && e.touches[0]) return { x: e.touches[0].clientX, y: e.touches[0].clientY };
        return { x: 0, y: 0 };
    }

    function startDrag(e) {
        e.preventDefault();
        var coords = getClientCoords(e);
        var containerRect = container.getBoundingClientRect();
        var left = element.offsetLeft;
        var top  = element.offsetTop;
        element.style.left = left + 'px';
        element.style.top  = top  + 'px';
        posX = coords.x - containerRect.left - left;
        posY = coords.y - containerRect.top  - top;
        if (e.pointerId && head && head.setPointerCapture) {
            pointerId = e.pointerId;
            head.setPointerCapture(pointerId);
        }
        document.addEventListener('pointermove', elementDrag);
        document.addEventListener('pointerup', endDrag);
    }

    function elementDrag(e) {
        var coords = getClientCoords(e);
        var containerRect = container.getBoundingClientRect();
        var newX = coords.x - containerRect.left - posX;
        var newY = coords.y - containerRect.top  - posY;
        var boundX = container.clientWidth  - element.offsetWidth;
        var boundY = container.clientHeight - element.offsetHeight;
        element.style.left = (Math.max(0, Math.min(snap(newX), boundX))) + "px";
        element.style.top  = (Math.max(0, Math.min(snap(newY), boundY))) + "px";
    }

    function endDrag() {
        document.removeEventListener('pointermove', elementDrag);
        document.removeEventListener('pointerup', endDrag);
        if (pointerId && head && head.releasePointerCapture) {
            try { head.releasePointerCapture(pointerId); } catch (err) {}
            pointerId = null;
        }
        saveSlideData();
    }

    if (!element.classList.contains('move-only')) {
        head.addEventListener('pointerdown', startDrag);
    }
}

var movingElement = null;
var movePosX = 0, movePosY = 0;
var movePointerId = null;

function startMoveMode(element, startEvent) {
    if (!element) return;
    var container = document.getElementById('mainSlide');
    movingElement = element;
    element.classList.add('moving');
    element.style.width  = element.offsetWidth  + 'px';
    element.style.height = element.offsetHeight + 'px';
    var containerRect = container.getBoundingClientRect();
    var rect = element.getBoundingClientRect();
    if (startEvent) {
        var x = (startEvent.clientX !== undefined) ? startEvent.clientX : (startEvent.touches && startEvent.touches[0] && startEvent.touches[0].clientX) || 0;
        var y = (startEvent.clientY !== undefined) ? startEvent.clientY : (startEvent.touches && startEvent.touches[0] && startEvent.touches[0].clientY) || 0;
        movePosX = x - containerRect.left - (parseFloat(element.style.left) || (rect.left - containerRect.left));
        movePosY = y - containerRect.top  - (parseFloat(element.style.top)  || (rect.top  - containerRect.top));
        if (startEvent.pointerId && element.setPointerCapture) {
            movePointerId = startEvent.pointerId;
            try { element.setPointerCapture(movePointerId); } catch (err) {}
        }
    } else {
        movePosX = Math.round(element.offsetWidth  / 2);
        movePosY = Math.round(element.offsetHeight / 2);
    }
    document.addEventListener('pointermove', moveModePointer);
    document.addEventListener('pointerup', stopMoveMode);
}

function moveModePointer(e) {
    if (!movingElement) return;
    var container = document.getElementById('mainSlide');
    var containerRect = container.getBoundingClientRect();
    var newX = e.clientX - containerRect.left - movePosX;
    var newY = e.clientY - containerRect.top  - movePosY;
    var boundX = container.clientWidth  - movingElement.offsetWidth;
    var boundY = container.clientHeight - movingElement.offsetHeight;
    movingElement.style.left = (Math.max(0, Math.min(snap(newX), boundX))) + 'px';
    movingElement.style.top  = (Math.max(0, Math.min(snap(newY), boundY))) + 'px';
}

function stopMoveMode() {
    if (!movingElement) return;
    document.removeEventListener('pointermove', moveModePointer);
    document.removeEventListener('pointerup', stopMoveMode);
    if (movePointerId && movingElement.releasePointerCapture) {
        try { movingElement.releasePointerCapture(movePointerId); } catch (err) {}
        movePointerId = null;
    }
    try {
        var idx = parseInt(movingElement.dataset.itemIndex, 10);
        if (!isNaN(idx) && slideData[slideDataIndex].items[idx]) {
            var it = slideData[slideDataIndex].items[idx];
            movingElement.style.width  = (it.width  || 300) + 'px';
            movingElement.style.height = (it.height || 50)  + 'px';
        }
    } catch (err) {}
    movingElement.classList.remove('moving');
    movingElement = null;
    saveSlideData();
}

function syncBoxHeight(box, contentEl, item, index) {
    var minH = item.type === "title" ? 50 : 80;
    var clone = contentEl.cloneNode(true);
    clone.style.cssText  = contentEl.style.cssText;
    clone.style.position = "absolute";
    clone.style.visibility = "hidden";
    clone.style.height   = "auto";
    clone.style.width    = contentEl.offsetWidth + "px";
    document.body.appendChild(clone);
    var naturalH = clone.scrollHeight;
    document.body.removeChild(clone);
    var newH = Math.max(minH, naturalH + 30);
    if (newH === parseInt(box.style.height)) return;
    box.style.height = newH + "px";
    item.height = newH;
    updatePreview(index);
}

function addResizeHandles(box, item, index) {
    var directions = ['n','s','e','w','ne','nw','se','sw'];
    directions.forEach(function(dir) {
        var handle = document.createElement('div');
        handle.className = 'resize-handle ' + dir;
        box.appendChild(handle);
        var startX, startY, startW, startH, startL, startT;
        handle.addEventListener('pointerdown', function(e) {
            e.stopPropagation();
            e.preventDefault();
            handle.setPointerCapture(e.pointerId);
            startX = e.clientX; startY = e.clientY;
            startW = box.offsetWidth; startH = box.offsetHeight;
            startL = parseInt(box.style.left) || item.x;
            startT = parseInt(box.style.top)  || item.y;
            function onMove(ev) {
                var dx = ev.clientX - startX;
                var dy = ev.clientY - startY;
                var newW = startW, newH = startH, newL = startL, newT = startT;
                if (dir.includes('e'))  newW = Math.max(80, snap(startW + dx));
                if (dir.includes('s'))  newH = Math.max(40, snap(startH + dy));
                if (dir.includes('w')) { newW = Math.max(80, snap(startW - dx)); newL = snap(startL + startW - newW); }
                if (dir.includes('n')) { newH = Math.max(40, snap(startH - dy)); newT = snap(startT + startH - newH); }
                box.style.width  = newW + 'px'; box.style.height = newH + 'px';
                box.style.left   = newL + 'px'; box.style.top    = newT + 'px';
                item.width = newW; item.height = newH; item.x = newL; item.y = newT;
                updatePreview(index);
            }
            function onUp() {
                handle.removeEventListener('pointermove', onMove);
                handle.removeEventListener('pointerup', onUp);
                saveSlideData();
            }
            handle.addEventListener('pointermove', onMove);
            handle.addEventListener('pointerup', onUp);
        });
    });
}

function renderSlide(index) {
    var main = document.getElementById("mainSlide");
    main.innerHTML = "";
    var s = slideData[index];
    if (s && s.background) {
        main.style.setProperty('background-color', s.background, 'important');
    } else {
        main.style.removeProperty('background-color');
    }
    var slide = slideData[index];
    if (!slide || !slide.items) return;

    slide.items.forEach(function(item, i) {
        var box = document.createElement("div");
        box.className = "position-absolute " + item.type + "-box move-only";
        box.style.left      = item.x + "px";
        box.style.top       = item.y + "px";
        box.style.width     = (item.width  || 300) + "px";
        box.style.height    = (item.height || (item.type === 'video' ? 200 : 50)) + "px";
        box.style.zIndex    = 10;
        box.style.boxSizing = 'border-box';
        box.style.overflow  = 'hidden';
        box.style.paddingTop = '26px';
        box.dataset.itemIndex = i;

        if (item.type === 'title' || item.type === 'text' || item.type === 'body') {
            box.oncontextmenu = (function(it) {
                return function(e) { currentItemData = it; showTextMenu(e, box); };
            }(item));
        }
        if (item.type === 'video') {
            box.oncontextmenu = (function(it) {
                return function(e) { e.preventDefault(); currentItem = box; currentItemData = it; showItemMenu(e, box); };
            }(item));
        }

        var header = document.createElement("div");
        if      (item.type === "title") header.className = 'titlebox-header';
        else if (item.type === "body")  header.className = 'bodybox-header';
        else if (item.type === "text")  header.className = 'textbox-header';
        else if (item.type === "video") header.className = 'videobox-header';

        if (item.type === "title" || item.type === "text") {
            var input = document.createElement("div");
            input.className = "slide-input";
            input.contentEditable = "true";
            input.innerText = item.text;
            input.dataset.placeholder = "Click to edit title";
            input.style.cssText = "width:100%;height:100%;outline:none;cursor:text;word-break:break-word;white-space:pre-wrap;font-weight:normal;";
            if (item.alignment) input.style.textAlign = item.alignment;
            else if (slideDataIndex === 0) { input.style.textAlign = "center"; item.alignment = "center"; }
            if (item.color)    input.style.color      = item.color;
            if (item.font)     input.style.fontFamily = item.font;
            if (item.fontSize) input.style.fontSize   = item.fontSize;
            input.addEventListener("input", (function(it) {
                return function() {
                    it.text = input.innerText;
                    requestAnimationFrame(function() { syncBoxHeight(box, input, it, index); });
                    updatePreview(index);
                };
            }(item)));
            requestAnimationFrame(function() { syncBoxHeight(box, input, item, index); });
            var controls = document.createElement("div");
            controls.style.cssText = "display:flex;align-items:flex-start;width:100%;height:100%;";
            controls.appendChild(input);
            box.appendChild(header);
            box.appendChild(controls);
        }

        if (item.type === "body") {
            var ta = document.createElement("div");
            ta.className = "slide-textarea";
            ta.contentEditable = "true";
            ta.innerText = item.text;
            ta.dataset.placeholder = "Click to edit text";
            ta.style.cssText = "width:100%;height:100%;outline:none;cursor:text;word-break:break-word;white-space:pre-wrap;overflow:hidden;";
            if (item.color)    ta.style.color      = item.color;
            if (item.font)     ta.style.fontFamily = item.font;
            if (item.fontSize) ta.style.fontSize   = item.fontSize;
            if (item.alignment) ta.style.textAlign = item.alignment;
            ta.addEventListener("input", (function(it) {
                return function() {
                    it.text = ta.innerText;
                    syncBoxHeight(box, ta, it, index);
                    updatePreview(index);
                };
            }(item)));
            requestAnimationFrame(function() { syncBoxHeight(box, ta, item, index); });
            box.appendChild(header);
            box.appendChild(ta);
        }

        if (item.type === "video") {
            var src = item.src || '';
            if (src.startsWith('local:')) {
                src = (window._localMediaStore && window._localMediaStore[src]) ? window._localMediaStore[src] : '';
            }
            var mediaStyle = 'width:100%;height:calc(100% - 26px);display:block;';
            if (item.mime && item.mime.startsWith('image/')) {
                var img = document.createElement('img');
                img.src = src;
                img.style.cssText = mediaStyle + 'object-fit:contain;';
                box.appendChild(header);
                box.appendChild(img);
            } else if (item.mime && item.mime.startsWith('video/')) {
                var vid = document.createElement('video');
                vid.src = src;
                vid.controls = true;
                vid.style.cssText = mediaStyle;
                box.appendChild(header);
                box.appendChild(vid);
            } else if (src) {
                var iframe = document.createElement("iframe");
                iframe.src = src;
                iframe.style.cssText = mediaStyle + 'border:none;';
                iframe.referrerPolicy = "strict-origin-when-cross-origin";
                iframe.allowFullscreen = true;
                box.appendChild(header);
                box.appendChild(iframe);
            }
        }

        main.appendChild(box);

        box.addEventListener('pointerdown', function() {
            document.querySelectorAll('#mainSlide .slide-item-selected')
                .forEach(function(el) { el.classList.remove('slide-item-selected'); });
            box.classList.add('slide-item-selected');
        });

        addResizeHandles(box, item, index);
        dragElement(box, header, main);

        box.addEventListener('dblclick', function(e) {
            if (e.target.closest('input, textarea')) return;
            startMoveMode(box, e);
        });

        box.addEventListener("pointerup", (function(it) {
            return function() {
                var newX = parseInt(box.style.left);
                var newY = parseInt(box.style.top);
                if (newX !== it.x || newY !== it.y) {
                    it.x = newX; it.y = newY;
                    updatePreview(index);
                    saveSlideData();
                }
            };
        }(item)));
    });
}

function updatePreview(index) {
    var preview = document.querySelector("#slidesList .preview[data-index='" + index + "']");
    if (!preview) return;
    var mainSlide = document.getElementById("mainSlide");
    var scale = mainSlide.offsetWidth / preview.offsetWidth;
    var s = slideData[index];
    if (s && s.background) {
        preview.style.setProperty('background-color', s.background, 'important');
    } else {
        preview.style.removeProperty('background-color');
    }
    preview.innerHTML = "";
    var slide = slideData[index];
    if (!slide || !slide.items) return;
    var wrapper = document.createElement("div");
    wrapper.style.cssText = "position:absolute;width:100%;height:100%;";
    slide.items.forEach(function(item) {
        var box = document.createElement("div");
        box.style.position    = "absolute";
        box.style.left        = (item.x / scale) + "px";
        box.style.top         = (item.y / scale) + "px";
        box.style.width       = ((item.width || 300) / scale) + "px";
        box.style.whiteSpace  = "pre-wrap";
        box.style.wordBreak   = "break-word";
        box.style.overflowWrap = "break-word";
        if (item.height)    box.style.height     = (item.height / scale) + "px";
        if (item.color)     box.style.color      = item.color;
        if (item.font)      box.style.fontFamily = item.font;
        var baseFontSize = item.fontSize ? parseFloat(item.fontSize) : (defaultFontSize[item.type] || 16);
        box.style.fontSize = (baseFontSize / scale) + "px";
        if (item.alignment) box.style.textAlign  = item.alignment;
        if (item.type === "title" || item.type === "text" || item.type === "body") box.innerText = item.text;
        if (item.type === "video") box.innerText = "[Video]";
        wrapper.appendChild(box);
    });
    preview.appendChild(wrapper);
}

function presentFromBeginning() { presentIndex = 0; startPresentation(); }
function presentFromCurrentSlide() { presentIndex = slideDataIndex; startPresentation(); }

function startPresentation() {
    var overlay = document.createElement('div');
    overlay.id = 'presentOverlay';
    overlay.style.cssText = 'position:fixed;inset:0;background:#000;z-index:9999;display:flex;align-items:center;justify-content:center;cursor:pointer;';
    var stage = document.createElement('div');
    stage.style.cssText = 'position:relative;width:100%;max-width:calc(100vh * 16/9);aspect-ratio:16/9;overflow:hidden;';
    overlay.appendChild(stage);
    var counter = document.createElement('div');
    counter.style.cssText = 'position:absolute;bottom:18px;right:24px;color:rgba(255,255,255,0.5);font-size:13px;z-index:2;pointer-events:none;';
    overlay.appendChild(counter);
    document.body.appendChild(overlay);

    function showSlide(index) {
        stage.innerHTML = '';
        var s = slideData[index];
        stage.style.setProperty('background-color', (s && s.background) ? s.background : '#ffffff', 'important');
        var mainSlide = document.getElementById('mainSlide');
        var sourceW = mainSlide.offsetWidth  || 800;
        var sourceH = mainSlide.offsetHeight || 450;
        var scale   = Math.min(stage.offsetWidth / sourceW, stage.offsetHeight / sourceH);
        s.items.forEach(function(item) {
            var box = document.createElement('div');
            box.style.position   = 'absolute';
            box.style.left       = (item.x * scale) + 'px';
            box.style.top        = (item.y * scale) + 'px';
            box.style.width      = ((item.width || 300) * scale) + 'px';
            if (item.height) box.style.height = (item.height * scale) + 'px';
            box.style.color      = item.color      || '#000000';
            box.style.fontFamily = item.font        || 'Arial';
            box.style.fontSize   = ((parseFloat(item.fontSize) || (item.type === 'title' ? 32 : 16)) * scale) + 'px';
            if (item.alignment)  box.style.textAlign = item.alignment;
            box.style.overflow      = 'hidden';
            box.style.whiteSpace    = 'pre-wrap';
            box.style.wordBreak     = 'break-word';
            box.style.overflowWrap  = 'break-word';
            if (item.type === 'title' || item.type === 'text' || item.type === 'body') box.innerText = item.text;
            if (item.type === 'video') {
                var iframe = document.createElement('iframe');
                iframe.src = item.src;
                iframe.style.cssText = 'width:100%;height:100%;border:none;';
                box.appendChild(iframe);
            }
            stage.appendChild(box);
        });
        counter.textContent = (index + 1) + ' / ' + slideData.length;
    }

    function next() { if (presentIndex < slideData.length - 1) { presentIndex++; showSlide(presentIndex); } }
    function prev() { if (presentIndex > 0) { presentIndex--; showSlide(presentIndex); } }
    function exit() {
        document.removeEventListener('keydown', onKey);
        overlay.remove();
        if (document.exitFullscreen) document.exitFullscreen();
    }
    function onKey(e) {
        if (e.key === 'ArrowRight' || e.key === 'ArrowDown' || e.key === ' ') next();
        if (e.key === 'ArrowLeft'  || e.key === 'ArrowUp') prev();
        if (e.key === 'Escape') exit();
    }
    overlay.addEventListener('click', function(e) { if (e.clientX < window.innerWidth / 2) prev(); else next(); });
    document.addEventListener('keydown', onKey);
    document.addEventListener('fullscreenchange', function onFS() {
        document.removeEventListener('fullscreenchange', onFS);
        showSlide(presentIndex);
    });
    if (overlay.requestFullscreen) overlay.requestFullscreen();
    else if (overlay.webkitRequestFullscreen) {
        document.addEventListener('webkitfullscreenchange', function onFS() {
            document.removeEventListener('webkitfullscreenchange', onFS);
            showSlide(presentIndex);
        });
        overlay.webkitRequestFullscreen();
    } else {
        showSlide(presentIndex);
    }
}

async function exportToPDF() {
    saveSlideData();
    var { jsPDF } = window.jspdf;
    var pdf = new jsPDF({ orientation: 'landscape', unit: 'px', format: [800, 450] });
    var mainSlide = document.getElementById('mainSlide');
    var savedIndex = slideDataIndex;
    var btn = document.querySelector('[onclick="exportToPDF()"]');
    var origText = btn ? btn.textContent : '';
    if (btn) btn.textContent = 'Exporting...';
    for (var i = 0; i < slideData.length; i++) {
        slideDataIndex = i;
        renderSlide(i);
        await new Promise(function(r) { setTimeout(r, 150); });
        var canvas = await html2canvas(mainSlide, {
            scale: 1, useCORS: true, allowTaint: true,
            backgroundColor: slideData[i].background || '#ffffff', width: 800, height: 450
        });
        var imgData = canvas.toDataURL('image/jpeg', 0.95);
        if (i > 0) pdf.addPage();
        pdf.addImage(imgData, 'JPEG', 0, 0, 800, 450);
    }
    slideDataIndex = savedIndex;
    renderSlide(savedIndex);
    selectPreview(savedIndex);
    if (btn) btn.textContent = origText;
    pdf.save('presentation.pdf');
}

function exportToPPTX() {
    saveSlideData();
    var pptx = new PptxGenJS();
    pptx.layout = 'LAYOUT_16x9';
    var mainSlide = document.getElementById('mainSlide');
    var slideW = mainSlide.offsetWidth  || 800;
    var slideH = mainSlide.offsetHeight || 450;
    var pptxW = 10, pptxH = 5.625;
    function pxToInW(px) { return (px / slideW) * pptxW; }
    function pxToInH(px) { return (px / slideH) * pptxH; }
    slideData.forEach(function(slide) {
        var s = pptx.addSlide();
        if (slide.background) {
            var hex = slide.background.replace('#', '');
            if (hex.length === 3) hex = hex.split('').map(function(c){ return c+c; }).join('');
            s.background = { fill: hex.toUpperCase() };
        }
        slide.items.forEach(function(item) {
            if (item.type === 'title' || item.type === 'body' || item.type === 'text') {
                var fontSize = item.fontSize ? parseFloat(item.fontSize) : (item.type === 'title' ? 32 : 16);
                var opts = {
                    x: pxToInW(item.x), y: pxToInH(item.y),
                    w: pxToInW(item.width || 300), h: pxToInH(item.height || (item.type === 'title' ? 80 : 150)),
                    fontSize: Math.round(fontSize * 0.75), fontFace: item.font || 'Arial',
                    color: item.color ? item.color.replace('#', '') : '000000',
                    align: item.alignment || 'left', wrap: true, valign: 'top'
                };
                if (item.type === 'title') { opts.bold = true; opts.align = item.alignment || 'center'; }
                s.addText(item.text || '', opts);
            }
            if (item.type === 'video') {
                s.addText('[Video: ' + (item.src || '') + ']', {
                    x: pxToInW(item.x), y: pxToInH(item.y),
                    w: pxToInW(item.width || 320), h: pxToInH(item.height || 180),
                    fontSize: 12, color: '888888', align: 'center', valign: 'middle'
                });
            }
        });
    });
    pptx.writeFile({ fileName: 'presentation.pptx' });
}

function updatePresName(name) {
    currentPresentationName = name;
    document.getElementById('presName').textContent = name;
}

function renamePresentationPrompt() {
    var name = prompt('Presentation name:', currentPresentationName);
    if (name && name.trim()) updatePresName(name.trim());
}

function slideDataToXML() {
    function escAttr(str) {
        return String(str)
            .replace(/&/g, '&amp;').replace(/"/g, '&quot;')
            .replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }
    var xml = '<?xml version="1.0" encoding="UTF-8"?>\n<presentation>\n';
    slideData.forEach(function(slide, i) {
        xml += '  <slide index="' + i + '" background="' + escAttr(slide.background || '') + '">\n';
        slide.items.forEach(function(item) {
            xml += '    <item'
                + ' type="'      + escAttr(item.type      || '') + '"'
                + ' x="'        + (item.x      || 0)             + '"'
                + ' y="'        + (item.y      || 0)             + '"'
                + ' width="'    + (item.width  || 300)           + '"'
                + ' height="'   + (item.height || 50)            + '"'
                + ' color="'    + escAttr(item.color     || '') + '"'
                + ' font="'     + escAttr(item.font      || '') + '"'
                + ' fontSize="' + escAttr(item.fontSize  || '') + '"'
                + ' alignment="'+ escAttr(item.alignment || '') + '"'
                + ' src="'      + escAttr(item.src       || '') + '"'
                + ' mime="'     + escAttr(item.mime      || '') + '"'
                + '><![CDATA[' + (item.text || '') + ']]></item>\n';
        });
        xml += '  </slide>\n';
    });
    xml += '</presentation>';
    return xml;
}

async function saveToXML() {
    var xml    = slideDataToXML();
    var params = '?name=' + encodeURIComponent(currentPresentationName);
    if (currentPresentationId) params += '&id=' + encodeURIComponent(currentPresentationId);
    try {
        var res  = await fetch('save.php' + params, {
            method: 'POST',
            headers: { 'Content-Type': 'application/xml' },
            body: xml
        });
        var data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Save failed');
        currentPresentationId = data.id;
        updatePresName(data.name);
        history.replaceState(null, '', '?id=' + encodeURIComponent(data.id));
        localStorage.setItem('presId',   data.id);
        localStorage.setItem('presName', data.name);
        var btn = document.querySelector('[onclick="saveToXML()"]');
        if (btn) { btn.textContent = 'Saved!'; setTimeout(function() { btn.textContent = 'Save'; }, 1500); }
    } catch (err) {
        alert('Save error: ' + err.message);
    }
}

async function loadFromXML(id, name) {
    try {
        var res = await fetch('load.php?id=' + encodeURIComponent(id));
        if (!res.ok) throw new Error('Presentation not found');
        var text = await res.text();
        var parser = new DOMParser();
        var doc = parser.parseFromString(text, 'application/xml');
        if (doc.querySelector('parsererror')) throw new Error('XML parse error');

        slideData = [];
        doc.querySelectorAll('slide').forEach(function(slide) {
            var items = [];
            slide.querySelectorAll('item').forEach(function(el) {
                items.push({
                    type:      el.getAttribute('type'),
                    x:         parseFloat(el.getAttribute('x')),
                    y:         parseFloat(el.getAttribute('y')),
                    width:     parseFloat(el.getAttribute('width')),
                    height:    parseFloat(el.getAttribute('height')),
                    color:     el.getAttribute('color')     || '',
                    font:      el.getAttribute('font')      || '',
                    fontSize:  el.getAttribute('fontSize')  || '',
                    alignment: el.getAttribute('alignment') || '',
                    src:       el.getAttribute('src')       || '',
                    mime:      el.getAttribute('mime')      || '',
                    text:      el.textContent
                });
            });
            slideData.push({ background: slide.getAttribute('background') || '', items: items });
        });

        rebuildSlideThumbs();
        slideDataIndex = 0;
        renderSlide(0);
        slideData.forEach(function(_, i) { updatePreview(i); });
        selectPreview(0);
        saveSlideData();
        currentPresentationId = id;
        updatePresName(name || 'Untitled');
        history.replaceState(null, '', '?id=' + encodeURIComponent(id));
        closePickerModal();
    } catch(err) {
        alert('Load error: ' + err.message);
    }
}

function rebuildSlideThumbs() {
    var container = document.getElementById('slidesList');
    container.innerHTML = '';
    slideData.forEach(function(_, i) {
        var thumb = document.createElement('div');
        thumb.id = 'preview' + i;
        thumb.className = 'preview ratio ratio-16x9 w-75 bg-light shadow';
        thumb.style.maxWidth = '400px';
        thumb.dataset.index = i;
        thumb.oncontextmenu = function(e) { showSlideMenu(e, this); };
        container.appendChild(thumb);
    });
    slideNum();
}

async function openPickerModal() {
    document.getElementById('pickerModal').style.display = 'flex';
    var list = document.getElementById('pickerList');
    list.innerHTML = '';
    var loading = document.createElement('div');
    loading.className = 'text-muted text-center py-3';
    loading.textContent = 'Loading...';
    list.appendChild(loading);

    try {
        var res = await fetch('list.php?_=' + Date.now());
        var items = await res.json();
        list.innerHTML = '';

        if (!items.length) {
            var empty = document.createElement('div');
            empty.className = 'text-muted text-center py-3';
            empty.textContent = 'No saved presentations yet.';
            list.appendChild(empty);
            return;
        }

        items.forEach(function(pres) {
            var row = document.createElement('div');
            row.className = 'd-flex align-items-center justify-content-between border rounded px-3 py-2';

            var info  = document.createElement('div');
            var title = document.createElement('div');
            title.className = 'fw-semibold';
            title.textContent = pres.name;
            var sub = document.createElement('small');
            sub.className = 'text-muted';
            sub.textContent = 'Saved: ' + pres.updated;
            info.appendChild(title);
            info.appendChild(sub);

            var btns   = document.createElement('div');
            btns.className = 'd-flex gap-2';
            var openBtn = document.createElement('button');
            openBtn.className = 'btn btn-sm btn-primary';
            openBtn.textContent = 'Open';
            openBtn.addEventListener('click', function() { loadFromXML(pres.id, pres.name); });
            var delBtn = document.createElement('button');
            delBtn.className = 'btn btn-sm btn-outline-danger';
            delBtn.textContent = 'Delete';
            delBtn.addEventListener('click', function() { deletePresentation(pres.id, row); });
            btns.appendChild(openBtn);
            btns.appendChild(delBtn);

            row.appendChild(info);
            row.appendChild(btns);
            list.appendChild(row);
        });
    } catch(err) {
        list.innerHTML = '';
        var errDiv = document.createElement('div');
        errDiv.className = 'text-danger text-center py-3';
        errDiv.textContent = 'Error loading list: ' + err.message;
        list.appendChild(errDiv);
    }
}

function closePickerModal() {
    document.getElementById('pickerModal').style.display = 'none';
}

async function deletePresentation(id, rowEl) {
    if (!confirm('Delete this presentation? This cannot be undone.')) return;
    try {
        var res  = await fetch('delete.php?id=' + encodeURIComponent(id), { method: 'POST' });
        var data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Delete failed');
        rowEl.remove();
        if (currentPresentationId === id) {
            currentPresentationId = null;
            updatePresName('Untitled');
            history.replaceState(null, '', location.pathname);
        }
    } catch(err) {
        alert('Delete error: ' + err.message);
    }
}

function newPresentation() {
    if (!confirm('Start a new presentation? Unsaved changes will be lost.')) return;
    localStorage.removeItem('slideData');
    slideData = [{ items: [], background: '' }];
    slideDataIndex = 0;
    currentPresentationId = null;
    updatePresName('Untitled');
    history.replaceState(null, '', location.pathname);
    localStorage.removeItem('slideData');
    localStorage.removeItem('presId');    
    localStorage.removeItem('presName');  
    rebuildSlideThumbs();
    createSlideLayout();
    saveSlideData();
    closePickerModal();
}

function openAIModal() {
    document.getElementById('aiModal').style.display = 'flex';
    document.getElementById('aiError').classList.add('d-none');
    if (slideData.length > 1 || (slideData[0] && slideData[0].items && slideData[0].items.some(function(it){ return it.text && it.text.trim(); }))) {
        document.getElementById('aiWarning').classList.remove('d-none');
    } else {
        document.getElementById('aiWarning').classList.add('d-none');
    }
}

function closeAIModal() {
    document.getElementById('aiModal').style.display = 'none';
}

async function generateOutline() {
    var topic = document.getElementById('aiTopic').value.trim();
    if (!topic) {
        document.getElementById('aiError').textContent = 'Please enter a topic.';
        document.getElementById('aiError').classList.remove('d-none');
        return;
    }
    var count = parseInt(document.getElementById('aiSlideCount').value, 10);
    if (isNaN(count) || count < 2 || count > 20) {
        document.getElementById('aiError').textContent = 'Please enter a number of slides between 2 and 20.';
        document.getElementById('aiError').classList.remove('d-none');
        return;
    }

    document.getElementById('aiError').classList.add('d-none');
    document.getElementById('aiGenerateBtn').disabled = true;
    document.getElementById('aiGenerateLabel').textContent = 'Generating...';
    document.getElementById('aiSpinner').classList.remove('d-none');

    var mainSlide = document.getElementById('mainSlide');
    var w = mainSlide.offsetWidth || 800;
    var h = mainSlide.offsetHeight || 450;

    var prompt = `You are generating slide content for a presentation tool. The user wants a ${count}-slide presentation about: "${topic}".

Return ONLY a valid JSON array with exactly ${count} objects. No explanation, no markdown, no code fences — raw JSON only.

Each object must follow this structure:
- Slide 1 (title slide): { "items": [ { "type": "title", "text": "<presentation title>", "x": 100, "y": ${Math.round(h*0.33)}, "width": ${w-200} } ] }
- All other slides: { "items": [ { "type": "title", "text": "<slide title>", "x": 80, "y": 40, "width": ${w-160} }, { "type": "body", "text": "<3-5 concise bullet points separated by newlines, each starting with • >", "x": 80, "y": 140, "width": ${w-160}, "height": ${h-200} } ] }

Every object must also have: "background": ""

Keep titles short (under 8 words). Keep body text concise and punchy. Do not include any extra fields.`;

    try {
        var response = await fetch("ai_proxy.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                model: "llama-3.3-70b-versatile",
                max_tokens: 1000,
                messages: [{ role: "user", content: prompt }]
            })
        });

        var data = await response.json();
        console.log('AI proxy response:', JSON.stringify(data));
        if (!response.ok) throw new Error(data.error && data.error.message ? data.error.message : 'API error');
        if (!data.choices || !data.choices[0]) throw new Error('Unexpected response from proxy. Check browser console for details.');

        var raw = data.choices[0].message.content;
        raw = raw.replace(/```json|```/g, '').trim();
        var outline = JSON.parse(raw);

        if (!Array.isArray(outline) || outline.length === 0) throw new Error('Unexpected response format from AI.');

        var container = document.getElementById('slidesList');
        container.innerHTML = '';
        slideData = [];
        slideDataIndex = 0;

        outline.forEach(function(slide, i) {
            slideData.push({ items: slide.items || [], background: slide.background || '' });

            var thumb = document.createElement('div');
            thumb.id = 'preview' + i;
            thumb.className = 'preview ratio ratio-16x9 w-75 bg-light shadow';
            thumb.style.maxWidth = '400px';
            thumb.dataset.index = i;
            thumb.oncontextmenu = function(e) { showSlideMenu(e, this); };
            container.appendChild(thumb);
        });

        slideNum();
        slideDataIndex = 0;
        renderSlide(0);
        slideData.forEach(function(_, i) { updatePreview(i); });
        selectPreview(0);
        saveSlideData();
        closeAIModal();

    } catch (err) {
        document.getElementById('aiError').textContent = 'Error: ' + err.message;
        document.getElementById('aiError').classList.remove('d-none');
    } finally {
        document.getElementById('aiGenerateBtn').disabled = false;
        document.getElementById('aiGenerateLabel').textContent = 'Generate';
        document.getElementById('aiSpinner').classList.add('d-none');
    }
}
</script>

<header>
    <nav class="navbar navbar-expand-lg bg-body-tertiary fixed-top" style="background-color:white;" data-bs-theme="dark">
        <a href="<?=URL.DS.'dashboard'?>" class="btn btn-outline-secondary btn-sm me-2">&#8592; Dashboard</a>
        <div class="container">
            <div class="d-flex align-items-center me-auto gap-2">
                <span id="presName" class="text-white fw-semibold small" style="cursor:pointer;"
                      onclick="renamePresentationPrompt()" title="Click to rename">Untitled</span>
                <button class="btn btn-success btn-sm" onclick="saveToXML()">Save</button>
                <button class="btn btn-outline-light btn-sm" onclick="openPickerModal()">&#128193; Open</button>
            </div>
            <div class="dropdown ms-auto">
                <button class="btn btn-secondary dropdown-toggle navbar-toggler" type="button"
                        data-bs-toggle="dropdown">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#">Design</a></li>
                    <li><a class="dropdown-item" href="#">Insert</a></li>
                    <li><a class="dropdown-item" href="#">Preview</a></li>
                    <li><a class="dropdown-item" href="#">Export</a></li>
                </ul>
            </div>
            <div class="collapse navbar-collapse justify-content-center">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" role="button" href="#">Design</a>
                        <ul class="dropdown-menu w-100">
                            <div class="d-flex flex-column align-items-center px-3 py-2 gap-2">
                                <div class="d-flex align-items-center gap-2">
                                    <label for="bgcolor" class="mb-0">Background</label>
                                    <input type="color" id="bgcolor" class="form-control form-control-color" style="width:40px">
                                </div>
                                <div class="d-flex flex-row align-items-center gap-2">
                                    <label class="mb-0">Layout</label>
                                    <div class="d-flex gap-2 flex-wrap justify-content-center">
                                        <button class="btn btn-sm btn-outline-secondary" onclick="applyLayout('title-only')">Title only</button>
                                        <button class="btn btn-sm btn-outline-secondary" onclick="applyLayout('title-body')">Title + Body</button>
                                        <button class="btn btn-sm btn-outline-secondary" onclick="applyLayout('title-two-col')">Two columns</button>
                                        <button class="btn btn-sm btn-outline-secondary" onclick="applyLayout('blank')">Blank</button>
                                    </div>
                                </div>
                            </div>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" role="button" href="#">Insert</a>
                        <ul class="dropdown-menu w-100">
                            <div class="d-flex justify-content-center">
                                <li><a class="dropdown-item" href="#" onclick="createTextBox()">Text Box</a></li>
                                <li><a class="dropdown-item" href="#" onclick="insertVideo()">Video or Image</a></li>
                            </div>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" role="button" href="#">Preview</a>
                        <ul class="dropdown-menu w-100">
                            <div class="d-flex justify-content-center">
                                <li><a class="dropdown-item" href="#" onclick="presentFromCurrentSlide()">Present From Current Slide</a></li>
                                <li><a class="dropdown-item" href="#" onclick="presentFromBeginning()">Present from Beginning</a></li>
                            </div>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" role="button" href="#">Export</a>
                        <ul class="dropdown-menu w-100">
                            <div class="d-flex justify-content-center">
                                <li><a class="dropdown-item" href="#" onclick="exportToPDF()">PDF</a></li>
                                <li><a class="dropdown-item" href="#" onclick="exportToPPTX()">PPTX</a></li>
                            </div>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#" onclick="openAIModal(); return false;">✦ AI</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>

<div class="container-fluid vh-100 d-flex align-items-center">
    <div class="col-md-3 d-flex flex-column justify-content-center align-items-center gap-3 h-100">
        <div id="slidesList" class="d-flex flex-column align-items-center gap-3 w-100 overflow-auto" style="max-height:70vh;"></div>
        <div class="d-flex gap-2 align-items-center mt-2">
            <button id="addslide" class="btn btn-primary">+</button>
        </div>
    </div>

    <div class="col-md-9 d-flex justify-content-center align-items-center">
        <div id="mainSlide" class="ratio ratio-16x9 w-100 bg-light shadow-lg border position-relative overflow-hidden" style="max-width:800px;"></div>
    </div>
</div>

<div id="slideMenu" class="card position-absolute d-none">
    <ul class="list-group list-group-flush mb-0">
        <li class="list-group-item list-group-item-action" onclick="deleteSlide()">Delete</li>
        <li class="list-group-item list-group-item-action" onclick="duplicateSlide()">Duplicate</li>
    </ul>
</div>

<div id="textMenu" class="card position-absolute d-none">
    <ul class="list-group mb-0 list-group-horizontal">
        <li class="list-group-item list-group-item-action"><input type="color" id="colorChoice"></li>
        <li class="list-group-item list-group-item-action">
            <select id="fontSelect">
                <option value="Arial">Arial</option>
                <option value="Times New Roman">Times New Roman</option>
                <option value="Courier New">Courier New</option>
                <option value="Georgia">Georgia</option>
                <option value="Verdana">Verdana</option>
            </select>
        </li>
        <li class="list-group-item list-group-item-action">
            <select id="sizeSelect">
                <option value="8px">8</option>
                <option value="10px">10</option>
                <option value="12px">12</option>
                <option value="14px">14</option>
                <option value="16px">16</option>
                <option value="20px">20</option>
                <option value="24px">24</option>
                <option value="28px">28</option>
                <option value="32px">32</option>
                <option value="48px">48</option>
                <option value="56px">56</option>
            </select>
        </li>
        <li class="list-group-item list-group-item-action">
            <select id="alignSelect">
                <option value="left">Left</option>
                <option value="center">Center</option>
                <option value="right">Right</option>
            </select>
        </li>
        <li class="list-group-item list-group-item-action" onclick="deleteItem()">Delete</li>
        <li class="list-group-item list-group-item-action" onclick="duplicateItem()">Duplicate</li>
    </ul>
</div>

<div id="itemMenu" class="card position-absolute d-none" style="z-index:1000;">
    <ul class="list-group list-group-flush mb-0">
        <li class="list-group-item list-group-item-action" onclick="deleteItem()">Delete</li>
        <li class="list-group-item list-group-item-action" onclick="duplicateItem()">Duplicate</li>
    </ul>
</div>

<!-- Media modal -->
<div id="mediaModal" class="position-fixed top-0 start-0 w-100 h-100"
     style="background:rgba(0,0,0,0.4);z-index:2000;align-items:center;justify-content:center;display:none;">
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span class="fw-semibold">Insert media</span>
            <button class="btn-close" onclick="closeMediaModal()"></button>
        </div>
        <div class="d-flex border-bottom">
            <button id="mediaTab-link" class="media-tab btn btn-link text-decoration-none flex-fill active" data-tab="link" onclick="switchMediaTab('link')">Link / embed</button>
            <button id="mediaTab-file" class="media-tab btn btn-link text-decoration-none flex-fill" data-tab="file" onclick="switchMediaTab('file')">Local file</button>
        </div>
        <div class="card-body">
            <div id="mediaPanel-link">
                <label class="form-label small text-muted">Paste a URL (YouTube, Vimeo, or image link)</label>
                <input id="mediaUrlInput" type="text" class="form-control" placeholder="https://">
                <small id="mediaUrlPreview" class="text-muted mt-1 d-block"></small>
            </div>
            <div id="mediaPanel-file" class="d-none">
                <label class="form-label small text-muted">Choose an image or video file</label>
                <input id="mediaFileInput" type="file" class="form-control" accept="image/*,video/*">
            </div>
        </div>
        <div class="card-footer d-flex justify-content-end gap-2">
            <button class="btn btn-secondary btn-sm" onclick="closeMediaModal()">Cancel</button>
            <button class="btn btn-primary btn-sm" onclick="confirmMediaInsert()">Insert</button>
        </div>
    </div>
</div>

<!-- AI menu -->
<div id="aiModal" class="position-fixed top-0 start-0 w-100 h-100"
     style="background:rgba(0,0,0,0.5);z-index:3000;align-items:center;justify-content:center;display:none;">
    <div class="card shadow-lg" style="width:420px;max-width:95vw;">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span class="fw-semibold">✦ AI Outline Generator</span>
            <button class="btn-close" onclick="closeAIModal()"></button>
        </div>
        <div class="card-body d-flex flex-column gap-3">
            <div>
                <label class="form-label fw-semibold">What is your presentation about?</label>
                <textarea id="aiTopic" class="form-control" rows="3" placeholder="e.g. The history of the Roman Empire..."></textarea>
            </div>
            <div>
                <label class="form-label fw-semibold">Number of slides</label>
                <input type="number" id="aiSlideCount" class="form-control" value="5" min="2" max="20" style="width:100px;">
            </div>
            <div id="aiWarning" class="alert alert-warning d-none py-2 mb-0">
                This will replace your current presentation. Export first if you want to keep it.
            </div>
            <div id="aiError" class="alert alert-danger d-none py-2 mb-0"></div>
        </div>
        <div class="card-footer d-flex justify-content-end gap-2">
            <button class="btn btn-secondary btn-sm" onclick="closeAIModal()">Cancel</button>
            <button id="aiGenerateBtn" class="btn btn-primary btn-sm" onclick="generateOutline()">
                <span id="aiGenerateLabel">Generate</span>
                <span id="aiSpinner" class="spinner-border spinner-border-sm ms-1 d-none" role="status"></span>
            </button>
        </div>
    </div>
</div>

</body>
</html>