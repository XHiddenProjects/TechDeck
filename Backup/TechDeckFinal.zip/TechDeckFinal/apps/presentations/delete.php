<?php
ob_start();
if (session_status() === PHP_SESSION_NONE) session_start();
ob_end_clean();

header('Content-Type: application/json');

$id  = preg_replace('/[^a-z0-9_-]/i', '', $_GET['id'] ?? '');
$dir = __DIR__ . '/presentations/';

if (!$id) {
    http_response_code(400);
    echo json_encode(['error' => 'No ID provided']);
    exit;
}

$xml  = $dir . $id . '.xml';
$json = $dir . $id . '.json';

if (!file_exists($xml)) {
    http_response_code(404);
    echo json_encode(['error' => 'Presentation not found']);
    exit;
}

@unlink($xml);
@unlink($json);

echo json_encode(['ok' => true]);