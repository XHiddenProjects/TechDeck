<?php
ob_start();
if (session_status() === PHP_SESSION_NONE) session_start();
ob_end_clean();
 
header('Content-Type: application/json');
 
$xml  = file_get_contents('php://input');
$id   = preg_replace('/[^a-z0-9_-]/i', '', $_GET['id'] ?? '');
$name = trim($_GET['name'] ?? 'Untitled');
if ($name === '') $name = 'Untitled';
 
if (!$id) {
    $id = 'pres_' . bin2hex(random_bytes(8));
}
 
$dir = __DIR__ . '/presentations/';
if (!is_dir($dir)) mkdir($dir, 0755, true);
 
libxml_use_internal_errors(true);
$doc = simplexml_load_string($xml);
if (!$doc) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid XML']);
    exit;
}
 
$meta = [
    'id'      => $id,
    'name'    => $name,
    'updated' => date('Y-m-d H:i:s')
];
 
file_put_contents($dir . $id . '.xml',  $xml);
file_put_contents($dir . $id . '.json', json_encode($meta));
 
echo json_encode(['ok' => true, 'id' => $id, 'name' => $name]);
 