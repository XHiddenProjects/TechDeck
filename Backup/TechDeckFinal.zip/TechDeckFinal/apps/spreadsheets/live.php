<?php

use TechDeck\Addons;
require_once __DIR__ . '/includes/storage.php';
$user = require_auth();
$id = (string)($_GET['id'] ?? '');
$workbook = load_workbook($id);
if (!$workbook || !user_can_access_workbook($workbook, (string)$user['username'])) {
    http_response_code(404);
    echo 'Workbook not found or access denied.';
    exit;
}
include_once dirname(__DIR__,2) . '/init.php';
$addons = new Addons();
?><!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<?=preg_replace('/<title>.*<\/title>/i', '<title>' . htmlspecialchars((string)$workbook['title']) . ' - Spreadsheets</title>', $addons->hook('head'))?>
<title><?= htmlspecialchars((string)$workbook['title']) ?> - Spreadsheets</title>
<?=$addons->hook('css')?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="assets/css/styles.css" rel="stylesheet">
</head><body class="editor-body">
<div class="editor-shell">
  <header class="editor-topbar bg-white border-bottom shadow-sm">
    <div class="editor-titlebar px-3 py-2 border-bottom d-flex align-items-center justify-content-between flex-wrap gap-2">
      <div class="d-flex align-items-center gap-3 flex-wrap">
        <a href="index.php" class="btn btn-sm btn-light border"><i class="bi bi-arrow-left"></i></a>
        <div class="app-mark"><i class="bi bi-file-earmark-spreadsheet-fill"></i></div>
        <div>
          <div class="fw-semibold" id="workbookTitleDisplay"></div>
          <div class="small text-secondary"><span id="selectionDisplay">A1</span> • Owner: <?= htmlspecialchars((string)$workbook['owner']) ?></div>
        </div>
      </div>
      <div class="d-flex align-items-center gap-2 flex-wrap">
        <span id="saveStatus" class="badge text-bg-light border">Ready</span>
        <button class="btn btn-sm btn-outline-secondary" id="undoBtn"><i class="bi bi-arrow-counterclockwise"></i></button>
        <button class="btn btn-sm btn-outline-secondary" id="redoBtn"><i class="bi bi-arrow-clockwise"></i></button>
        <button class="btn btn-sm btn-outline-secondary" id="formulaHelperBtn"><i class="bi bi-function"></i> Functions</button>
        <button class="btn btn-sm btn-outline-secondary" id="shareBtn"><i class="bi bi-share"></i> Share</button>
        <button class="btn btn-sm btn-outline-secondary" id="renameWorkbookBtn"><i class="bi bi-pencil"></i> Rename</button>
        <button class="btn btn-sm btn-outline-secondary" id="exportXlsxBtn"><i class="bi bi-filetype-xlsx"></i> XLSX</button>
        <a class="btn btn-sm btn-outline-secondary" id="exportCsvBtn" href="#"><i class="bi bi-filetype-csv"></i> CSV</a>
        <a class="btn btn-sm btn-outline-secondary" id="exportJsonBtn" href="#"><i class="bi bi-braces-asterisk"></i> JSON</a>
        <a class="btn btn-sm btn-outline-secondary" href="logout.php"><i class="bi bi-box-arrow-right"></i></a>
      </div>
    </div>
    <div class="ribbon-wrap">
      <ul class="nav nav-tabs ribbon-tabs px-2 pt-2" role="tablist">
        <li class="nav-item"><button class="nav-link active" data-bs-toggle="tab" data-bs-target="#tab-home" type="button"><i class="bi bi-house-door me-1"></i>Home</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-insert" type="button"><i class="bi bi-plus-square me-1"></i>Insert</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-format" type="button"><i class="bi bi-palette me-1"></i>Format</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-data" type="button"><i class="bi bi-table me-1"></i>Data</button></li>
        <li class="nav-item"><button class="nav-link" data-bs-toggle="tab" data-bs-target="#tab-view" type="button"><i class="bi bi-layout-text-window me-1"></i>View</button></li>
      </ul>
      <div class="tab-content ribbon-content border-top-0 border rounded-bottom-4 rounded-top-0 bg-ribbon px-2 py-2">
        <div class="tab-pane fade show active" id="tab-home">
          <div class="ribbon-groups">
            <div class="ribbon-group"><div class="ribbon-buttons"><button class="btn btn-light border" data-style-toggle="bold"><i class="bi bi-type-bold"></i></button><button class="btn btn-light border" data-style-toggle="italic"><i class="bi bi-type-italic"></i></button><button class="btn btn-light border" data-style-toggle="underline"><i class="bi bi-type-underline"></i></button></div><div class="ribbon-label">Font</div></div>
            <div class="ribbon-group"><div class="d-flex gap-2 flex-wrap align-items-center"><select id="fontSizeSelect" class="form-select form-select-sm ribbon-select"><option>10</option><option>11</option><option selected>13</option><option>14</option><option>16</option><option>18</option><option>20</option><option>24</option></select><select id="alignSelect" class="form-select form-select-sm ribbon-select"><option value="left">Align Left</option><option value="center">Align Center</option><option value="right">Align Right</option></select><select id="formatSelect" class="form-select form-select-sm ribbon-select"><option value="general">General</option><option value="number">Number</option><option value="currency">Currency</option><option value="percent">Percent</option><option value="date">Date</option></select></div><div class="ribbon-label">Cell Format</div></div>
            <div class="ribbon-group"><div class="d-flex gap-2 flex-wrap align-items-center"><label class="btn btn-light border d-flex align-items-center gap-2 mb-0"><i class="bi bi-droplet"></i> Text <input type="color" id="textColorInput" value="#212529" class="color-input"></label><label class="btn btn-light border d-flex align-items-center gap-2 mb-0"><i class="bi bi-paint-bucket"></i> Fill <input type="color" id="fillColorInput" value="#ffffff" class="color-input"></label></div><div class="ribbon-label">Colors</div></div>
          </div>
        </div>
        <div class="tab-pane fade" id="tab-insert">
          <div class="ribbon-groups">
            <div class="ribbon-group"><div class="ribbon-buttons wrap"><button class="btn btn-light border" id="insertRowBtn"><i class="bi bi-plus-square"></i> Row</button><button class="btn btn-light border" id="insertColBtn"><i class="bi bi-plus-square"></i> Column</button><button class="btn btn-light border" id="addSheetBtn"><i class="bi bi-file-earmark-plus"></i> Sheet</button></div><div class="ribbon-label">Structure</div></div>
            <div class="ribbon-group"><div class="ribbon-buttons wrap"><button class="btn btn-light border" id="chartBtn"><i class="bi bi-bar-chart"></i> Chart</button><button class="btn btn-light border" id="insertImageBtn"><i class="bi bi-image"></i> Image</button><button class="btn btn-light border" id="insertVideoBtn"><i class="bi bi-film"></i> Video</button><button class="btn btn-light border" id="insertLinkBtn"><i class="bi bi-link-45deg"></i> Link</button></div><div class="ribbon-label">Worksheet Objects</div></div>
            <div class="ribbon-group"><div class="ribbon-buttons wrap"><button class="btn btn-light border" id="mergeBtn"><i class="bi bi-distribute-vertical"></i> Merge</button><button class="btn btn-light border" id="unmergeBtn"><i class="bi bi-border-all"></i> Unmerge</button></div><div class="ribbon-label">Cells</div></div>
          </div>
        </div>
        <div class="tab-pane fade" id="tab-format">
          <div class="ribbon-groups">
            <div class="ribbon-group"><div class="ribbon-buttons wrap"><button class="btn btn-light border" id="clearCellBtn"><i class="bi bi-eraser"></i> Clear</button><button class="btn btn-light border" id="conditionalFormatBtn"><i class="bi bi-magic"></i> Conditional</button><button class="btn btn-light border" id="clearConditionalBtn"><i class="bi bi-x-octagon"></i> Clear Conditional</button></div><div class="ribbon-label">Formatting</div></div>
            <div class="ribbon-group"><div class="ribbon-buttons wrap"><button class="btn btn-light border" id="commentBtn"><i class="bi bi-chat-left-text"></i> Comment</button></div><div class="ribbon-label">Review</div></div>
          </div>
        </div>
        <div class="tab-pane fade" id="tab-data">
          <div class="ribbon-groups">
            <div class="ribbon-group"><div class="ribbon-buttons wrap"><button class="btn btn-light border" id="sortAscBtn"><i class="bi bi-sort-alpha-down"></i> Sort A→Z</button><button class="btn btn-light border" id="sortDescBtn"><i class="bi bi-sort-alpha-up-alt"></i> Sort Z→A</button><button class="btn btn-light border" id="filterBtn"><i class="bi bi-funnel"></i> Filter Non-Blank</button><button class="btn btn-light border" id="clearFilterBtn"><i class="bi bi-funnel-fill"></i> Clear Filter</button></div><div class="ribbon-label">Data Tools</div></div>
          </div>
        </div>
        <div class="tab-pane fade" id="tab-view">
          <div class="ribbon-groups">
            <div class="ribbon-group"><div class="ribbon-buttons wrap"><button class="btn btn-light border" id="renameSheetBtn"><i class="bi bi-input-cursor-text"></i> Rename Sheet</button><button class="btn btn-outline-danger border" id="deleteSheetBtn"><i class="bi bi-trash"></i> Delete Sheet</button><button class="btn btn-light border" id="historyBtn"><i class="bi bi-clock-history"></i> Revisions</button><button class="btn btn-light border" id="auditBtn"><i class="bi bi-journal-text"></i> Audit</button></div><div class="ribbon-label">Workbook</div></div>
            <div class="ribbon-group"><div class="d-flex gap-2 flex-wrap align-items-center"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="freezeTopToggle" checked><label class="form-check-label" for="freezeTopToggle">Freeze header row</label></div><div class="form-check form-switch"><input class="form-check-input" type="checkbox" id="freezeLeftToggle" checked><label class="form-check-label" for="freezeLeftToggle">Freeze first column</label></div></div><div class="ribbon-label">Freeze Panes</div></div>
          </div>
        </div>
      </div>
    </div>
    <div class="formula-bar-wrap bg-white border-top border-bottom px-2 py-2 position-relative">
      <div class="d-flex align-items-center gap-2">
        <div id="nameBox" class="name-box">A1</div>
        <div class="formula-symbol">fx</div>
        <div class="flex-grow-1 position-relative">
          <input id="formulaBar" class="form-control form-control-sm formula-input" placeholder="Enter value or formula, e.g. =SUM(A1:A10)">
          <div id="formulaSuggestions" class="formula-suggestions d-none"></div>
        </div>
      </div>
    </div>
  </header>
  <main class="editor-main">
    <div class="grid-scroller" id="gridScroller">
      <div class="grid-host" id="gridHost">
        <table class="sheet-grid" id="sheetGrid"></table>
        <div id="objectsLayer" class="sheet-objects-layer"></div>
      </div>
    </div>
  </main>
  <footer class="editor-footer bg-white border-top d-flex justify-content-between align-items-center px-2 py-2 gap-2 flex-wrap">
    <div class="sheet-tabs d-flex align-items-center gap-2 flex-wrap" id="sheetTabs"></div>
    <div class="small text-secondary">Drag to multi-select ranges • Right-click for actions • Resize row/column headers • Worksheet objects can be inserted onto cells</div>
  </footer>
</div>

<div class="modal fade" id="chartModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-lg modal-dialog-centered"><div class="modal-content rounded-4 border-0 shadow-lg"><div class="modal-header border-0 pb-0"><h2 class="modal-title fs-5">Chart Designer</h2><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><div class="row g-3 mb-3"><div class="col-md-4"><label class="form-label">Title</label><input id="chartTitleInput" class="form-control" placeholder="Sales by month"></div><div class="col-md-4"><label class="form-label">Data range</label><input id="chartRangeInput" class="form-control" placeholder="A1:B5"></div><div class="col-md-4"><label class="form-label">Chart type</label><select id="chartTypeSelect" class="form-select"><option value="bar">Bar</option><option value="line">Line</option><option value="pie">Pie</option><option value="doughnut">Doughnut</option></select></div></div><div class="d-flex gap-2 justify-content-end mb-3"><button id="previewChartBtn" class="btn btn-outline-secondary">Preview</button><button id="insertChartBtn" class="btn btn-primary">Insert onto Sheet</button></div><div class="chart-canvas-wrap"><canvas id="chartCanvas"></canvas></div></div></div></div></div>
<div class="modal fade" id="conditionalModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-dialog-centered"><div class="modal-content rounded-4 border-0 shadow-lg"><div class="modal-header border-0 pb-0"><h2 class="modal-title fs-5">Conditional Formatting</h2><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><div class="mb-3"><label class="form-label">Range</label><input id="cfRangeInput" class="form-control" placeholder="A1:A20"></div><div class="row g-3 mb-3"><div class="col-md-6"><label class="form-label">Rule</label><select id="cfOperator" class="form-select"><option value=">">Greater than</option><option value="<">Less than</option><option value="=">Equal to</option><option value="contains">Contains text</option></select></div><div class="col-md-6"><label class="form-label">Value</label><input id="cfValue" class="form-control" placeholder="100"></div></div><div class="row g-3"><div class="col-md-6"><label class="form-label">Text color</label><input id="cfTextColor" type="color" value="#842029" class="form-control form-control-color"></div><div class="col-md-6"><label class="form-label">Fill color</label><input id="cfFillColor" type="color" value="#f8d7da" class="form-control form-control-color"></div></div></div><div class="modal-footer border-0 pt-0"><button class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" id="saveConditionalBtn">Save Rule</button></div></div></div></div>
<div class="modal fade" id="objectModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-dialog-centered"><div class="modal-content rounded-4 border-0 shadow-lg"><div class="modal-header border-0 pb-0"><h2 class="modal-title fs-5" id="objectModalTitle">Insert Object</h2><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><input type="hidden" id="objectTypeInput"><div class="mb-3"><label class="form-label">Anchor cell</label><input id="objectAnchorInput" class="form-control" placeholder="C5"></div><div class="mb-3"><label class="form-label">Title / Label</label><input id="objectLabelInput" class="form-control"></div><div class="mb-3"><label class="form-label">URL</label><input id="objectUrlInput" class="form-control" placeholder="https://..."></div></div><div class="modal-footer border-0 pt-0"><button class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" id="insertObjectSaveBtn">Insert</button></div></div></div></div>
<div class="modal fade" id="commentModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-dialog-centered"><div class="modal-content rounded-4 border-0 shadow-lg"><div class="modal-header border-0 pb-0"><h2 class="modal-title fs-5">Cell Comment</h2><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><div class="mb-3"><label class="form-label">Cell</label><input id="commentCellInput" class="form-control" readonly></div><div class="mb-3"><label class="form-label">Comment</label><textarea id="commentTextInput" class="form-control" rows="4" placeholder="Enter a comment..."></textarea></div><div id="commentHistory" class="small text-secondary border rounded-3 p-2 bg-light"></div></div><div class="modal-footer border-0 pt-0"><button class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button><button class="btn btn-primary" id="saveCommentBtn">Save Comment</button></div></div></div></div>
<div class="modal fade" id="shareModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-dialog-centered"><div class="modal-content rounded-4 border-0 shadow-lg"><div class="modal-header border-0 pb-0"><h2 class="modal-title fs-5">Share Workbook</h2><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><label class="form-label">Username to share with</label><input id="shareUsernameInput" class="form-control" placeholder="username"></div><div class="modal-footer border-0 pt-0"><button class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" id="saveShareBtn">Share</button></div></div></div></div>
<div class="modal fade" id="historyModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-lg modal-dialog-centered"><div class="modal-content rounded-4 border-0 shadow-lg"><div class="modal-header border-0 pb-0"><h2 class="modal-title fs-5">Revision History</h2><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><div id="historyList" class="list-group"></div></div></div></div></div>
<div class="modal fade" id="auditModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-lg modal-dialog-centered"><div class="modal-content rounded-4 border-0 shadow-lg"><div class="modal-header border-0 pb-0"><h2 class="modal-title fs-5">Audit Trail</h2><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><div id="auditList" class="list-group"></div></div></div></div></div>
<div class="modal fade" id="formulaHelperModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-lg modal-dialog-centered"><div class="modal-content rounded-4 border-0 shadow-lg"><div class="modal-header border-0 pb-0"><h2 class="modal-title fs-5">Formula Helper</h2><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body"><div class="mb-3"><input id="formulaSearchInput" class="form-control" placeholder="Search functions, e.g. SUM or VLOOKUP"></div><div id="formulaCatalog" class="formula-catalog"></div></div></div></div></div>
<div id="contextMenu" class="context-menu d-none"><button data-action="copy">Copy</button><button data-action="paste">Paste</button><button data-action="clear">Clear</button><button data-action="comment">Comment</button><button data-action="link">Insert Link</button></div>
<script>
window.__WORKBOOK__ = <?= json_encode($workbook, JSON_UNESCAPED_SLASHES) ?>;
window.__CURRENT_USER__ = <?= json_encode($user, JSON_UNESCAPED_SLASHES) ?>;
</script>
<?=$addons->hook('scripts')?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.2/dist/chart.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
<script src="assets/js/formula-engine.js"></script>
<script src="assets/js/editor.js"></script>

</body></html>
