<?php

declare(strict_types=1);
require_once __DIR__ . '/includes/storage.php';

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit;

$action = $_GET['action'] ?? $_POST['action'] ?? '';

function wants_json(): bool {
    $accept = $_SERVER['HTTP_ACCEPT'] ?? '';
    return str_contains($accept, 'application/json') || strtolower((string)($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')) === 'xmlhttprequest';
}
function json_response(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_SLASHES);
    exit;
}
function success_redirect(string $url): void {
    header('Location: ' . $url);
    exit;
}
function require_api_user(): array {
    $user = current_user();
    if (!$user) json_response(['success' => false, 'message' => 'Authentication required.'], 401);
    return ['username' => $user, 'displayName' => $user];
}
function load_accessible_workbook_or_fail(string $id, string $username): array {
    $workbook = load_workbook($id);
    if (!$workbook) json_response(['success' => false, 'message' => 'Workbook not found.'], 404);
    if (!user_can_access_workbook($workbook, $username)) json_response(['success' => false, 'message' => 'Access denied.'], 403);
    return $workbook;
}

try {
    switch ($action) {
        case 'create':
            $user = require_api_user();
            $workbook = create_workbook(trim((string)($_POST['title'] ?? 'New Workbook')), (string)$user['username']);
            if (!wants_json()) success_redirect('live.php?id=' . urlencode((string)$workbook['id']));
            json_response(['success' => true, 'workbook' => $workbook]);
            break;

        case 'list':
            $user = require_api_user();
            json_response(['success' => true, 'items' => list_workbooks_for_user((string)$user['username'])]);
            break;

        case 'load':
            $user = require_api_user();
            $workbook = load_accessible_workbook_or_fail((string)($_GET['id'] ?? ''), (string)$user['username']);
            json_response(['success' => true, 'workbook' => $workbook]);
            break;

        case 'save':
            $user = require_api_user();
            $payload = json_decode(file_get_contents('php://input') ?: '', true);
            if (!is_array($payload) || !isset($payload['workbook']) || !is_array($payload['workbook'])) {
                json_response(['success' => false, 'message' => 'Invalid save payload.'], 400);
            }
            $workbook = $payload['workbook'];
            if (empty($workbook['id'])) json_response(['success' => false, 'message' => 'Workbook id is required.'], 400);
            $existing = load_accessible_workbook_or_fail((string)$workbook['id'], (string)$user['username']);
            $workbook['owner'] = $existing['owner'];
            $workbook['sharedWith'] = $existing['sharedWith'];
            $workbook['shareToken'] = $existing['shareToken'];
            $workbook['createdAt'] = $existing['createdAt'];
            $workbook['revisions'] = $existing['revisions'];
            $workbook['auditTrail'] = $existing['auditTrail'];
            save_workbook($workbook, (string)$user['username'], 'save');
            json_response(['success' => true, 'updatedAt' => gmdate('c')]);
            break;

        case 'poll':
            $user = require_api_user();
            $workbook = load_accessible_workbook_or_fail((string)($_GET['id'] ?? ''), (string)$user['username']);
            json_response(['success' => true, 'updatedAt' => $workbook['updatedAt'] ?? null]);
            break;

        case 'share':
            $user = require_api_user();
            $id = (string)($_POST['id'] ?? '');
            $shareWith = trim((string)($_POST['shareWith'] ?? ''));
            $workbook = load_accessible_workbook_or_fail($id, (string)$user['username']);
            if (($workbook['owner'] ?? '') !== (string)$user['username']) {
                json_response(['success' => false, 'message' => 'Only the owner can share this workbook.'], 403);
            }
            if (!$shareWith || !find_user($shareWith)) {
                json_response(['success' => false, 'message' => 'User not found.'], 404);
            }
            if (!in_array($shareWith, $workbook['sharedWith'], true)) {
                $workbook['sharedWith'][] = $shareWith;
                save_workbook($workbook, (string)$user['username'], 'share');
            }
            json_response(['success' => true]);
            break;

        case 'delete':
            $user = require_api_user();
            $id = (string)($_POST['id'] ?? '');
            $workbook = load_accessible_workbook_or_fail($id, (string)$user['username']);
            if (($workbook['owner'] ?? '') !== (string)$user['username']) {
                json_response(['success' => false, 'message' => 'Only the owner can delete this workbook.'], 403);
            }
            $ok = delete_workbook($id);
            if (!wants_json()) success_redirect('index.php');
            json_response(['success' => $ok]);
            break;

        case 'import':
            $user = require_api_user();
            if (!isset($_FILES['file']) || !is_uploaded_file($_FILES['file']['tmp_name'])) {
                json_response(['success' => false, 'message' => 'No file uploaded.'], 400);
            }
            $name = $_FILES['file']['name'] ?? 'import.csv';
            $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            if ($ext !== 'csv') {
                json_response(['success' => false, 'message' => 'Only CSV import is supported directly by PHP; XLSX import uses the browser importer.'], 400);
            }
            $title = trim((string)($_POST['title'] ?? pathinfo($name, PATHINFO_FILENAME)));
            $workbook = import_csv_workbook($_FILES['file']['tmp_name'], $title, (string)$user['username']);
            if (!wants_json()) success_redirect('live.php?id=' . urlencode((string)$workbook['id']));
            json_response(['success' => true, 'workbook' => $workbook]);
            break;

        case 'import_workbook':
            $user = require_api_user();
            $payload = json_decode(file_get_contents('php://input') ?: '', true);
            if (!is_array($payload) || !isset($payload['workbook']) || !is_array($payload['workbook'])) {
                json_response(['success' => false, 'message' => 'Invalid import payload.'], 400);
            }
            $workbook = save_imported_workbook($payload['workbook'], (string)$user['username']);
            json_response(['success' => true, 'workbook' => $workbook]);
            break;

        case 'export_csv':
            $user = require_api_user();
            $id = (string)($_GET['id'] ?? '');
            $sheetIndex = isset($_GET['sheet']) ? (int)$_GET['sheet'] : 0;
            $workbook = load_accessible_workbook_or_fail($id, (string)$user['username']);
            $safeName = preg_replace('/[^a-zA-Z0-9_-]+/', '_', (string)($workbook['title'] ?? 'workbook'));
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $safeName . '.csv"');
            echo workbook_to_csv($workbook, $sheetIndex);
            exit;

        case 'export_json':
            $user = require_api_user();
            $id = (string)($_GET['id'] ?? '');
            $workbook = load_accessible_workbook_or_fail($id, (string)$user['username']);
            $safeName = preg_replace('/[^a-zA-Z0-9_-]+/', '_', (string)($workbook['title'] ?? 'workbook'));
            header('Content-Type: application/json; charset=utf-8');
            header('Content-Disposition: attachment; filename="' . $safeName . '.json"');
            echo json_encode($workbook, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
            exit;

        default:
            json_response(['success' => false, 'message' => 'Unknown action.'], 400);
    }
} catch (Throwable $e) {
    json_response(['success' => false, 'message' => $e->getMessage()], 500);
}
