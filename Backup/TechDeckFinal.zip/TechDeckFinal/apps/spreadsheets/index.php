<?php

use TechDeck\Addons;
require_once __DIR__ . '/includes/storage.php';
$user = require_auth();
$items = list_workbooks_for_user((string)$user['username']);
include_once dirname(__DIR__,2) . '/init.php';
$addons = new Addons();
?><!doctype html>
<html lang="en"><head>
<?=preg_replace('/<title>.*<\/title>/i', '<title>Spreadsheets</title>', $addons->hook('head'))?>
<title>Spreadsheets</title>
<?=$addons->hook('css')?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="assets/css/styles.css" rel="stylesheet">
</head><body class="dashboard-body bg-light">
<nav class="navbar navbar-expand-lg bg-white border-bottom shadow-sm sticky-top">
  <div class="container-fluid px-4">
    <span class="navbar-brand fw-semibold d-flex align-items-center gap-2">
      <span class="brand-icon"><i class="bi bi-file-earmark-spreadsheet-fill"></i></span>
      Spreadsheets
    </span>
    <div class="d-flex gap-2 align-items-center ms-auto flex-wrap">
      <span class="text-secondary small">Signed in as <strong><?= htmlspecialchars((string)$user['displayName']) ?></strong></span>
      <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#newWorkbookModal"><i class="bi bi-plus-lg me-1"></i>New Spreadsheet</button>
      <button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#importModal"><i class="bi bi-upload me-1"></i>Import CSV/XLSX</button>
      <a class="btn btn-outline-secondary" href="logout.php"><i class="bi bi-box-arrow-right me-1"></i>Logout</a>
    </div>
  </div>
</nav>
<header class="container-fluid px-4 pt-4 pb-3">
  <div class="hero-card bg-white border shadow-sm rounded-4 p-4">
    <div class="row align-items-center g-3">
      <div class="col-lg-8">
        <div class="eyebrow text-success mb-2">Spreadsheet Workspace</div>
        <h1 class="display-6 mb-2">Professional spreadsheet dashboard</h1>
        <p class="lead text-secondary mb-0">Manage secure workbooks with ownership, sharing, formulas, charts, media objects, comments, autosave, revision history, and rich worksheet editing.</p>
      </div>
      <div class="col-lg-4 text-lg-end"><div class="stats-chip"><strong><?= count($items) ?></strong> workbook(s)</div></div>
    </div>
  </div>
</header>
<main class="container-fluid px-4 pb-4">
  <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
    <div class="card-body p-0">
      <div class="d-flex justify-content-between align-items-center border-bottom px-4 py-3">
        <div><h2 class="h5 mb-1">Your Workbooks</h2><div class="text-secondary small">Owned and shared spreadsheets available to your account.</div></div>
      </div>
      <?php if (empty($items)): ?>
        <div class="empty-state text-center p-5">
          <div class="empty-icon mb-3"><i class="bi bi-grid-3x3-gap"></i></div>
          <h3 class="h4">No workbooks yet</h3>
          <p class="text-secondary">Create a workbook or import a CSV/XLSX file to get started.</p>
          <div class="d-flex justify-content-center gap-2 flex-wrap">
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#newWorkbookModal">New Spreadsheet</button>
            <button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#importModal">Import CSV/XLSX</button>
          </div>
        </div>
      <?php else: ?>
      <div class="table-responsive">
        <table class="table align-middle mb-0">
          <thead class="table-light"><tr>
            <th class="ps-4">Workbook</th><th>Owner</th><th>Sheets</th><th>Revisions</th><th>Updated</th><th class="text-end pe-4">Actions</th>
          </tr></thead>
          <tbody>
            <?php foreach ($items as $item): ?>
              <tr>
                <td class="ps-4">
                  <div class="d-flex align-items-center gap-3">
                    <div class="file-avatar"><i class="bi bi-file-earmark-spreadsheet"></i></div>
                    <div>
                      <div class="fw-semibold"><?= htmlspecialchars((string)$item['title']) ?> <?php if ($item['shared']): ?><span class="badge text-bg-light border ms-1">Shared</span><?php endif; ?></div>
                      <div class="small text-secondary"><?= htmlspecialchars((string)$item['id']) ?></div>
                    </div>
                  </div>
                </td>
                <td><?= htmlspecialchars((string)$item['owner']) ?></td>
                <td><?= (int)$item['sheetCount'] ?></td>
                <td><?= (int)$item['revisionCount'] ?></td>
                <td><?= htmlspecialchars((string)date('M j, Y g:i A', strtotime((string)$item['updatedAt']))) ?></td>
                <td class="text-end pe-4">
                  <div class="btn-group">
                    <a class="btn btn-sm btn-success" href="live.php?id=<?= urlencode((string)$item['id']) ?>"><i class="bi bi-pencil-square me-1"></i>Open</a>
                    <a class="btn btn-sm btn-outline-secondary" href="api.php?action=export_json&id=<?= urlencode((string)$item['id']) ?>"><i class="bi bi-braces-asterisk me-1"></i>JSON</a>
                    <?php if ($item['owner'] === $user['username']): ?>
                    <form method="post" action="api.php?action=delete" class="d-inline-block delete-form">
                      <input type="hidden" name="id" value="<?= htmlspecialchars((string)$item['id']) ?>">
                      <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash me-1"></i>Delete</button>
                    </form>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php endif; ?>
    </div>
  </div>
</main>
<div class="modal fade" id="newWorkbookModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-dialog-centered"><div class="modal-content rounded-4 border-0 shadow"><form method="post" action="api.php?action=create"><div class="modal-header border-0 pb-0"><h2 class="modal-title fs-5">Create Spreadsheet</h2><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body pt-3"><label class="form-label">Workbook name</label><input class="form-control form-control-lg" name="title" placeholder="Quarterly Forecast" required></div><div class="modal-footer border-0 pt-0"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-success">Create</button></div></form></div></div></div>
<div class="modal fade" id="importModal" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-dialog-centered"><div class="modal-content rounded-4 border-0 shadow"><form id="importForm" method="post" action="api.php?action=import" enctype="multipart/form-data"><div class="modal-header border-0 pb-0"><h2 class="modal-title fs-5">Import Spreadsheet</h2><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div><div class="modal-body pt-3"><div class="mb-3"><label class="form-label">Workbook name</label><input class="form-control" name="title" id="importTitle" placeholder="Imported Workbook"></div><div><label class="form-label">CSV or XLSX file</label><input class="form-control" type="file" name="file" id="importFile" accept=".csv,.xlsx,.xls,text/csv" required><div class="form-text">CSV uploads go to PHP directly; XLSX is parsed in the browser and saved as a workbook.</div></div></div><div class="modal-footer border-0 pt-0"><button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary"><i class="bi bi-upload me-1"></i>Import</button></div></form></div></div></div>
<?=$addons->hook('scripts')?>
<script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
<script>
document.querySelectorAll('.delete-form').forEach(form => form.addEventListener('submit', e => { if (!confirm('Delete this workbook permanently?')) e.preventDefault(); }));
document.getElementById('importForm').addEventListener('submit', async (e) => {
  const fileInput = document.getElementById('importFile');
  const title = document.getElementById('importTitle').value.trim();
  const file = fileInput.files?.[0];
  if (!file) return;
  const name = file.name.toLowerCase();
  if (name.endsWith('.xlsx') || name.endsWith('.xls')) {
    e.preventDefault();
    const data = await file.arrayBuffer();
    const wb = XLSX.read(data, { type: 'array' });
    const workbook = { title: title || file.name.replace(/\.[^.]+$/, ''), activeSheet: 0, sheets: wb.SheetNames.map((sheetName) => {
      const ws = wb.Sheets[sheetName];
      const range = XLSX.utils.decode_range(ws['!ref'] || 'A1:A1');
      const cells = {};
      for (let r = range.s.r; r <= range.e.r; r++) for (let c = range.s.c; c <= range.e.c; c++) {
        const ref = XLSX.utils.encode_cell({ r, c });
        const cell = ws[ref];
        if (!cell || cell.v === undefined || cell.v === null || cell.v === '') continue;
        cells[ref] = { raw: typeof cell.f === 'string' ? '=' + cell.f : String(cell.w ?? cell.v), style: { bold:false, italic:false, underline:false, align:'left', fontSize:13, color:'#212529', background:'#ffffff', format:'general' } };
      }
      return { id: 'sheet_' + Math.random().toString(36).slice(2), name: sheetName, rowCount: Math.max(range.e.r + 1, 120), colCount: Math.max(range.e.c + 1, 26), cells, colWidths:{}, rowHeights:{}, merges:[], conditionalFormats:[], hiddenRows:[], comments:{}, objects:[], freeze:{topRow:1,leftCol:1} };
    }) };
    const res = await fetch('api.php?action=import_workbook', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ workbook }) });
    const result = await res.json();
    if (result.success) window.location.href = 'live.php?id=' + encodeURIComponent(result.workbook.id); else alert(result.message || 'Import failed.');
  }
});
</script>

</body></html>
