<?php
require_once __DIR__ . '/../includes/storage.php';
header('Content-Type: application/json');
$raw = file_get_contents('php://input');
$data = json_decode($raw, true);
if (!$data || empty($data['id'])) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => 'Invalid workbook payload']);
    exit;
}
save_workbook($data);
echo json_encode(['ok' => true, 'updatedAt' => date('c')]);
?>
