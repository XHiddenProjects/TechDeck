<?php
require_once __DIR__ . '/../includes/storage.php';
$wb = load_workbook($_GET['id'] ?? '');
if (!$wb) {
    http_response_code(404);
    echo 'Workbook not found';
    exit;
}
$sheet = $wb['sheets'][$wb['activeSheet'] ?? 0] ?? null;
if (!$sheet) {
    http_response_code(400);
    echo 'No active sheet';
    exit;
}
$cells = $sheet['cells'] ?? [];
$maxRow = 1;
$maxCol = 1;
foreach ($cells as $ref => $data) {
    if (preg_match('/^([A-Z]+)(\d+)$/', $ref, $m)) {
        $row = intval($m[2]);
        $letters = $m[1];
        $col = 0;
        for ($i = 0; $i < strlen($letters); $i++) {
            $col = $col * 26 + (ord($letters[$i]) - 64);
        }
        $maxRow = max($maxRow, $row);
        $maxCol = max($maxCol, $col);
    }
}
$filename = preg_replace('/[^a-zA-Z0-9_-]/', '_', ($wb['name'] ?? 'workbook')) . '.csv';
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="' . $filename . '"');
$out = fopen('php://output', 'w');
for ($r = 1; $r <= $maxRow; $r++) {
    $row = [];
    for ($c = 1; $c <= $maxCol; $c++) {
        $letters = '';
        $num = $c;
        while ($num > 0) {
            $mod = ($num - 1) % 26;
            $letters = chr(65 + $mod) . $letters;
            $num = intdiv($num - 1, 26);
        }
        $ref = $letters . $r;
        $row[] = $cells[$ref]['display'] ?? $cells[$ref]['raw'] ?? '';
    }
    fputcsv($out, $row);
}
fclose($out);
exit;
?>
