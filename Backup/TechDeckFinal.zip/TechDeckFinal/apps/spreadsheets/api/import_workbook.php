<?php
require_once __DIR__ . '/../includes/storage.php';
if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
    header('Location: ../index.php');
    exit;
}
$name = trim($_POST['name'] ?? 'Imported Workbook');
if ($name === '') $name = 'Imported Workbook';
$wb = default_workbook($name);
$wb['sheets'][0]['name'] = 'Imported';
$handle = fopen($_FILES['csv_file']['tmp_name'], 'r');
$rowIndex = 1;
$maxCols = 0;
while (($row = fgetcsv($handle)) !== false) {
    $maxCols = max($maxCols, count($row));
    foreach ($row as $colIndex => $value) {
        $letters = '';
        $num = $colIndex + 1;
        while ($num > 0) {
            $mod = ($num - 1) % 26;
            $letters = chr(65 + $mod) . $letters;
            $num = intdiv($num - 1, 26);
        }
        $wb['sheets'][0]['cells'][$letters . $rowIndex] = [
            'raw' => $value,
            'display' => $value,
            'style' => []
        ];
    }
    $rowIndex++;
}
if ($handle) fclose($handle);
$wb['sheets'][0]['rowCount'] = max(100, $rowIndex + 10);
$wb['sheets'][0]['colCount'] = max(26, $maxCols + 5);
save_workbook($wb);
header('Location: ../live.php?id=' . urlencode($wb['id']));
exit;
?>
