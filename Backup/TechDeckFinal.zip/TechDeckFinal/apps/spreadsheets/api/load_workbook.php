<?php
require_once __DIR__ . '/../includes/storage.php';
header('Content-Type: application/json');
$wb = load_workbook($_GET['id'] ?? '');
if (!$wb) {
    http_response_code(404);
    echo json_encode(['ok' => false, 'message' => 'Workbook not found']);
    exit;
}
echo json_encode(['ok' => true, 'workbook' => $wb], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>
