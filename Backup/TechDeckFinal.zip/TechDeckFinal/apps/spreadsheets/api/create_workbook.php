<?php
require_once __DIR__ . '/../includes/storage.php';
$name = trim($_POST['name'] ?? 'Book 1');
if ($name === '') $name = 'Book 1';
$workbook = default_workbook($name);
save_workbook($workbook);
header('Location: ../live.php?id=' . urlencode($workbook['id']));
exit;
?>
