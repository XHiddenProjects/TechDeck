<?php
require_once __DIR__ . '/../includes/storage.php';
if (!empty($_POST['id'])) {
    delete_workbook($_POST['id']);
}
header('Location: ../index.php');
exit;
?>
