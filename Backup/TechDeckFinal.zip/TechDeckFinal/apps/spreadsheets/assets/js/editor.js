(function () {
    const { FormulaEngine, splitRef, indexToCol, colToIndex, refsInRange, FUNCTION_META, KNOWN_FUNCTIONS } = window.SpreadsheetFormulaEngine;
    const DEFAULT_STYLE = { bold:false, italic:false, underline:false, align:'left', fontSize:13, color:'#212529', background:'#ffffff', format:'general' };

    const state = {
        workbook: structuredClone(window.__WORKBOOK__),
        currentUser: window.__CURRENT_USER__,
        activeSheetIndex: window.__WORKBOOK__.activeSheet || 0,
        selectedRef: 'A1',
        selection: { startRef: 'A1', endRef: 'A1' },
        editingRef: null,
        formulaEditRef: null,
        chartPreview: null,
        objectCharts: [],
        saveTimer: null,
        isDirty: false,
        undoStack: [],
        redoStack: [],
        dragSelecting: false,
        resizing: null,
        lastServerUpdatedAt: window.__WORKBOOK__.updatedAt || null,
    };

    const els = {
        titleDisplay: document.getElementById('workbookTitleDisplay'),
        selectionDisplay: document.getElementById('selectionDisplay'),
        saveStatus: document.getElementById('saveStatus'),
        grid: document.getElementById('sheetGrid'),
        gridHost: document.getElementById('gridHost'),
        gridScroller: document.getElementById('gridScroller'),
        objectsLayer: document.getElementById('objectsLayer'),
        nameBox: document.getElementById('nameBox'),
        formulaBar: document.getElementById('formulaBar'),
        formulaSuggestions: document.getElementById('formulaSuggestions'),
        sheetTabs: document.getElementById('sheetTabs'),
        exportCsvBtn: document.getElementById('exportCsvBtn'),
        exportJsonBtn: document.getElementById('exportJsonBtn'),
        exportXlsxBtn: document.getElementById('exportXlsxBtn'),
        chartRangeInput: document.getElementById('chartRangeInput'),
        chartTitleInput: document.getElementById('chartTitleInput'),
        chartTypeSelect: document.getElementById('chartTypeSelect'),
        previewChartBtn: document.getElementById('previewChartBtn'),
        insertChartBtn: document.getElementById('insertChartBtn'),
        textColorInput: document.getElementById('textColorInput'),
        fillColorInput: document.getElementById('fillColorInput'),
        fontSizeSelect: document.getElementById('fontSizeSelect'),
        alignSelect: document.getElementById('alignSelect'),
        formatSelect: document.getElementById('formatSelect'),
        historyList: document.getElementById('historyList'),
        auditList: document.getElementById('auditList'),
        commentHistory: document.getElementById('commentHistory'),
        contextMenu: document.getElementById('contextMenu'),
        formulaCatalog: document.getElementById('formulaCatalog'),
        formulaSearchInput: document.getElementById('formulaSearchInput'),
        freezeTopToggle: document.getElementById('freezeTopToggle'),
        freezeLeftToggle: document.getElementById('freezeLeftToggle')
    };

    const modals = {
        chart: new bootstrap.Modal(document.getElementById('chartModal')),
        conditional: new bootstrap.Modal(document.getElementById('conditionalModal')),
        object: new bootstrap.Modal(document.getElementById('objectModal')),
        comment: new bootstrap.Modal(document.getElementById('commentModal')),
        share: new bootstrap.Modal(document.getElementById('shareModal')),
        history: new bootstrap.Modal(document.getElementById('historyModal')),
        audit: new bootstrap.Modal(document.getElementById('auditModal')),
        formulaHelper: new bootstrap.Modal(document.getElementById('formulaHelperModal')),
    };

    function currentSheet() { return state.workbook.sheets[state.activeSheetIndex]; }
    function activeEngine() { return new FormulaEngine(currentSheet()); }
    function clone(obj) { return JSON.parse(JSON.stringify(obj)); }
    function snapshotState() { return clone(state.workbook); }
    function normalizeSheet(sheet) {
        sheet.cells = sheet.cells || {};
        sheet.rowCount = Math.max(1, sheet.rowCount || 120);
        sheet.colCount = Math.max(1, sheet.colCount || 26);
        sheet.name = sheet.name || `Sheet${state.activeSheetIndex + 1}`;
        sheet.merges = Array.isArray(sheet.merges) ? sheet.merges : [];
        sheet.conditionalFormats = Array.isArray(sheet.conditionalFormats) ? sheet.conditionalFormats : [];
        sheet.hiddenRows = Array.isArray(sheet.hiddenRows) ? sheet.hiddenRows : [];
        sheet.comments = sheet.comments || {};
        sheet.objects = Array.isArray(sheet.objects) ? sheet.objects : [];
        sheet.colWidths = sheet.colWidths || {};
        sheet.rowHeights = sheet.rowHeights || {};
        sheet.freeze = sheet.freeze || { topRow: 1, leftCol: 1 };
    }
    function ensureCell(ref) {
        const sheet = currentSheet(); normalizeSheet(sheet);
        if (!sheet.cells[ref]) sheet.cells[ref] = { raw:'', style: clone(DEFAULT_STYLE) };
        else sheet.cells[ref].style = { ...DEFAULT_STYLE, ...(sheet.cells[ref].style || {}) };
        return sheet.cells[ref];
    }
    function getCell(ref) { return currentSheet().cells?.[ref] || null; }
    function setSaveStatus(text, cls) { els.saveStatus.className = `badge border ${cls}`; els.saveStatus.textContent = text; }
    function pushUndoSnapshot() { state.undoStack.push(snapshotState()); if (state.undoStack.length > 80) state.undoStack.shift(); state.redoStack = []; }
    function escapeHtml(text) { return String(text).replace(/[&<>"']/g, s => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[s])); }
    function refToRC(ref) { const p = splitRef(ref); return { row:p.row, col:colToIndex(p.col) }; }
    function rcToRef(row, col) { return `${indexToCol(col)}${row}`; }
    function selectionBounds() { const s = refToRC(state.selection.startRef), e = refToRC(state.selection.endRef); return { startRow:Math.min(s.row,e.row), endRow:Math.max(s.row,e.row), startCol:Math.min(s.col,e.col), endCol:Math.max(s.col,e.col) }; }
    function selectionRangeString() { const b = selectionBounds(); const a = rcToRef(b.startRow,b.startCol), z = rcToRef(b.endRow,b.endCol); return a === z ? a : `${a}:${z}`; }
    function isCellInSelection(ref) { const { row, col } = refToRC(ref); const b = selectionBounds(); return row >= b.startRow && row <= b.endRow && col >= b.startCol && col <= b.endCol; }
    function isSelectionEdge(ref) { const { row, col } = refToRC(ref); const b = selectionBounds(); return isCellInSelection(ref) && (row === b.startRow || row === b.endRow || col === b.startCol || col === b.endCol); }
    function rangeRefs(range) { return refsInRange(range.toUpperCase()); }
    function selectedComments(ref) { const comments = currentSheet().comments?.[ref]; return Array.isArray(comments) ? comments : []; }

    function markDirty(pushSnapshot = false) {
        if (pushSnapshot) pushUndoSnapshot();
        state.isDirty = true;
        setSaveStatus('Saving...', 'text-bg-warning');
        clearTimeout(state.saveTimer);
        state.saveTimer = setTimeout(saveWorkbook, 650);
    }

    async function saveWorkbook() {
        try {
            const res = await fetch('api.php?action=save', { method:'POST', headers:{ 'Content-Type':'application/json' }, body: JSON.stringify({ workbook: state.workbook }) });
            const data = await res.json();
            if (!data.success) throw new Error(data.message || 'Save failed');
            state.isDirty = false;
            state.lastServerUpdatedAt = data.updatedAt;
            setSaveStatus('Saved', 'text-bg-success');
        } catch (err) {
            console.error(err);
            setSaveStatus('Save error', 'text-bg-danger');
        }
    }

    async function pollForRemoteChanges() {
        try {
            const res = await fetch(`api.php?action=poll&id=${encodeURIComponent(state.workbook.id)}`, { headers: { 'Accept':'application/json' } });
            const data = await res.json();
            if (!data.success || !data.updatedAt) return;
            if (state.lastServerUpdatedAt && new Date(data.updatedAt) > new Date(state.lastServerUpdatedAt)) {
                if (state.isDirty) {
                    setSaveStatus('Remote changes available', 'text-bg-warning');
                } else {
                    const loadRes = await fetch(`api.php?action=load&id=${encodeURIComponent(state.workbook.id)}`, { headers: { 'Accept':'application/json' } });
                    const loadData = await loadRes.json();
                    if (loadData.success) {
                        state.workbook = structuredClone(loadData.workbook);
                        state.activeSheetIndex = state.workbook.activeSheet || 0;
                        state.lastServerUpdatedAt = state.workbook.updatedAt || data.updatedAt;
                        render();
                        setSaveStatus('Updated from server', 'text-bg-light');
                    }
                }
            }
        } catch (err) {
            console.warn('poll failed', err);
        }
    }

    function updateTitle() {
        els.titleDisplay.textContent = state.workbook.title || 'Untitled Workbook';
        els.selectionDisplay.textContent = selectionRangeString();
        els.nameBox.textContent = state.selectedRef;
        const id = encodeURIComponent(state.workbook.id);
        els.exportCsvBtn.href = `api.php?action=export_csv&id=${id}&sheet=${state.activeSheetIndex}`;
        els.exportJsonBtn.href = `api.php?action=export_json&id=${id}`;
        const freeze = currentSheet().freeze || { topRow: 1, leftCol: 1 };
        els.freezeTopToggle.checked = !!freeze.topRow;
        els.freezeLeftToggle.checked = !!freeze.leftCol;
        els.gridScroller.classList.toggle('grid-no-freeze-top', !freeze.topRow);
        els.gridScroller.classList.toggle('grid-no-freeze-left', !freeze.leftCol);
    }

    function applyStyleToInline(style) {
        return [
            `font-weight:${style.bold ? '700':'400'}`,
            `font-style:${style.italic ? 'italic':'normal'}`,
            `text-decoration:${style.underline ? 'underline':'none'}`,
            `text-align:${style.align || 'left'}`,
            `font-size:${style.fontSize || 13}px`,
            `color:${style.color || '#212529'}`,
            `background:${style.background || '#ffffff'}`,
        ].join(';');
    }

    function conditionalStyle(ref, value) {
        for (const rule of (currentSheet().conditionalFormats || [])) {
            if (!rangeRefs(rule.range || '').includes(ref)) continue;
            const stringVal = String(value ?? '');
            const numVal = Number(value);
            let ok = false;
            if (rule.operator === '>') ok = Number.isFinite(numVal) && numVal > Number(rule.value);
            else if (rule.operator === '<') ok = Number.isFinite(numVal) && numVal < Number(rule.value);
            else if (rule.operator === '=') ok = stringVal === String(rule.value);
            else if (rule.operator === 'contains') ok = stringVal.toLowerCase().includes(String(rule.value).toLowerCase());
            if (ok) return { color: rule.color, background: rule.background };
        }
        return null;
    }

    function buildMergeMaps() {
        const renderMap = new Map();
        const skip = new Set();
        (currentSheet().merges || []).forEach(m => {
            const key = `${m.startRow}:${m.startCol}`;
            renderMap.set(key, m);
            for (let r = m.startRow; r < m.startRow + m.rowspan; r++) {
                for (let c = m.startCol; c < m.startCol + m.colspan; c++) {
                    if (r === m.startRow && c === m.startCol) continue;
                    skip.add(`${r}:${c}`);
                }
            }
        });
        return { renderMap, skip };
    }

    function renderGrid() {
        normalizeSheet(currentSheet());
        const sheet = currentSheet();
        const engine = activeEngine();
        const { renderMap, skip } = buildMergeMaps();
        let html = '<tr><th class="corner-cell"></th>';
        for (let c = 0; c < sheet.colCount; c++) {
            const width = sheet.colWidths[c] || 120;
            html += `<th style="width:${width}px;min-width:${width}px"><div class="col-header" data-col="${c}">${indexToCol(c)}<div class="col-resizer" data-col-resizer="${c}"></div></div></th>`;
        }
        html += '</tr>';
        for (let r = 1; r <= sheet.rowCount; r++) {
            if (sheet.hiddenRows.includes(r)) continue;
            const rowHeight = sheet.rowHeights[r] || 28;
            html += `<tr style="height:${rowHeight}px"><th class="row-header" style="height:${rowHeight}px"><div class="row-header-inner" data-row="${r}">${r}<div class="row-resizer" data-row-resizer="${r}"></div></div></th>`;
            for (let c = 0; c < sheet.colCount; c++) {
                if (skip.has(`${r}:${c}`)) continue;
                const ref = rcToRef(r,c);
                const cell = getCell(ref);
                const style = { ...DEFAULT_STYLE, ...(cell?.style || {}) };
                const evaluated = engine.evaluateCell(ref);
                const cfStyle = conditionalStyle(ref, evaluated);
                if (cfStyle) Object.assign(style, cfStyle);
                const value = engine.formatValue(evaluated, style);
                const classes = [];
                if (ref === state.selectedRef) classes.push('active-cell');
                if (isCellInSelection(ref)) classes.push('range-cell');
                if (isSelectionEdge(ref)) classes.push('range-edge');
                if (selectedComments(ref).length) classes.push('comment-cell');
                const merge = renderMap.get(`${r}:${c}`);
                const rowspan = merge ? ` rowspan="${merge.rowspan}"` : '';
                const colspan = merge ? ` colspan="${merge.colspan}"` : '';
                const width = sheet.colWidths[c] || 120;
                const titleAttr = selectedComments(ref).length ? ` title="${escapeHtml(selectedComments(ref).slice(-1)[0].text)}"` : '';
                html += `<td data-ref="${ref}" class="${classes.join(' ')}" style="width:${width}px;min-width:${width}px;height:${rowHeight}px"${rowspan}${colspan}${titleAttr}><div class="cell-inner" style="${applyStyleToInline(style)}">${escapeHtml(String(value ?? ''))}</div></td>`;
            }
            html += '</tr>';
        }
        els.grid.innerHTML = html;
        requestAnimationFrame(renderObjectsLayer);
    }

    function renderObjectsLayer() {
        state.objectCharts.forEach(ch => ch.destroy());
        state.objectCharts = [];
        els.objectsLayer.innerHTML = '';
        const objects = currentSheet().objects || [];
        objects.forEach(obj => {
            const cellEl = els.grid.querySelector(`td[data-ref="${CSS.escape(obj.ref)}"]`);
            if (!cellEl) return;
            const sheetRect = els.gridHost.getBoundingClientRect();
            const cellRect = cellEl.getBoundingClientRect();
            const left = cellEl.offsetLeft + (obj.x || 8);
            const top = cellEl.offsetTop + (obj.y || 8);
            const wrap = document.createElement('div');
            wrap.className = 'worksheet-object';
            wrap.style.left = `${left}px`;
            wrap.style.top = `${top}px`;
            wrap.style.width = `${obj.width || 260}px`;
            wrap.dataset.objectId = obj.id;
            wrap.innerHTML = `<div class="object-header"><span>${escapeHtml(obj.label || obj.type)}</span><div class="d-flex gap-1"><button class="btn btn-sm btn-light border p-1" data-object-action="nudge" data-object-id="${obj.id}" data-dx="10" title="Move right"><i class="bi bi-arrow-right"></i></button><button class="btn btn-sm btn-light border p-1" data-object-action="delete" data-object-id="${obj.id}" title="Delete"><i class="bi bi-x-lg"></i></button></div></div><div class="object-body"></div>`;
            const body = wrap.querySelector('.object-body');
            if (obj.type === 'image') {
                body.innerHTML = `<img src="${escapeHtml(obj.url)}" alt="${escapeHtml(obj.label || 'Image object')}">`;
            } else if (obj.type === 'video') {
                if (/youtube\.com|youtu\.be/.test(obj.url || '')) {
                    const embed = toYouTubeEmbed(obj.url);
                    body.innerHTML = `<iframe src="${escapeHtml(embed)}" allowfullscreen></iframe>`;
                } else {
                    body.innerHTML = `<video controls src="${escapeHtml(obj.url)}"></video>`;
                }
            } else if (obj.type === 'link') {
                body.innerHTML = `<a class="object-link" href="${escapeHtml(obj.url)}" target="_blank" rel="noopener"><i class="bi bi-link-45deg me-1"></i>${escapeHtml(obj.label || obj.url)}</a>`;
            } else if (obj.type === 'chart') {
                body.innerHTML = `<canvas id="chart_${obj.id}" style="width:100%;height:220px"></canvas>`;
            }
            els.objectsLayer.appendChild(wrap);
            if (obj.type === 'chart') {
                const canvas = body.querySelector('canvas');
                const data = parseRangeToSeries(obj.range || selectionRangeString());
                if (canvas && data) {
                    const chart = new Chart(canvas, {
                        type: obj.chartType || 'bar',
                        data: { labels: data.labels, datasets: [{ label: obj.label || obj.range || 'Chart', data: data.values, borderColor:'#198754', backgroundColor:['#198754','#0d6efd','#ffc107','#dc3545','#6f42c1','#20c997','#fd7e14','#6610f2'], borderWidth:2, fill:false }] },
                        options: { responsive:true, maintainAspectRatio:false, plugins:{ legend:{ display:false }, title:{ display: !!obj.label, text: obj.label || '' } } }
                    });
                    state.objectCharts.push(chart);
                }
            }
        });
    }

    function renderSheetTabs() {
        els.sheetTabs.innerHTML = '';
        state.workbook.sheets.forEach((sheet, idx) => {
            const btn = document.createElement('button');
            btn.className = `sheet-tab ${idx === state.activeSheetIndex ? 'active' : ''}`;
            btn.textContent = sheet.name;
            btn.addEventListener('click', () => { state.activeSheetIndex = idx; state.workbook.activeSheet = idx; selectCell('A1'); render(); });
            els.sheetTabs.appendChild(btn);
        });
    }

    function syncFormulaBar() { els.formulaBar.value = ensureCell(state.selectedRef).raw ?? ''; els.nameBox.textContent = state.selectedRef; }
    function syncToolbar() {
        const style = { ...DEFAULT_STYLE, ...(ensureCell(state.selectedRef).style || {}) };
        els.textColorInput.value = style.color;
        els.fillColorInput.value = style.background;
        els.fontSizeSelect.value = String(style.fontSize || 13);
        els.alignSelect.value = style.align || 'left';
        els.formatSelect.value = style.format || 'general';
    }
    function render() { updateTitle(); renderSheetTabs(); renderGrid(); syncFormulaBar(); syncToolbar(); renderFormulaCatalog(); }

    function selectCell(ref, extend = false) {
        if (extend) state.selection.endRef = ref;
        else state.selection = { startRef: ref, endRef: ref };
        state.selectedRef = ref;
        updateTitle(); syncFormulaBar(); syncToolbar(); renderGrid();
    }

    function startEdit(ref) {
        state.editingRef = ref;
        state.selectedRef = ref;
        state.selection = { startRef: ref, endRef: ref };
        renderGrid();
        const td = els.grid.querySelector(`td[data-ref="${CSS.escape(ref)}"]`);
        if (!td) return;
        const cell = ensureCell(ref);
        td.classList.add('editing');
        td.innerHTML = '<input>';
        const input = td.querySelector('input');
        input.value = cell.raw ?? '';
        input.focus(); input.select();
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') { e.preventDefault(); commitEdit(ref, input.value, 'down'); }
            else if (e.key === 'Tab') { e.preventDefault(); commitEdit(ref, input.value, e.shiftKey ? 'left' : 'right'); }
            else if (e.key === 'Escape') { e.preventDefault(); state.editingRef = null; render(); }
        });
        input.addEventListener('blur', () => commitEdit(ref, input.value));
    }

    function updateCellRaw(ref, value) {
        const cell = ensureCell(ref);
        if ((cell.raw ?? '') === value) return;
        markDirty(true);
        cell.raw = value;
        render();
    }
    function commitEdit(ref, raw, moveDir = null) {
        if (state.editingRef !== ref) return;
        state.editingRef = null;
        updateCellRaw(ref, raw);
        if (moveDir) navigate(moveDir);
    }

    function navigate(direction) {
        const parts = splitRef(state.selectedRef); if (!parts) return;
        let c = colToIndex(parts.col), r = parts.row;
        if (direction === 'up') r = Math.max(1, r - 1);
        if (direction === 'down') r = Math.min(currentSheet().rowCount, r + 1);
        if (direction === 'left') c = Math.max(0, c - 1);
        if (direction === 'right') c = Math.min(currentSheet().colCount - 1, c + 1);
        selectCell(rcToRef(r, c));
        els.grid.querySelector(`td[data-ref="${CSS.escape(state.selectedRef)}"]`)?.scrollIntoView({ block:'nearest', inline:'nearest' });
    }

    function forEachSelectedCell(callback) {
        const b = selectionBounds();
        for (let r = b.startRow; r <= b.endRow; r++) for (let c = b.startCol; c <= b.endCol; c++) callback(rcToRef(r,c), r, c);
    }

    function applyStyle(patch) { markDirty(true); forEachSelectedCell(ref => { const cell = ensureCell(ref); cell.style = { ...DEFAULT_STYLE, ...(cell.style || {}), ...patch }; }); render(); }
    function clearSelectedCell() { markDirty(true); forEachSelectedCell(ref => { ensureCell(ref).raw = ''; }); render(); }
    function addRow() { markDirty(true); currentSheet().rowCount += 1; render(); }
    function addColumn() { markDirty(true); currentSheet().colCount += 1; render(); }
    function addSheet() { markDirty(true); state.workbook.sheets.push({ id:`sheet_${Date.now()}`, name:`Sheet${state.workbook.sheets.length + 1}`, rowCount:120, colCount:26, cells:{}, colWidths:{}, rowHeights:{}, merges:[], conditionalFormats:[], hiddenRows:[], comments:{}, objects:[], freeze:{ topRow:1, leftCol:1 } }); state.activeSheetIndex = state.workbook.sheets.length - 1; state.workbook.activeSheet = state.activeSheetIndex; selectCell('A1'); render(); }
    function renameSheet() { const name = prompt('Rename sheet', currentSheet().name); if (!name) return; markDirty(true); currentSheet().name = name.trim(); render(); }
    function deleteSheet() { if (state.workbook.sheets.length <= 1) return alert('A workbook must have at least one sheet.'); if (!confirm(`Delete sheet "${currentSheet().name}"?`)) return; markDirty(true); state.workbook.sheets.splice(state.activeSheetIndex, 1); state.activeSheetIndex = Math.max(0, state.activeSheetIndex - 1); state.workbook.activeSheet = state.activeSheetIndex; selectCell('A1'); render(); }
    function renameWorkbook() { const title = prompt('Rename workbook', state.workbook.title || 'Untitled Workbook'); if (!title) return; markDirty(true); state.workbook.title = title.trim(); render(); }

    function rangesOverlap(a, b) {
        const aEndRow = a.startRow + a.rowspan - 1, aEndCol = a.startCol + a.colspan - 1;
        const bEndRow = b.startRow + b.rowspan - 1, bEndCol = b.startCol + b.colspan - 1;
        return !(aEndRow < b.startRow || bEndRow < a.startRow || aEndCol < b.startCol || bEndCol < a.startCol);
    }
    function mergeSelection() {
        const b = selectionBounds();
        if (b.startRow === b.endRow && b.startCol === b.endCol) return alert('Select more than one cell to merge.');
        markDirty(true);
        currentSheet().merges = (currentSheet().merges || []).filter(m => !rangesOverlap(m, { startRow:b.startRow, startCol:b.startCol, rowspan:b.endRow-b.startRow+1, colspan:b.endCol-b.startCol+1 }));
        currentSheet().merges.push({ startRow:b.startRow, startCol:b.startCol, rowspan:b.endRow-b.startRow+1, colspan:b.endCol-b.startCol+1 });
        render();
    }
    function unmergeSelection() {
        const b = selectionBounds();
        markDirty(true);
        currentSheet().merges = (currentSheet().merges || []).filter(m => !(m.startRow >= b.startRow && m.startRow <= b.endRow && m.startCol >= b.startCol && m.startCol <= b.endCol));
        render();
    }

    function openConditionalModal() { document.getElementById('cfRangeInput').value = selectionRangeString(); modals.conditional.show(); }
    function saveConditionalRule() {
        const range = document.getElementById('cfRangeInput').value.trim();
        if (!range) return alert('Enter a range.');
        markDirty(true);
        currentSheet().conditionalFormats.push({ id: 'cf_' + Date.now(), range, operator: document.getElementById('cfOperator').value, value: document.getElementById('cfValue').value, color: document.getElementById('cfTextColor').value, background: document.getElementById('cfFillColor').value });
        modals.conditional.hide();
        render();
    }
    function clearConditionalRange() {
        const selected = new Set(rangeRefs(selectionRangeString()));
        if (!selected.size) return;
        markDirty(true);
        currentSheet().conditionalFormats = (currentSheet().conditionalFormats || []).filter(rule => {
            const refs = rangeRefs(rule.range || '');
            return !refs.some(ref => selected.has(ref));
        });
        render();
    }

    function sortSelection(direction) {
        const b = selectionBounds();
        if (b.startCol !== b.endCol) return alert('Select a single column range to sort.');
        const refs = [];
        for (let r = b.startRow; r <= b.endRow; r++) refs.push(rcToRef(r, b.startCol));
        const rows = refs.map(ref => ({ ref, raw: ensureCell(ref).raw ?? '' }));
        rows.sort((a, bItem) => direction === 'asc' ? String(a.raw).localeCompare(String(bItem.raw), undefined, { numeric:true, sensitivity:'base' }) : String(bItem.raw).localeCompare(String(a.raw), undefined, { numeric:true, sensitivity:'base' }));
        markDirty(true);
        rows.forEach((row, i) => { ensureCell(refs[i]).raw = row.raw; });
        render();
    }
    function filterNonBlank() {
        const b = selectionBounds();
        if (b.startCol !== b.endCol) return alert('Select a single column range to filter.');
        markDirty(true);
        const hidden = [];
        for (let r = 1; r <= currentSheet().rowCount; r++) {
            const ref = rcToRef(r, b.startCol);
            const val = ensureCell(ref).raw ?? '';
            if (r >= b.startRow && r <= b.endRow && String(val).trim() === '') hidden.push(r);
        }
        currentSheet().hiddenRows = hidden;
        render();
    }
    function clearFilter() { markDirty(true); currentSheet().hiddenRows = []; render(); }

    function parseRangeToSeries(range) {
        const refs = refsInRange(range.toUpperCase()); if (!refs.length) return null;
        const [a, b] = range.split(':').map(splitRef); if (!a || !b) return null;
        const startCol = Math.min(colToIndex(a.col), colToIndex(b.col)), endCol = Math.max(colToIndex(a.col), colToIndex(b.col));
        const startRow = Math.min(a.row, b.row), endRow = Math.max(a.row, b.row);
        const engine = activeEngine(), labels = [], values = [];
        if (endCol - startCol >= 1) {
            for (let r = startRow; r <= endRow; r++) {
                labels.push(String(engine.evaluateCell(rcToRef(r, startCol)) ?? ''));
                values.push(Number(engine.evaluateCell(rcToRef(r, startCol + 1))) || 0);
            }
        } else {
            for (let r = startRow; r <= endRow; r++) {
                labels.push(rcToRef(r, startCol));
                values.push(Number(engine.evaluateCell(rcToRef(r, startCol))) || 0);
            }
        }
        return { labels, values };
    }
    function previewChart() {
        const range = els.chartRangeInput.value.trim();
        if (!range) return alert('Enter a range such as A1:B5');
        const data = parseRangeToSeries(range); if (!data) return alert('Invalid range');
        const ctx = document.getElementById('chartCanvas');
        if (state.chartPreview) state.chartPreview.destroy();
        state.chartPreview = new Chart(ctx, { type: els.chartTypeSelect.value, data: { labels: data.labels, datasets: [{ label: els.chartTitleInput.value || range, data: data.values, borderColor:'#198754', backgroundColor:['#198754','#0d6efd','#ffc107','#dc3545','#6f42c1','#20c997','#fd7e14','#6610f2'], borderWidth:2, fill:false }] }, options: { responsive:true, maintainAspectRatio:false } });
    }
    function insertChartObject() {
        const range = els.chartRangeInput.value.trim(); if (!range) return alert('Enter a range.');
        markDirty(true);
        currentSheet().objects.push({ id: 'obj_' + Date.now(), type:'chart', ref: state.selectedRef, range, chartType: els.chartTypeSelect.value, label: els.chartTitleInput.value || `Chart ${range}`, width: 340, x: 8, y: 8 });
        modals.chart.hide(); render();
    }

    function openObjectModal(type) {
        document.getElementById('objectTypeInput').value = type;
        document.getElementById('objectModalTitle').textContent = `Insert ${type.charAt(0).toUpperCase() + type.slice(1)}`;
        document.getElementById('objectAnchorInput').value = state.selectedRef;
        document.getElementById('objectLabelInput').value = '';
        document.getElementById('objectUrlInput').value = '';
        modals.object.show();
    }
    function saveObjectInsert() {
        const type = document.getElementById('objectTypeInput').value;
        const ref = (document.getElementById('objectAnchorInput').value || state.selectedRef).toUpperCase();
        const label = document.getElementById('objectLabelInput').value.trim();
        const url = document.getElementById('objectUrlInput').value.trim();
        if (!type || !url) return alert('Please provide a valid URL.');
        markDirty(true);
        currentSheet().objects.push({ id:'obj_' + Date.now(), type, ref, label: label || type, url, width: type === 'link' ? 240 : 300, x:8, y:8 });
        modals.object.hide(); render();
    }
    function toYouTubeEmbed(url) {
        try {
            const u = new URL(url);
            if (u.hostname.includes('youtu.be')) return `https://www.youtube.com/embed/${u.pathname.replace('/', '')}`;
            if (u.searchParams.get('v')) return `https://www.youtube.com/embed/${u.searchParams.get('v')}`;
        } catch (e) {}
        return url;
    }

    function openCommentModal() {
        document.getElementById('commentCellInput').value = state.selectedRef;
        document.getElementById('commentTextInput').value = '';
        const comments = selectedComments(state.selectedRef);
        els.commentHistory.innerHTML = comments.length ? comments.map(c => `<div class="mb-2"><strong>${escapeHtml(c.author)}</strong> <span class="text-secondary">${new Date(c.createdAt).toLocaleString()}</span><div>${escapeHtml(c.text)}</div></div>`).join('') : 'No comments yet.';
        modals.comment.show();
    }
    function saveComment() {
        const ref = document.getElementById('commentCellInput').value;
        const text = document.getElementById('commentTextInput').value.trim();
        if (!text) return;
        markDirty(true);
        currentSheet().comments[ref] = Array.isArray(currentSheet().comments[ref]) ? currentSheet().comments[ref] : [];
        currentSheet().comments[ref].push({ author: state.currentUser.displayName || state.currentUser.username, text, createdAt: new Date().toISOString() });
        modals.comment.hide(); render();
    }

    async function shareWorkbook() {
        const shareWith = document.getElementById('shareUsernameInput').value.trim();
        if (!shareWith) return;
        const form = new FormData();
        form.append('id', state.workbook.id);
        form.append('shareWith', shareWith);
        const res = await fetch('api.php?action=share', { method:'POST', body: form, headers:{ 'Accept':'application/json' } });
        const data = await res.json();
        if (!data.success) return alert(data.message || 'Share failed.');
        modals.share.hide();
        alert(`Workbook shared with ${shareWith}.`);
    }

    function exportXlsx() {
        const wb = XLSX.utils.book_new();
        state.workbook.sheets.forEach(sheet => {
            const rows = [];
            for (let r = 1; r <= sheet.rowCount; r++) {
                const row = [];
                for (let c = 0; c < sheet.colCount; c++) row.push(sheet.cells?.[rcToRef(r,c)]?.raw ?? '');
                rows.push(row);
            }
            const ws = XLSX.utils.aoa_to_sheet(rows);
            XLSX.utils.book_append_sheet(wb, ws, sheet.name || 'Sheet');
        });
        XLSX.writeFile(wb, `${state.workbook.title || 'Workbook'}.xlsx`);
    }

    function undo() { if (!state.undoStack.length) return; state.redoStack.push(snapshotState()); state.workbook = state.undoStack.pop(); state.activeSheetIndex = state.workbook.activeSheet || 0; render(); markDirty(false); }
    function redo() { if (!state.redoStack.length) return; state.undoStack.push(snapshotState()); state.workbook = state.redoStack.pop(); state.activeSheetIndex = state.workbook.activeSheet || 0; render(); markDirty(false); }

    function showHistory() {
        els.historyList.innerHTML = '';
        const revisions = [...(state.workbook.revisions || [])].reverse();
        if (!revisions.length) els.historyList.innerHTML = '<div class="list-group-item">No saved revisions yet.</div>';
        revisions.forEach(rev => {
            const item = document.createElement('button');
            item.type = 'button'; item.className = 'list-group-item list-group-item-action d-flex justify-content-between align-items-center';
            item.innerHTML = `<span><strong>${new Date(rev.savedAt).toLocaleString()}</strong><br><small class="text-secondary">${escapeHtml(rev.title)}</small></span><span class="btn btn-sm btn-outline-primary">Restore</span>`;
            item.addEventListener('click', () => {
                if (!confirm('Restore this revision? Current unsaved state will be replaced.')) return;
                pushUndoSnapshot();
                state.workbook.title = rev.title;
                state.workbook.activeSheet = rev.activeSheet || 0;
                state.workbook.sheets = clone(rev.sheets || state.workbook.sheets);
                state.activeSheetIndex = state.workbook.activeSheet || 0;
                modals.history.hide(); markDirty(false); render();
            });
            els.historyList.appendChild(item);
        });
        modals.history.show();
    }
    function showAudit() {
        els.auditList.innerHTML = '';
        const entries = [...(state.workbook.auditTrail || [])].reverse();
        if (!entries.length) els.auditList.innerHTML = '<div class="list-group-item">No audit events yet.</div>';
        entries.forEach(entry => {
            const item = document.createElement('div');
            item.className = 'list-group-item';
            item.innerHTML = `<strong>${escapeHtml(entry.user || 'User')}</strong> • ${escapeHtml(entry.action || 'action')}<div class="small text-secondary">${new Date(entry.at).toLocaleString()}</div>`;
            els.auditList.appendChild(item);
        });
        modals.audit.show();
    }

    function renderFormulaCatalog() {
        const term = (els.formulaSearchInput.value || '').trim().toUpperCase();
        const items = KNOWN_FUNCTIONS.filter(name => !term || name.includes(term) || FUNCTION_META[name].desc.toUpperCase().includes(term));
        els.formulaCatalog.innerHTML = items.map(name => `<div class="formula-card"><h6>${name}</h6><div class="text-secondary small">${escapeHtml(FUNCTION_META[name].desc)}</div><code>${escapeHtml(FUNCTION_META[name].syntax)}</code><button class="btn btn-sm btn-outline-primary mt-2" data-insert-formula="${name}">Insert</button></div>`).join('');
        els.formulaCatalog.querySelectorAll('[data-insert-formula]').forEach(btn => {
            btn.addEventListener('click', () => {
                const name = btn.dataset.insertFormula;
                const syntax = FUNCTION_META[name].syntax;
                const template = '=' + syntax.replace(name, name).replace(/\[[^\]]+\]/g, '').replace(/number1|number2|value1|value2|text1|text2|logical1|logical2|lookup_value|range|criteria|sum_range|row_num|col_num|power|digits|condition|value_if_true|value_if_false|fallback|old_text|new_text|text|value/g, '');
                const finalTemplate = '=' + name + '(' + selectionRangeString() + ')';
                els.formulaBar.value = finalTemplate;
                els.formulaBar.focus();
                modals.formulaHelper.hide();
            });
        });
    }

    function updateFormulaSuggestions() {
        const value = els.formulaBar.value;
        const match = /^=([A-Z]*)$/i.exec(value.trim());
        if (!match) { els.formulaSuggestions.classList.add('d-none'); els.formulaSuggestions.innerHTML = ''; return; }
        const term = match[1].toUpperCase();
        const suggestions = KNOWN_FUNCTIONS.filter(name => name.startsWith(term)).slice(0, 8);
        if (!suggestions.length) { els.formulaSuggestions.classList.add('d-none'); els.formulaSuggestions.innerHTML = ''; return; }
        els.formulaSuggestions.innerHTML = suggestions.map((name, idx) => `<div class="formula-suggestion ${idx===0 ? 'active':''}" data-formula-suggestion="${name}"><strong>${name}</strong><small>${escapeHtml(FUNCTION_META[name].desc)}</small></div>`).join('');
        els.formulaSuggestions.classList.remove('d-none');
        els.formulaSuggestions.querySelectorAll('[data-formula-suggestion]').forEach(item => item.addEventListener('mousedown', (e) => {
            e.preventDefault();
            const name = item.dataset.formulaSuggestion;
            els.formulaBar.value = '=' + name + '(' + selectionRangeString() + ')';
            els.formulaSuggestions.classList.add('d-none');
            els.formulaBar.focus();
        }));
    }

    function copySelected() {
        const b = selectionBounds(); const lines = [];
        for (let r = b.startRow; r <= b.endRow; r++) {
            const row = [];
            for (let c = b.startCol; c <= b.endCol; c++) row.push(ensureCell(rcToRef(r,c)).raw ?? '');
            lines.push(row.join('\t'));
        }
        navigator.clipboard.writeText(lines.join('\n'));
        setSaveStatus(`Copied ${selectionRangeString()}`, 'text-bg-light');
    }
    async function pasteIntoSelection() {
        const text = await navigator.clipboard.readText(); if (!text) return;
        const rows = text.split(/\r?\n/).filter(Boolean).map(line => line.split('\t'));
        const start = splitRef(state.selectedRef); const startCol = colToIndex(start.col); const maxCols = Math.max(...rows.map(r => r.length), 1);
        currentSheet().rowCount = Math.max(currentSheet().rowCount, start.row + rows.length - 1);
        currentSheet().colCount = Math.max(currentSheet().colCount, startCol + maxCols);
        markDirty(true);
        rows.forEach((row, rIdx) => row.forEach((value, cIdx) => ensureCell(rcToRef(start.row + rIdx, startCol + cIdx)).raw = value));
        render();
    }

    function openContextMenu(x, y) {
        els.contextMenu.style.left = `${x}px`;
        els.contextMenu.style.top = `${y}px`;
        els.contextMenu.classList.remove('d-none');
    }
    function hideContextMenu() { els.contextMenu.classList.add('d-none'); }

    function onGridMouseDown(e) {
        const colResizer = e.target.closest('[data-col-resizer]');
        if (colResizer) {
            e.preventDefault();
            state.resizing = { type:'col', index:Number(colResizer.dataset.colResizer), startX:e.clientX, original: currentSheet().colWidths[Number(colResizer.dataset.colResizer)] || 120 };
            return;
        }
        const rowResizer = e.target.closest('[data-row-resizer]');
        if (rowResizer) {
            e.preventDefault();
            state.resizing = { type:'row', index:Number(rowResizer.dataset.rowResizer), startY:e.clientY, original: currentSheet().rowHeights[Number(rowResizer.dataset.rowResizer)] || 28 };
            return;
        }
        const td = e.target.closest('td[data-ref]');
        if (!td) return;
        state.dragSelecting = true;
        const ref = td.dataset.ref;
        if (e.shiftKey) selectCell(ref, true);
        else { state.selection = { startRef: ref, endRef: ref }; state.selectedRef = ref; renderGrid(); updateTitle(); syncFormulaBar(); syncToolbar(); }
    }
    function onGridMouseOver(e) {
        if (!state.dragSelecting) return;
        const td = e.target.closest('td[data-ref]');
        if (!td) return;
        state.selection.endRef = td.dataset.ref; state.selectedRef = td.dataset.ref; updateTitle(); renderGrid();
    }
    function onDocumentMouseMove(e) {
        if (!state.resizing) return;
        if (state.resizing.type === 'col') {
            const nextWidth = Math.max(60, state.resizing.original + (e.clientX - state.resizing.startX));
            currentSheet().colWidths[state.resizing.index] = nextWidth;
        } else {
            const nextHeight = Math.max(22, state.resizing.original + (e.clientY - state.resizing.startY));
            currentSheet().rowHeights[state.resizing.index] = nextHeight;
        }
        renderGrid();
    }
    function onDocumentMouseUp() {
        state.dragSelecting = false;
        if (state.resizing) {
            markDirty(true);
            state.resizing = null;
        }
    }
    function onGridDoubleClick(e) { const td = e.target.closest('td[data-ref]'); if (td) startEdit(td.dataset.ref); }
    function onGridClick(e) { const td = e.target.closest('td[data-ref]'); if (td && !state.dragSelecting) selectCell(td.dataset.ref, e.shiftKey); }
    function onGridContextMenu(e) {
        const td = e.target.closest('td[data-ref]');
        if (!td) return;
        e.preventDefault();
        selectCell(td.dataset.ref);
        openContextMenu(e.clientX, e.clientY);
    }

    function handleGlobalKeydown(e) {
        if (e.target.matches('input, textarea, select')) return;
        if (e.key === 'ArrowUp') { e.preventDefault(); navigate('up'); }
        else if (e.key === 'ArrowDown') { e.preventDefault(); navigate('down'); }
        else if (e.key === 'ArrowLeft') { e.preventDefault(); navigate('left'); }
        else if (e.key === 'ArrowRight') { e.preventDefault(); navigate('right'); }
        else if (e.key === 'Enter') { e.preventDefault(); startEdit(state.selectedRef); }
        else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'c') { e.preventDefault(); copySelected(); }
        else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'v') { e.preventDefault(); pasteIntoSelection(); }
        else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); undo(); }
        else if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'y') { e.preventDefault(); redo(); }
        else if (e.key === 'Delete') { e.preventDefault(); clearSelectedCell(); }
        else if (!e.ctrlKey && !e.metaKey && e.key.length === 1) {
            startEdit(state.selectedRef);
            requestAnimationFrame(() => {
                const input = els.grid.querySelector('td.editing input');
                if (input) { input.value = e.key; input.setSelectionRange(1,1); }
            });
        }
    }

    function wireEvents() {
        document.querySelectorAll('[data-style-toggle]').forEach(btn => btn.addEventListener('click', () => {
            const key = btn.dataset.styleToggle; const cell = ensureCell(state.selectedRef); applyStyle({ [key]: !Boolean(cell.style?.[key]) });
        }));
        els.textColorInput.addEventListener('input', () => applyStyle({ color: els.textColorInput.value }));
        els.fillColorInput.addEventListener('input', () => applyStyle({ background: els.fillColorInput.value }));
        els.fontSizeSelect.addEventListener('change', () => applyStyle({ fontSize: parseInt(els.fontSizeSelect.value, 10) || 13 }));
        els.alignSelect.addEventListener('change', () => applyStyle({ align: els.alignSelect.value }));
        els.formatSelect.addEventListener('change', () => applyStyle({ format: els.formatSelect.value }));
        els.formulaBar.addEventListener('focus', () => { state.formulaEditRef = state.selectedRef; });
        els.formulaBar.addEventListener('input', updateFormulaSuggestions);
        els.formulaBar.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); const targetRef = state.formulaEditRef || state.selectedRef; updateCellRaw(targetRef, els.formulaBar.value); state.formulaEditRef = null; hideContextMenu(); els.formulaSuggestions.classList.add('d-none'); } });
        els.formulaBar.addEventListener('blur', () => { const targetRef = state.formulaEditRef || state.selectedRef; updateCellRaw(targetRef, els.formulaBar.value); state.formulaEditRef = null; setTimeout(() => els.formulaSuggestions.classList.add('d-none'), 100); });

        document.getElementById('insertRowBtn').addEventListener('click', addRow);
        document.getElementById('insertColBtn').addEventListener('click', addColumn);
        document.getElementById('clearCellBtn').addEventListener('click', clearSelectedCell);
        document.getElementById('addSheetBtn').addEventListener('click', addSheet);
        document.getElementById('renameSheetBtn').addEventListener('click', renameSheet);
        document.getElementById('deleteSheetBtn').addEventListener('click', deleteSheet);
        document.getElementById('renameWorkbookBtn').addEventListener('click', renameWorkbook);
        document.getElementById('chartBtn').addEventListener('click', () => { els.chartRangeInput.value = selectionRangeString(); els.chartTitleInput.value = ''; modals.chart.show(); });
        els.previewChartBtn.addEventListener('click', previewChart);
        els.insertChartBtn.addEventListener('click', insertChartObject);
        document.getElementById('insertImageBtn').addEventListener('click', () => openObjectModal('image'));
        document.getElementById('insertVideoBtn').addEventListener('click', () => openObjectModal('video'));
        document.getElementById('insertLinkBtn').addEventListener('click', () => openObjectModal('link'));
        document.getElementById('insertObjectSaveBtn').addEventListener('click', saveObjectInsert);
        document.getElementById('mergeBtn').addEventListener('click', mergeSelection);
        document.getElementById('unmergeBtn').addEventListener('click', unmergeSelection);
        document.getElementById('conditionalFormatBtn').addEventListener('click', openConditionalModal);
        document.getElementById('saveConditionalBtn').addEventListener('click', saveConditionalRule);
        document.getElementById('clearConditionalBtn').addEventListener('click', clearConditionalRange);
        document.getElementById('sortAscBtn').addEventListener('click', () => sortSelection('asc'));
        document.getElementById('sortDescBtn').addEventListener('click', () => sortSelection('desc'));
        document.getElementById('filterBtn').addEventListener('click', filterNonBlank);
        document.getElementById('clearFilterBtn').addEventListener('click', clearFilter);
        document.getElementById('historyBtn').addEventListener('click', showHistory);
        document.getElementById('auditBtn').addEventListener('click', showAudit);
        document.getElementById('undoBtn').addEventListener('click', undo);
        document.getElementById('redoBtn').addEventListener('click', redo);
        document.getElementById('formulaHelperBtn').addEventListener('click', () => { renderFormulaCatalog(); modals.formulaHelper.show(); });
        document.getElementById('commentBtn').addEventListener('click', openCommentModal);
        document.getElementById('saveCommentBtn').addEventListener('click', saveComment);
        document.getElementById('shareBtn').addEventListener('click', () => modals.share.show());
        document.getElementById('saveShareBtn').addEventListener('click', shareWorkbook);
        els.exportXlsxBtn.addEventListener('click', exportXlsx);
        els.formulaSearchInput.addEventListener('input', renderFormulaCatalog);

        els.freezeTopToggle.addEventListener('change', () => { markDirty(true); currentSheet().freeze.topRow = els.freezeTopToggle.checked ? 1 : 0; render(); });
        els.freezeLeftToggle.addEventListener('change', () => { markDirty(true); currentSheet().freeze.leftCol = els.freezeLeftToggle.checked ? 1 : 0; render(); });

        els.grid.addEventListener('mousedown', onGridMouseDown);
        els.grid.addEventListener('mouseover', onGridMouseOver);
        document.addEventListener('mousemove', onDocumentMouseMove);
        document.addEventListener('mouseup', onDocumentMouseUp);
        els.grid.addEventListener('dblclick', onGridDoubleClick);
        els.grid.addEventListener('click', onGridClick);
        els.grid.addEventListener('contextmenu', onGridContextMenu);
        els.gridScroller.addEventListener('scroll', () => requestAnimationFrame(renderObjectsLayer));
        window.addEventListener('resize', () => requestAnimationFrame(renderObjectsLayer));
        window.addEventListener('keydown', handleGlobalKeydown);
        window.addEventListener('beforeunload', (e) => { if (state.isDirty) { e.preventDefault(); e.returnValue = ''; } });
        document.addEventListener('click', (e) => { if (!e.target.closest('#contextMenu')) hideContextMenu(); });
        els.contextMenu.addEventListener('click', (e) => {
            const btn = e.target.closest('button[data-action]'); if (!btn) return;
            const action = btn.dataset.action; hideContextMenu();
            if (action === 'copy') copySelected();
            else if (action === 'paste') pasteIntoSelection();
            else if (action === 'clear') clearSelectedCell();
            else if (action === 'comment') openCommentModal();
            else if (action === 'link') openObjectModal('link');
        });
        els.objectsLayer.addEventListener('click', (e) => {
            const btn = e.target.closest('[data-object-action]'); if (!btn) return;
            const id = btn.dataset.objectId;
            if (btn.dataset.objectAction === 'delete') {
                markDirty(true);
                currentSheet().objects = currentSheet().objects.filter(obj => obj.id !== id);
                render();
            } else if (btn.dataset.objectAction === 'nudge') {
                markDirty(true);
                const obj = currentSheet().objects.find(o => o.id === id);
                if (obj) { obj.x = (obj.x || 8) + Number(btn.dataset.dx || 0); render(); }
            }
        });
    }

    render();
    wireEvents();
    setInterval(pollForRemoteChanges, 5000);
})();
