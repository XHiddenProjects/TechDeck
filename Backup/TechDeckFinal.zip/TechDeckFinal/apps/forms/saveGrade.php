<?php
/**
 * Save quiz response grade overrides
 * Handles manual grade corrections for open-ended questions
 */
declare(strict_types=1);

use TechDeck\Addons\Form\FormUtils;
use TechDeck\Data;

include_once dirname(__DIR__, 2) . '/init.php';
include_once dirname(__FILE__) . '/libs/form.lib.php';

header('Content-Type: application/json; charset=utf-8');

if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}

function error_response(int $code, string $message): never
{
    http_response_code($code);
    echo json_encode(
        ['success' => false, 'error' => $message],
        JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
    );
    exit;
}

try {
    $formId = trim((string)($_POST['formId'] ?? ''));
    $responseId = trim((string)($_POST['responseId'] ?? ''));
    $questionId = trim((string)($_POST['questionId'] ?? ''));
    $grade = trim((string)($_POST['grade'] ?? 'clear'));

    if (!$formId) {
        error_response(400, 'Missing formId');
    }

    if (!$responseId) {
        error_response(400, 'Missing responseId');
    }

    if (!$questionId) {
        error_response(400, 'Missing questionId');
    }

    // Verify the user is the form author (editor)
    $formUtils = new FormUtils($formId);
    $formMeta = $formUtils->xml();

    if (!$formMeta) {
        error_response(404, 'Form not found');
    }

    if (!$formUtils->isEditorMode()) {
        error_response(403, 'Only form editors can modify grades');
    }

    // Load the response XML using Data
    $databasePath = dirname(__FILE__) . '/database';
    $data = new Data($formId, null, [], $databasePath);
    $xml = $data->xml();

    if ($xml === null) {
        error_response(404, 'Form file not found');
    }

    $found = false;
    $responses = $xml->xpath('//response') ?: [];

    foreach ($responses as $responseNode) {
        if ((string)($responseNode['id'] ?? '') !== $responseId) {
            continue;
        }

        $questions = $responseNode->xpath('./question') ?: [];
        foreach ($questions as $questionNode) {
            if ((string)($questionNode['id'] ?? '') !== $questionId) {
                continue;
            }

            if ($grade === 'clear') {
                unset($questionNode['gradeOverride']);
            } else {
                $override = ($grade === 'correct') ? 'correct' : 'incorrect';

                if (isset($questionNode['gradeOverride'])) {
                    $questionNode['gradeOverride'] = $override;
                } else {
                    $questionNode->addAttribute('gradeOverride', $override);
                }
            }

            $found = true;
            break 2;
        }
    }

    if (!$found) {
        error_response(404, 'Response or question not found');
    }

    if (!$data->save($formId, $xml, $databasePath, Data::SAVE_PRETTY)) {
        error_response(500, 'Failed to save form file');
    }

    echo json_encode(
        [
            'success' => true,
            'message' => 'Grade override saved',
            'formId' => $formId,
            'responseId' => $responseId,
            'questionId' => $questionId,
            'grade' => $grade,
        ],
        JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
    );
} catch (Throwable $e) {
    error_response(500, $e->getMessage());
}