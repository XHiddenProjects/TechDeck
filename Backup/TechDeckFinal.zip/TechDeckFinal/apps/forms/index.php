<?php
use TechDeck\Locales,
TechDeck\Addons,
TechDeck\Storage,
TechDeck\Data,
TechDeck\Files;
use TechDeck\URI;
include_once dirname(__DIR__,2).'/init.php';
$l = implode('-',LANGUAGE);
$lang = new Locales($l);
$addon = new Addons();
$storage = new Storage();
$data = new Data();
$files = new Files();
$uri = new URI();
if(!$storage->session('TechDeck_auth', action: 'Get')&&!$storage->cookie(name: 'TechDeck_auth',action: 'load')) header('Location: '.URL.DS.'auth');
?>
<?php    
if($uri->match('forms')){
?>
<!DOCTYPE html>
<html lang="<?=$l?>">
    <head>
        <?php
        $lang = new Locales($l);
        echo $addon->hook('head');
        echo $addon->hook('css');
        ?>
        <link rel="stylesheet" href="<?=URL.DS.'apps'.DS.'forms'.DS.'css'.DS.'forms-main.css'?>"/>
    </head>
    <body>
        <?=$addon->hook('beforeMain')?>
        <header class="p-2 bg-secondary-subtle">
            <a class="link-dark text-decoration-none link-hoverable" href="<?=URL.DS.'dashboard'?>"><i class="fa-solid fa-arrow-left"></i> <?=$lang->load(['authorization','_dashboard'])?></a>
        </header>
        <main>
            <div class="form-action-box d-flex flex-column w-100 bg-secondary-subtle pb-2">
                <div class="row w-100 p-2 align-items-start">
                    <div class="col">
                        <div class="d-flex flex-wrap gap-2 flex-column flex-sm-row">
                        <button class="form-btn form-btn-new form-btn-new-quiz">
                            <img src="<?=ASSETS_URL?>/icons/forms/new_quiz_icon.svg" class="d-inline-block"/>
                            <?=$lang->load(['apps','applications','forms','new_quiz'])?>
                        </button>
                        <button class="form-btn form-btn-new form-btn-new-form">
                            <img src="<?=ASSETS_URL?>/icons/forms/new_form_icon.svg" class="d-inline-block"/>
                            <?=$lang->load(['apps','applications','forms','new_form'])?>
                        </button>
                        <button class="form-btn form-btn-import">
                            <i class="fa-sharp fa-solid fa-arrow-up-long-to-line"></i>
                            <?=$lang->load(['apps','applications','forms','quick_import'])?>
                        </button>
                        </div>
                    </div>

                    <div class="col">
                        <a class="text-decoration-none link-dark float-end btn outline-none border-0 toggle-templates-btn"
                        data-bs-toggle="collapse"
                        href="#templates"
                        role="button"
                        aria-expanded="false"
                        aria-controls="templatesControls"
                        data-label-show="<?=$lang->load(['apps','applications','forms','explore_templates'])?>"
                        data-label-hide="<?=$lang->load(['apps','applications','forms','hide_templates'])?>">
                        <?=$lang->load(['apps','applications','forms','hide_templates'])?> <i class="fa-regular fa-angle-up"></i>
                        </a>
                    </div>
                </div>
                <div class="row w-100">
                    <div class="collapse" id="templates">
                        <div class="container-fluid p-3">
                            <div class="d-flex flex-column flex-lg-row align-items-lg-end justify-content-between gap-3 mb-3">
                                <div>
                                    <h6 class="mb-1"><?=$lang->load(['apps','applications','forms','explore_templates'])?></h6>
                                    <p class="text-secondary mb-0 forms-index-template-copy">Choose a ready-made starting point. Each card includes a quick visual preview and can launch the correct builder for you.</p>
                                </div>
                                <span class="forms-index-template-hint">Tip: select a card first, then create a new form or quiz.</span>
                            </div>
                            <div class="forms-index-template-grid" data-template-gallery>
                                <article class="forms-index-template-card is-active" tabindex="0" data-template-id="feedback" data-template-mode="form">
                                    <div class="forms-template-shot is-feedback" aria-hidden="true">
                                        <div class="forms-template-shot-banner has-media"></div>
                                        <div class="forms-template-shot-body">
                                            <div class="forms-template-shot-heading"><span class="forms-template-shot-title"></span><span class="forms-template-shot-pill"></span></div>
                                            <div class="forms-template-shot-lines"><span class="forms-template-shot-line is-wide"></span><span class="forms-template-shot-line"></span><span class="forms-template-shot-line is-short"></span></div>
                                            <div class="forms-template-shot-chips"><span></span><span></span><span></span></div>
                                        </div>
                                    </div>
                                    <div class="forms-index-template-card-body">
                                        <div class="forms-index-template-card-top"><h6 class="mb-1">Customer feedback</h6><span class="forms-index-template-badge">Form</span></div>
                                        <p class="text-secondary mb-2">Great for satisfaction surveys, post-visit feedback, NPS, and service follow-up.</p>
                                        <div class="forms-index-template-tags"><span>Feedback</span><span>NPS</span><span>Survey</span></div>
                                        <div class="forms-index-template-actions"><button type="button" class="form-card-action-btn form-card-export" data-template-use="feedback" data-template-mode="form"><i class="fa-solid fa-wand-magic-sparkles"></i><span>Use template</span></button></div>
                                    </div>
                                </article>
                                <article class="forms-index-template-card" tabindex="0" data-template-id="event" data-template-mode="form">
                                    <div class="forms-template-shot is-event" aria-hidden="true">
                                        <div class="forms-template-shot-banner"></div>
                                        <div class="forms-template-shot-body">
                                            <div class="forms-template-shot-heading"><span class="forms-template-shot-title"></span><span class="forms-template-shot-pill"></span></div>
                                            <div class="forms-template-shot-lines"><span class="forms-template-shot-line is-wide"></span><span class="forms-template-shot-line"></span><span class="forms-template-shot-line"></span><span class="forms-template-shot-line is-short"></span></div>
                                            <div class="forms-template-shot-chips"><span></span><span></span><span></span><span></span></div>
                                        </div>
                                    </div>
                                    <div class="forms-index-template-card-body">
                                        <div class="forms-index-template-card-top"><h6 class="mb-1">Event registration</h6><span class="forms-index-template-badge">Form</span></div>
                                        <p class="text-secondary mb-2">Collect attendee details, meal preferences, uploads, and ranked topic interest.</p>
                                        <div class="forms-index-template-tags"><span>Registration</span><span>Upload</span><span>Planning</span></div>
                                        <div class="forms-index-template-actions"><button type="button" class="form-card-action-btn form-card-export" data-template-use="event" data-template-mode="form"><i class="fa-solid fa-wand-magic-sparkles"></i><span>Use template</span></button></div>
                                    </div>
                                </article>
                                <article class="forms-index-template-card" tabindex="0" data-template-id="support-ticket" data-template-mode="form">
                                    <div class="forms-template-shot is-support" aria-hidden="true">
                                        <div class="forms-template-shot-banner"></div>
                                        <div class="forms-template-shot-body">
                                            <div class="forms-template-shot-heading"><span class="forms-template-shot-title"></span><span class="forms-template-shot-pill"></span></div>
                                            <div class="forms-template-shot-lines"><span class="forms-template-shot-line is-wide"></span><span class="forms-template-shot-line"></span><span class="forms-template-shot-line is-short"></span></div>
                                            <div class="forms-template-shot-chips"><span></span><span></span></div>
                                        </div>
                                    </div>
                                    <div class="forms-index-template-card-body">
                                        <div class="forms-index-template-card-top"><h6 class="mb-1">Support ticket</h6><span class="forms-index-template-badge">Form</span></div>
                                        <p class="text-secondary mb-2">Capture priority, issue details, screenshots, and routing in one place.</p>
                                        <div class="forms-index-template-tags"><span>Support</span><span>Routing</span><span>Upload</span></div>
                                        <div class="forms-index-template-actions"><button type="button" class="form-card-action-btn form-card-export" data-template-use="support-ticket" data-template-mode="form"><i class="fa-solid fa-wand-magic-sparkles"></i><span>Use template</span></button></div>
                                    </div>
                                </article>
                                <article class="forms-index-template-card" tabindex="0" data-template-id="employee-pulse" data-template-mode="form">
                                    <div class="forms-template-shot is-pulse" aria-hidden="true">
                                        <div class="forms-template-shot-banner has-media"></div>
                                        <div class="forms-template-shot-body">
                                            <div class="forms-template-shot-heading"><span class="forms-template-shot-title"></span><span class="forms-template-shot-pill"></span></div>
                                            <div class="forms-template-shot-lines"><span class="forms-template-shot-line is-wide"></span><span class="forms-template-shot-line"></span><span class="forms-template-shot-line"></span></div>
                                            <div class="forms-template-shot-chips"><span></span><span></span><span></span></div>
                                        </div>
                                    </div>
                                    <div class="forms-index-template-card-body">
                                        <div class="forms-index-template-card-top"><h6 class="mb-1">Employee pulse</h6><span class="forms-index-template-badge">Form</span></div>
                                        <p class="text-secondary mb-2">Run internal culture, workload, and manager support check-ins.</p>
                                        <div class="forms-index-template-tags"><span>HR</span><span>Internal</span><span>Engagement</span></div>
                                        <div class="forms-index-template-actions"><button type="button" class="form-card-action-btn form-card-export" data-template-use="employee-pulse" data-template-mode="form"><i class="fa-solid fa-wand-magic-sparkles"></i><span>Use template</span></button></div>
                                    </div>
                                </article>
                                <article class="forms-index-template-card" tabindex="0" data-template-id="contact" data-template-mode="form">
                                    <div class="forms-template-shot is-contact" aria-hidden="true">
                                        <div class="forms-template-shot-banner has-media"></div>
                                        <div class="forms-template-shot-body">
                                            <div class="forms-template-shot-heading"><span class="forms-template-shot-title"></span><span class="forms-template-shot-pill"></span></div>
                                            <div class="forms-template-shot-lines"><span class="forms-template-shot-line is-wide"></span><span class="forms-template-shot-line"></span><span class="forms-template-shot-line is-short"></span></div>
                                            <div class="forms-template-shot-chips"><span></span><span></span><span></span></div>
                                        </div>
                                    </div>
                                    <div class="forms-index-template-card-body">
                                        <div class="forms-index-template-card-top"><h6 class="mb-1">Contact request</h6><span class="forms-index-template-badge">Form</span></div>
                                        <p class="text-secondary mb-2">Perfect for lead capture, website contact pages, and demo requests.</p>
                                        <div class="forms-index-template-tags"><span>Website</span><span>Lead</span><span>CRM</span></div>
                                        <div class="forms-index-template-actions"><button type="button" class="form-card-action-btn form-card-export" data-template-use="contact" data-template-mode="form"><i class="fa-solid fa-wand-magic-sparkles"></i><span>Use template</span></button></div>
                                    </div>
                                </article>
                                <article class="forms-index-template-card" tabindex="0" data-template-id="job-application" data-template-mode="form">
                                    <div class="forms-template-shot is-job" aria-hidden="true">
                                        <div class="forms-template-shot-banner"></div>
                                        <div class="forms-template-shot-body">
                                            <div class="forms-template-shot-heading"><span class="forms-template-shot-title"></span><span class="forms-template-shot-pill"></span></div>
                                            <div class="forms-template-shot-lines"><span class="forms-template-shot-line is-wide"></span><span class="forms-template-shot-line"></span><span class="forms-template-shot-line"></span><span class="forms-template-shot-line is-short"></span></div>
                                            <div class="forms-template-shot-chips"><span></span><span></span><span></span></div>
                                        </div>
                                    </div>
                                    <div class="forms-index-template-card-body">
                                        <div class="forms-index-template-card-top"><h6 class="mb-1">Job application</h6><span class="forms-index-template-badge">Form</span></div>
                                        <p class="text-secondary mb-2">Collect resume uploads, candidate highlights, and availability.</p>
                                        <div class="forms-index-template-tags"><span>Hiring</span><span>Resume</span><span>Recruiting</span></div>
                                        <div class="forms-index-template-actions"><button type="button" class="form-card-action-btn form-card-export" data-template-use="job-application" data-template-mode="form"><i class="fa-solid fa-wand-magic-sparkles"></i><span>Use template</span></button></div>
                                    </div>
                                </article>
                                <article class="forms-index-template-card" tabindex="0" data-template-id="order-request" data-template-mode="form">
                                    <div class="forms-template-shot is-order" aria-hidden="true">
                                        <div class="forms-template-shot-banner has-media"></div>
                                        <div class="forms-template-shot-body">
                                            <div class="forms-template-shot-heading"><span class="forms-template-shot-title"></span><span class="forms-template-shot-pill"></span></div>
                                            <div class="forms-template-shot-lines"><span class="forms-template-shot-line is-wide"></span><span class="forms-template-shot-line"></span><span class="forms-template-shot-line"></span></div>
                                            <div class="forms-template-shot-chips"><span></span><span></span><span></span></div>
                                        </div>
                                    </div>
                                    <div class="forms-index-template-card-body">
                                        <div class="forms-index-template-card-top"><h6 class="mb-1">Order request</h6><span class="forms-index-template-badge">Form</span></div>
                                        <p class="text-secondary mb-2">Handle product requests, delivery notes, and approval-ready details.</p>
                                        <div class="forms-index-template-tags"><span>Operations</span><span>Request</span><span>Ordering</span></div>
                                        <div class="forms-index-template-actions"><button type="button" class="form-card-action-btn form-card-export" data-template-use="order-request" data-template-mode="form"><i class="fa-solid fa-wand-magic-sparkles"></i><span>Use template</span></button></div>
                                    </div>
                                </article>
                                
                                <article class="forms-index-template-card" tabindex="0" data-template-id="vendor-onboarding" data-template-mode="form">
                                    <div class="forms-template-shot" aria-hidden="true">
                                        <div class="forms-template-shot-banner has-media"></div>
                                        <div class="forms-template-shot-body">
                                            <div class="forms-template-shot-heading"><span class="forms-template-shot-title"></span><span class="forms-template-shot-pill"></span></div>
                                            <div class="forms-template-shot-lines"><span class="forms-template-shot-line is-wide"></span><span class="forms-template-shot-line"></span><span class="forms-template-shot-line is-short"></span></div>
                                            <div class="forms-template-shot-chips"><span></span><span></span><span></span></div>
                                        </div>
                                    </div>
                                    <div class="forms-index-template-card-body">
                                        <div class="forms-index-template-card-top"><h6 class="mb-1">Vendor onboarding</h6><span class="forms-index-template-badge">Form</span></div>
                                        <p class="text-secondary mb-2">Collect compliance documents, service scope, and go-live priorities in one flow.</p>
                                        <div class="forms-index-template-tags"><span>Procurement</span><span>Compliance</span><span>Launch</span></div>
                                        <div class="forms-index-template-actions"><button type="button" class="form-card-action-btn form-card-export" data-template-use="vendor-onboarding" data-template-mode="form"><i class="fa-solid fa-wand-magic-sparkles"></i><span>Use template</span></button></div>
                                    </div>
                                </article>
                                <article class="forms-index-template-card" tabindex="0" data-template-id="incident-report" data-template-mode="form">
                                    <div class="forms-template-shot" aria-hidden="true">
                                        <div class="forms-template-shot-banner has-media"></div>
                                        <div class="forms-template-shot-body">
                                            <div class="forms-template-shot-heading"><span class="forms-template-shot-title"></span><span class="forms-template-shot-pill"></span></div>
                                            <div class="forms-template-shot-lines"><span class="forms-template-shot-line is-wide"></span><span class="forms-template-shot-line"></span><span class="forms-template-shot-line"></span></div>
                                            <div class="forms-template-shot-chips"><span></span><span></span><span></span></div>
                                        </div>
                                    </div>
                                    <div class="forms-index-template-card-body">
                                        <div class="forms-index-template-card-top"><h6 class="mb-1">Incident report</h6><span class="forms-index-template-badge">Form</span></div>
                                        <p class="text-secondary mb-2">Capture severity, evidence, and impacted systems for operations or security response.</p>
                                        <div class="forms-index-template-tags"><span>Incident</span><span>Evidence</span><span>Urgency</span></div>
                                        <div class="forms-index-template-actions"><button type="button" class="form-card-action-btn form-card-export" data-template-use="incident-report" data-template-mode="form"><i class="fa-solid fa-wand-magic-sparkles"></i><span>Use template</span></button></div>
                                    </div>
                                </article>
                                <article class="forms-index-template-card" tabindex="0" data-template-id="travel-request" data-template-mode="form">
                                    <div class="forms-template-shot" aria-hidden="true">
                                        <div class="forms-template-shot-banner"></div>
                                        <div class="forms-template-shot-body">
                                            <div class="forms-template-shot-heading"><span class="forms-template-shot-title"></span><span class="forms-template-shot-pill"></span></div>
                                            <div class="forms-template-shot-lines"><span class="forms-template-shot-line is-wide"></span><span class="forms-template-shot-line"></span><span class="forms-template-shot-line is-short"></span></div>
                                            <div class="forms-template-shot-chips"><span></span><span></span><span></span></div>
                                        </div>
                                    </div>
                                    <div class="forms-index-template-card-body">
                                        <div class="forms-index-template-card-top"><h6 class="mb-1">Travel request</h6><span class="forms-index-template-badge">Form</span></div>
                                        <p class="text-secondary mb-2">Handle itinerary, booking preferences, attachments, and business justification.</p>
                                        <div class="forms-index-template-tags"><span>Travel</span><span>Approval</span><span>Planning</span></div>
                                        <div class="forms-index-template-actions"><button type="button" class="form-card-action-btn form-card-export" data-template-use="travel-request" data-template-mode="form"><i class="fa-solid fa-wand-magic-sparkles"></i><span>Use template</span></button></div>
                                    </div>
                                </article>
                                <article class="forms-index-template-card" tabindex="0" data-template-id="maintenance-request" data-template-mode="form">
                                    <div class="forms-template-shot" aria-hidden="true">
                                        <div class="forms-template-shot-banner"></div>
                                        <div class="forms-template-shot-body">
                                            <div class="forms-template-shot-heading"><span class="forms-template-shot-title"></span><span class="forms-template-shot-pill"></span></div>
                                            <div class="forms-template-shot-lines"><span class="forms-template-shot-line is-wide"></span><span class="forms-template-shot-line"></span><span class="forms-template-shot-line"></span></div>
                                            <div class="forms-template-shot-chips"><span></span><span></span><span></span></div>
                                        </div>
                                    </div>
                                    <div class="forms-index-template-card-body">
                                        <div class="forms-index-template-card-top"><h6 class="mb-1">Maintenance request</h6><span class="forms-index-template-badge">Form</span></div>
                                        <p class="text-secondary mb-2">Log facility issues with photos, access windows, and completion preferences.</p>
                                        <div class="forms-index-template-tags"><span>Facilities</span><span>Photos</span><span>Flexible</span></div>
                                        <div class="forms-index-template-actions"><button type="button" class="form-card-action-btn form-card-export" data-template-use="maintenance-request" data-template-mode="form"><i class="fa-solid fa-wand-magic-sparkles"></i><span>Use template</span></button></div>
                                    </div>
                                </article>
                                <article class="forms-index-template-card" tabindex="0" data-template-id="training-evaluation" data-template-mode="form">
                                    <div class="forms-template-shot" aria-hidden="true">
                                        <div class="forms-template-shot-banner has-media"></div>
                                        <div class="forms-template-shot-body">
                                            <div class="forms-template-shot-heading"><span class="forms-template-shot-title"></span><span class="forms-template-shot-pill"></span></div>
                                            <div class="forms-template-shot-lines"><span class="forms-template-shot-line is-wide"></span><span class="forms-template-shot-line"></span><span class="forms-template-shot-line is-short"></span></div>
                                            <div class="forms-template-shot-chips"><span></span><span></span><span></span></div>
                                        </div>
                                    </div>
                                    <div class="forms-index-template-card-body">
                                        <div class="forms-index-template-card-top"><h6 class="mb-1">Training evaluation</h6><span class="forms-index-template-badge">Form</span></div>
                                        <p class="text-secondary mb-2">A lighter post-session feedback form with ratings, priorities, and open suggestions.</p>
                                        <div class="forms-index-template-tags"><span>Training</span><span>Feedback</span><span>Low-friction</span></div>
                                        <div class="forms-index-template-actions"><button type="button" class="form-card-action-btn form-card-export" data-template-use="training-evaluation" data-template-mode="form"><i class="fa-solid fa-wand-magic-sparkles"></i><span>Use template</span></button></div>
                                    </div>
                                </article>
                                <article class="forms-index-template-card" tabindex="0" data-template-id="advanced-it-assessment" data-template-mode="quiz">
                                    <div class="forms-template-shot is-quiz" aria-hidden="true">
                                        <div class="forms-template-shot-banner"></div>
                                        <div class="forms-template-shot-body">
                                            <div class="forms-template-shot-heading"><span class="forms-template-shot-title"></span><span class="forms-template-shot-pill"></span></div>
                                            <div class="forms-template-shot-lines"><span class="forms-template-shot-line is-wide"></span><span class="forms-template-shot-line"></span><span class="forms-template-shot-line"></span><span class="forms-template-shot-line is-short"></span></div>
                                            <div class="forms-template-shot-chips"><span></span><span></span><span></span><span></span></div>
                                        </div>
                                    </div>
                                    <div class="forms-index-template-card-body">
                                        <div class="forms-index-template-card-top"><h6 class="mb-1">Advanced IT assessment</h6><span class="forms-index-template-badge is-quiz">Quiz</span></div>
                                        <p class="text-secondary mb-2">Advanced IT quiz with better preview rendering and the full section set.</p>
                                        <div class="forms-index-template-tags"><span>Advanced</span><span>IT</span><span>Quiz</span></div>
                                        <div class="forms-index-template-actions"><button type="button" class="form-card-action-btn form-card-export" data-template-use="advanced-it-assessment" data-template-mode="quiz"><i class="fa-solid fa-wand-magic-sparkles"></i><span>Use template</span></button></div>
                                    </div>
                                </article>
                                <article class="forms-index-template-card" tabindex="0" data-template-id="quiz" data-template-mode="quiz">
                                    <div class="forms-template-shot is-quiz" aria-hidden="true">
                                        <div class="forms-template-shot-banner"></div>
                                        <div class="forms-template-shot-body">
                                            <div class="forms-template-shot-heading"><span class="forms-template-shot-title"></span><span class="forms-template-shot-pill"></span></div>
                                            <div class="forms-template-shot-lines"><span class="forms-template-shot-line is-wide"></span><span class="forms-template-shot-line"></span><span class="forms-template-shot-line is-short"></span></div>
                                            <div class="forms-template-shot-chips"><span></span><span></span><span></span><span></span></div>
                                        </div>
                                    </div>
                                    <div class="forms-index-template-card-body">
                                        <div class="forms-index-template-card-top"><h6 class="mb-1">Quick quiz</h6><span class="forms-index-template-badge is-quiz">Quiz</span></div>
                                        <p class="text-secondary mb-2">Start with answer keys, points, and an assessment-ready layout.</p>
                                        <div class="forms-index-template-tags"><span>Quiz</span><span>Scoring</span><span>Training</span></div>
                                        <div class="forms-index-template-actions"><button type="button" class="form-card-action-btn form-card-favorite" data-template-use="quiz" data-template-mode="quiz"><i class="fa-solid fa-graduation-cap"></i><span>Use template</span></button></div>
                                    </div>
                                </article>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row align-items-center">
                <div class="col">
                    <!-- Desktop / Tablet: horizontal nav (no wrap) -->
                    <ul class="form-nav d-none d-md-flex" data-no-select>
                    <li class="form-nav-item active">
                        <i class="fa-regular fa-clock"></i>
                        <?=$lang->load(['buttons','recent'])?>
                    </li>

                    <li class="form-nav-item">
                        <i class="fa-regular fa-file"></i>
                        <?=$lang->load(['apps','applications','forms','my_forms'])?>
                    </li>

                    <li class="form-nav-item">
                        <i class="fa-sharp fa-light fa-bookmark"></i>
                        <?=$lang->load(['apps','applications','forms','filled_forms'])?>
                    </li>

                    <li class="form-nav-item">
                        <i class="fa-sharp fa-light fa-star"></i>
                        <?=$lang->load(['buttons','favorites'])?>
                    </li>
                    </ul>

                    <!-- Mobile: dropdown -->
                    <div class="dropdown d-md-none">
                    <button class="btn form-btn form-btn-extra dropdown-toggle w-100"
                            type="button"
                            data-bs-toggle="dropdown"
                            aria-expanded="false">
                        <i class="fa-regular fa-clock me-2"></i>
                        <?=$lang->load(['buttons','recent'])?>
                    </button>

                    <ul class="dropdown-menu w-100">
                        <li>
                        <a class="dropdown-item active" href="#">
                            <i class="fa-regular fa-clock me-2"></i>
                            <?=$lang->load(['buttons','recent'])?>
                        </a>
                        </li>
                        <li>
                        <a class="dropdown-item" href="#">
                            <i class="fa-regular fa-file me-2"></i>
                            <?=$lang->load(['apps','applications','forms','my_forms'])?>
                        </a>
                        </li>
                        <li>
                        <a class="dropdown-item" href="#">
                            <i class="fa-sharp fa-light fa-bookmark me-2"></i>
                            <?=$lang->load(['apps','applications','forms','filled_forms'])?>
                        </a>
                        </li>
                        <li>
                        <a class="dropdown-item" href="#">
                            <i class="fa-sharp fa-light fa-star me-2"></i>
                            <?=$lang->load(['buttons','favorites'])?>
                        </a>
                        </li>
                    </ul>
                    </div>
                </div>
                <div class="col">
                    <div class="d-flex align-items-center gap-2">
                        <input type="text"
                                class="form-control flex-grow-1"
                                id="form-search"
                                placeholder="<?=$lang->load(['search','filter_by_keyword'])??'Filter by Keyword'?>"/>
                        <ul class="form-sorting flex-shrink-0 mb-0">
                            <li class="form-sorting-item" data-sorting="list"><i class="fa-light fa-list"></i></li>
                            <li class="form-sorting-item active" data-sorting="grid"><i class="fa-light fa-grid"></i></li>
                        </ul>
                    </div>
                </div>
            </div>
            <section class="section section-recent display is-grid">
            <?php
                if(count($files->scan(dirname(__FILE__).DS.'database'))>0){
                    foreach($files->scan(dirname(__FILE__).DS.'database') as $forms){
                        $xml = new Data($forms, null, [], dirname(__FILE__).DS.'database');
                        $xml = $xml->xml();
            ?>
            <a class="text-decoration-none form-action-link" href="./live?formId=<?=$xml['id']?>">
                <div class="card" style="width: 18rem;">
                    <div class="card-img-top screenshot" style="background: <?=$xml->metadata->styles->background['style']?>"></div>
                    <div class="card-body">
                        <h5 class="card-title"><?=$xml->metadata->title?></h5>
                        <p class="card-text text-secondary"><?=$xml->metadata->author?></p>
                        <p class="card-text"><?=count($xml->responses->response)?> <?=$lang->load(['apps','applications','forms','responses'])?></p>
                    </div>
                    <button type="button" class="form-card-delete btn btn-outline-secondary" data-delete-form="<?=$xml['id']?>" data-form-title="<?=htmlspecialchars((string)$xml->metadata->title, ENT_QUOTES, "UTF-8")?>" aria-label="<?=htmlspecialchars((string)$xml->metadata->title, ENT_QUOTES, "UTF-8")?>" title="<?=htmlspecialchars((string)$xml->metadata->title, ENT_QUOTES, "UTF-8")?>"><i class="fa-solid fa-trash-can"></i></button>
                </div>
            </a>
            <?php
                    }
                }else{
                ?>
                <div class="form-no-results">
                    <img src="<?=ASSETS_URL?>/icons/forms/no_form_icon.png" width="64" height="64"/>
                    <h4 class="text-muted"><?=$lang->load(['apps','applications','forms','getting_started'])?></h4>
                    <p class="text-dark"><?=$lang->load(['apps','applications','forms','getting_started_memo'])?></p>
                </div>
                <?php
                }
            ?>
            </section>
            <section class="section section-my-forms d-none display is-grid">
                <?php
                if(count($files->scan(dirname(__FILE__).DS.'database'))>0){
                     foreach($files->scan(dirname(__FILE__).DS.'database') as $forms){
                        $xml = new Data($forms, null, [], dirname(__FILE__).DS.'database');
                        $xml = $xml->xml();
                ?>
                <a class="text-decoration-none form-action-link" href="./live?formId=<?=$xml['id']?>">
                    <div class="card" style="width: 18rem;">
                        <div class="card-img-top screenshot" style="background: <?=$xml->metadata->styles->background['style']?>"></div>
                        <div class="card-body">
                            <h5 class="card-title"><?=$xml->metadata->title?></h5>
                            <p class="card-text text-secondary"><?=$xml->metadata->author?></p>
                            <p class="card-text"><?=count($xml->responses->response)?> <?=$lang->load(['apps','applications','forms','responses'])?></p>
                        </div>
                    </div>
                </a>
                <?php
                    }
                }else{
                ?>
                <div class="form-no-results">
                    <img src="<?=ASSETS_URL?>/icons/forms/no_form_icon.png" width="64" height="64"/>
                    <h4 class="text-muted"><?=$lang->load(['apps','applications','forms','getting_started'])?></h4>
                    <p class="text-dark"><?=$lang->load(['apps','applications','forms','getting_started_memo'])?></p>
                </div>
                <?php
                }
            ?>
            </section>
            <section class="section section-filled-forms d-none display is-grid">
            <?php
            if(count($files->scan(dirname(__FILE__).DS.'database'))>0){

            }else{
                ?>
                <div class="form-no-results">
                    <img src="<?=ASSETS_URL?>/icons/forms/no_filled_forms.png" width="64" height="64"/>
                    <h4 class="text-muted"><?=$lang->load(['apps','applications','forms','filled_form_memo'])?></h4>
                </div>
                <?php
                }
            ?>
            </section>
            <section class="section section-favorites d-none display is-grid">
            <?php
            if(count($files->scan(dirname(__FILE__).DS.'database'))>0){

            }else{
                ?>
                <div class="form-no-results">
                    <img src="<?=ASSETS_URL?>/icons/forms/no_favorite_forms.png" width="64" height="64"/>
                    <h4 class="text-muted"><?=$lang->load(['apps','applications','forms','favorites'])?></h4>
                    <p class="text-dark"><?=$lang->load(['apps','applications','forms','favorites_memo'])?></p>
                </div>
                <?php
                }
            ?>
            </section>
        </main>
        <footer><?=$addon->hook('footer')?></footer>
        <?=$addon->hook('afterMain')?>
        <?=$addon->hook('scripts')?>
        <script>
            window.ASSETS_URL = '<?=ASSETS_URL?>';
            window.APPLICATION_URL = '<?=APPLICATION_URL?>';
        </script>
        <script src="<?=APPLICATION_URL.DS.'forms'.DS.'js'.DS.'forms-index.js'?>"></script>
        <?php
        }
        if($uri->match('forms/live')){
            include_once dirname(__FILE__).'/libs/form.lib.php';
            include_once 'live.php';
        }
        ?>
        
    
<style id="forms-index-inline-enhancements">
.display {
  display: grid;
  gap: 18px;
  align-items: stretch;
}
.display.is-grid {
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
}
.display.is-list {
  grid-template-columns: minmax(0, 1fr);
}
.form-action-link { display:block; min-width:0; }
.form-card { width:100% !important; min-width:0; height:100%; display:flex; flex-direction:column; overflow:hidden; }
.form-card .screenshot { min-height:138px; }
.form-card .card-body { flex:1 1 auto; }
.form-card-actions { display:flex; flex-wrap:wrap; gap:8px; align-items:center; padding:0 1rem 1rem; margin-top:auto; }
.form-card-action-btn { display:inline-flex; align-items:center; justify-content:center; gap:8px; min-height:38px; padding:8px 12px; border-radius:999px; border:1px solid #d7e2f2; background:#fff; color:#1d2939; font-weight:700; }
.form-card-action-btn:hover { border-color:#2563eb; color:#2563eb; }
.form-card-action-btn.is-favorite { border-color:rgba(245,158,11,.55); background:rgba(245,158,11,.12); color:#b45309; }
.form-card-action-btn.form-card-delete:hover { border-color:rgba(217,45,32,.4); color:#d92d20; }
.display.is-list .form-card { flex-direction:row; align-items:stretch; }
.display.is-list .form-card .screenshot { width:200px; min-width:200px; min-height:100%; }
.display.is-list .form-card .card-body { padding-right:.5rem; }
.display.is-list .form-card-actions { flex-direction:column; justify-content:center; align-items:stretch; width:180px; padding:1rem; }
.display.is-list .form-card-action-btn { width:100%; }
.form-favorites-empty { grid-column:1 / -1; padding:24px; border:1px dashed #d7e2f2; border-radius:18px; background:#fff; text-align:center; }
@media (max-width: 920px) {
  .display.is-grid { grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); }
  .display.is-list .form-card { flex-direction:column; }
  .display.is-list .form-card .screenshot { width:100%; min-width:0; min-height:138px; }
  .display.is-list .form-card-actions { width:auto; flex-direction:row; align-items:center; padding-top:0; }
}
@media (max-width: 640px) {
  .display, .display.is-grid, .display.is-list { grid-template-columns: minmax(0, 1fr); }
  .form-card-actions { flex-direction:column; align-items:stretch; }
  .form-card-action-btn { width:100%; }
}
</style>
<script src="js/form-templates.js"></script>
</body>
</html>