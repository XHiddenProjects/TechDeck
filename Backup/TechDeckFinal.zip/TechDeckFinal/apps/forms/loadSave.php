<?php
// Enhanced form loader for editor + publish experience

declare(strict_types=1);
use TechDeck\Addons\Form\FormUtils;
include_once dirname(__DIR__, 2) . '/init.php';
include_once dirname(__FILE__) . '/libs/form.lib.php';
header('Content-Type: application/json; charset=utf-8');

function xml_attr(mixed $node, string $attr, string $default = ''): string {
    if ($node === null) return $default;
    $attrs = $node->attributes();
    return isset($attrs[$attr]) ? (string)$attrs[$attr] : $default;
}
function xml_flag(mixed $node, string $attr = 'enabled', bool $default = false): bool {
    $value = strtolower(trim(xml_attr($node, $attr, $default ? '1' : '0')));
    return in_array($value, ['1', 'true', 'yes', 'on', 'enabled'], true);
}
function normalize_bool(mixed $value): bool {
    if (is_bool($value)) return $value;
    if (is_numeric($value)) return (int)$value === 1;
    $normalized = strtolower(trim((string)$value));
    return in_array($normalized, ['1', 'true', 'yes', 'on', 'enabled'], true);
}
function parse_json_or_list(mixed $value): array {
    if (is_array($value)) return array_values($value);
    $raw = trim((string)$value);
    if ($raw === '') return [];
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) return array_values($decoded);
    return array_values(array_filter(array_map('trim', explode(',', $raw)), static fn($item) => $item !== ''));
}
function normalize_branch_rule(array $item): array {
    $operator = (string)($item['operator'] ?? 'answered');
    $value = (string)($item['value'] ?? '');
    $action = strtolower(trim((string)($item['action'] ?? '')));
    if (!in_array($action, ['jump', 'show', 'hide', 'require', 'optional'], true)) {
        $action = isset($item['targetQuestionId']) && trim((string)$item['targetQuestionId']) !== '' ? 'show' : 'jump';
    }
    $target = (string)($item['target'] ?? ($action === 'jump' ? '**next**' : ''));
    $targetQuestionId = (string)($item['targetQuestionId'] ?? '');
    if ($action !== 'jump' && $targetQuestionId === '' && $target !== '' && !str_starts_with($target, '**')) {
        $targetQuestionId = $target;
        $target = '';
    }
    if (in_array($operator, ['answered', 'not_answered'], true)) {
        $value = '';
    }
    return [
        'operator' => $operator,
        'value' => $value,
        'action' => $action,
        'target' => $target,
        'targetQuestionId' => $targetQuestionId,
    ];
}
function parse_branch_rules(mixed $value): array {
    $normalizeList = static function(array $items): array {
        $rules = [];
        foreach ($items as $item) {
            if (!is_array($item) || empty($item)) continue;
            $rules[] = normalize_branch_rule($item);
        }
        return array_values($rules);
    };
    if (is_array($value)) return $normalizeList($value);
    $raw = trim((string)$value);
    if ($raw === '') return [];
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) {
        if (array_is_list($decoded)) return $normalizeList($decoded);
        return $normalizeList([$decoded]);
    }
    $parts = preg_split('/\s*,\s*(?=\{)/', $raw) ?: [];
    $rules = [];
    foreach ($parts as $part) {
        $item = json_decode((string)$part, true);
        if (is_array($item) && !empty($item)) {
            $rules[] = normalize_branch_rule($item);
        }
    }
    return array_values($rules);
}

function parse_responses(?SimpleXMLElement $xml): array {
    if ($xml === null || !isset($xml->responses)) return [];
    $responses = [];
    foreach ($xml->responses->response as $response) {
        $answers = [];
        $answersByQuestion = [];
        $gradeOverrides = [];
        foreach ($response->question as $questionNode) {
            $answerValues = [];
            foreach ($questionNode->answer as $answerNode) {
                $text = trim((string)$answerNode);
                if ($text === '') continue;
                $decoded = json_decode($text, true);
                $answerValues[] = json_last_error() === JSON_ERROR_NONE ? $decoded : $text;
            }
            $questionId = (string)($questionNode['id'] ?? '');
            if ($questionId === '') continue;
            $answers[] = ['questionId' => $questionId, 'answers' => $answerValues];
            $answersByQuestion[$questionId] = count($answerValues) <= 1 ? ($answerValues[0] ?? '') : array_values($answerValues);
            $attrs = $questionNode->attributes();
            $override = isset($attrs['gradeOverride']) ? strtolower(trim((string)$attrs['gradeOverride'])) : '';
            if ($override !== '') $gradeOverrides[$questionId] = $override === 'correct';
        }
        $responses[] = [
            'id' => (string)($response['id'] ?? ''),
            'timestamp' => (string)($response['timestamp'] ?? ''),
            'answers' => $answers,
            'answersByQuestion' => $answersByQuestion,
            'gradeOverrides' => $gradeOverrides,
        ];
    }
    usort($responses, static fn(array $a, array $b): int => strcmp((string)($b['timestamp'] ?? ''), (string)($a['timestamp'] ?? '')));
    return $responses;
}

try {

    $id = trim((string)($_POST['id'] ?? $_GET['id'] ?? ''));
    if ($id === '') {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Missing form id.'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        exit;
    }

    $formUtils = new FormUtils($id);
    $payload = $formUtils->toEditorPayload();
    $xml = $formUtils->xml();
    if ($xml === null) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Form not found.'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        exit;
    }

    $metadataSettings = [
        'who_can_fill' => (string)($xml->metadata->settings->who_can_fill ?? 'logged_in'),
        'accepted_responses' => ['enabled' => xml_flag($xml->metadata->settings->accepted_responses ?? null, 'enabled', true)],
        'start_date' => ['datetime' => xml_attr($xml->metadata->settings->start_date ?? null, 'datetime', '')],
        'end_date' => ['datetime' => xml_attr($xml->metadata->settings->end_date ?? null, 'datetime', '')],
        'time_duration' => ['minutes' => (int)xml_attr($xml->metadata->settings->time_duration ?? null, 'minutes', '0')],
        'shuffle_questions' => ['enabled' => xml_flag($xml->metadata->settings->shuffle_questions ?? null, 'enabled', false)],
        'disable_question_number_for_respondents' => ['enabled' => xml_flag($xml->metadata->settings->disable_question_number_for_respondents ?? null, 'enabled', false)],
        'show_progress_bar' => ['enabled' => xml_flag($xml->metadata->settings->show_progress_bar ?? null, 'enabled', true)],
        'hide_submit_another_response' => ['enabled' => xml_flag($xml->metadata->settings->hide_submit_another_response ?? null, 'enabled', false)],
        'customize_thank_you_message' => ['message' => xml_attr($xml->metadata->settings->customize_thank_you_message ?? null, 'message', '')],
        'show_score_in_thank_you' => ['enabled' => xml_flag($xml->metadata->settings->show_score_in_thank_you ?? null, 'enabled', false)],
        'allow_respondents_to_save_their_responses' => ['enable' => xml_flag($xml->metadata->settings->allow_respondents_to_save_their_responses ?? null, 'enable', false)],
        'allow_respondents_to_edit_their_responses' => ['enable' => xml_flag($xml->metadata->settings->allow_respondents_to_edit_their_responses ?? null, 'enable', false)],
        'allow_receipt_of_responses_after_submission' => ['enable' => xml_flag($xml->metadata->settings->allow_receipt_of_responses_after_submission ?? null, 'enable', false)],
        'get_email_notification_of_each_response' => ['enable' => xml_flag($xml->metadata->settings->get_email_notification_of_each_response ?? null, 'enable', false)],
    ];

    $headerBannerNode = $xml->metadata->styles->{'header-banner'} ?? $xml->metadata->styles->headerBanner ?? null;
    $metadataStyles = [
        'layout' => (string)($xml->metadata->styles->layout ?? 'default'),
        'background' => ['style' => xml_attr($xml->metadata->styles->background ?? null, 'style', 'linear-gradient(180deg, #f5f8fc 0%, #edf4ff 48%, #f7f9fd 100%)')],
        'backgroundMusic' => [
            'enable' => xml_flag($xml->metadata->styles->{'background-music'} ?? null, 'enable', false),
            'src' => xml_attr($xml->metadata->styles->{'background-music'} ?? null, 'src', ''),
        ],
        'headerBanner' => [
            'enable' => xml_flag($headerBannerNode, 'enable', false) || trim(xml_attr($headerBannerNode, 'src', '')) !== '',
            'src' => xml_attr($headerBannerNode, 'src', ''),
            'type' => strtolower(trim(xml_attr($headerBannerNode, 'type', 'image'))) ?: 'image',
            'alt' => xml_attr($headerBannerNode, 'alt', ''),
        ],
        'accentColor' => (string)($xml->metadata->styles->accentColor ?? '#2563eb'),
        'cardRadius' => (int)($xml->metadata->styles->cardRadius ?? 18),
        'formWidth' => (int)($xml->metadata->styles->formWidth ?? 80),
    ];

    $metadataUi = [
        'showRequiredAsterisk' => xml_flag($xml->metadata->ui->show_required_asterisk ?? null, 'enabled', true),
        'publishFunctional' => xml_flag($xml->metadata->ui->publish_functional ?? null, 'enabled', true),
        'submitLabel' => xml_attr($xml->metadata->ui->submit_label ?? null, 'value', 'Submit'),
        'publishModeLabel' => xml_attr($xml->metadata->ui->publish_mode_label ?? null, 'value', 'Publish'),
        'thankYouTitle' => xml_attr($xml->metadata->ui->thank_you_title ?? null, 'value', 'Response submitted'),
    ];

    $questions = [];
    if (isset($payload['questions']) && is_array($payload['questions'])) {
        $index = 0;
        foreach ($payload['questions'] as $question) {
            if (!is_array($question)) { $index++; continue; }
            $node = null;
            if (isset($xml->questions)) {
                $children = [];
                foreach ($xml->questions->children() as $child) $children[] = $child;
                $node = $children[$index] ?? null;
            }
            $extra = [
                'mediaUrl' => $node ? (string)($node->mediaUrl ?? '') : '',
                'mediaType' => $node ? (string)($node->mediaType ?? 'image') : 'image',
                'mediaAlt' => $node ? (string)($node->mediaAlt ?? '') : '',
                'maxRating' => $node ? (int)($node->maxRating ?? 5) : 5,
                'minLabel' => $node ? (string)($node->minLabel ?? 'Not likely') : 'Not likely',
                'maxLabel' => $node ? (string)($node->maxLabel ?? 'Very likely') : 'Very likely',
                'maxRank' => $node ? (int)($node->maxRank ?? 4) : 4,
                'fileAccept' => $node ? (string)($node->fileAccept ?? '') : (string)($question['fileAccept'] ?? ''),
                'fileMaxSize' => $node ? (string)($node->fileMaxSize ?? '') : (string)($question['fileMaxSize'] ?? ''),
                'multipleFiles' => $node ? normalize_bool((string)($node->multipleFiles ?? 'false')) : normalize_bool($question['multipleFiles'] ?? false),
            ];

            $question['required'] = normalize_bool($question['required'] ?? false);
            $question['isMultiple'] = normalize_bool($question['isMultiple'] ?? false);
            $question['isDropdown'] = normalize_bool($question['isDropdown'] ?? false);
            $question['shuffle'] = normalize_bool($question['shuffle'] ?? false);
            $question['restrictionEnabled'] = normalize_bool($question['restrictionEnabled'] ?? false);
            $question['options'] = parse_json_or_list($node ? (string)($node->optionsJson ?? $node->options ?? '') : ($question['options'] ?? []));
            $question['columns'] = parse_json_or_list($node ? (string)($node->columnsJson ?? $node->columns ?? '') : ($question['columns'] ?? []));
            $question['statements'] = parse_json_or_list($node ? (string)($node->statementsJson ?? $node->statements ?? '') : ($question['statements'] ?? []));
            $question['limit'] = parse_json_or_list($node ? (string)($node->limitJson ?? $node->limit ?? '') : ($question['limit'] ?? []));
            if (count($question['limit']) < 2) $question['limit'] = ['noLimit', 0];
            $question['branchingRules'] = parse_branch_rules($node ? (string)($node->branchingRulesJson ?? $node->branchingRules ?? '') : ($question['branchingRules'] ?? []));
            $question['branching'] = normalize_bool($question['branching'] ?? false) || !empty($question['branchingRules']);

            $correctAnswersRaw = $node ? trim((string)($node->correctAnswersJson ?? $node->correctAnswers ?? '')) : '';
            $acceptedAnswersRaw = $node ? trim((string)($node->acceptedAnswersJson ?? $node->acceptedAnswers ?? '')) : '';
            $question['correctAnswers'] = parse_json_or_list($correctAnswersRaw !== '' ? $correctAnswersRaw : ($question['correctAnswers'] ?? []));
            $question['acceptedAnswers'] = parse_json_or_list($acceptedAnswersRaw !== '' ? $acceptedAnswersRaw : ($question['acceptedAnswers'] ?? []));

            $questions[] = array_merge($question, $extra);
            $index++;
        }
    }

    $payload['questions'] = $questions;
    $payload['metadataSettings'] = $metadataSettings;
    $payload['metadataStyles'] = $metadataStyles;
    $payload['metadataUi'] = $metadataUi;
    $payload['responses'] = parse_responses($xml);
    $requestedResponseId = trim((string)($_POST['responseId'] ?? $_GET['responseId'] ?? ''));
    $payload['requestedResponseId'] = $requestedResponseId;
    $payload['currentResponse'] = null;
    $payload['currentAnswers'] = [];
    if ($requestedResponseId !== '') {
        foreach ($payload['responses'] as $responseItem) {
            if (($responseItem['id'] ?? '') === $requestedResponseId) {
                $payload['currentResponse'] = $responseItem;
                $payload['currentAnswers'] = is_array($responseItem['answersByQuestion'] ?? null) ? $responseItem['answersByQuestion'] : [];
                break;
            }
        }
    }

    echo json_encode([
        'success' => true,
        'data' => $payload,
        'editorMode' => $formUtils->isEditorMode(),
        'isQuiz' => $formUtils->isQuiz(),
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
}
