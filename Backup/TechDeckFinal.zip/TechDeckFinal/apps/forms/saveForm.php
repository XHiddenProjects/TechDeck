<?php

declare(strict_types=1);

ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
ini_set('html_errors', '0');
error_reporting(0);

ob_start();

$GLOBALS['__saveform_tmp_path'] = null;

register_shutdown_function(static function (): void {
    $tmpPath = $GLOBALS['__saveform_tmp_path'] ?? null;
    $error = error_get_last();

    if ($error === null) {
        return;
    }

    if (is_string($tmpPath) && $tmpPath !== '' && is_file($tmpPath)) {
        @unlink($tmpPath);
    }

    while (ob_get_level() > 0) {
        ob_end_clean();
    }

    $rawMessage = (string)($error['message'] ?? 'Unknown PHP error');
    $rawCode = (int)($error['type'] ?? 0);
    $rawFile = (string)($error['file'] ?? '');
    $rawLine = (int)($error['line'] ?? 0);

    $errorName = match ($rawCode) {
        E_ERROR => 'E_ERROR',
        E_WARNING => 'E_WARNING',
        E_PARSE => 'E_PARSE',
        E_NOTICE => 'E_NOTICE',
        E_CORE_ERROR => 'E_CORE_ERROR',
        E_CORE_WARNING => 'E_CORE_WARNING',
        E_COMPILE_ERROR => 'E_COMPILE_ERROR',
        E_COMPILE_WARNING => 'E_COMPILE_WARNING',
        E_USER_ERROR => 'E_USER_ERROR',
        E_USER_WARNING => 'E_USER_WARNING',
        E_USER_NOTICE => 'E_USER_NOTICE',
        E_STRICT => 'E_STRICT',
        E_RECOVERABLE_ERROR => 'E_RECOVERABLE_ERROR',
        E_DEPRECATED => 'E_DEPRECATED',
        E_USER_DEPRECATED => 'E_USER_DEPRECATED',
        default => 'UNKNOWN'
    };

    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
    }

    echo json_encode([
        'success' => false,
        'error' => $rawMessage,
        'code' => $rawCode,
        'code_name' => $errorName,
        'file' => $rawFile,
        'line' => $rawLine
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
});

use TechDeck\Addons\Form\FormUtils;
use TechDeck\Users;

include_once dirname(__DIR__, 2) . '/init.php';
include_once dirname(__FILE__) . '/libs/form.lib.php';

header('Content-Type: application/json; charset=utf-8');

$users = new Users();

function posted_json_array(mixed $raw): array {
    if (is_array($raw)) {
        return $raw;
    }

    $text = trim((string)$raw);
    if ($text === '') {
        return [];
    }

    $decoded = json_decode($text, true);
    return is_array($decoded) ? $decoded : [];
}

function posted_bool(mixed $value): bool {
    if (is_bool($value)) {
        return $value;
    }

    if (is_numeric($value)) {
        return (int)$value === 1;
    }

    $normalized = strtolower(trim((string)$value));
    return in_array($normalized, ['1', 'true', 'yes', 'on', 'enabled'], true);
}

function value_to_string(mixed $value): string {
    if ($value === null) {
        return '';
    }

    if (is_bool($value)) {
        return $value ? 'true' : 'false';
    }

    if (is_array($value)) {
        return (string)json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }

    return (string)$value;
}

function append_text(DOMDocument $dom, DOMElement $parent, string $name, mixed $value): DOMElement {
    $node = $dom->createElement($name);
    $node->appendChild($dom->createTextNode(value_to_string($value)));
    $parent->appendChild($node);
    return $node;
}

function append_attr_el(DOMDocument $dom, DOMElement $parent, string $name, array $attrs = [], mixed $value = null): DOMElement {
    $node = $dom->createElement($name);

    foreach ($attrs as $attr => $attrValue) {
        $node->setAttribute($attr, value_to_string($attrValue));
    }

    if ($value !== null) {
        $node->appendChild($dom->createTextNode(value_to_string($value)));
    }

    $parent->appendChild($node);
    return $node;
}

function list_payload(mixed $raw): array {
    if (is_array($raw)) {
        return array_values($raw);
    }

    $text = trim((string)$raw);
    if ($text === '') {
        return [];
    }

    $decoded = json_decode($text, true);
    if (is_array($decoded)) {
        return array_values($decoded);
    }

    return array_values(array_filter(array_map('trim', explode(',', $text)), static fn($item) => $item !== ''));
}

function branch_payload(mixed $raw): array {
    if (is_array($raw)) {
        return array_values(array_filter($raw, static fn($item) => is_array($item) && !empty($item)));
    }

    $text = trim((string)$raw);
    if ($text === '') {
        return [];
    }

    $decoded = json_decode($text, true);
    if (is_array($decoded)) {
        return array_values(array_filter($decoded, static fn($item) => is_array($item) && !empty($item)));
    }

    return [];
}

try {
    $id = trim((string)($_POST['formId'] ?? ''));
    if ($id === '') {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Missing formId'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        exit;
    }

    $formUtils = new FormUtils($id);
    $xml = $formUtils->xml();
    if ($xml === null) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Form not found'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        exit;
    }

    $filePath = dirname(__FILE__) . '/database/' . basename($id) . '.xml';

    $dom = new DOMDocument('1.0', 'UTF-8');
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;
    $dom->loadXML($xml->asXML());

    /** @var DOMElement $form */
    $form = $dom->documentElement;

    $metadata = $form->getElementsByTagName('metadata')->item(0);
    if (!$metadata instanceof DOMElement) {
        $metadata = $dom->createElement('metadata');
        $form->appendChild($metadata);
    }

    while ($metadata->firstChild) {
        $metadata->removeChild($metadata->firstChild);
    }

    $title = trim((string)($_POST['title'] ?? 'Untitled form'));
    $description = trim((string)($_POST['description'] ?? ''));
    $type = strtolower(trim((string)($_POST['type'] ?? (string)($xml->metadata->type ?? 'form'))));
    if (!in_array($type, ['form', 'quiz'], true)) {
        $type = 'form';
    }

    append_text($dom, $metadata, 'type', $type);
    append_text($dom, $metadata, 'title', $title !== '' ? $title : 'Untitled form');
    append_text($dom, $metadata, 'description', $description);
    append_text(
        $dom,
        $metadata,
        'author',
        trim((string)$xml->metadata->author) !== '' ? (string)$xml->metadata->author : (string)$users->getUsername()
    );
    append_text($dom, $metadata, 'created', (string)($xml->metadata->created ?? gmdate(DATE_ATOM)));
    append_text($dom, $metadata, 'edited', gmdate(DATE_ATOM));

    $styles = posted_json_array($_POST['metadataStyles'] ?? null);
    $settings = posted_json_array($_POST['metadataSettings'] ?? null);
    $ui = posted_json_array($_POST['metadataUi'] ?? null);

    $stylesNode = $dom->createElement('styles');
    append_text($dom, $stylesNode, 'layout', (string)($styles['layout'] ?? 'default'));
    append_attr_el($dom, $stylesNode, 'background', ['style' => (string)($styles['background']['style'] ?? 'linear-gradient(180deg, #f5f8fc 0%, #edf4ff 48%, #f7f9fd 100%)')]);
    append_attr_el($dom, $stylesNode, 'background-music', [
        'enable' => !empty($styles['backgroundMusic']['enable']) ? '1' : '0',
        'src' => (string)($styles['backgroundMusic']['src'] ?? ''),
    ]);

    $headerBanner = $styles['headerBanner'] ?? $styles['header-banner'] ?? [];
    $headerBannerSrc = trim((string)($headerBanner['src'] ?? ''));
    $headerBannerType = strtolower(trim((string)($headerBanner['type'] ?? 'image')));
    if (!in_array($headerBannerType, ['image', 'video', 'audio'], true)) {
        $headerBannerType = 'image';
    }

    append_attr_el($dom, $stylesNode, 'header-banner', [
        'enable' => (!empty($headerBanner['enable']) || $headerBannerSrc !== '') ? '1' : '0',
        'src' => $headerBannerSrc,
        'type' => $headerBannerType,
        'alt' => (string)($headerBanner['alt'] ?? ''),
    ]);
    append_text($dom, $stylesNode, 'accentColor', (string)($styles['accentColor'] ?? '#2563eb'));
    append_text($dom, $stylesNode, 'cardRadius', (string)($styles['cardRadius'] ?? 18));
    append_text($dom, $stylesNode, 'formWidth', (string)($styles['formWidth'] ?? 80));
    $metadata->appendChild($stylesNode);

    $settingsNode = $dom->createElement('settings');
    append_text($dom, $settingsNode, 'who_can_fill', (string)($settings['who_can_fill'] ?? 'logged_in'));
    append_attr_el($dom, $settingsNode, 'accepted_responses', ['enabled' => !empty($settings['accepted_responses']['enabled']) ? '1' : '0']);
    append_attr_el($dom, $settingsNode, 'start_date', ['datetime' => (string)($settings['start_date']['datetime'] ?? '')]);
    append_attr_el($dom, $settingsNode, 'end_date', ['datetime' => (string)($settings['end_date']['datetime'] ?? '')]);
    append_attr_el($dom, $settingsNode, 'time_duration', ['minutes' => (string)($settings['time_duration']['minutes'] ?? 0)]);
    append_attr_el($dom, $settingsNode, 'shuffle_questions', ['enabled' => !empty($settings['shuffle_questions']['enabled']) ? '1' : '0']);
    append_attr_el($dom, $settingsNode, 'disable_question_number_for_respondents', ['enabled' => !empty($settings['disable_question_number_for_respondents']['enabled']) ? '1' : '0']);
    append_attr_el($dom, $settingsNode, 'show_progress_bar', ['enabled' => !empty($settings['show_progress_bar']['enabled']) ? '1' : '0']);
    append_attr_el($dom, $settingsNode, 'hide_submit_another_response', ['enabled' => !empty($settings['hide_submit_another_response']['enabled']) ? '1' : '0']);
    append_attr_el($dom, $settingsNode, 'customize_thank_you_message', ['message' => (string)($settings['customize_thank_you_message']['message'] ?? '')]);
    append_attr_el($dom, $settingsNode, 'show_score_in_thank_you', ['enabled' => !empty($settings['show_score_in_thank_you']['enabled']) ? '1' : '0']);
    append_attr_el($dom, $settingsNode, 'allow_respondents_to_save_their_responses', ['enable' => !empty($settings['allow_respondents_to_save_their_responses']['enable']) ? '1' : '0']);
    append_attr_el($dom, $settingsNode, 'allow_respondents_to_edit_their_responses', ['enable' => !empty($settings['allow_respondents_to_edit_their_responses']['enable']) ? '1' : '0']);
    append_attr_el($dom, $settingsNode, 'allow_receipt_of_responses_after_submission', ['enable' => !empty($settings['allow_receipt_of_responses_after_submission']['enable']) ? '1' : '0']);
    append_attr_el($dom, $settingsNode, 'get_email_notification_of_each_response', ['enable' => !empty($settings['get_email_notification_of_each_response']['enable']) ? '1' : '0']);
    append_attr_el($dom, $settingsNode, 'text_similarity_leniency', ['percent' => array_key_exists('percent', $settings['text_similarity_leniency'] ?? []) ? (string)($settings['text_similarity_leniency']['percent'] ?? '') : '']);
    $metadata->appendChild($settingsNode);

    append_text($dom, $metadata, 'favorites', '');

    $uiNode = $dom->createElement('ui');
    append_attr_el($dom, $uiNode, 'show_required_asterisk', ['enabled' => !empty($ui['showRequiredAsterisk']) ? '1' : '0']);
    append_attr_el($dom, $uiNode, 'publish_functional', ['enabled' => !empty($ui['publishFunctional']) ? '1' : '0']);
    append_attr_el($dom, $uiNode, 'submit_label', ['value' => (string)($ui['submitLabel'] ?? 'Submit')]);
    append_attr_el($dom, $uiNode, 'publish_mode_label', ['value' => (string)($ui['publishModeLabel'] ?? 'Publish')]);
    append_attr_el($dom, $uiNode, 'thank_you_title', ['value' => (string)($ui['thankYouTitle'] ?? 'Response submitted')]);
    $metadata->appendChild($uiNode);

    $questionsNode = $form->getElementsByTagName('questions')->item(0);
    if (!$questionsNode instanceof DOMElement) {
        $questionsNode = $dom->createElement('questions');
        $form->appendChild($questionsNode);
    }

    while ($questionsNode->firstChild) {
        $questionsNode->removeChild($questionsNode->firstChild);
    }

    $postedQuestions = $_POST['questions'] ?? [];
    if (!is_array($postedQuestions)) {
        $postedQuestions = [];
    }

    foreach (array_values($postedQuestions) as $index => $question) {
        if (!is_array($question)) {
            continue;
        }

        $key = 'q' . ($index + 1);
        $qNode = $dom->createElement($key);
        $questionsNode->appendChild($qNode);

        $options = list_payload($question['options'] ?? []);
        $columns = list_payload($question['columns'] ?? []);
        $statements = list_payload($question['statements'] ?? []);
        $limit = list_payload($question['limit'] ?? []);
        if (count($limit) < 2) {
            $limit = ['noLimit', 0];
        }
        $branchRules = branch_payload($question['branchingRules'] ?? []);
        $correctAnswers = list_payload($question['correctAnswers'] ?? []);
        $acceptedAnswers = list_payload($question['acceptedAnswers'] ?? []);

        $fields = [
            'questionId' => (string)($question['questionId'] ?? ('Q-' . uniqid('', true))),
            'type' => strtolower((string)($question['type'] ?? 'choice')),
            'title' => (string)($question['title'] ?? 'Question'),
            'subtitle' => (string)($question['subtitle'] ?? ''),
            'description' => (string)($question['description'] ?? ''),
            'required' => posted_bool($question['required'] ?? false) ? 'true' : 'false',
            'isMultiple' => posted_bool($question['isMultiple'] ?? false) ? 'true' : 'false',
            'isDropdown' => posted_bool($question['isDropdown'] ?? false) ? 'true' : 'false',
            'shuffle' => posted_bool($question['shuffle'] ?? false) ? 'true' : 'false',
            'branching' => (!empty($branchRules) || posted_bool($question['branching'] ?? false)) ? 'true' : 'false',
            'otherOptionEnabled' => posted_bool($question['otherOptionEnabled'] ?? false) ? 'true' : 'false',
            'otherOptionLabel' => (string)($question['otherOptionLabel'] ?? ''),
            'pointValue' => (string)($question['pointValue'] ?? 0),
            'sectionTitle' => (string)($question['sectionTitle'] ?? ''),
            'sectionOrder' => (string)($question['sectionOrder'] ?? $index),
            'textMode' => (string)($question['textMode'] ?? 'short'),
            'restrictionEnabled' => posted_bool($question['restrictionEnabled'] ?? false) ? 'true' : 'false',
            'restrictionType' => (string)($question['restrictionType'] ?? 'text'),
            'restrictionOperator' => (string)($question['restrictionOperator'] ?? ''),
            'restrictionValue' => (string)($question['restrictionValue'] ?? ''),
            'restrictionValueSecondary' => (string)($question['restrictionValueSecondary'] ?? ''),
            'mediaUrl' => (string)($question['mediaUrl'] ?? ''),
            'mediaType' => (string)($question['mediaType'] ?? 'image'),
            'mediaAlt' => (string)($question['mediaAlt'] ?? ''),
            'maxRating' => (string)($question['maxRating'] ?? 5),
            'minLabel' => (string)($question['minLabel'] ?? 'Not likely'),
            'maxLabel' => (string)($question['maxLabel'] ?? 'Very likely'),
            'maxRank' => (string)($question['maxRank'] ?? max(4, count($options))),
            'fileAccept' => (string)($question['fileAccept'] ?? ''),
            'fileMaxSize' => (string)($question['fileMaxSize'] ?? ''),
            'multipleFiles' => posted_bool($question['multipleFiles'] ?? false) ? 'true' : 'false',
        ];

        foreach ($fields as $name => $value) {
            append_text($dom, $qNode, $name, $value);
        }

        append_text($dom, $qNode, 'options', implode(',', array_map('value_to_string', $options)));
        append_text($dom, $qNode, 'optionsJson', $options);
        append_text($dom, $qNode, 'columns', implode(',', array_map('value_to_string', $columns)));
        append_text($dom, $qNode, 'columnsJson', $columns);
        append_text($dom, $qNode, 'statements', implode(',', array_map('value_to_string', $statements)));
        append_text($dom, $qNode, 'statementsJson', $statements);
        append_text($dom, $qNode, 'limit', implode(',', array_map('value_to_string', $limit)));
        append_text($dom, $qNode, 'limitJson', $limit);
        append_text($dom, $qNode, 'branchingRules', implode(',', array_map(static fn($item): string => json_encode($item, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), $branchRules)));
        append_text($dom, $qNode, 'branchingRulesJson', $branchRules);
        append_text($dom, $qNode, 'correctAnswers', implode(',', array_map('value_to_string', $correctAnswers)));
        append_text($dom, $qNode, 'correctAnswersJson', $correctAnswers);
        append_text($dom, $qNode, 'acceptedAnswers', implode(',', array_map('value_to_string', $acceptedAnswers)));
        append_text($dom, $qNode, 'acceptedAnswersJson', $acceptedAnswers);
    }

    $responsesNode = $form->getElementsByTagName('responses')->item(0);
    if (!$responsesNode instanceof DOMElement) {
        $responsesNode = $dom->createElement('responses');
        $form->appendChild($responsesNode);
    }

    $responsePayload = [
        'success' => true,
        'saved' => [
            'questions' => count($postedQuestions),
            'edited' => gmdate(DATE_ATOM),
            'type' => $type,
        ],
    ];

    $xmlOutput = $dom->saveXML();
    if ($xmlOutput === false) {
        throw new RuntimeException('Unable to generate XML output');
    }

    $tmpFilePath = $filePath . '.tmp.' . bin2hex(random_bytes(8));
    $GLOBALS['__saveform_tmp_path'] = $tmpFilePath;

    if (file_put_contents($tmpFilePath, $xmlOutput, LOCK_EX) === false) {
        throw new RuntimeException('Unable to write form data');
    }

    $verifyDom = new DOMDocument('1.0', 'UTF-8');
    $verifyDom->preserveWhiteSpace = false;
    if (!$verifyDom->load($tmpFilePath)) {
        throw new RuntimeException('Generated XML failed validation');
    }

    if (!@rename($tmpFilePath, $filePath)) {
        throw new RuntimeException('Unable to finalize form save');
    }

    $GLOBALS['__saveform_tmp_path'] = null;

    echo json_encode($responsePayload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    $tmpPath = $GLOBALS['__saveform_tmp_path'] ?? null;
    if (is_string($tmpPath) && $tmpPath !== '' && is_file($tmpPath)) {
        @unlink($tmpPath);
    }
    $GLOBALS['__saveform_tmp_path'] = null;

    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage(),
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
}
