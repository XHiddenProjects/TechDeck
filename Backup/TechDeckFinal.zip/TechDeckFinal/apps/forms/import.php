<?php
declare(strict_types=1);

use TechDeck\Addons\Form\FormUtils;
use TechDeck\Data;

include_once dirname(__DIR__, 2) . '/init.php';
include_once dirname(__FILE__) . '/libs/form.lib.php';

header('Content-Type: application/json; charset=utf-8');

function import_respond(array $payload, int $status = 200): void {
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function import_bool(mixed $value, bool $default = false): bool {
    if ($value instanceof SimpleXMLElement) $value = (string)$value;
    if (is_bool($value)) return $value;
    if ($value === null) return $default;
    $normalized = strtolower(trim((string)$value));
    if ($normalized === '') return $default;
    return in_array($normalized, ['1', 'true', 'yes', 'on', 'enabled'], true);
}

function import_text(mixed $value, string $default = ''): string {
    if ($value instanceof SimpleXMLElement) $value = (string)$value;
    if ($value === null) return $default;
    $text = trim((string)$value);
    return $text === '' ? $default : $text;
}

function import_children_list(?SimpleXMLElement $node): array {
    if ($node === null) return [];
    $values = [];
    foreach ($node->children() as $child) {
        $text = trim((string)$child);
        if ($text !== '') $values[] = $text;
    }
    if (!empty($values)) return $values;
    $text = trim((string)$node);
    if ($text === '') return [];
    $decoded = json_decode($text, true);
    if (is_array($decoded)) return array_values(array_map(static fn($item) => is_scalar($item) ? trim((string)$item) : '', $decoded));
    return array_values(array_filter(array_map('trim', explode(',', $text)), static fn($item) => $item !== ''));
}

function normalize_import_rule(array $item): array {
    $operator = import_text($item['operator'] ?? 'answered', 'answered');
    $value = import_text($item['value'] ?? '');
    $action = strtolower(import_text($item['action'] ?? '', ''));
    if (!in_array($action, ['jump', 'show', 'hide', 'require', 'optional'], true)) {
        $action = import_text($item['targetQuestionId'] ?? '') !== '' ? 'show' : 'jump';
    }
    $target = import_text($item['target'] ?? ($action === 'jump' ? '**next**' : ''), $action === 'jump' ? '**next**' : '');
    $targetQuestionId = import_text($item['targetQuestionId'] ?? '');
    if ($action !== 'jump' && $targetQuestionId === '' && $target !== '' && !str_starts_with($target, '**')) {
        $targetQuestionId = $target;
        $target = '';
    }
    if (in_array($operator, ['answered', 'not_answered'], true)) {
        $value = '';
    }
    return [
        'operator' => $operator,
        'value' => $value,
        'action' => $action,
        'target' => $target,
        'targetQuestionId' => $targetQuestionId,
    ];
}
function import_rules_list(?SimpleXMLElement $node): array {
    if ($node === null) return [];
    $rules = [];
    foreach ($node->children() as $child) {
        $rules[] = normalize_import_rule([
            'operator' => (string)($child->operator ?? 'answered'),
            'value' => (string)($child->value ?? ''),
            'action' => (string)($child->action ?? ''),
            'target' => (string)($child->target ?? ''),
            'targetQuestionId' => (string)($child->targetQuestionId ?? ''),
        ]);
    }
    if (!empty($rules)) return array_values($rules);
    $text = trim((string)$node);
    if ($text === '') return [];
    $decoded = json_decode($text, true);
    if (is_array($decoded)) {
        if (array_is_list($decoded)) {
            return array_values(array_filter(array_map(static function ($item): array {
                if (!is_array($item)) return [];
                return normalize_import_rule($item);
            }, $decoded)));
        }
        return [normalize_import_rule($decoded)];
    }
    $parts = preg_split('/\s*,\s*(?=\{)/', $text) ?: [];
    foreach ($parts as $part) {
        $item = json_decode((string)$part, true);
        if (is_array($item) && !empty($item)) {
            $rules[] = normalize_import_rule($item);
        }
    }
    return array_values($rules);
}

function import_node(?SimpleXMLElement $parent, string $name): ?SimpleXMLElement {
    if ($parent === null) return null;
    return isset($parent->{$name}) ? $parent->{$name} : null;
}

function append_text(DOMDocument $dom, DOMElement $parent, string $name, mixed $value): DOMElement {
    $node = $dom->createElement($name);
    $node->appendChild($dom->createTextNode((string)$value));
    $parent->appendChild($node);
    return $node;
}

function append_attr_el(DOMDocument $dom, DOMElement $parent, string $name, array $attrs = [], mixed $value = null): DOMElement {
    $node = $dom->createElement($name);
    foreach ($attrs as $attr => $attrValue) {
        $node->setAttribute($attr, (string)$attrValue);
    }
    if ($value !== null) {
        $node->appendChild($dom->createTextNode((string)$value));
    }
    $parent->appendChild($node);
    return $node;
}

function append_json_list(DOMDocument $dom, DOMElement $parent, string $legacyName, string $jsonName, array $values): void {
    append_text($dom, $parent, $legacyName, implode(',', $values));
    append_text($dom, $parent, $jsonName, json_encode(array_values($values), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
}

function append_rules(DOMDocument $dom, DOMElement $parent, string $legacyName, string $jsonName, array $rules): void {
    $legacy = [];
    foreach ($rules as $rule) {
        $legacy[] = json_encode($rule, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    }
    append_text($dom, $parent, $legacyName, implode(',', $legacy));
    append_text($dom, $parent, $jsonName, json_encode(array_values($rules), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
}

try {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        import_respond(['success' => false, 'error' => 'Method not allowed. Use POST.'], 405);
    }

    if (!isset($_FILES['xmlFile']) || $_FILES['xmlFile']['error'] !== UPLOAD_ERR_OK) {
        import_respond(['success' => false, 'error' => 'No file uploaded or upload error occurred.'], 400);
    }

    $file = $_FILES['xmlFile'];
    if (!preg_match('/\.xml$/i', (string)$file['name'])) {
        import_respond(['success' => false, 'error' => 'Invalid file type. Only XML files are allowed.'], 400);
    }

    $xmlContent = file_get_contents((string)$file['tmp_name']);
    if ($xmlContent === false || trim($xmlContent) === '') {
        import_respond(['success' => false, 'error' => 'Failed to read file content.'], 400);
    }

    libxml_use_internal_errors(true);
    $importedXml = simplexml_load_string($xmlContent, 'SimpleXMLElement', LIBXML_NOCDATA);
    if (!$importedXml instanceof SimpleXMLElement) {
        $errors = array_map(static fn($error) => trim((string)$error->message), libxml_get_errors() ?: []);
        libxml_clear_errors();
        import_respond(['success' => false, 'error' => 'Invalid XML format.', 'details' => $errors], 400);
    }
    libxml_clear_errors();

    $rootName = $importedXml->getName();
    if (!in_array($rootName, ['form', 'formExport'], true)) {
        import_respond(['success' => false, 'error' => 'Unsupported XML root. Expected <form> or <formExport>.'], 400);
    }

    $metadataNode = import_node($importedXml, 'metadata');
    $settingsNode = import_node($metadataNode, 'settings') ?? import_node($importedXml, 'settings');
    $stylesNode   = import_node($metadataNode, 'styles') ?? import_node($importedXml, 'styles');
    $uiNode       = import_node($metadataNode, 'ui') ?? import_node($importedXml, 'ui');
    $responsesNode = import_node($importedXml, 'responses');
    $questionsNode = import_node($importedXml, 'questions');

    if ($questionsNode === null && !isset($importedXml->questions)) {
        import_respond(['success' => false, 'error' => 'Invalid XML format. Missing questions section.'], 400);
    }

    $utils = new FormUtils();
    $newFormId = $utils->createNew();
    $dbPath = rtrim(dirname(__FILE__) . '/database', "/\\");
    $newFormPath = $dbPath . DIRECTORY_SEPARATOR . $newFormId . '.xml';

    $dom = new DOMDocument('1.0', 'UTF-8');
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;

    $form = $dom->createElement('form');
    $form->setAttribute('id', $newFormId);
    $dom->appendChild($form);

    $metadata = $dom->createElement('metadata');
    $form->appendChild($metadata);

    $sourceType = strtolower(import_text($metadataNode?->type ?? $importedXml['kind'] ?? 'form', 'form'));
    if (!in_array($sourceType, ['form', 'quiz'], true)) $sourceType = 'form';
    append_text($dom, $metadata, 'type', $sourceType);
    append_text($dom, $metadata, 'title', import_text($metadataNode?->title ?? 'Imported form', 'Imported form'));
    append_text($dom, $metadata, 'description', import_text($metadataNode?->description ?? ''));
    append_text($dom, $metadata, 'author', import_text($metadataNode?->author ?? ''));
    append_text($dom, $metadata, 'created', import_text($metadataNode?->created ?? gmdate(DATE_ATOM), gmdate(DATE_ATOM)));
    append_text($dom, $metadata, 'edited', gmdate(DATE_ATOM));

    $styles = $dom->createElement('styles');
    append_text($dom, $styles, 'layout', import_text($stylesNode?->layout ?? 'default', 'default'));
    append_attr_el($dom, $styles, 'background', [
        'style' => import_text($stylesNode?->background?->style ?? $stylesNode?->background['style'] ?? 'linear-gradient(180deg, #f5f8fc 0%, #edf4ff 48%, #f7f9fd 100%)', 'linear-gradient(180deg, #f5f8fc 0%, #edf4ff 48%, #f7f9fd 100%)')
    ]);
    append_attr_el($dom, $styles, 'background-music', [
        'enable' => import_bool($stylesNode?->{'background-music'}['enable'] ?? $stylesNode?->backgroundMusic->enable ?? false) ? '1' : '0',
        'src' => import_text($stylesNode?->{'background-music'}['src'] ?? $stylesNode?->backgroundMusic->src ?? '')
    ]);
    append_text($dom, $styles, 'accentColor', import_text($stylesNode?->accentColor ?? '#2563eb', '#2563eb'));
    append_text($dom, $styles, 'cardRadius', import_text($stylesNode?->cardRadius ?? '18', '18'));
    append_text($dom, $styles, 'formWidth', import_text($stylesNode?->formWidth ?? '80', '80'));
    $metadata->appendChild($styles);

    $settings = $dom->createElement('settings');
    append_text($dom, $settings, 'who_can_fill', import_text($settingsNode?->who_can_fill ?? 'logged_in', 'logged_in'));
    append_attr_el($dom, $settings, 'accepted_responses', ['enabled' => import_bool($settingsNode?->accepted_responses?->enabled ?? $settingsNode?->accepted_responses['enabled'] ?? true, true) ? '1' : '0']);
    append_attr_el($dom, $settings, 'start_date', ['datetime' => import_text($settingsNode?->start_date?->datetime ?? $settingsNode?->start_date['datetime'] ?? '')]);
    append_attr_el($dom, $settings, 'end_date', ['datetime' => import_text($settingsNode?->end_date?->datetime ?? $settingsNode?->end_date['datetime'] ?? '')]);
    append_attr_el($dom, $settings, 'time_duration', ['minutes' => import_text($settingsNode?->time_duration?->minutes ?? $settingsNode?->time_duration['minutes'] ?? '0', '0')]);
    append_attr_el($dom, $settings, 'shuffle_questions', ['enabled' => import_bool($settingsNode?->shuffle_questions?->enabled ?? $settingsNode?->shuffle_questions['enabled'] ?? false) ? '1' : '0']);
    append_attr_el($dom, $settings, 'disable_question_number_for_respondents', ['enabled' => import_bool($settingsNode?->disable_question_number_for_respondents?->enabled ?? $settingsNode?->disable_question_number_for_respondents['enabled'] ?? false) ? '1' : '0']);
    append_attr_el($dom, $settings, 'show_progress_bar', ['enabled' => import_bool($settingsNode?->show_progress_bar?->enabled ?? $settingsNode?->show_progress_bar['enabled'] ?? true, true) ? '1' : '0']);
    append_attr_el($dom, $settings, 'hide_submit_another_response', ['enabled' => import_bool($settingsNode?->hide_submit_another_response?->enabled ?? $settingsNode?->hide_submit_another_response['enabled'] ?? false) ? '1' : '0']);
    append_attr_el($dom, $settings, 'customize_thank_you_message', ['message' => import_text($settingsNode?->customize_thank_you_message?->message ?? $settingsNode?->customize_thank_you_message['message'] ?? '')]);
    append_attr_el($dom, $settings, 'show_score_in_thank_you', ['enabled' => import_bool($settingsNode?->show_score_in_thank_you?->enabled ?? $settingsNode?->show_score_in_thank_you['enabled'] ?? false) ? '1' : '0']);
    append_attr_el($dom, $settings, 'allow_respondents_to_save_their_responses', ['enable' => import_bool($settingsNode?->allow_respondents_to_save_their_responses?->enable ?? $settingsNode?->allow_respondents_to_save_their_responses['enable'] ?? false) ? '1' : '0']);
    append_attr_el($dom, $settings, 'allow_respondents_to_edit_their_responses', ['enable' => import_bool($settingsNode?->allow_respondents_to_edit_their_responses?->enable ?? $settingsNode?->allow_respondents_to_edit_their_responses['enable'] ?? false) ? '1' : '0']);
    append_attr_el($dom, $settings, 'allow_receipt_of_responses_after_submission', ['enable' => import_bool($settingsNode?->allow_receipt_of_responses_after_submission?->enable ?? $settingsNode?->allow_receipt_of_responses_after_submission['enable'] ?? false) ? '1' : '0']);
    append_attr_el($dom, $settings, 'get_email_notification_of_each_response', ['enable' => import_bool($settingsNode?->get_email_notification_of_each_response?->enable ?? $settingsNode?->get_email_notification_of_each_response['enable'] ?? false) ? '1' : '0']);
    $metadata->appendChild($settings);

    append_text($dom, $metadata, 'favorites', '');

    $ui = $dom->createElement('ui');
    append_attr_el($dom, $ui, 'show_required_asterisk', ['enabled' => import_bool($uiNode?->show_required_asterisk['enabled'] ?? $uiNode?->showRequiredAsterisk ?? true, true) ? '1' : '0']);
    append_attr_el($dom, $ui, 'publish_functional', ['enabled' => import_bool($uiNode?->publish_functional['enabled'] ?? $uiNode?->publishFunctional ?? true, true) ? '1' : '0']);
    append_attr_el($dom, $ui, 'submit_label', ['value' => import_text($uiNode?->submit_label['value'] ?? $uiNode?->submitLabel ?? 'Submit', 'Submit')]);
    append_attr_el($dom, $ui, 'publish_mode_label', ['value' => import_text($uiNode?->publish_mode_label['value'] ?? $uiNode?->publishModeLabel ?? 'Publish', 'Publish')]);
    append_attr_el($dom, $ui, 'thank_you_title', ['value' => import_text($uiNode?->thank_you_title['value'] ?? $uiNode?->thankYouTitle ?? 'Response submitted', 'Response submitted')]);
    $metadata->appendChild($ui);

    $questionsEl = $dom->createElement('questions');
    $form->appendChild($questionsEl);

    $sourceQuestions = [];
    if ($questionsNode !== null) {
        foreach ($questionsNode->children() as $child) {
            $sourceQuestions[] = $child;
        }
    }

    $questionCount = 0;
    foreach ($sourceQuestions as $index => $questionNode) {
        $questionCount++;
        $qNode = $dom->createElement('q' . ($index + 1));
        $questionsEl->appendChild($qNode);

        $options = import_children_list($questionNode->options ?? null);
        $columns = import_children_list($questionNode->columns ?? null);
        $statements = import_children_list($questionNode->statements ?? null);
        $limit = import_children_list($questionNode->limit ?? null);
        if (count($limit) < 2) $limit = ['noLimit', '0'];
        $branchingRules = import_rules_list($questionNode->branchingRulesJson ?? $questionNode->branchingRules ?? $questionNode->branchRules ?? null);
        $correctAnswers = import_children_list($questionNode->correctAnswers ?? null);
        $acceptedAnswers = import_children_list($questionNode->acceptedAnswers ?? null);

        $fields = [
            'questionId' => import_text($questionNode->questionId ?? ('Q-' . uniqid('', true)), 'Q-' . uniqid('', true)),
            'type' => strtolower(import_text($questionNode->type ?? 'choice', 'choice')),
            'title' => import_text($questionNode->title ?? 'Question', 'Question'),
            'subtitle' => import_text($questionNode->subtitle ?? ''),
            'description' => import_text($questionNode->description ?? ''),
            'required' => import_bool($questionNode->required ?? false) ? 'true' : 'false',
            'isMultiple' => import_bool($questionNode->isMultiple ?? false) ? 'true' : 'false',
            'isDropdown' => import_bool($questionNode->isDropdown ?? false) ? 'true' : 'false',
            'shuffle' => import_bool($questionNode->shuffle ?? false) ? 'true' : 'false',
            'branching' => (!empty($branchingRules) || import_bool($questionNode->branching ?? false)) ? 'true' : 'false',
            'otherOptionEnabled' => import_bool($questionNode->otherOptionEnabled ?? false) ? 'true' : 'false',
            'otherOptionLabel' => import_text($questionNode->otherOptionLabel ?? ''),
            'pointValue' => import_text($questionNode->pointValue ?? '0', '0'),
            'sectionTitle' => import_text($questionNode->sectionTitle ?? ''),
            'sectionOrder' => import_text($questionNode->sectionOrder ?? (string)$index, (string)$index),
            'textMode' => import_text($questionNode->textMode ?? 'short', 'short'),
            'restrictionEnabled' => import_bool($questionNode->restrictionEnabled ?? false) ? 'true' : 'false',
            'restrictionType' => import_text($questionNode->restrictionType ?? 'text', 'text'),
            'restrictionOperator' => import_text($questionNode->restrictionOperator ?? ''),
            'restrictionValue' => import_text($questionNode->restrictionValue ?? ''),
            'restrictionValueSecondary' => import_text($questionNode->restrictionValueSecondary ?? ''),
            'mediaUrl' => import_text($questionNode->mediaUrl ?? ''),
            'mediaType' => import_text($questionNode->mediaType ?? 'image', 'image'),
            'mediaAlt' => import_text($questionNode->mediaAlt ?? ''),
            'maxRating' => import_text($questionNode->maxRating ?? '5', '5'),
            'minLabel' => import_text($questionNode->minLabel ?? 'Not likely', 'Not likely'),
            'maxLabel' => import_text($questionNode->maxLabel ?? 'Very likely', 'Very likely'),
            'maxRank' => import_text($questionNode->maxRank ?? (string)max(count($options), 4), (string)max(count($options), 4)),
            'fileAccept' => import_text($questionNode->fileAccept ?? ''),
            'fileMaxSize' => import_text($questionNode->fileMaxSize ?? ''),
            'multipleFiles' => import_bool($questionNode->multipleFiles ?? false) ? 'true' : 'false',
        ];

        if ($fields['subtitle'] === 'false') $fields['subtitle'] = '';
        if ($fields['description'] === 'false') $fields['description'] = '';

        foreach ($fields as $name => $value) {
            append_text($dom, $qNode, $name, $value);
        }
        append_json_list($dom, $qNode, 'options', 'optionsJson', $options);
        append_json_list($dom, $qNode, 'columns', 'columnsJson', $columns);
        append_json_list($dom, $qNode, 'statements', 'statementsJson', $statements);
        append_json_list($dom, $qNode, 'limit', 'limitJson', $limit);
        append_rules($dom, $qNode, 'branchingRules', 'branchingRulesJson', $branchingRules);
        append_json_list($dom, $qNode, 'correctAnswers', 'correctAnswersJson', $correctAnswers);
        append_json_list($dom, $qNode, 'acceptedAnswers', 'acceptedAnswersJson', $acceptedAnswers);
    }

    $responsesEl = $dom->createElement('responses');
    $form->appendChild($responsesEl);

    if ($responsesNode !== null) {
        foreach ($responsesNode->children() as $responseNode) {
            $responseEl = $dom->createElement('response');
            if (isset($responseNode['id'])) $responseEl->setAttribute('id', (string)$responseNode['id']);
            if (isset($responseNode['timestamp'])) $responseEl->setAttribute('timestamp', (string)$responseNode['timestamp']);
            foreach ($responseNode->children() as $questionResponseNode) {
                $questionEl = $dom->createElement('question');
                if (isset($questionResponseNode['id'])) $questionEl->setAttribute('id', (string)$questionResponseNode['id']);
                foreach ($questionResponseNode->children() as $answerNode) {
                    $answerEl = $dom->createElement('answer');
                    $answerEl->appendChild($dom->createTextNode((string)$answerNode));
                    $questionEl->appendChild($answerEl);
                }
                $responseEl->appendChild($questionEl);
            }
            $responsesEl->appendChild($responseEl);
        }
    }

    $dom->save($newFormPath);

    import_respond([
        'success' => true,
        'formId' => $newFormId,
        'title' => import_text($metadataNode?->title ?? 'Imported form', 'Imported form'),
        'isQuiz' => $sourceType === 'quiz',
        'questionCount' => $questionCount,
        'root' => $rootName,
    ]);
} catch (Throwable $e) {
    import_respond(['success' => false, 'error' => 'Server error: ' . $e->getMessage()], 500);
}
