(() => {
  const STORAGE_KEYS = {
    favorites: 'forms.index.favorites.v2',
    viewMode: 'forms.index.viewMode.v2',
    activeTab: 'forms.index.activeTab.v2',
    search: 'forms.index.search.v2'
  };

  const SECTION_KEYS = ['recent', 'my-forms', 'filled-forms', 'favorites'];
  const SELECTORS = {
    searchInput: '#form-search',
    navItems: '.form-nav .form-nav-item',
    sortItems: '.form-sorting .form-sorting-item',
    sections: 'section.section.display',
    templatesToggle: '.toggle-templates-btn',
    templatesCollapse: '#templates',
    importButton: '.form-btn-import',
    cardLinks: '.form-action-link',
    cardTitle: '.card-title',
    cardAuthor: '.card-text.text-secondary'
  };


let languageData = {};

function getBrowserLanguage() {
  const browserLang = (navigator.language || navigator.userLanguage || 'en').toLowerCase();
  const langCode = browserLang.split('-')[0];
  return langCode || 'en';
}

async function loadLanguage(lang = 'en') {
  try {
    const langCode = lang || 'en';
    const response = await fetch(`../../locales/${langCode}.json`);
    if (!response.ok) throw new Error(`Failed to load language: ${langCode}`);
    languageData = await response.json();
  } catch (error) {
    console.warn(`Language loading error`, error);
    languageData = {};
  }
}

function t(path, defaultValue = path) {
  const keys = path.split('.');
  let value = languageData;
  for (const key of keys) {
    if (value && typeof value === 'object' && key in value) value = value[key];
    else return defaultValue;
  }
  return typeof value === 'string' ? value : defaultValue;
}

function translate(template, params = {}) {
  return Object.entries(params).reduce((output, [key, value]) => output.replaceAll(`{${key}}`, String(value)), template);
}

  const state = {
    viewMode: readStorage(STORAGE_KEYS.viewMode, 'grid'),
    activeTab: readStorage(STORAGE_KEYS.activeTab, 'recent'),
    search: readStorage(STORAGE_KEYS.search, ''),
    favorites: readJSONStorage(STORAGE_KEYS.favorites, []),
    exportModal: null,
    exportForm: null,
    exportTitle: null,
    exportDownloadBtn: null,
    exportStatus: null,
    currentExportFormId: null,
  };

  const refs = {
    navItems: [],
    sortItems: [],
    sections: new Map(),
    searchInput: null,
    templatesToggle: null,
    templatesCollapse: null,
  };

  document.addEventListener('DOMContentLoaded', () => { init().catch(console.error); }, { once: true });

  async function init() {
    await loadLanguage(getBrowserLanguage());
    refs.searchInput = document.querySelector(SELECTORS.searchInput);
    refs.templatesToggle = document.querySelector(SELECTORS.templatesToggle);
    refs.templatesCollapse = document.querySelector(SELECTORS.templatesCollapse);
    refs.navItems = Array.from(document.querySelectorAll(SELECTORS.navItems));
    refs.sortItems = Array.from(document.querySelectorAll(SELECTORS.sortItems));

    const sections = Array.from(document.querySelectorAll(SELECTORS.sections));
    sections.forEach((section, index) => {
      section.dataset.sectionKey = section.dataset.sectionKey || inferSectionKey(section, index);
      refs.sections.set(section.dataset.sectionKey, section);
    });

    localizeStaticIndexContent();
    enhanceAllCards();
    buildFavoritesSection();
    bindStaticEvents();
    syncTemplateToggleLabel();
    applyViewMode(state.viewMode);
    activateTab(refs.sections.has(state.activeTab) ? state.activeTab : SECTION_KEYS[0]);

    if (refs.searchInput) refs.searchInput.value = state.search;
    applySearch();
    refreshEmptyStates();
  }


function localizeStaticIndexContent() {
  if (refs.searchInput) refs.searchInput.setAttribute('placeholder', t('apps.applications.forms.index.search_placeholder', 'Search forms'));

  refs.navItems.forEach((item, index) => {
    const key = item.dataset.tab || item.dataset.sectionKey || SECTION_KEYS[index] || inferKeyFromNavText(item.textContent) || `tab-${index}`;
    if (key === 'recent') item.textContent = t('apps.applications.forms.index.recent', t('apps.applications.forms.recent', 'Recent'));
    if (key === 'my-forms') item.textContent = t('apps.applications.forms.index.my_forms', t('apps.applications.forms.my_forms', 'My Forms'));
    if (key === 'filled-forms') item.textContent = t('apps.applications.forms.index.filled_forms', t('apps.applications.forms.filled_forms', 'Filled Forms'));
    if (key === 'favorites') item.textContent = t('apps.applications.forms.index.favorites_tab', t('apps.applications.forms.favorites', 'Favorites'));
  });

  refs.sortItems.forEach((item) => {
    if (item.dataset.sorting === 'list') item.textContent = t('apps.applications.forms.index.list_view', 'List');
    else item.textContent = t('apps.applications.forms.index.grid_view', 'Grid');
  });

  if (refs.templatesToggle) {
    refs.templatesToggle.dataset.labelShow = t('apps.applications.forms.index.explore_templates', t('apps.applications.forms.explore_templates', t('apps.applications.forms.index.explore_templates', 'Explore templates')));
    refs.templatesToggle.dataset.labelHide = t('apps.applications.forms.index.hide_templates', t('apps.applications.forms.hide_templates', t('apps.applications.forms.index.hide_templates', 'Hide templates')));
  }

  const importButton = document.querySelector(SELECTORS.importButton);
  if (importButton) {
    const label = t('apps.applications.forms.quick_import', 'Quick Import');
    importButton.dataset.label = label;
    const span = importButton.querySelector('span');
    if (span) span.textContent = label;
    else if (!importButton.querySelector('i')) importButton.textContent = label;
  }
}

  function bindStaticEvents() {
    refs.navItems.forEach((item, index) => {
      const key = item.dataset.tab || item.dataset.sectionKey || SECTION_KEYS[index] || inferKeyFromNavText(item.textContent) || `tab-${index}`;
      item.dataset.tab = key;
      item.addEventListener('click', () => activateTab(key));
      item.setAttribute('role', 'button');
      item.setAttribute('tabindex', '0');
      item.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          activateTab(key);
        }
      });
    });

    refs.sortItems.forEach((item) => {
      item.addEventListener('click', () => applyViewMode(item.dataset.sorting === 'list' ? 'list' : 'grid'));
      item.setAttribute('role', 'button');
      item.setAttribute('tabindex', '0');
      item.addEventListener('keydown', (event) => {
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          applyViewMode(item.dataset.sorting === 'list' ? 'list' : 'grid');
        }
      });
    });

    if (refs.searchInput) {
      refs.searchInput.addEventListener('input', () => {
        state.search = refs.searchInput.value.trim();
        writeStorage(STORAGE_KEYS.search, state.search);
        applySearch();
        refreshEmptyStates();
      });
    }

    if (refs.templatesCollapse) {
      refs.templatesCollapse.addEventListener('shown.bs.collapse', syncTemplateToggleLabel);
      refs.templatesCollapse.addEventListener('hidden.bs.collapse', syncTemplateToggleLabel);
    }
    if (refs.templatesToggle) {
      refs.templatesToggle.addEventListener('click', () => {
        window.setTimeout(syncTemplateToggleLabel, 10);
        window.setTimeout(syncTemplateToggleLabel, 260);
      });
    }

    setupImportButton();
    setupEventDelegation();
    ensureExportModal();
  }

  function setupEventDelegation() {
    document.addEventListener('click', async (event) => {
      const favoriteBtn = event.target.closest('[data-action="toggle-favorite"]');
      if (favoriteBtn) {
        event.preventDefault();
        event.stopPropagation();
        const formId = favoriteBtn.dataset.formId;
        if (!formId) return;
        toggleFavorite(formId);
        return;
      }

      const exportBtn = event.target.closest('[data-action="open-export"]');
      if (exportBtn) {
        event.preventDefault();
        event.stopPropagation();
        const formId = exportBtn.dataset.formId;
        const title = exportBtn.dataset.formTitle || t('apps.applications.forms.index.form_export_fallback', 'Form export');
        if (!formId) return;
        openExportModal(formId, title);
        return;
      }

      const deleteBtn = event.target.closest('[data-delete-form]');
      if (deleteBtn) {
        event.preventDefault();
        event.stopPropagation();
        const formId = deleteBtn.dataset.deleteForm;
        const formTitle = deleteBtn.dataset.formTitle || t('apps.applications.forms.index.this_form', 'this form');
        if (!formId) return;
        const okay = window.confirm(translate(t('apps.applications.forms.index.delete_confirm', 'Delete “{title}”? This removes the XML file and cannot be undone.'), { title: formTitle }));
        if (!okay) return;
        await deleteForm(deleteBtn, formId);
        return;
      }

      if (event.target.closest('.form-card-action-btn')) {
        event.preventDefault();
        event.stopPropagation();
      }
    });
  }

  function enhanceAllCards() {
    Array.from(document.querySelectorAll(SELECTORS.cardLinks)).forEach((link) => enhanceCard(link));
  }

  function enhanceCard(link) {
    if (!(link instanceof HTMLElement) || link.dataset.indexEnhanced === '1') return;
    const formId = getFormIdFromLink(link);
    if (!formId) return;

    const card = link.querySelector('.card');
    if (!card) return;

    const titleNode = card.querySelector(SELECTORS.cardTitle);
    const authorNode = card.querySelector(SELECTORS.cardAuthor);
    const title = (titleNode?.textContent || '').trim() || t('apps.applications.forms.index.untitled_form', t('apps.applications.forms.untitled', 'Untitled form'));
    const author = (authorNode?.textContent || '').trim();

    link.dataset.indexEnhanced = '1';
    link.dataset.formId = formId;
    link.dataset.formTitle = title;
    link.dataset.formAuthor = author;

    card.classList.add('form-card');

    let actions = card.querySelector('.form-card-actions');
    if (!actions) {
      actions = document.createElement('div');
      actions.className = 'form-card-actions';
      card.appendChild(actions);
    }

    const favoriteBtn = createActionButton({
      className: 'form-card-action-btn form-card-favorite',
      icon: 'fa-star',
      label: t('apps.applications.forms.index.favorite', 'Favorite'),
      action: 'toggle-favorite',
      formId,
      formTitle: title,
    });

    const exportBtn = createActionButton({
      className: 'form-card-action-btn form-card-export',
      icon: 'fa-file-export',
      label: t('apps.applications.forms.index.export', 'Export'),
      action: 'open-export',
      formId,
      formTitle: title,
    });

    let deleteBtn = card.querySelector('[data-delete-form]');
    if (!deleteBtn) {
      deleteBtn = createActionButton({
        className: 'form-card-action-btn form-card-delete',
        icon: 'fa-trash-can',
        label: t('apps.applications.forms.index.delete', 'Delete'),
        action: '',
        formId,
        formTitle: title,
      });
      deleteBtn.dataset.deleteForm = formId;
      deleteBtn.dataset.formTitle = title;
    } else {
      deleteBtn.classList.add('form-card-action-btn');
      deleteBtn.dataset.deleteForm = deleteBtn.dataset.deleteForm || formId;
      deleteBtn.dataset.formTitle = deleteBtn.dataset.formTitle || title;
      if (!deleteBtn.querySelector('span')) {
        const span = document.createElement('span');
        span.textContent = t('apps.applications.forms.index.delete', 'Delete');
        deleteBtn.appendChild(span);
      }
    }

    if (!actions.querySelector(`[data-action="toggle-favorite"][data-form-id="${cssEscape(formId)}"]`)) actions.appendChild(favoriteBtn);
    if (!actions.querySelector(`[data-action="open-export"][data-form-id="${cssEscape(formId)}"]`)) actions.appendChild(exportBtn);
    if (deleteBtn.parentElement !== actions) actions.appendChild(deleteBtn);

    syncFavoriteButtons(formId);
  }

  function createActionButton({ className, icon, label, action, formId, formTitle }) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = className;
    if (action) button.dataset.action = action;
    if (formId) button.dataset.formId = formId;
    if (formTitle) button.dataset.formTitle = formTitle;
    button.innerHTML = `<i class="fa-solid ${icon}" aria-hidden="true"></i><span>${escapeHtml(label)}</span>`;
    return button;
  }

  function buildFavoritesSection() {
    const favoritesSection = refs.sections.get('favorites') || Array.from(refs.sections.values())[3];
    if (!favoritesSection) return;

    favoritesSection.dataset.sectionKey = 'favorites';
    refs.sections.set('favorites', favoritesSection);
    favoritesSection.innerHTML = '';

    const favoriteIds = Array.isArray(state.favorites) ? state.favorites.slice() : [];
    const sourceCards = favoriteIds
      .map((formId) => document.querySelector(`${SELECTORS.cardLinks}[data-form-id="${cssEscape(formId)}"]`))
      .filter((node) => node instanceof HTMLElement);

    if (!sourceCards.length) {
      favoritesSection.appendChild(createFavoritesEmptyState());
      return;
    }

    sourceCards.forEach((sourceLink) => {
      const clone = sourceLink.cloneNode(true);
      clone.dataset.favoriteClone = '1';
      clone.dataset.formId = sourceLink.dataset.formId;
      clone.dataset.formTitle = sourceLink.dataset.formTitle || '';
      clone.dataset.formAuthor = sourceLink.dataset.formAuthor || '';
      favoritesSection.appendChild(clone);
      enhanceCard(clone);
      syncFavoriteButtons(clone.dataset.formId);
    });
  }

  function createFavoritesEmptyState() {
    const node = document.createElement('div');
    node.className = 'form-favorites-empty';
    node.innerHTML = `
      <img src="${(window.ASSETS_URL || '').replace(/\/$/, '')}/icons/forms/no_favorite_forms.png" width="64" height="64" alt="${escapeAttribute(t('apps.applications.forms.index.favorites_alt', 'Favorites'))}">
      <h4 class="text-muted mt-3 mb-2">${escapeHtml(t('apps.applications.forms.index.no_favorites_title', 'No favorite forms yet'))}</h4>
      <p class="text-dark mb-0">${escapeHtml(t('apps.applications.forms.index.no_favorites_desc', 'Click the star button on any form card and it will show up here.'))}</p>
    `;
    return node;
  }

  function toggleFavorite(formId) {
    const favorites = new Set(Array.isArray(state.favorites) ? state.favorites : []);
    if (favorites.has(formId)) favorites.delete(formId);
    else favorites.add(formId);

    state.favorites = Array.from(favorites);
    writeJSONStorage(STORAGE_KEYS.favorites, state.favorites);

    syncFavoriteButtons(formId);
    buildFavoritesSection();
    applyViewMode(state.viewMode);
    applySearch();
    refreshEmptyStates();
  }

  function syncFavoriteButtons(formId) {
    const isFavorite = state.favorites.includes(formId);
    document.querySelectorAll(`[data-action="toggle-favorite"][data-form-id="${cssEscape(formId)}"]`).forEach((btn) => {
      btn.classList.toggle('is-favorite', isFavorite);
      btn.setAttribute('aria-pressed', isFavorite ? 'true' : 'false');
      const label = btn.querySelector('span');
      if (label) label.textContent = isFavorite ? t('apps.applications.forms.index.favorited', 'Favorited') : t('apps.applications.forms.index.favorite', 'Favorite');
      btn.title = isFavorite ? 'Remove from favorites' : 'Add to favorites';
    });
  }

  function activateTab(key) {
    state.activeTab = key;
    writeStorage(STORAGE_KEYS.activeTab, key);

    refs.navItems.forEach((item) => item.classList.toggle('active', item.dataset.tab === key));
    refs.sections.forEach((section, sectionKey) => {
      const isActive = sectionKey === key;
      section.classList.toggle('d-none', !isActive);
      section.hidden = !isActive;
    });

    applySearch();
    refreshEmptyStates();
  }

  function applyViewMode(mode) {
    state.viewMode = mode === 'list' ? 'list' : 'grid';
    writeStorage(STORAGE_KEYS.viewMode, state.viewMode);

    refs.sortItems.forEach((item) => item.classList.toggle('active', item.dataset.sorting === state.viewMode));
    refs.sections.forEach((section) => {
      section.classList.remove('is-grid', 'is-list');
      section.classList.add(state.viewMode === 'list' ? 'is-list' : 'is-grid');
    });
  }

  function applySearch() {
    const query = (state.search || '').toLowerCase();
    refs.sections.forEach((section) => {
      const cards = Array.from(section.querySelectorAll(SELECTORS.cardLinks));
      cards.forEach((link) => {
        const haystack = [link.dataset.formTitle, link.dataset.formAuthor, link.href].join(' ').toLowerCase();
        const match = !query || haystack.includes(query);
        link.classList.toggle('d-none', !match);
        link.hidden = !match;
      });
    });
  }

  function refreshEmptyStates() {
    refs.sections.forEach((section, key) => {
      const visibleCards = Array.from(section.querySelectorAll(SELECTORS.cardLinks)).filter((link) => !link.hidden && !link.classList.contains('d-none'));
      let emptyState = section.querySelector('.form-no-results[data-generated-empty="1"]');
      if (visibleCards.length) {
        if (emptyState) emptyState.remove();
        return;
      }
      if (section.querySelector('.form-no-results') && !emptyState) return;
      if (!emptyState) {
        emptyState = document.createElement('div');
        emptyState.className = 'form-no-results';
        emptyState.dataset.generatedEmpty = '1';
        emptyState.innerHTML = `
          <img src="${(window.ASSETS_URL || '').replace(/\/$/, '')}/icons/forms/no_form_icon.png" width="64" height="64" alt="${escapeAttribute(t('apps.applications.forms.index.no_forms_alt', 'No forms'))}">
          <h4 class="text-muted mt-3 mb-2">${escapeHtml(t('apps.applications.forms.index.no_forms_match_title', 'No forms match'))}</h4>
          <p class="text-dark mb-0">${escapeHtml(t('apps.applications.forms.index.no_forms_match_desc', 'Try a different search, tab, or add a favorite from another section.'))}</p>
        `;
        section.appendChild(emptyState);
      }
      if (key === 'favorites' && !state.favorites.length) emptyState.remove();
    });
  }

  async function deleteForm(button, formId) {
    const originalHtml = button.innerHTML;
    button.disabled = true;
    button.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i><span>${escapeHtml(t('apps.applications.forms.index.deleting', 'Deleting…'))}</span>`;
    try {
      const body = new URLSearchParams();
      body.set('action', 'delete_form');
      body.set('formId', formId);
      const response = await fetch('./deleteForm.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
        credentials: 'same-origin',
        body,
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok || !payload.success) throw new Error(payload.error || t('apps.applications.forms.index.unable_delete', 'Unable to delete this form.'));
      document.querySelectorAll(`${SELECTORS.cardLinks}[data-form-id="${cssEscape(formId)}"]`).forEach((link) => link.remove());
      state.favorites = state.favorites.filter((id) => id !== formId);
      writeJSONStorage(STORAGE_KEYS.favorites, state.favorites);
      buildFavoritesSection();
      applySearch();
      refreshEmptyStates();
      toast(t('apps.applications.forms.index.form_deleted', 'Form deleted.'));
    } catch (error) {
      console.error(error);
      toast(error.message || t('apps.applications.forms.index.unable_delete', 'Unable to delete this form.'), true);
      button.disabled = false;
      button.innerHTML = originalHtml;
    }
  }

  function ensureExportModal() {
    if (state.exportModal) return;
    const modal = document.createElement('div');
    modal.className = 'form-export-modal';
    modal.hidden = true;
    modal.innerHTML = `
      <div class="form-export-dialog" role="dialog" aria-modal="true" aria-labelledby="forms-export-title">
        <div class="form-export-dialog-header">
          <div>
            <h3 id="forms-export-title">${escapeHtml(t('apps.applications.forms.index.export_form', 'Export form'))}</h3>
            <p>${escapeHtml(t('apps.applications.forms.index.export_dialog_desc', 'Select which parts of the form should be included in the export file.'))}</p>
          </div>
          <button type="button" class="form-export-close" data-action="close-export" aria-label="${escapeAttribute(t('apps.applications.forms.index.close_export_dialog', 'Close export dialog'))}">
            <i class="fa-solid fa-xmark"></i>
          </button>
        </div>
        <form class="form-export-dialog-body" data-export-dialog-form>
          <div class="form-export-toolbar">
            <button type="button" class="form-export-link-btn" data-action="export-select-all">${escapeHtml(t('apps.applications.forms.index.select_all', 'Select all'))}</button>
            <button type="button" class="form-export-link-btn" data-action="export-select-none">${escapeHtml(t('apps.applications.forms.index.select_none', 'Select none'))}</button>
          </div>
          <div class="form-export-checkboxes">
            
${[
            ['includeMetadata', t('apps.applications.forms.index.metadata', 'Metadata')],
            ['includeStyles', t('apps.applications.forms.index.styles', 'Styles')],
            ['includeSettings', t('apps.applications.forms.index.settings', 'Settings')],
            ['includeUi', t('apps.applications.forms.index.ui_labels', 'UI labels')],
            ['includeQuestions', t('apps.applications.forms.index.questions', 'Questions')],
            ['includeResponses', t('apps.applications.forms.index.responses', 'Responses')],
            ['includeScoring', t('apps.applications.forms.index.scoring', 'Scoring')],
            ['includeBranching', t('apps.applications.forms.index.branching_rules', 'Branching rules')],
            ['includeMedia', t('apps.applications.forms.index.media_fields', 'Media fields')],
          ].map(([name, label]) => `
            <label class="form-export-option">
              <input type="checkbox" name="${name}"${label!==t('apps.applications.forms.index.responses', 'Responses')&&label!==t('apps.applications.forms.index.scoring', 'Scoring') ? ' checked' : ''}${label===t('apps.applications.forms.index.metadata', 'Metadata') ? ' disabled' : ''}>
              <span>${label}</span>
            </label>
          `).join('')}

          </div>
          <p class="form-export-hint" data-export-status>Export will download as an XML file.</p>
        </form>
        <div class="form-export-dialog-footer">
          <button type="button" class="form-card-action-btn" data-action="close-export">${escapeHtml(t('apps.applications.forms.index.cancel', 'Cancel'))}</button>
          <button type="button" class="form-card-action-btn form-card-export" data-action="submit-export">
            <i class="fa-solid fa-file-arrow-down"></i>
            <span>${escapeHtml(t('apps.applications.forms.index.download_xml', 'Download XML'))}</span>
          </button>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
    state.exportModal = modal;
    state.exportForm = modal.querySelector('[data-export-dialog-form]');
    state.exportTitle = modal.querySelector('#forms-export-title');
    state.exportDownloadBtn = modal.querySelector('[data-action="submit-export"]');
    state.exportStatus = modal.querySelector('[data-export-status]');

    modal.addEventListener('click', async (event) => {
      const action = event.target.closest('[data-action]')?.dataset.action;
      if (!action) {
        if (event.target === modal) closeExportModal();
        return;
      }
      if (action === 'close-export') { closeExportModal(); return; }
      if (action === 'export-select-all' || action === 'export-select-none') {
        const checked = action === 'export-select-all';
        state.exportForm.querySelectorAll('input[type="checkbox"]').forEach((input) => { if(!input.disabled) input.checked = checked; });
        return;
      }
      if (action === 'submit-export') await submitExport();
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape' && state.exportModal && !state.exportModal.hidden) closeExportModal();
    });
  }

  function openExportModal(formId, title) {
    ensureExportModal();
    state.currentExportFormId = formId;
    if (state.exportTitle) state.exportTitle.textContent = translate(t('apps.applications.forms.index.export_form_named', 'Export “{title}”'), { title });
    if (state.exportStatus) {
      state.exportStatus.textContent = t('apps.applications.forms.index.export_hint', 'Export will download as an XML file.');
      state.exportStatus.classList.remove('text-danger');
    }
    state.exportModal.hidden = false;
    document.body.classList.add('modal-open');
  }

  function closeExportModal() {
    if (!state.exportModal) return;
    state.exportModal.hidden = true;
    document.body.classList.remove('modal-open');
    state.currentExportFormId = null;
  }

  async function submitExport() {
    if (!state.currentExportFormId || !state.exportForm) return;
    const button = state.exportDownloadBtn;
    const original = button.innerHTML;
    button.disabled = true;
    button.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i><span>Preparing…</span>';
    if (state.exportStatus) {
      state.exportStatus.textContent = t('apps.applications.forms.index.preparing_export', 'Preparing your export…');
      state.exportStatus.classList.remove('text-danger');
    }
    try {
      const data = new FormData();
      data.set('formId', state.currentExportFormId);
      data.set('format', 'xml');
      state.exportForm.querySelectorAll('input[type="checkbox"]').forEach((input) => data.set(input.name, input.checked ? '1' : '0'));
      const response = await fetch('./export.php', { method: 'POST', credentials: 'same-origin', body: data });
      if (!response.ok) {
        let message = t('apps.applications.forms.index.export_failed', 'Export failed.');
        try { const payload = await response.json(); message = payload.error || message; } catch (_) {}
        throw new Error(message);
      }
      const blob = await response.blob();
      const filename = getDownloadFileName(response.headers, `${state.currentExportFormId}-export.xml`);
      downloadBlob(blob, filename);
      toast(t('apps.applications.forms.index.export_downloaded', 'Export downloaded.'));
      closeExportModal();
    } catch (error) {
      console.error(error);
      if (state.exportStatus) {
        state.exportStatus.textContent = error.message || 'Unable to export this form.';
        state.exportStatus.classList.add('text-danger');
      }
    } finally {
      button.disabled = false;
      button.innerHTML = original;
    }
  }

  function setupImportButton() {
    const importButton = document.querySelector(SELECTORS.importButton);
    if (!importButton) return;
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = '.xml,text/xml,application/xml';
    fileInput.hidden = true;
    document.body.appendChild(fileInput);
    const originalHtml = importButton.innerHTML;
    const originalDisabled = importButton.disabled;

    function setButtonState(stateName, message = '') {
      importButton.dataset.state = stateName;
      importButton.disabled = stateName === 'loading';
      const label = message || importButton.dataset.label || importButton.textContent.trim();
      if (stateName === 'loading') { importButton.innerHTML = `<i class="fa-solid fa-spinner fa-spin"></i>${label}`; return; }
      if (stateName === 'success') { importButton.innerHTML = `<i class="fa-solid fa-check"></i>${label}`; return; }
      if (stateName === 'error') { importButton.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i>${label}`; return; }
      importButton.innerHTML = originalHtml;
      importButton.disabled = originalDisabled;
    }

    importButton.addEventListener('click', () => { if (importButton.dataset.state !== 'loading') fileInput.click(); });
    fileInput.addEventListener('change', async () => {
      const [file] = Array.from(fileInput.files || []);
      if (!file) return;
      const data = new FormData();
      data.append('xmlFile', file, file.name || 'form.xml');
      setButtonState('loading', t('apps.applications.forms.index.importing', 'Importing…'));
      try {
        const response = await fetch('./import.php', { method: 'POST', body: data, credentials: 'same-origin' });
        const payload = await response.json();
        if (!response.ok || !payload.success) throw new Error(payload.error || 'Import failed.');
        setButtonState('success', t('apps.applications.forms.index.imported', 'Imported'));
        toast(translate(t('apps.applications.forms.index.imported_redirecting', 'Imported “{title}”. Redirecting…'), { title: payload.title || t('apps.applications.forms.index.untitled_form', 'Untitled form') }));
        window.setTimeout(() => { window.location.href = `./live?formId=${encodeURIComponent(payload.formId)}`; }, 700);
      } catch (error) {
        console.error(error);
        setButtonState('error', t('apps.applications.forms.index.import_failed', 'Import failed'));
        toast(error.message || t('apps.applications.forms.index.unable_import_xml', 'Unable to import this XML file.'), true);
        window.setTimeout(() => setButtonState('idle'), 1600);
      } finally { fileInput.value = ''; }
    });
  }

  function syncTemplateToggleLabel() {
    if (!refs.templatesToggle || !refs.templatesCollapse) return;
    const expanded = refs.templatesCollapse.classList.contains('show');
    const label = expanded ? (refs.templatesToggle.dataset.labelHide || t('apps.applications.forms.index.hide_templates', 'Hide templates')) : (refs.templatesToggle.dataset.labelShow || t('apps.applications.forms.index.explore_templates', 'Explore templates'));
    refs.templatesToggle.innerHTML = `${label} <i class="fa-regular ${expanded ? 'fa-angle-up' : 'fa-angle-down'}"></i>`;
    refs.templatesToggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
  }

  function inferSectionKey(section, index) {
    const className = section.className || '';
    if (className.includes('recent')) return 'recent';
    if (className.includes('my-forms')) return 'my-forms';
    if (className.includes('filled')) return 'filled-forms';
    if (className.includes('favorite')) return 'favorites';
    return SECTION_KEYS[index] || `section-${index}`;
  }

  function inferKeyFromNavText(text) {
    const value = (text || '').toLowerCase();
    if (value.includes('recent')) return 'recent';
    if (value.includes('favorite')) return 'favorites';
    if (value.includes('filled')) return 'filled-forms';
    if (value.includes('my')) return 'my-forms';
    return '';
  }

  function getFormIdFromLink(link) {
    const existing = link.dataset.formId || link.querySelector('[data-delete-form]')?.dataset.deleteForm;
    if (existing) return existing;
    try {
      const href = link.getAttribute('href') || '';
      const url = new URL(href, window.location.href);
      return url.searchParams.get('formId') || '';
    } catch (_) {
      const href = link.getAttribute('href') || '';
      const match = href.match(/[?&]formId=([^&]+)/i);
      return match ? decodeURIComponent(match[1]) : '';
    }
  }

  function getDownloadFileName(headers, fallback) {
    const disposition = headers.get('content-disposition') || headers.get('Content-Disposition') || '';
    const match = disposition.match(/filename\*=UTF-8''([^;]+)|filename="?([^";]+)"?/i);
    if (!match) return fallback;
    return decodeURIComponent(match[1] || match[2] || fallback);
  }

  function downloadBlob(blob, fileName) {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function toast(message, isError = false) {
    const node = document.createElement('div');
    node.className = `forms-index-toast ${isError ? 'is-error' : 'is-success'}`;
    node.innerHTML = `<strong>${escapeHtml(isError ? t('apps.applications.forms.index.error', 'Error') : t('apps.applications.forms.index.done', 'Done'))}</strong><span>${escapeHtml(message)}</span>`;
    document.body.appendChild(node);
    requestAnimationFrame(() => node.classList.add('is-visible'));
    window.setTimeout(() => { node.classList.remove('is-visible'); window.setTimeout(() => node.remove(), 180); }, 3200);
  }

  function readStorage(key, fallback = '') {
    try { const value = window.localStorage.getItem(key); return value === null ? fallback : value; } catch (_) { return fallback; }
  }

  function writeStorage(key, value) {
    try { window.localStorage.setItem(key, String(value)); } catch (_) {}
  }

  function readJSONStorage(key, fallback) {
    try {
      const raw = window.localStorage.getItem(key);
      if (!raw) return fallback;
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? parsed : fallback;
    } catch (_) { return fallback; }
  }

  function writeJSONStorage(key, value) {
    try { window.localStorage.setItem(key, JSON.stringify(value)); } catch (_) {}
  }

  function cssEscape(value) {
    if (window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(String(value));
    return String(value).replace(/([ #;?%&,.+*~\':"!^$\[\]()=>|\/])/g, '\\$1');
  }

  function escapeAttribute(value) {
    return escapeHtml(value).replace(/`/g, '&#96;');
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }
})();
