(() => {
  function getBootData() {
    const root = document.getElementById('forms-app');
    if (!root || !root.dataset.boot) return {};
    try {
      return JSON.parse(root.dataset.boot || '{}');
    } catch {
      return {};
    }
  }

  function parseFileName(headers, fallback = 'form-export.xml') {
    const disposition = headers.get('Content-Disposition') || headers.get('content-disposition') || '';
    const match = disposition.match(/filename\*=UTF-8''([^;]+)|filename="?([^";]+)"?/i);
    const raw = match ? decodeURIComponent(match[1] || match[2] || fallback) : fallback;
    return raw || fallback;
  }

  function downloadBlob(blob, fileName) {
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1200);
  }

  function findModal(element) {
    return element.closest('.modal');
  }

  function closeModal(modal) {
    if (!modal) return;
    if (window.bootstrap && bootstrap.Modal) {
      bootstrap.Modal.getOrCreateInstance(modal).hide();
      return;
    }
    modal.classList.remove('show');
    modal.setAttribute('aria-hidden', 'true');
    modal.style.display = 'none';
    document.body.classList.remove('modal-open');
    document.querySelectorAll('.modal-backdrop').forEach((node) => node.remove());
  }

  function ensureOverlay(scope) {
    const host = scope || document.body;
    let overlay = host.querySelector('.forms-export-overlay');
    if (overlay) return overlay;
    overlay = document.createElement('div');
    overlay.className = 'forms-export-overlay';
    overlay.innerHTML = `
      <div class="forms-export-overlay-card">
        <div class="spinner-border text-primary" role="status" aria-hidden="true"></div>
        <div>
          <strong>Preparing export…</strong>
          <div class="forms-export-overlay-copy">Your file will download automatically when it is ready.</div>
        </div>
      </div>
    `;
    if (getComputedStyle(host).position === 'static') host.style.position = 'relative';
    host.appendChild(overlay);
    return overlay;
  }

  async function runExport(form) {
    const boot = getBootData();
    const endpoint = form.getAttribute('action') || boot.exportUrl || './export.php';
    const method = (form.getAttribute('method') || 'POST').toUpperCase();
    const data = new FormData(form);
    if (!data.get('formId') && boot.formId) data.set('formId', boot.formId);
    const modal = findModal(form);
    const overlay = ensureOverlay(modal?.querySelector('.modal-content') || modal || document.body);
    overlay.classList.add('is-visible');

    Array.from(form.elements || []).forEach((element) => {
      if ('disabled' in element) element.disabled = true;
    });

    try {
      const response = await fetch(endpoint, {
        method,
        body: data,
        credentials: 'same-origin'
      });
      if (!response.ok) {
        let message = 'Export failed.';
        try {
          const payload = await response.json();
          message = payload.error || message;
        } catch {}
        throw new Error(message);
      }
      const blob = await response.blob();
      const fileName = parseFileName(response.headers, `form-${boot.formId || 'export'}.xml`);
      downloadBlob(blob, fileName);
      window.setTimeout(() => closeModal(modal), 250);
      window.setTimeout(() => overlay.classList.remove('is-visible'), 350);
    } catch (error) {
      console.error(error);
      overlay.querySelector('strong').textContent = 'Export failed';
      overlay.querySelector('.forms-export-overlay-copy').textContent = error.message || 'Unable to export the form.';
      overlay.classList.add('is-error');
      window.setTimeout(() => {
        overlay.classList.remove('is-visible', 'is-error');
        overlay.querySelector('strong').textContent = 'Preparing export…';
        overlay.querySelector('.forms-export-overlay-copy').textContent = 'Your file will download automatically when it is ready.';
      }, 2200);
    } finally {
      Array.from(form.elements || []).forEach((element) => {
        if (element.dataset.keepDisabled !== '1' && 'disabled' in element) element.disabled = false;
      });
    }
  }

  function attachExportHandlers() {
    const forms = Array.from(document.querySelectorAll('form[data-export-form], form[action*="export.php"]'));
    if (!forms.length) return;
    forms.forEach((form) => {
      if (form.dataset.exportBound === '1') return;
      form.dataset.exportBound = '1';
      form.addEventListener('submit', (event) => {
        event.preventDefault();
        runExport(form);
      });
    });
  }

  const style = document.createElement('style');
  style.textContent = `
    .forms-export-overlay {
      position: absolute;
      inset: 0;
      display: grid;
      place-items: center;
      padding: 20px;
      background: rgba(255,255,255,.78);
      backdrop-filter: blur(4px);
      opacity: 0;
      pointer-events: none;
      transition: opacity .18s ease;
      z-index: 40;
    }
    .forms-export-overlay.is-visible {
      opacity: 1;
      pointer-events: all;
    }
    .forms-export-overlay-card {
      display: flex;
      align-items: center;
      gap: 14px;
      padding: 18px 20px;
      max-width: min(420px, 100%);
      border-radius: 18px;
      background: #fff;
      border: 1px solid rgba(37,99,235,.14);
      box-shadow: 0 18px 48px rgba(15,23,42,.18);
    }
    .forms-export-overlay-card strong {
      display: block;
      margin-bottom: 4px;
      font-size: 14px;
      color: #111827;
    }
    .forms-export-overlay-copy {
      font-size: 12px;
      color: #475467;
    }
    .forms-export-overlay.is-error .forms-export-overlay-card {
      border-color: rgba(217,45,32,.18);
    }
  `;
  document.head.appendChild(style);

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', attachExportHandlers, { once: true });
  } else {
    attachExportHandlers();
  }
})();
