(() => {
  const root = document.getElementById('forms-app');
  if (!root) return;

  const boot = JSON.parse(root.dataset.boot || '{}');
  const queryParams = new URLSearchParams(window.location.search || '');
  const requestedMode = (String(boot.requestedMode || queryParams.get('mode') || '').toLowerCase())||'edit';
  // ===== MULTILINGUAL SUPPORT =====
  let languageData = {};

  /**
   * Detect user's browser language
   * @returns {string} Language code (en, fr, ru, etc.)
   */
  function getBrowserLanguage() {
    const browserLang = (navigator.language || navigator.userLanguage || 'en').toLowerCase();
    const langCode = browserLang.split('-')[0];
    return langCode||'en';
  }

  /**
   * Load language file from locales folder
   * @param {string} lang - Language code
   * @returns {Promise<void>}
   */
  async function loadLanguage(lang = 'en') {
    try {
      const langCode = lang||'en';
      const response = await fetch(`../../locales/${langCode}.json`);
      if (!response.ok) throw new Error(`Failed to load language: ${langCode}`);
      languageData = await response.json();
    } catch (error) {
      console.warn(`Language loading error for ${lang}:`, error);
      // Fallback to empty object, translations will show keys
      languageData = {};
    }
  }

  /**
   * Get translated string by dot-separated path
   * @param {string} path - e.g., 'apps.applications.forms.save_status'
   * @param {string} defaultValue - Fallback text
   * @returns {string} Translated string
   */
  function t(path, defaultValue = path) {
    const keys = path.split('.');
    let value = languageData;
    
    for (const key of keys) {
      if (value && typeof value === 'object' && key in value) {
        value = value[key];
      } else {
        return defaultValue;
      }
    }
    
    return typeof value === 'string' ? value : defaultValue;
  }


function buildFormsLocaleMap() {
  return new Map([
    ['Quiz mode', t('apps.applications.forms.editor_i18n.quiz_mode', 'Quiz mode')],
    ['Show points for each question and save as quiz metadata.', t('apps.applications.forms.editor_i18n.quiz_mode_desc', 'Show points for each question and save as quiz metadata.')],
    ['Who can fill', t('apps.applications.forms.settings.who_can_fill', 'Who can fill')],
    ['Logged in users', t('apps.applications.forms.editor_i18n.logged_in_users', 'Logged in users')],
    ['Anyone with the link', t('apps.applications.forms.editor_i18n.anyone_with_link', 'Anyone with the link')],
    ['Organization only', t('apps.applications.forms.editor_i18n.organization_only', 'Organization only')],
    ['Accept responses', t('apps.applications.forms.editor_i18n.accept_responses_title', 'Accept responses')],
    ['Turn submissions on or off.', t('apps.applications.forms.editor_i18n.accept_responses_desc', 'Turn submissions on or off.')],
    ['Shuffle questions', t('apps.applications.forms.editor_i18n.shuffle_questions_title', 'Shuffle questions')],
    ['Randomize question order for respondents.', t('apps.applications.forms.editor_i18n.shuffle_questions_desc', 'Randomize question order for respondents.')],
    ['Hide question numbers', t('apps.applications.forms.editor_i18n.hide_question_numbers_title', 'Hide question numbers')],
    ['Publish without numbering prompts.', t('apps.applications.forms.editor_i18n.hide_question_numbers_desc', 'Publish without numbering prompts.')],
    ['Show progress bar', t('apps.applications.forms.editor_i18n.show_progress_bar_title', 'Show progress bar')],
    ['Display progress across section pages.', t('apps.applications.forms.editor_i18n.show_progress_bar_desc', 'Display progress across section pages.')],
    ['Hide re-submit', t('apps.applications.forms.editor_i18n.hide_resubmit_title', 'Hide re-submit')],
    ['Hide submit another response action after completion.', t('apps.applications.forms.editor_i18n.hide_resubmit_desc', 'Hide submit another response action after completion.')],
    ['Allow save progress', t('apps.applications.forms.editor_i18n.allow_save_progress_title', 'Allow save progress')],
    ['Respondents can return later.', t('apps.applications.forms.editor_i18n.allow_save_progress_desc', 'Respondents can return later.')],
    ['Allow edit responses', t('apps.applications.forms.editor_i18n.allow_edit_responses_title', 'Allow edit responses')],
    ['Respondents can update submitted answers.', t('apps.applications.forms.editor_i18n.allow_edit_responses_desc', 'Respondents can update submitted answers.')],
    ['Send receipt after submit', t('apps.applications.forms.editor_i18n.send_receipt_title', 'Send receipt after submit')],
    ['Store a receipt preference in settings.', t('apps.applications.forms.editor_i18n.send_receipt_desc', 'Store a receipt preference in settings.')],
    ['Notify on each response', t('apps.applications.forms.editor_i18n.notify_each_response_title', 'Notify on each response')],
    ['Store email notification preference.', t('apps.applications.forms.editor_i18n.notify_each_response_desc', 'Store email notification preference.')],
    ['Show required asterisk', t('apps.applications.forms.editor_i18n.show_required_asterisk_title', 'Show required asterisk')],
    ['Display the required indicator in publish mode.', t('apps.applications.forms.editor_i18n.show_required_asterisk_desc', 'Display the required indicator in publish mode.')],
    ['Show score in thank you section', t('apps.applications.forms.editor_i18n.show_score_thank_you_title', 'Show score in thank you section')],
    ['Display the quiz score after submission in the thank you section.', t('apps.applications.forms.editor_i18n.show_score_thank_you_desc', 'Display the quiz score after submission in the thank you section.')],
    ['Start date', t('apps.applications.forms.editor_i18n.start_date', 'Start date')],
    ['End date', t('apps.applications.forms.editor_i18n.end_date', 'End date')],
    ['Time duration (minutes)', t('apps.applications.forms.editor_i18n.time_duration_minutes', 'Time duration (minutes)')],
    ['Text answer similarity threshold (%)', t('apps.applications.forms.editor_i18n.text_similarity_threshold', 'Text answer similarity threshold (%)')],
    ['Used for both short and long text quiz answers. Leave blank to use the default of 70%.', t('apps.applications.forms.editor_i18n.text_similarity_threshold_desc', 'Used for both short and long text quiz answers. Leave blank to use the default of 70%.')],
    ['Submit button label', t('apps.applications.forms.editor_i18n.submit_button_label', 'Submit button label')],
    ['Publish button label', t('apps.applications.forms.editor_i18n.publish_button_label', 'Publish button label')],
    ['Thank you title', t('apps.applications.forms.editor_i18n.thank_you_title', 'Thank you title')],
    ['Thank you message', t('apps.applications.forms.editor_i18n.thank_you_message', 'Thank you message')],
    ['Required', t('apps.applications.forms.common.required', 'Required')],
    ['Optional', t('apps.applications.forms.common.optional', 'Optional')],
    ['Move up', t('apps.applications.forms.common.move_up', 'Move up')],
    ['Move down', t('apps.applications.forms.common.move_down', 'Move down')],
    ['Copy', t('apps.applications.forms.common.copy', 'Copy')],
    ['Delete', t('apps.applications.forms.common.delete', 'Delete')],
    ['Close', t('apps.applications.forms.common.close', 'Close')],
    ['Restrictions', t('apps.applications.forms.editor_i18n.restrictions', 'Restrictions')],
    ['Shuffle options', t('apps.applications.forms.editor_i18n.shuffle_options', 'Shuffle options')],
    ['Multiple answers', t('apps.applications.forms.editor_i18n.multiple_answers', 'Multiple answers')],
    ['Dropdown', t('apps.applications.forms.editor_i18n.dropdown', 'Dropdown')],
    ['Answer key', t('apps.applications.forms.editor_i18n.answer_key_title', 'Answer key')],
    ['Accepted answers', t('apps.applications.forms.editor_i18n.accepted_answers_title', 'Accepted answers')],
    ['Response type', t('apps.applications.forms.editor_i18n.response_type', 'Response type')],
    ['Short answer', t('apps.applications.forms.editor_i18n.short_answer', 'Short answer')],
    ['Long answer', t('apps.applications.forms.editor_i18n.long_answer', 'Long answer')],
    ['Restriction type', t('apps.applications.forms.editor_i18n.restriction_type', 'Restriction type')],
    ['Operator', t('apps.applications.forms.editor_i18n.operator', 'Operator')],
    ['None', t('apps.applications.forms.editor_i18n.none', 'None')],
    ['Valid', t('apps.applications.forms.editor_i18n.valid', 'Valid')],
    ['Equals', t('apps.applications.forms.editor_i18n.equals', 'Equals')],
    ['Contains', t('apps.applications.forms.editor_i18n.contains', 'Contains')],
    ['Minimum', t('apps.applications.forms.editor_i18n.minimum', 'Minimum')],
    ['Maximum', t('apps.applications.forms.editor_i18n.maximum', 'Maximum')],
    ['Between', t('apps.applications.forms.editor_i18n.between', 'Between')],
    ['Pattern', t('apps.applications.forms.editor_i18n.pattern', 'Pattern')],
    ['Primary value', t('apps.applications.forms.editor_i18n.primary_value', 'Primary value')],
    ['Secondary value', t('apps.applications.forms.editor_i18n.secondary_value', 'Secondary value')],
    ['Scale max', t('apps.applications.forms.editor_i18n.scale_max', 'Scale max')],
    ['Date question', t('apps.applications.forms.editor_i18n.date_question_title', 'Date question')],
    ['Validation checks the required state and any active time window.', t('apps.applications.forms.editor_i18n.date_question_desc', 'Validation checks the required state and any active time window.')],
    ['Ranking items', t('apps.applications.forms.editor_i18n.ranking_items_title', 'Ranking items')],
    ['Respondents drag items into their preferred order.', t('apps.applications.forms.editor_i18n.ranking_items_desc', 'Respondents drag items into their preferred order.')],
    ['Statements', t('apps.applications.forms.editor_i18n.statements', 'Statements')],
    ['Scale columns', t('apps.applications.forms.editor_i18n.scale_columns', 'Scale columns')],
    ['Upload file', t('apps.applications.forms.editor_i18n.upload_file_title', 'Upload file')],
    ['Allow multiple files', t('apps.applications.forms.editor_i18n.allow_multiple_files_title', 'Allow multiple files')],
    ['Respondents can attach more than one file.', t('apps.applications.forms.editor_i18n.allow_multiple_files_desc', 'Respondents can attach more than one file.')],
    ['Min label', t('apps.applications.forms.editor_i18n.min_label', 'Min label')],
    ['Max label', t('apps.applications.forms.editor_i18n.max_label', 'Max label')],
    ['Question title', t('apps.applications.forms.common.question_title', 'Question title')],
    ['Description or help text', t('apps.applications.forms.common.description_help', 'Description or help text')],
    ['Select an option', t('apps.applications.forms.common.select_option', 'Select an option')],
    ['Choose…', t('apps.applications.forms.common.choose', 'Choose…')],
    ['Type your answer', t('apps.applications.forms.common.type_your_answer', 'Type your answer')],
    ['Drag items into the preferred order.', t('apps.applications.forms.editor_i18n.drag_items_order', 'Drag items into the preferred order.')],
    ['Time left', t('apps.applications.forms.common.time_left', 'Time left')],
    ['Notice', t('apps.applications.forms.common.notice', 'Notice')],
    ['Logic map', t('apps.applications.forms.logic.logic_map', 'Logic map')],
    ['Automation preview', t('apps.applications.forms.logic.automation_preview', 'Automation preview')],
    ['Add branching to any question and the editor will summarize what happens here.', t('apps.applications.forms.logic.automation_desc', 'Add branching to any question and the editor will summarize what happens here.')],
    ['No logic rules yet', t('apps.applications.forms.logic.no_rules_title', 'No logic rules yet')],
    ['Create a rule to jump, show, hide, or change whether a later question is required.', t('apps.applications.forms.logic.no_rules_desc', 'Create a rule to jump, show, hide, or change whether a later question is required.')],
    ['A live summary of how answers change the respondent flow.', t('apps.applications.forms.logic.live_summary', 'A live summary of how answers change the respondent flow.')],
    ['Not answered', t('apps.applications.forms.logic.not_answered', 'Not answered')],
    ['Does not equal', t('apps.applications.forms.logic.does_not_equal', 'Does not equal')],
    ['Greater than', t('apps.applications.forms.logic.greater_than', 'Greater than')],
    ['Less than', t('apps.applications.forms.logic.less_than', 'Less than')],
    ['Jump to', t('apps.applications.forms.logic.jump_to', 'Jump to')],
    ['Show question', t('apps.applications.forms.logic.show_question', 'Show question')],
    ['Hide question', t('apps.applications.forms.logic.hide_question', 'Hide question')],
    ['Make required', t('apps.applications.forms.logic.make_required', 'Make required')],
    ['Make optional', t('apps.applications.forms.logic.make_optional', 'Make optional')],
    ['Next question', t('apps.applications.forms.logic.next_question', 'Next question')],
    ['Submit form', t('apps.applications.forms.logic.submit_form', 'Submit form')],
    ['selected question', t('apps.applications.forms.logic.selected_question', 'selected question')],
    ['is answered', t('apps.applications.forms.logic.is_answered', 'is answered')],
    ['is not answered', t('apps.applications.forms.logic.is_not_answered', 'is not answered')],
    ['When this answer', t('apps.applications.forms.logic.when_this_answer', 'When this answer')],
    ['Ready to begin?', t('apps.applications.forms.editor_i18n.ready_to_begin', 'Ready to begin?')],
    ['This form is not open right now', t('apps.applications.forms.editor_i18n.form_not_open', 'This form is not open right now')],
    ['Questions stay hidden until the quiz or form is opened. Your timer will begin only after you start.', t('apps.applications.forms.editor_i18n.hidden_until_start', 'Questions stay hidden until the quiz or form is opened. Your timer will begin only after you start.')],
    ['Start quiz', t('apps.applications.forms.editor_i18n.start_quiz', 'Start quiz')],
    ['Start form', t('apps.applications.forms.editor_i18n.start_form', 'Start form')],
  ]);
}

function localizeRenderedContent(container = root) {
  if (!container) return;
  const dictionary = buildFormsLocaleMap();
  const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      if (!node || !node.parentElement) return NodeFilter.FILTER_REJECT;
      const tag = node.parentElement.tagName;
      if (tag === 'SCRIPT' || tag === 'STYLE' || tag === 'TEXTAREA') return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  });

  const textNodes = [];
  while (walker.nextNode()) textNodes.push(walker.currentNode);
  textNodes.forEach((node) => {
    const original = node.textContent;
    const trimmed = original.trim();
    if (!trimmed || !dictionary.has(trimmed)) return;
    const localized = dictionary.get(trimmed);
    node.textContent = original.replace(trimmed, localized);
  });

  container.querySelectorAll('[placeholder], [title], [aria-label]').forEach((element) => {
    ['placeholder', 'title', 'aria-label'].forEach((attribute) => {
      const current = element.getAttribute(attribute);
      if (!current || !dictionary.has(current)) return;
      element.setAttribute(attribute, dictionary.get(current));
    });
  });
}

  const TEMPLATES = [
  {
    id: 'blank',
    get title() { return t('apps.applications.forms.templates.blank', 'Blank form'); },
    get description() { return t('apps.applications.forms.templates.blank_desc', 'Start from scratch with a polished layout.'); },
    get tags() { return [t('apps.applications.forms.templates.general', 'General')]; },
    build: () => [],
  },
  {
    id: 'feedback',
    get title() { return t('apps.applications.forms.templates.feedback', 'Customer feedback'); },
    get description() { return t('apps.applications.forms.templates.feedback_desc', 'Great for satisfaction surveys, post-visit feedback, NPS, and service follow-up.'); },
    get tags() { return [t('apps.applications.forms.templates.feedback_tag', 'Feedback'), t('apps.applications.forms.templates.nps_tag', 'NPS'), t('apps.applications.forms.templates.survey_tag', 'Survey')]; },
    build: () => [
      section(t('apps.applications.forms.questions.section', 'Section'), t('apps.applications.forms.templates.visit_overview', 'Tell us about your recent visit and how things felt.')),
      choiceQ(t('apps.applications.forms.templates.service_question', 'Which service did you use today?'), [t('support', 'Support'), t('sales', 'Sales'), t('billing', 'Billing'), t('other', 'Other')], true),
      ratingQ(t('apps.applications.forms.templates.rate_experience', 'How would you rate your experience?'), 5, true),
      npsQ(t('apps.applications.forms.templates.recommend_us', 'How likely are you to recommend us?'), true),
      textQ(t('apps.applications.forms.templates.improvements', 'What could we improve?'), 'long', false),
    ],
  },
  {
    id: 'event',
    get title() { return t('apps.applications.forms.templates.event', 'Event registration'); },
    get description() { return t('apps.applications.forms.templates.event_desc', 'Collect attendee details, meal preferences, uploads, and ranked topic interest.'); },
    get tags() { return [t('apps.applications.forms.templates.registration_tag', 'Registration'), t('apps.applications.forms.templates.upload_tag', 'Upload'), t('apps.applications.forms.templates.planning_tag', 'Planning')]; },
    build: () => [
      section(t('apps.applications.forms.templates.attendee_details', 'Attendee details'), t('apps.applications.forms.templates.attendee_info', 'The essentials for registration.')),
      textQ(t('users.first_name', 'Full name'), 'short', true),
      textQ(t('users.email', 'Email address'), 'short', true, { restrictionEnabled: true, restrictionType: 'email', restrictionOperator: 'valid', restrictionValue: '' }),
      dateQ(t('apps.applications.forms.templates.session_date', 'Preferred session date'), true),
      uploadQ(t('apps.applications.forms.templates.upload_document', 'Upload your attendee document'), false),
      choiceQ(t('apps.applications.forms.templates.meal_preference', 'Meal preference'), [t('standard', 'Standard'), t('vegetarian', 'Vegetarian'), t('vegan', 'Vegan'), t('gluten_free', 'Gluten-free')], false),
    ],
  },
  {
    id: 'support-ticket',
    get title() { return t('apps.applications.forms.templates.support_ticket', 'Support ticket'); },
    get description() { return t('apps.applications.forms.templates.support_ticket_desc', 'Capture priority, issue details, screenshots, and routing in one place.'); },
    get tags() { return [t('apps.applications.forms.templates.support_tag', 'Support'), t('apps.applications.forms.templates.routing_tag', 'Routing'), t('apps.applications.forms.templates.upload_tag', 'Upload')]; },
    build: () => [
      section(t('apps.applications.forms.questions.section', 'Section'), t('apps.applications.forms.templates.issue_details', 'Help the team triage the issue faster.')),
      textQ(t('apps.applications.forms.templates.requester_name', 'Requester name'), 'short', true, { questionId: 'support_requester_name' }),
      textQ(t('apps.applications.forms.templates.contact_email', 'Contact email'), 'short', true, { questionId: 'support_contact_email', restrictionEnabled: true, restrictionType: 'email', restrictionOperator: 'valid', restrictionValue: '' }),
      choiceQ(t('apps.applications.forms.templates.priority', 'Priority'), ['Low', 'Medium', 'High', 'Critical'], true, { questionId: 'support_priority' }),
      choiceQ(t('apps.applications.forms.templates.affected_area', 'Affected area'), ['Login', 'Billing', 'Reporting', 'Integrations', 'Other'], true, {
        questionId: 'support_affected_area',
        branching: true,
        branchingRules: [
          { operator: 'not_answered', action: 'hide', targetQuestionId: 'support_other_affected_area' },
          { operator: 'not_equals', value: 'Other', action: 'hide', targetQuestionId: 'support_other_affected_area' },
          { operator: 'equals', value: 'Other', action: 'show', targetQuestionId: 'support_other_affected_area' },
        ],
      }),
      textQ(t('apps.applications.forms.templates.other_affected_area', 'Other affected area'), 'short', true, { questionId: 'support_other_affected_area' }),
      textQ(t('apps.applications.forms.templates.describe_issue', 'Describe the issue'), 'long', true, { questionId: 'support_issue_description' }),
      uploadQ(t('apps.applications.forms.templates.attach_file', 'Attach screenshot or log file'), false, {
        questionId: 'support_attachment',
        multipleFiles: true,
        fileAccept: '.png,.jpg,.jpeg,.pdf,.txt,.log,.zip',
        fileMaxSize: '100MB',
      }),
    ],
  },
  {
    id: 'employee-pulse',
    get title() { return t('apps.applications.forms.templates.employee_pulse', 'Employee pulse'); },
    get description() { return t('apps.applications.forms.templates.employee_pulse_desc', 'Run internal culture, workload, and manager support check-ins.'); },
    get tags() { return [t('apps.applications.forms.templates.hr_tag', 'HR'), t('apps.applications.forms.templates.internal_tag', 'Internal'), t('apps.applications.forms.templates.engagement_tag', 'Engagement')]; },
    build: () => [
      section(t('apps.applications.forms.questions.section', 'Section'), t('apps.applications.forms.templates.quick_checkin', 'A lightweight pulse survey for your team.')),
      ratingQ(t('apps.applications.forms.templates.workload_manageable', 'How manageable is your workload right now?'), 5, true),
      choiceQ(t('apps.applications.forms.templates.connected_priorities', 'How connected do you feel to team priorities?'), ['Very connected', 'Mostly connected', 'Somewhat connected', 'Not connected'], true),
      ratingQ(t('apps.applications.forms.templates.manager_support', 'How supported do you feel by your manager?'), 5, true),
      textQ(t('apps.applications.forms.templates.what_harder', 'What is making your work harder?'), 'long', false),
    ],
  },
  {
    id: 'contact',
    get title() { return t('apps.applications.forms.templates.contact_request', 'Contact request'); },
    get description() { return t('apps.applications.forms.templates.contact_request_desc', 'Perfect for lead capture, website contact pages, and demo requests.'); },
    get tags() { return [t('apps.applications.forms.templates.website_tag', 'Website'), t('apps.applications.forms.templates.lead_tag', 'Lead'), t('apps.applications.forms.templates.crm_tag', 'CRM')]; },
    build: () => [
      section(t('apps.applications.forms.questions.section', 'Section'), t('apps.applications.forms.templates.contact_intro', 'A polished intake flow for demo requests or contact pages.')),
      textQ(t('users.first_name', 'Full name'), 'short', true),
      textQ(t('users.email', 'Email address'), 'short', true, { restrictionEnabled: true, restrictionType: 'email', restrictionOperator: 'valid', restrictionValue: '' }),
      choiceQ(t('apps.applications.forms.templates.help_with', 'What can we help with?'), ['Request a demo', 'Pricing question', 'Technical question', 'Partnership'], true),
      textQ(t('apps.applications.forms.templates.message', 'Message'), 'long', true),
      choiceQ(t('apps.applications.forms.templates.preferred_contact', 'Preferred contact method'), ['Email', 'Phone', 'Teams meeting'], false),
    ],
  },
  {
    id: 'job-application',
    get title() { return t('apps.applications.forms.templates.job_application', 'Job application'); },
    get description() { return t('apps.applications.forms.templates.job_application_desc', 'Collect resume uploads, candidate highlights, and availability.'); },
    get tags() { return [t('apps.applications.forms.templates.hiring_tag', 'Hiring'), t('apps.applications.forms.templates.resume_tag', 'Resume'), t('apps.applications.forms.templates.recruiting_tag', 'Recruiting')]; },
    build: () => [
      section(t('apps.applications.forms.questions.section', 'Section'), t('apps.applications.forms.templates.candidate_profile', 'The essentials for a fast first review.')),
      textQ(t('users.first_name', 'Full name'), 'short', true),
      textQ(t('users.email', 'Email address'), 'short', true, { restrictionEnabled: true, restrictionType: 'email', restrictionOperator: 'valid', restrictionValue: '' }),
      textQ(t('apps.applications.forms.templates.portfolio', 'LinkedIn or portfolio URL'), 'short', false),
      uploadQ(t('apps.applications.forms.templates.resume_upload', 'Resume / CV'), true),
      choiceQ(t('apps.applications.forms.templates.years_experience', 'Years of experience'), ['0–2', '3–5', '6–8', '9+'], true),
      dateQ(t('apps.applications.forms.templates.start_date', 'When could you start?'), false),
    ],
  },
  {
    id: 'order-request',
    get title() { return t('apps.applications.forms.templates.order_request', 'Order request'); },
    get description() { return t('apps.applications.forms.templates.order_request_desc', 'Handle product requests, delivery notes, and approval-ready details.'); },
    get tags() { return [t('apps.applications.forms.templates.operations_tag', 'Operations'), t('apps.applications.forms.templates.request_tag', 'Request'), t('apps.applications.forms.templates.ordering_tag', 'Ordering')]; },
    build: () => [
      section(t('apps.applications.forms.questions.section', 'Section'), t('apps.applications.forms.templates.request_details', 'A structured request form for products or internal orders.')),
      textQ(t('apps.applications.forms.templates.requester_name', 'Requester name'), 'short', true),
      choiceQ(t('apps.applications.forms.templates.department', 'Department'), ['Operations', 'Sales', 'Finance', 'Marketing', 'IT'], true),
      choiceQ(t('apps.applications.forms.templates.request_type', 'Request type'), ['New order', 'Replacement', 'Restock', 'Urgent request'], true),
      rankingQ(t('apps.applications.forms.templates.priority_items', 'Which items are highest priority?'), ['Laptop', 'Monitor', 'Dock', 'Headset', 'Accessories'], false),
      textQ(t('apps.applications.forms.templates.order_details', 'Order details'), 'long', true),
    ],
  },
  {
    id: 'quiz',
    get title() { return t('apps.applications.forms.templates.quiz', 'Quick quiz'); },
    get description() { return t('apps.applications.forms.templates.quiz_desc', 'Start with answer keys, points, and an assessment-ready layout.'); },
    get tags() { return [t('apps.applications.forms.templates.quiz_tag', 'Quiz'), t('apps.applications.forms.templates.scoring_tag', 'Scoring'), t('apps.applications.forms.templates.training_tag', 'Training')]; },
    build: () => [
      choiceQ(t('apps.applications.forms.templates.correct_answer', 'Which answer is correct?'), [t('option_a', 'Option A'), t('option_b', 'Option B'), t('option_c', 'Option C')], true, { pointValue: 10, correctAnswers: [t('option_b', 'Option B')] }),
      ratingQ(t('apps.applications.forms.templates.confidence', 'Confidence level'), 5, false, { pointValue: 5 }),
      textQ(t('apps.applications.forms.templates.explain_reasoning', 'Explain your reasoning'), 'long', false, { pointValue: 15 }),
    ],
    quizMode: true,
  },
];

  const QUESTION_TYPES = [
    ['choice', () => t('apps.applications.forms.questions.choice', 'Choice')],
    ['text', () => t('apps.applications.forms.questions.text', 'Text')],
    ['rating', () => t('apps.applications.forms.questions.rating', 'Rating')],
    ['date', () => t('apps.applications.forms.questions.date', 'Date')],
    ['ranking', () => t('apps.applications.forms.questions.ranking', 'Ranking')],
    ['likert', () => t('apps.applications.forms.questions.likert', 'Likert')],
    ['upload', () => t('apps.applications.forms.questions.upload', 'Upload file')],
    ['nps', () => t('apps.applications.forms.questions.nps', 'Net promoter score')],
    ['section', () => t('apps.applications.forms.questions.section', 'Section')],
  ];

  const FILE_SIZE_PRESETS = [
    { value: '10MB', label: '10 MB' },
    { value: '100MB', label: '100 MB' },
    { value: '1GB', label: '1 GB' },
  ];

  const DEFAULT_SETTINGS = {
    who_can_fill: 'logged_in',
    accepted_responses: { enabled: true },
    start_date: { datetime: '' },
    end_date: { datetime: '' },
    time_duration: { minutes: 0 },
    shuffle_questions: { enabled: false },
    disable_question_number_for_respondents: { enabled: false },
    show_progress_bar: { enabled: true },
    hide_submit_another_response: { enabled: false },
    customize_thank_you_message: { message: '' },
    allow_respondents_to_save_their_responses: { enable: false },
    allow_respondents_to_edit_their_responses: { enable: false },
    allow_receipt_of_responses_after_submission: { enable: false },
    get_email_notification_of_each_response: { enable: false },
    show_score_in_thank_you: { enabled: false },
    text_similarity_leniency: { percent: 70 },
  };

  
const DEFAULT_STYLES = {
    layout: 'default',
    background: {
      style: 'linear-gradient(180deg, #f5f8fc 0%, #eef2ff 48%, #f7f9fd 100%)',
      startColor: '#f5f8fc',
      endColor: '#f7f9fd',
      direction: '180deg',
    },
    backgroundMusic: { enable: false, src: '' },
    headerBanner: {
      enable: false,
      src: '',
      type: 'image',
      alt: '',
    },
    accentColor: '#2563eb',
    cardRadius: 18,
    formWidth: 80,
  };

  const DEFAULT_UI = {
    showRequiredAsterisk: true,
    publishFunctional: true,
    get submitLabel() { return t('apps.applications.forms.ui.submit', 'Submit'); },
    get publishModeLabel() { return t('apps.applications.forms.ui.publish', 'Publish'); },
    get thankYouTitle() { return t('apps.applications.forms.ui.response_submitted', 'Response submitted'); },
  };

  let state = {
    formId: boot.formId || '',
    title: 'Untitled form',
    description: '',
    editorMode: boot.editorMode || (requestedMode === 'edit') ? true : !!boot.editorMode,
    mode: boot.editorMode === false ? 'publish' : 'edit',
    isQuiz: !!boot.isQuiz,
    activePanel: 'style',
    metadataSettings: structuredClone(DEFAULT_SETTINGS),
    metadataStyles: structuredClone(DEFAULT_STYLES),
    metadataUi: structuredClone(DEFAULT_UI),
    questions: [],
    responses: [],
    responseDraft: {},
    editingResponseId: boot.responseId || '',
    currentResponse: null,
    currentAnswers: {},
    currentPageIndex: 0,
    templateId: 'blank',
    templatesExpanded: false,
    inspectorExpanded: false,
    openMenuId: null,
    savingState: 'idle',
    saveMessage: t('apps.applications.forms.all_changes_saved', 'All changes saved'),
    lastSavedAt: null,
    previewMessage: '',
    validationErrors: {},
    responsePageIndex: 0,
    submissionComplete: false,
    quizOpened: false,
    timerStartedAt: null,
    timerExpired: false,
    autoSubmitted: false,
    lastSubmissionScore: null,
  };
  let saveTimer = null;
  let dragQuestionId = null;
  let dragOptionContext = null;
  let toastTimer = null;
  let timerInterval = null;
  let timerAutoSubmitting = false;

  const els = {
    toast: null,
  };


init();
syncTimeDurationWithSchedule();
function isPlainObject(value) {
  return !!value && typeof value === 'object' && !Array.isArray(value);
}

function normalizeLoadedAnswer(question, answer) {
  if (!question) return answer;
  if (typeof answer === 'undefined' || answer === null) return answer;
  if (question.type === 'choice') {
    if (question.isMultiple) return Array.isArray(answer) ? answer.map((item) => String(item ?? '')) : (String(answer).trim() ? [String(answer)] : []);
    if (Array.isArray(answer)) return answer[0] ?? '';
    return String(answer ?? '');
  }
  if (question.type === 'text' || question.type === 'date') {
    if (Array.isArray(answer)) return answer[0] ?? '';
    return String(answer ?? '');
  }
  if (question.type === 'rating' || question.type === 'nps') {
    const raw = Array.isArray(answer) ? answer[0] : answer;
    const num = Number(raw);
    return Number.isNaN(num) ? raw : num;
  }
  if (question.type === 'ranking') {
    if (Array.isArray(answer)) return answer.map((item) => String(item ?? ''));
    return answer ? [String(answer)] : [];
  }
  if (question.type === 'upload') return Array.isArray(answer) ? answer : (answer ? [answer] : []);
  if (question.type === 'likert') {
    if (isPlainObject(answer)) return { ...answer };
    const mapped = {};
    if (Array.isArray(answer)) {
      answer.forEach((item, index) => {
        if (item && typeof item === 'object' && !Array.isArray(item)) {
          const statement = String(item.statement ?? question.statements?.[index] ?? '').trim();
          const value = typeof item.value === 'undefined' ? '' : String(item.value);
          if (statement) mapped[statement] = value;
          return;
        }
        const statement = question.statements?.[index];
        if (statement) mapped[statement] = String(item ?? '');
      });
    }
    return mapped;
  }
  return answer;
}

function normalizeResponsesForEditor(responses, questions) {
  if (!Array.isArray(responses)) return [];
  return responses.map((response) => {
    const answersByQuestion = isPlainObject(response?.answersByQuestion) ? { ...response.answersByQuestion } : {};
    (Array.isArray(response?.answers) ? response.answers : []).forEach((entry) => {
      if (!entry || !entry.questionId) return;
      if (typeof answersByQuestion[entry.questionId] !== 'undefined') return;
      const values = Array.isArray(entry.answers) ? entry.answers : [];
      answersByQuestion[entry.questionId] = values.length <= 1 ? (values[0] ?? '') : values;
    });
    const normalizedAnswers = (Array.isArray(response?.answers) ? response.answers : []).map((entry) => {
      const question = questions.find((item) => item.questionId === entry.questionId);
      const normalizedValue = normalizeLoadedAnswer(question, answersByQuestion[entry.questionId]);
      let normalizedArray;
      if (question?.type === 'choice' && question.isMultiple) normalizedArray = Array.isArray(normalizedValue) ? normalizedValue : (normalizedValue ? [normalizedValue] : []);
      else if (question?.type === 'likert' && isPlainObject(normalizedValue)) normalizedArray = Object.entries(normalizedValue).map(([statement, value]) => ({ statement, value }));
      else if (Array.isArray(normalizedValue)) normalizedArray = normalizedValue;
      else normalizedArray = typeof normalizedValue === 'undefined' || normalizedValue === null || normalizedValue === '' ? [] : [normalizedValue];
      return { ...entry, answers: normalizedArray };
    });
    return { ...response, answersByQuestion, answers: normalizedAnswers };
  });
}

function buildDraftFromCurrentAnswers(questions, currentAnswers) {
  if (!currentAnswers || typeof currentAnswers !== 'object') return {};
  const draft = {};
  questions.filter((question) => question.type !== 'section').forEach((question) => {
    if (!Object.prototype.hasOwnProperty.call(currentAnswers, question.questionId)) return;
    const normalized = normalizeLoadedAnswer(question, currentAnswers[question.questionId]);
    if (typeof normalized !== 'undefined') draft[question.questionId] = normalized;
  });
  return draft;
}

function getInitialResponseDraft(questions, data) {
  const requestedId = data?.requestedResponseId || boot.responseId || '';
  const directAnswers = isPlainObject(data?.currentAnswers) ? data.currentAnswers : {};
  if (Object.keys(directAnswers).length) return buildDraftFromCurrentAnswers(questions, directAnswers);
  if (!requestedId || !Array.isArray(data?.responses)) return {};
  const currentResponse = data.responses.find((item) => item?.id === requestedId);
  if (!currentResponse) return {};
  return buildDraftFromCurrentAnswers(questions, currentResponse.answersByQuestion || {});
}

async function init() {
    try {
      // Load language based on browser preference
      const detectedLang = getBrowserLanguage();
      await loadLanguage(detectedLang);
      
      const payload = await postJSON(boot.loadUrl, { id: state.formId, responseId: boot.responseId || '' });
      const data = payload.data || {};
      const normalizedQuestions = Array.isArray(data.questions) ? data.questions.map(normalizeQuestion).map(refreshSectionMeta) : [];
      const templateQuestionIntent = applyTemplateQuestionsIntent(data.formId || state.formId || boot.formId || '', normalizedQuestions);
      const hydratedQuestions = templateQuestionIntent.questions;
      const recoveredTemplateQuestions = !!templateQuestionIntent.recovered;
      const normalizedResponses = normalizeResponsesForEditor(Array.isArray(data.responses) ? data.responses : [], hydratedQuestions);

const initialDraft = getInitialResponseDraft(hydratedQuestions, { ...data, responses: normalizedResponses });

const recoveredHeaderBanner = (() => {
  const currentBanner =
    normalizeStyles(
      deepMerge(structuredClone(DEFAULT_STYLES), data.metadataStyles || {})
    ).headerBanner || {};

  // If imported style metadata already has a URL, keep it.
  if (currentBanner.src) return currentBanner;

  // Fallback: recover from first question media
  const fallbackQuestion = normalizedQuestions.find(
    (question) => question && question.mediaUrl
  );

  if (!fallbackQuestion) return currentBanner;

  return {
    ...currentBanner,
    enable: true,
    src: fallbackQuestion.mediaUrl,
    type: fallbackQuestion.mediaType || 'image',
    alt: fallbackQuestion.mediaAlt || fallbackQuestion.title || data.title || 'Form banner',
  };
})();
state = {
        ...state,
        formId: data.formId || state.formId,
        title: data.title || t('apps.applications.forms.untitled', 'Untitled form'),
        description: data.description || '',
        editorMode: (requestedMode === 'edit') ? true : (typeof payload.editorMode === 'boolean' ? payload.editorMode : state.editorMode),
        mode: (requestedMode === 'edit') ? 'edit' : ((typeof payload.editorMode === 'boolean' && !payload.editorMode) ? 'publish' : state.mode),
        isQuiz: typeof payload.isQuiz === 'boolean' ? payload.isQuiz : state.isQuiz,
        metadataSettings: deepMerge(structuredClone(DEFAULT_SETTINGS), data.metadataSettings || {}),
        metadataStyles: (() => {
          const nextStyles = normalizeStyles(
            deepMerge(structuredClone(DEFAULT_STYLES), data.metadataStyles || {})
          );
          nextStyles.headerBanner = recoveredHeaderBanner;
          return nextStyles;
        })(),
        metadataUi: deepMerge(structuredClone(DEFAULT_UI), data.metadataUi || data.ui || {}),
        questions: hydratedQuestions,
        responses: normalizedResponses,
        editingResponseId: data.requestedResponseId || boot.responseId || state.editingResponseId || '',
        currentResponse: data.currentResponse || null,
        currentAnswers: isPlainObject(data.currentAnswers) ? data.currentAnswers : {},
        responseDraft: initialDraft
      };
      if (!state.questions.length && state.editorMode) {
        state.questions = [];
      }
      render();
      if (recoveredTemplateQuestions) {
        window.setTimeout(() => {
          try {
            scheduleSave('template logic');
          } catch (_) {}
        }, 50);
      }
    } catch (error) {
      console.error(error);
      root.innerHTML = `<div class="forms-empty-state"><h2>${escapeHtml(t('apps.applications.forms.messages.unable_to_load', 'Unable to load this form'))}</h2><p>${escapeHtml(error.message || t('apps.applications.forms.messages.unexpected_error', 'An unexpected error occurred.'))}</p></div>`;
    }
  }


  

function normalizeStyles(styles) {
    const normalized = deepMerge(structuredClone(DEFAULT_STYLES), styles || {});
    const parsed = parseBackgroundStyle(
      normalized.background && normalized.background.style
        ? normalized.background.style
        : DEFAULT_STYLES.background.style
    );

    normalized.background = {
      ...normalized.background,
      ...parsed,
      style: buildBackgroundStyle(parsed.startColor, parsed.endColor, parsed.direction),
    };

    normalized.backgroundMusic = deepMerge(
      structuredClone(DEFAULT_STYLES.backgroundMusic),
      normalized.backgroundMusic || {}
    );
    normalized.backgroundMusic.enable = !!normalized.backgroundMusic.enable;
    normalized.backgroundMusic.src = String(normalized.backgroundMusic.src || '').trim();

    const bannerAliases = [
      normalized.headerBanner,
      normalized.header_banner,
      normalized['header-banner'],
      normalized.banner,
      normalized.bannerImage ? { src: normalized.bannerImage, type: 'image', alt: normalized.bannerAlt || '' } : null,
    ].filter(Boolean);

    const bannerNode = bannerAliases.find((value) => isPlainObject(value)) || {};
    const bannerAttrs = isPlainObject(bannerNode['@attributes'])
      ? bannerNode['@attributes']
      : (isPlainObject(bannerNode.attributes) ? bannerNode.attributes : {});

    const enableValue =
      typeof normalized.headerBannerEnable !== 'undefined' ? normalized.headerBannerEnable
      : typeof normalized.header_banner_enable !== 'undefined' ? normalized.header_banner_enable
      : typeof normalized['header-banner-enable'] !== 'undefined' ? normalized['header-banner-enable']
      : typeof bannerNode.enable !== 'undefined' ? bannerNode.enable
      : typeof bannerNode.enabled !== 'undefined' ? bannerNode.enabled
      : typeof bannerAttrs.enable !== 'undefined' ? bannerAttrs.enable
      : typeof bannerAttrs.enabled !== 'undefined' ? bannerAttrs.enabled
      : (bannerNode.src || bannerNode.url || bannerAttrs.src || normalized.bannerImage ? '1' : '0');

    const bannerSrc = [
      normalized.headerBannerSrc,
      normalized.header_banner_src,
      normalized['header-banner-src'],
      bannerNode.src,
      bannerNode.url,
      bannerAttrs.src,
      normalized.bannerImage,
      ''
    ].find((value) => typeof value !== 'undefined' && value !== null && String(value).trim() !== '');

    const bannerType = [
      normalized.headerBannerType,
      normalized.header_banner_type,
      normalized['header-banner-type'],
      bannerNode.type,
      bannerAttrs.type,
      'image'
    ].find((value) => typeof value !== 'undefined' && value !== null && String(value).trim() !== '');

    const bannerAlt = [
      normalized.headerBannerAlt,
      normalized.header_banner_alt,
      normalized['header-banner-alt'],
      bannerNode.alt,
      bannerNode.caption,
      bannerAttrs.alt,
      bannerAttrs.caption,
      normalized.bannerAlt,
      ''
    ].find((value) => typeof value !== 'undefined' && value !== null);

    normalized.headerBanner = {
      enable: ['1', 'true', 'yes', 'on'].includes(String(enableValue).toLowerCase()) || !!String(bannerSrc || '').trim(),
      src: String(bannerSrc || '').trim(),
      type: ['image', 'video', 'audio'].includes(String(bannerType || '').toLowerCase())
        ? String(bannerType).toLowerCase()
        : 'image',
      alt: String(bannerAlt || '').trim(),
    };

    return normalized;
  }

  function parseBackgroundStyle(style) {
    const input = String(style || '').trim();
    const match = input.match(/linear-gradient\(\s*([^,]+),\s*(#[0-9a-fA-F]{3,8})[^,]*,\s*(#[0-9a-fA-F]{3,8})[^,]*,\s*(#[0-9a-fA-F]{3,8})[^)]*\)/i);
    if (match) {
      return {
        direction: match[1].trim(),
        startColor: normalizeHexColor(match[2]),
        endColor: normalizeHexColor(match[4]),
      };
    }
    const simpleMatch = input.match(/linear-gradient\(\s*([^,]+),\s*(#[0-9a-fA-F]{3,8})[^,]*,\s*(#[0-9a-fA-F]{3,8})[^)]*\)/i);
    if (simpleMatch) {
      return {
        direction: simpleMatch[1].trim(),
        startColor: normalizeHexColor(simpleMatch[2]),
        endColor: normalizeHexColor(simpleMatch[3]),
      };
    }
    return {
      startColor: DEFAULT_STYLES.background.startColor,
      endColor: DEFAULT_STYLES.background.endColor,
      direction: DEFAULT_STYLES.background.direction,
    };
  }

  function buildBackgroundStyle(startColor, endColor, direction) {
    const start = normalizeHexColor(startColor || DEFAULT_STYLES.background.startColor);
    const end = normalizeHexColor(endColor || DEFAULT_STYLES.background.endColor);
    const dir = direction || DEFAULT_STYLES.background.direction;
    const midpoint = mixHexColors(start, end, 0.5);
    return `linear-gradient(${dir}, ${start} 0%, ${midpoint} 48%, ${end} 100%)`;
  }

  function normalizeHexColor(value) {
    const hex = String(value || '').trim();
    if (/^#[0-9a-fA-F]{6}$/.test(hex)) return hex.toLowerCase();
    if (/^#[0-9a-fA-F]{3}$/.test(hex)) return `#${hex[1]}${hex[1]}${hex[2]}${hex[2]}${hex[3]}${hex[3]}`.toLowerCase();
    return '#000000';
  }

  function mixHexColors(startColor, endColor, weight = 0.5) {
    const start = normalizeHexColor(startColor).slice(1);
    const end = normalizeHexColor(endColor).slice(1);
    const mix = [0, 2, 4].map((offset) => {
      const from = parseInt(start.slice(offset, offset + 2), 16);
      const to = parseInt(end.slice(offset, offset + 2), 16);
      return Math.round((from * (1 - weight)) + (to * weight)).toString(16).padStart(2, '0');
    }).join('');
    return `#${mix}`;
  }

  function formatSaveBadgeDateTime(value) {
    const date = value instanceof Date ? value : parseDate(value);
    if (!date) return '';
    const datePart = date.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' });
    const timePart = date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })
      .replace(/\sAM$/i, 'am')
      .replace(/\sPM$/i, 'pm');
    return `${datePart} at ${timePart}`;
  }

  function deepMerge(target, source) {
    if (!source || typeof source !== 'object') return target;
    Object.keys(source).forEach((key) => {
      const value = source[key];
      if (Array.isArray(value)) target[key] = value.slice();
      else if (value && typeof value === 'object') target[key] = deepMerge(target[key] && typeof target[key] === 'object' ? target[key] : {}, value);
      else target[key] = value;
    });
    return target;
  }

  function uid(prefix = 'Q') {
    return `${prefix}-${crypto.randomUUID ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(16).slice(2)}`}`;
  }

  function baseQuestion(type, extras = {}) {
    return {
      questionId: uid('Q'),
      type,
      title: type === 'section' ? t('apps.applications.forms.questions.section', 'Section') : t('apps.applications.forms.questions.question', 'Question'),
      subtitle: false,
      description: false,
      required: false,
      isMultiple: false,
      isDropdown: false,
      shuffle: false,
      branching: false,
      branchingRules: [],
      otherOptionEnabled: false,
      otherOptionLabel: '',
      pointValue: 0,
      sectionTitle: '',
      sectionOrder: 0,
      options: [t('apps.applications.forms.options.option', 'Option') + ' 1', t('apps.applications.forms.options.option', 'Option') + ' 2'],
      limit: ['noLimit', 0],
      columns: [t('likert_strongly_disagree', 'Strongly disagree'), t('likert_disagree', 'Disagree'), t('likert_neutral', 'Neutral'), t('likert_agree', 'Agree'), t('likert_strongly_agree', 'Strongly agree')],
      statements: [t('statement', 'Statement') + ' 1', t('statement', 'Statement') + ' 2'],
      textMode: 'short',
      restrictionEnabled: false,
      restrictionType: 'text',
      restrictionOperator: '',
      restrictionValue: '',
      restrictionValueSecondary: '',
      mediaUrl: '',
      mediaType: 'image',
      mediaAlt: '',
      maxRating: 5,
      minLabel: t('nps_min', 'Not likely'),
      maxLabel: t('nps_max', 'Very likely'),
      maxRank: 4,
      fileAccept: '',
      fileMaxSize: '',
      multipleFiles: false,
      correctAnswers: [],
      acceptedAnswers: [],
      ...extras,
    };
  }

  function section(title = 'Section', description = '') {
    return baseQuestion('section', {
      title,
      description,
      required: false,
      options: [],
      pointValue: 0,
    });
  }

  function choiceQ(title, options, required = false, extras = {}) {
    return baseQuestion('choice', { title, options, required, ...extras });
  }

  function textQ(title, mode = 'short', required = false, extras = {}) {
    return baseQuestion('text', { title, textMode: mode, required, options: [], ...extras });
  }

  function ratingQ(title, maxRating = 5, required = false, extras = {}) {
    return baseQuestion('rating', { title, maxRating, required, options: [], ...extras });
  }

  function dateQ(title, required = false, extras = {}) {
    return baseQuestion('date', { title, required, options: [], ...extras });
  }

  function rankingQ(title, options, required = false, extras = {}) {
    return baseQuestion('ranking', { title, options, required, isDropdown: false, ...extras });
  }

  function npsQ(title, required = false, extras = {}) {
    return baseQuestion('nps', { title, required, options: [], minLabel: 'Not likely', maxLabel: 'Very likely', ...extras });
  }

  function uploadQ(title, required = false, extras = {}) {
    return baseQuestion('upload', { title, required, options: [], fileAccept: '.pdf,.doc,.docx,.png,.jpg,.jpeg', ...extras });
  }

  function normalizeQuestion(input, index = 0) {
    const q = baseQuestion(input.type || 'choice');
    const normalized = { ...q, ...input };
    normalized.questionId = normalized.questionId || uid('Q');
    normalized.type = (normalized.type || 'choice').toLowerCase();
    normalized.title = normalized.title || (normalized.type === 'section' ? t('apps.applications.forms.questions.section', 'Section') : t('apps.applications.forms.questions.question', 'Question'));
    normalized.subtitle = normalizeOptionalText(normalized.subtitle);
    normalized.description = normalizeOptionalText(normalized.description);
    normalized.options = ensureStringArray(normalized.options.length ? normalized.options : (normalized.type === 'choice' || normalized.type === 'ranking' ? [t('apps.applications.forms.options.option', 'Option') + ' 1', t('apps.applications.forms.options.option', 'Option') + ' 2'] : []));
    normalized.columns = ensureStringArray(normalized.columns && normalized.columns.length ? normalized.columns : [t('likert_strongly_disagree', 'Strongly disagree'), t('likert_disagree', 'Disagree'), t('likert_neutral', 'Neutral'), t('likert_agree', 'Agree'), t('likert_strongly_agree', 'Strongly agree')]);
    normalized.statements = ensureStringArray(normalized.statements && normalized.statements.length ? normalized.statements : [t('statement', 'Statement') + ' 1', t('statement', 'Statement') + ' 2']);
    normalized.branchingRules = coerceBranchingRules(normalized.branchingRules || normalized.branchingRulesJson);
    normalized.required = !!normalized.required && normalized.type !== 'section';
    normalized.isMultiple = !!normalized.isMultiple;
    normalized.isDropdown = normalized.type === 'choice' ? (!!normalized.isDropdown && !normalized.isMultiple) : false;
    normalized.shuffle = !!normalized.shuffle;
    normalized.branching = !!normalized.branching || normalized.branchingRules.length > 0;
    normalized.pointValue = Number(normalized.pointValue || 0);
    normalized.sectionOrder = Number(normalized.sectionOrder || index);
    normalized.limit = Array.isArray(normalized.limit) ? [normalized.limit[0] || 'noLimit', Number(normalized.limit[1] || 0)] : ['noLimit', 0];
    normalized.textMode = normalized.textMode || 'short';
    normalized.restrictionEnabled = !!normalized.restrictionEnabled;
    normalized.restrictionType = normalized.restrictionType || 'text';
    normalized.restrictionOperator = normalized.restrictionOperator || '';
    normalized.restrictionValue = normalized.restrictionValue || '';
    normalized.restrictionValueSecondary = normalized.restrictionValueSecondary || '';
    normalized.mediaUrl = normalized.mediaUrl || '';
    normalized.mediaType = normalized.mediaType || 'image';
    normalized.mediaAlt = normalized.mediaAlt || '';
    normalized.maxRating = Math.max(3, Math.min(10, Number(normalized.maxRating || 5)));
    normalized.minLabel = normalized.minLabel || t('nps_min', 'Not likely');
    normalized.maxLabel = normalized.maxLabel || t('nps_max', 'Very likely');
    normalized.maxRank = Math.max(2, Math.min(10, Number(normalized.maxRank || Math.max(normalized.options.length, 4))));
    normalized.fileAccept = normalized.fileAccept || '';
    normalized.fileMaxSize = normalized.fileMaxSize || '';
    normalized.multipleFiles = !!normalized.multipleFiles;
    normalized.correctAnswers = ensureStringArray(normalized.correctAnswers || []).filter((answer) => normalized.options.includes(answer));
    normalized.acceptedAnswers = ensureStringArray(normalized.acceptedAnswers || []);
    if (normalized.type === 'section') {
      normalized.required = false;
      normalized.pointValue = 0;
      normalized.options = [];
      normalized.correctAnswers = [];
      normalized.acceptedAnswers = [];
    }
    return normalized;
  }

  function refreshSectionMeta(question, index, list) {
    if (!list) return question;
    if (question.type === 'section') {
      return { ...question, sectionTitle: '', sectionOrder: index };
    }
    let currentSection = '';
    let order = 0;
    for (let i = 0; i <= index; i += 1) {
      if ((list[i] || {}).type === 'section') {
        currentSection = list[i].title || `Section ${i + 1}`;
        order = i;
      }
    }
    return { ...question, sectionTitle: currentSection, sectionOrder: order };
  }

  function recomputeSections() {
    state.questions = state.questions.map((question, index, list) => refreshSectionMeta(question, index, list));
  }

  function ensureStringArray(value) {
    if (!Array.isArray(value)) return [];
    return value.map((item) => String(item ?? '').trim()).filter(Boolean);
  }

  function coerceBranchingRules(value) {
    if (Array.isArray(value)) return value.filter(Boolean).map((rule) => normalizeBranchRule(rule));
    if (typeof value === 'string') {
      const raw = value.trim();
      if (!raw) return [];
      try {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed.filter(Boolean).map((rule) => normalizeBranchRule(rule));
      } catch (_) {}
      const parts = raw.match(/\{[^}]*\}/g) || [];
      return parts.map((item) => {
        try { return normalizeBranchRule(JSON.parse(item)); } catch (_) { return null; }
      }).filter(Boolean);
    }
    return [];
  }

  function parseFileSizeLimit(value) {
    const raw = String(value || '').trim().toUpperCase();
    if (!raw) return 0;
    const match = raw.match(/^(\d+)(MB|GB)$/i);
    if (!match) return 0;
    const amount = Number(match[1]);
    const unit = match[2].toUpperCase();
    if (!Number.isFinite(amount) || amount <= 0) return 0;
    return unit === 'GB' ? amount * 1024 * 1024 * 1024 : amount * 1024 * 1024;
  }


  function parseAcceptedFileTypes(value) {
    return String(value || '')
      .split(',')
      .map((item) => item.trim().toLowerCase())
      .filter(Boolean);
  }

  function fileTypeMatchesAcceptToken(file, token, normalizedName = '') {
    const safeToken = String(token || '').trim().toLowerCase();
    if (!safeToken) return false;
    const safeName = String(normalizedName || file?.name || '').trim().toLowerCase();
    const safeMime = String(file?.type || '').trim().toLowerCase();
    const lastDot = safeName.lastIndexOf('.');
    const extension = lastDot >= 0 ? safeName.slice(lastDot) : '';

    if (safeToken.startsWith('.')) return extension === safeToken;
    if (safeToken.endsWith('/*')) {
      const prefix = safeToken.slice(0, -1);
      return safeMime.startsWith(prefix);
    }
    return safeMime === safeToken;
  }

  function getUploadValidationError(question, file) {
    if (!file) {
      return t('apps.applications.forms.messages.invalid_upload_file', 'Invalid upload file.');
    }

    const rawName = typeof file.name === 'string' ? file.name : '';
    if (!rawName) {
      return t('apps.applications.forms.messages.invalid_upload_file', 'Invalid upload file.');
    }

    if (/[\u0000]/.test(rawName)) {
      return t('apps.applications.forms.messages.invalid_upload_file_name', 'Invalid file name.');
    }

    const normalizedName = rawName.normalize('NFKC').trim();
    if (!normalizedName || /[\u0000]/.test(normalizedName)) {
      return t('apps.applications.forms.messages.invalid_upload_file_name', 'Invalid file name.');
    }

    const maxBytes = parseFileSizeLimit(question?.fileMaxSize);
    if (maxBytes > 0 && Number(file?.size || 0) > maxBytes) {
      return t('apps.applications.forms.messages.invalid_upload_file_size', '{file} exceeds the maximum size of {size}.')
        .replace('{file}', normalizedName)
        .replace('{size}', question.fileMaxSize || 'the configured limit');
    }

    const acceptedTypes = parseAcceptedFileTypes(question?.fileAccept);
    if (acceptedTypes.length && !acceptedTypes.some((token) => fileTypeMatchesAcceptToken(file, token, normalizedName))) {
      return t('apps.applications.forms.messages.invalid_upload_file_type', '{file} is not an allowed file type. Allowed types: {types}.')
        .replace('{file}', normalizedName)
        .replace('{types}', question.fileAccept || acceptedTypes.join(', '));
    }

    return '';
  }

  function validateUploadSelection(question, files) {
    const normalizedFiles = Array.isArray(files) ? files : [];
    if (!normalizedFiles.length) return '';

    for (const file of normalizedFiles) {
      const error = getUploadValidationError(question, file);
      if (error) return error;
    }

    return '';
  }

  function normalizeOptionalText(value) {
    if (value === false || value === null || typeof value === 'undefined') return false;
    const text = String(value).trim();
    return text && text !== 'false' ? text : false;
  }

  function scheduleSave(reason = '') {
    if (!state.editorMode) return;
    if (saveTimer) clearTimeout(saveTimer);
    state.savingState = 'saving';
    state.saveMessage = reason ? t('apps.applications.forms.saving_item', 'Saving {item}…', { item: reason }).replace('{item}', reason) : t('apps.applications.forms.saving_changes', 'Saving changes…');
    renderHeaderStatus();
    saveTimer = setTimeout(saveNow, 700);
  }

  async function saveNow() {
    if (!state.editorMode) return;
    try {
      const payload = serializeForSave();
      const response = await postForm(boot.saveUrl, payload);
      if (!response.success) throw new Error(response.error || t('apps.applications.forms.common.save_failed', 'Save failed'));
      state.savingState = 'success';
      state.lastSavedAt = Date.now();
      state.saveMessage = t('apps.applications.forms.common.saved_at', 'Saved {time}').replace('{time}', new Date(state.lastSavedAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }));
      renderHeaderStatus();
    } catch (error) {
      console.error(error);
      state.savingState = 'error';
      state.saveMessage = error.message || t('apps.applications.forms.common.unable_save', 'Unable to save');
      renderHeaderStatus();
      toast(error.message || t('apps.applications.forms.common.unable_save', 'Unable to save'), true);
    }
  }

  function serializeForSave() {
    const normalizedStyles = normalizeStyles(structuredClone(state.metadataStyles || {}));
    return {
      formId: state.formId,
      title: state.title,
      description: state.description,
      type: state.isQuiz ? 'quiz' : 'form',
      metadataSettings: JSON.stringify(state.metadataSettings),
      metadataStyles: JSON.stringify(normalizedStyles),
      metadataUi: JSON.stringify(state.metadataUi),
      questions: state.questions.map((question, index, list) => {
        const q = refreshSectionMeta(question, index, list);
        return {
          questionId: q.questionId,
          type: q.type,
          title: q.title,
          subtitle: q.subtitle || false,
          description: q.description || false,
          required: q.required ? 'true' : 'false',
          isMultiple: q.isMultiple ? 'true' : 'false',
          isDropdown: q.isDropdown ? 'true' : 'false',
          shuffle: q.shuffle ? 'true' : 'false',
          branching: q.branching ? 'true' : 'false',
          otherOptionEnabled: q.otherOptionEnabled ? 'true' : 'false',
          otherOptionLabel: q.otherOptionLabel || '',
          pointValue: String(q.pointValue || 0),
          sectionTitle: q.sectionTitle || '',
          sectionOrder: String(q.sectionOrder || 0),
          options: q.options,
          columns: q.columns,
          statements: q.statements,
          limit: q.limit,
          textMode: q.textMode,
          restrictionEnabled: q.restrictionEnabled ? 'true' : 'false',
          restrictionType: q.restrictionType,
          restrictionOperator: q.restrictionOperator,
          restrictionValue: q.restrictionValue,
          restrictionValueSecondary: q.restrictionValueSecondary,
          branchingRules: q.branchingRules,
          mediaUrl: q.mediaUrl,
          mediaType: q.mediaType,
          mediaAlt: q.mediaAlt,
          maxRating: String(q.maxRating || 5),
          minLabel: q.minLabel,
          maxLabel: q.maxLabel,
          maxRank: String(q.maxRank || q.options.length || 4),
          fileAccept: q.fileAccept || '',
          fileMaxSize: q.fileMaxSize || '',
          multipleFiles: q.multipleFiles ? 'true' : 'false',
          correctAnswers: q.correctAnswers || [],
          acceptedAnswers: q.acceptedAnswers || [],
        };
      }),
    };
  }



function getHeaderBannerConfig() {
  const banner = state.metadataStyles?.headerBanner || null;
  if (!banner || !banner.enable || !banner.src) return null;

  return {
    src: String(banner.src || ''),
    type: String(banner.type || 'image').toLowerCase(),
    alt: String(banner.alt || state.title || 'Form banner'),
  };
}

function getPublishHeaderBackgroundMarkup() {
  const banner = getHeaderBannerConfig();
  if (!banner || !banner.src) return '';

  // Audio can't really be a visual background, so skip it here.
  if (banner.type === 'audio') return '';

  if (banner.type === 'video') {
    return `
      <div class="forms-publish-header-media is-video" aria-hidden="true">
        <video src="${escapeAttribute(banner.src)}" autoplay muted loop playsinline></video>
      </div>
    `;
  }

  return `
    <div class="forms-publish-header-media is-image" aria-hidden="true">
      <img src="${escapeAttribute(banner.src)}" alt="">
    </div>
  `;
}

function getPublishHeaderAudioMarkup() {
  const banner = getHeaderBannerConfig();
  if (!banner || banner.type !== 'audio' || !banner.src) return '';
  return `
    <div class="forms-publish-header-audio">
      <audio controls src="${escapeAttribute(banner.src)}"></audio>
    </div>
  `;
}

function renderHeaderBanner(mode = 'publish') {
  const banner = getHeaderBannerConfig();
  if (!banner) return '';

  const mediaType = banner.type || 'image';
  const label = banner.alt || state.title || (mode === 'edit' ? 'Form banner' : 'Header banner');
  const sublabel = mode === 'edit'
    ? 'Banner media used in edit mode'
    : 'Banner media used in publish mode';

  if (mediaType === 'video') {
    return `<div class="forms-header-banner forms-header-banner-video"><video src="${escapeAttribute(banner.src)}" autoplay muted loop playsinline></video><div class="forms-header-banner-overlay"><strong>${escapeHtml(label)}</strong><span>${escapeHtml(sublabel)}</span></div></div>`;
  }
  if (mediaType === 'audio') {
    return `<div class="forms-header-banner forms-header-banner-audio"><div class="forms-header-banner-audio-copy"><strong>${escapeHtml(label)}</strong><span>${escapeHtml(sublabel)}</span></div><audio controls src="${escapeAttribute(banner.src)}"></audio></div>`;
  }
  return `<div class="forms-header-banner forms-header-banner-image"><img src="${escapeAttribute(banner.src)}" alt="${escapeAttribute(label)}"><div class="forms-header-banner-overlay"><strong>${escapeHtml(label)}</strong><span>${escapeHtml(sublabel)}</span></div></div>`;
}
function consumeTemplateBannerIntent(formId) {
  try {
    const raw = window.sessionStorage.getItem('forms.templateBannerIntent.v1');
    if (!raw) return null;

    const parsed = JSON.parse(raw);
    if (!parsed || parsed.formId !== formId) return null;

    const createdAt = Number(parsed.createdAt || 0);
    const ageMs = Date.now() - createdAt;

    // expire after 10 minutes just to be safe
    if (createdAt && ageMs > 10 * 60 * 1000) {
      window.sessionStorage.removeItem('forms.templateBannerIntent.v1');
      return null;
    }

    window.sessionStorage.removeItem('forms.templateBannerIntent.v1');

    const banner = parsed.banner || {};
    if (!banner.src) return null;

    return {
      enable: true,
      src: String(banner.src || ''),
      type: ['image', 'video', 'audio'].includes(String(banner.type || '').toLowerCase())
        ? String(banner.type).toLowerCase()
        : 'image',
      alt: String(banner.alt || state.title || 'Form banner')
    };
  } catch (_) {
    return null;
  }
}

function applyTemplateBannerIntent() {
  if (!state || !state.formId || !state.metadataStyles) return false;

  const incoming = consumeTemplateBannerIntent(state.formId);
  if (!incoming) return false;

  const current = state.metadataStyles.headerBanner || {};
  const shouldApply = !current.src || !current.enable;

  if (!shouldApply) return false;

  state.metadataStyles.headerBanner = {
    ...current,
    enable: true,
    src: incoming.src,
    type: incoming.type || 'image',
    alt: incoming.alt || state.title || 'Form banner'
  };

  // persist it after hydration
  window.setTimeout(() => {
    try {
      scheduleSave('styles');
    } catch (_) {}
  }, 50);

  return true;
}

function consumeTemplateQuestionsIntent(formId) {
  try {
    const raw = window.sessionStorage.getItem('forms.templateQuestionsIntent.v1');
    if (!raw) return null;

    const parsed = JSON.parse(raw);
    if (!parsed || parsed.formId !== formId || !Array.isArray(parsed.questions)) return null;

    const createdAt = Number(parsed.createdAt || 0);
    const ageMs = Date.now() - createdAt;
    if (createdAt && ageMs > 10 * 60 * 1000) {
      window.sessionStorage.removeItem('forms.templateQuestionsIntent.v1');
      return null;
    }

    window.sessionStorage.removeItem('forms.templateQuestionsIntent.v1');
    return parsed.questions;
  } catch (_) {
    return null;
  }
}

function questionNeedsTemplateRecovery(currentQuestion, templateQuestion) {
  if (!currentQuestion || !templateQuestion) return false;
  const missingLogic = !!currentQuestion.branching
    && (!Array.isArray(currentQuestion.branchingRules) || !currentQuestion.branchingRules.length)
    && Array.isArray(templateQuestion.branchingRules)
    && templateQuestion.branchingRules.length > 0;
  const missingUploadLimit = currentQuestion.type === 'upload'
    && !String(currentQuestion.fileMaxSize || '').trim()
    && !!String(templateQuestion.fileMaxSize || '').trim();
  return missingLogic || missingUploadLimit;
}

function applyTemplateQuestionsIntent(formId, questions) {
  const incoming = consumeTemplateQuestionsIntent(formId);
  if (!incoming || !Array.isArray(questions) || !questions.length) {
    return { questions, recovered: false };
  }

  const incomingById = new Map(
    incoming
      .filter((question) => question && question.questionId)
      .map((question) => [question.questionId, question])
  );

  let recovered = false;
  const merged = questions.map((question) => {
    const templateQuestion = incomingById.get(question.questionId);
    if (!questionNeedsTemplateRecovery(question, templateQuestion)) return question;
    recovered = true;
    return normalizeQuestion({
      ...question,
      branching: question.branching || templateQuestion.branching,
      branchingRules: (Array.isArray(question.branchingRules) && question.branchingRules.length)
        ? question.branchingRules
        : (templateQuestion.branchingRules || []),
      fileAccept: question.fileAccept || templateQuestion.fileAccept,
      fileMaxSize: question.fileMaxSize || templateQuestion.fileMaxSize,
      multipleFiles: question.multipleFiles || templateQuestion.multipleFiles,
    });
  }).map(refreshSectionMeta);

  return { questions: merged, recovered };
}

function render() {
  applyTemplateBannerIntent();

  root.innerHTML = state.mode === 'edit'
    ? renderEditorShell()
    : renderPublishShell(state.mode === 'preview');

  syncPublishHeaderBanner();
  upgradePublishProgressBar();
  localizeRenderedContent();

  attachHandlers();
  renderHeaderStatus();
  ensurePublishTimer();

  window.requestAnimationFrame(() => {
    syncPublishHeaderBanner();
    upgradePublishProgressBar();
    updatePublishProgressUI();
    localizeRenderedContent();
  });
}

  

function syncPublishHeaderBanner() {
  const header = root.querySelector('.forms-publish-header');
  if (!header) return;
  wirePublishHeaderContrast(header);
}

function wirePublishHeaderContrast(header) {
  if (!header || !header.classList.contains('has-banner')) return;
  const media = header.querySelector('.forms-publish-header-media img, .forms-publish-header-media video');
  if (!media) return;

  const apply = () => applyPublishHeaderContrast(header, media);

  if (media.tagName === 'IMG') {
    if (media.complete) apply();
    else {
      media.addEventListener('load', apply, { once: true });
      media.addEventListener('error', () => {
        header.dataset.tone = 'light';
      }, { once: true });
    }
    return;
  }

  media.addEventListener('loadeddata', apply, { once: true });
  media.addEventListener('error', () => {
    header.dataset.tone = 'light';
  }, { once: true });
  window.setTimeout(apply, 320);
}

function applyPublishHeaderContrast(header, media) {
  if (!header || !media) return;
  header.dataset.tone = 'light';

  try {
    const canvas = document.createElement('canvas');
    canvas.width = 24;
    canvas.height = 24;

    const context = canvas.getContext('2d', { willReadFrequently: true });
    if (!context) return;

    context.drawImage(media, 0, 0, 24, 24);
    const pixels = context.getImageData(0, 0, 24, 24).data;

    let totalLuminance = 0;
    let samples = 0;

    for (let index = 0; index < pixels.length; index += 4) {
      const alpha = pixels[index + 3] / 255;
      if (alpha <= 0.05) continue;

      const red = pixels[index] / 255;
      const green = pixels[index + 1] / 255;
      const blue = pixels[index + 2] / 255;
      const luminance = (0.2126 * red) + (0.7152 * green) + (0.0722 * blue);

      totalLuminance += luminance;
      samples += 1;
    }

    if (!samples) return;

    const average = totalLuminance / samples;
    header.dataset.tone = average >= 0.62 ? 'dark' : 'light';
  } catch (error) {
    header.dataset.tone = 'light';
  }
}

function upgradePublishProgressBar() {
  const progress = root.querySelector('.forms-progress');
  if (!progress) return;

  let requiredBar = progress.querySelector('[data-role="forms-progress-bar-required"]');
  let filledBar = progress.querySelector('[data-role="forms-progress-bar-filled"]');
  let legacyBar = progress.querySelector('[data-role="forms-progress-bar"]');

  if (!requiredBar) {
    requiredBar = document.createElement('div');
    requiredBar.className = 'forms-progress-bar forms-progress-bar-required';
    requiredBar.dataset.role = 'forms-progress-bar-required';
    progress.appendChild(requiredBar);
  }

  if (!filledBar) {
    if (legacyBar) {
      legacyBar.dataset.role = 'forms-progress-bar-filled';
      legacyBar.classList.add('forms-progress-bar-filled');
      filledBar = legacyBar;
    } else {
      filledBar = document.createElement('div');
      filledBar.className = 'forms-progress-bar forms-progress-bar-filled';
      filledBar.dataset.role = 'forms-progress-bar-filled';
      progress.appendChild(filledBar);
    }
  }
}

const TEMPLATE_SHOWCASE_ORDER = ['feedback', 'event', 'support-ticket', 'employee-pulse', 'contact', 'job-application', 'order-request', 'quiz'];

const TEMPLATE_CARD_LIBRARY = {
  feedback: {
    kind: 'form',
    accentColor: '#2563eb',
    backgroundStart: '#f5f8fc',
    backgroundEnd: '#eef2ff',
    cardRadius: 18,
    formWidth: 80,
    previewBanner: 'feedback',
    bannerImage: 'https://images.unsplash.com/photo-1556740749-887f6717d7e4?auto=format&fit=crop&w=1600&q=80',
    bannerAlt: 'Customer service banner image',
    previewFields: ['choice', 'rating', 'textarea', 'chips'],
  },
  event: {
    kind: 'form',
    accentColor: '#f97316',
    backgroundStart: '#fff8f1',
    backgroundEnd: '#fff1e6',
    cardRadius: 20,
    formWidth: 82,
    previewBanner: 'event',
    bannerImage: 'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=1600&q=80',
    bannerAlt: 'Event registration banner image',
    previewFields: ['text', 'date', 'upload', 'chips'],
  },
  'support-ticket': {
    kind: 'form',
    accentColor: '#1d4ed8',
    backgroundStart: '#f6f9ff',
    backgroundEnd: '#eef4ff',
    cardRadius: 18,
    formWidth: 78,
    previewBanner: 'support',
    bannerImage: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1600&q=80',
    bannerAlt: 'Support ticket banner image',
    previewFields: ['select', 'textarea', 'upload', 'cta'],
  },
  'employee-pulse': {
    kind: 'form',
    accentColor: '#10b981',
    backgroundStart: '#f0fdf8',
    backgroundEnd: '#ecfdf3',
    cardRadius: 20,
    formWidth: 76,
    previewBanner: 'pulse',
    bannerImage: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1600&q=80',
    bannerAlt: 'Employee pulse banner image',
    previewFields: ['rating', 'choice', 'textarea', 'cta'],
  },
  contact: {
    kind: 'form',
    accentColor: '#ec4899',
    backgroundStart: '#fff7fb',
    backgroundEnd: '#fdf2f8',
    cardRadius: 22,
    formWidth: 74,
    previewBanner: 'contact',
    bannerImage: 'https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=1600&q=80',
    bannerAlt: 'Contact request banner image',
    previewFields: ['text', 'textarea', 'chips', 'cta'],
  },
  'job-application': {
    kind: 'form',
    accentColor: '#0f172a',
    backgroundStart: '#f8fafc',
    backgroundEnd: '#f1f5f9',
    cardRadius: 18,
    formWidth: 80,
    previewBanner: 'job',
    bannerImage: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=1600&q=80',
    bannerAlt: 'Job application banner image',
    previewFields: ['text', 'upload', 'date', 'cta'],
  },
  'order-request': {
    kind: 'form',
    accentColor: '#f59e0b',
    backgroundStart: '#fffbeb',
    backgroundEnd: '#fef3c7',
    cardRadius: 18,
    formWidth: 78,
    previewBanner: 'order',
    bannerImage: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=1600&q=80',
    bannerAlt: 'Order request banner image',
    previewFields: ['select', 'chips', 'textarea', 'cta'],
  },
  quiz: {
    kind: 'quiz',
    accentColor: '#7c3aed',
    backgroundStart: '#f5f3ff',
    backgroundEnd: '#ede9fe',
    cardRadius: 20,
    formWidth: 76,
    previewBanner: 'quiz',
    bannerImage: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=1600&q=80',
    bannerAlt: 'Quick quiz banner image',
    previewFields: ['choice', 'rating', 'textarea', 'cta'],
  },
  blank: {
    kind: 'form',
    accentColor: '#2563eb',
    backgroundStart: '#f8fbff',
    backgroundEnd: '#eef4ff',
    cardRadius: 18,
    formWidth: 80,
    previewBanner: 'blank',
    bannerImage: '',
    bannerAlt: '',
    previewFields: ['text', 'choice', 'cta'],
  },
};

function getTemplateCardConfig(templateId, mode = 'form') {
  return TEMPLATE_CARD_LIBRARY[templateId] || (mode === 'quiz' ? TEMPLATE_CARD_LIBRARY.quiz : TEMPLATE_CARD_LIBRARY.blank);
}

function renderTemplatePreviewMarkup(templateId, template) {
  const config = getTemplateCardConfig(templateId, template?.quizMode ? 'quiz' : 'form');
  const fieldMarkup = (config.previewFields || []).map((field) => {
    if (field === 'choice') return '<div class="template-mock-row"><span class="template-mock-circle"></span><span class="template-mock-line is-medium"></span></div><div class="template-mock-row"><span class="template-mock-circle"></span><span class="template-mock-line is-short"></span></div>';
    if (field === 'rating') return '<div class="template-mock-rating"><span></span><span></span><span></span><span></span><span></span></div>';
    if (field === 'textarea') return '<div class="template-mock-box is-tall"></div>';
    if (field === 'upload') return '<div class="template-mock-upload"><span class="template-mock-upload-icon"></span><span class="template-mock-line is-medium"></span></div>';
    if (field === 'date') return '<div class="template-mock-box is-compact"></div>';
    if (field === 'select') return '<div class="template-mock-box is-select"></div>';
    if (field === 'chips') return '<div class="template-mock-chips"><span></span><span></span><span></span></div>';
    if (field === 'cta') return '<div class="template-mock-actions"><span class="template-mock-button"></span></div>';
    return '<div class="template-mock-box"></div>';
  }).join('');

  const bannerStyle = config.bannerImage
    ? `style="background-image:linear-gradient(135deg,rgba(15,23,42,.20),rgba(15,23,42,.18)),url('${escapeAttribute(config.bannerImage)}');"`
    : `style="background-image:linear-gradient(135deg,rgba(191,219,254,.8),rgba(199,210,254,.8));"`;

  return `
    <div class="template-preview-shell template-preview-${escapeAttribute(config.previewBanner)}" style="--template-accent:${escapeAttribute(config.accentColor)}; --template-surface-start:${escapeAttribute(config.backgroundStart)}; --template-surface-end:${escapeAttribute(config.backgroundEnd)}; --template-radius:${escapeAttribute(String(config.cardRadius))}px; --template-width:${escapeAttribute(String(config.formWidth))}%">
      <div class="template-preview-banner" ${bannerStyle}>
        <div class="template-preview-banner-overlay"></div>
        <div class="template-preview-banner-copy">
          <span class="template-preview-badge">${template?.quizMode ? 'Quiz' : 'Form'}</span>
          <strong>${escapeHtml(template.title)}</strong>
          <small>${escapeHtml(template.description)}</small>
        </div>
      </div>
      <div class="template-preview-canvas">
        <div class="template-preview-card">
          <div class="template-preview-card-head">
            <span class="template-mock-heading is-wide"></span>
            <span class="template-mock-heading is-short"></span>
          </div>
          <div class="template-preview-card-body">${fieldMarkup}</div>
        </div>
      </div>
    </div>
  `.trim();
}

function renderTemplateShowcaseCard(template) {
  const config = getTemplateCardConfig(template.id, template.quizMode ? 'quiz' : 'form');
  return `
    <button type="button" class="forms-template-card forms-template-card-index-style ${state.templateId === template.id ? 'is-active' : ''}" data-action="apply-template" data-template-id="${template.id}" style="--template-accent:${escapeAttribute(config.accentColor)}; --template-surface-start:${escapeAttribute(config.backgroundStart)}; --template-surface-end:${escapeAttribute(config.backgroundEnd)}; --template-radius:${escapeAttribute(String(config.cardRadius))}px; --template-width:${escapeAttribute(String(config.formWidth))}%">
      <div class="forms-template-shot">${renderTemplatePreviewMarkup(template.id, template)}</div>
      <div class="forms-template-card-body-shell">
        <div class="forms-template-card-headline-row">
          <strong>${escapeHtml(template.title)}</strong>
          <span class="forms-template-card-kind">${template.quizMode ? 'Quiz' : 'Form'}</span>
        </div>
        <p>${escapeHtml(template.description)}</p>
        <div class="forms-template-tags">${template.tags.map((tag) => `<span class="forms-template-tag">${escapeHtml(tag)}</span>`).join('')}</div>
        <div class="forms-template-card-actions"><span class="forms-template-card-cta"><span>🪄</span><span>Use template</span></span></div>
      </div>
    </button>
  `;
}


function normalizeBranchRule(rule = {}) {
  const fallbackAction = rule.action || (rule.targetQuestionId ? 'show' : 'jump');
  const normalized = {
    operator: rule.operator || 'answered',
    value: typeof rule.value === 'undefined' ? '' : String(rule.value),
    action: ['jump', 'show', 'hide', 'require', 'optional'].includes(fallbackAction) ? fallbackAction : 'jump',
    target: typeof rule.target === 'string' && rule.target ? rule.target : '__next__',
    targetQuestionId: typeof rule.targetQuestionId === 'string' ? rule.targetQuestionId : '',
  };
  if (normalized.action !== 'jump') {
    if (!normalized.targetQuestionId && normalized.target && !normalized.target.startsWith('__')) {
      normalized.targetQuestionId = normalized.target;
    }
    normalized.target = '';
  }
  if (!shouldBranchRuleHaveValue(normalized.operator)) normalized.value = '';
  return normalized;
}

function shouldBranchRuleHaveValue(operator) {
  return !['answered', 'not_answered'].includes(String(operator || 'answered'));
}

function getBranchRuleOperatorOptions() {
  return [
    ['answered', 'Answered'],
    ['not_answered', 'Not answered'],
    ['equals', 'Equals'],
    ['not_equals', 'Does not equal'],
    ['contains', 'Contains'],
    ['greater_than', 'Greater than'],
    ['less_than', 'Less than'],
  ];
}

function getBranchRuleActionOptions() {
  return [
    ['jump', 'Jump to'],
    ['show', 'Show question'],
    ['hide', 'Hide question'],
    ['require', 'Make required'],
    ['optional', 'Make optional'],
  ];
}

function getBranchRuleTargetChoices(question, rule) {
  const targets = state.questions.filter((item) => item.type !== 'section' && item.questionId !== question.questionId);
  if ((rule.action || 'jump') === 'jump') {
    return [
      { value: '__next__', label: 'Next question' },
      { value: '__submit__', label: 'Submit form' },
      ...targets.map((target) => ({ value: target.questionId, label: target.title || 'Untitled question' })),
    ];
  }
  return targets.map((target) => ({ value: target.questionId, label: target.title || 'Untitled question' }));
}

function getBranchRuleTargetLabel(rule) {
  const normalizedRule = normalizeBranchRule(rule);
  if (normalizedRule.action === 'jump') {
    if (normalizedRule.target === '__next__') return 'next question';
    if (normalizedRule.target === '__submit__') return 'submit form';
    const targetQuestion = findQuestion(normalizedRule.target);
    return targetQuestion ? `“${targetQuestion.title || 'Untitled question'}”` : 'selected question';
  }
  const targetQuestion = findQuestion(normalizedRule.targetQuestionId);
  return targetQuestion ? `“${targetQuestion.title || 'Untitled question'}”` : 'selected question';
}

function describeBranchRule(rule, question = null) {
  const normalizedRule = normalizeBranchRule(rule);
  const actionLabels = {
    jump: 'Jump to',
    show: 'Show',
    hide: 'Hide',
    require: 'Require',
    optional: 'Make optional',
  };
  const operatorLabels = {
    answered: 'is answered',
    not_answered: 'is not answered',
    equals: `equals “${normalizedRule.value || '…'}”`,
    not_equals: `does not equal “${normalizedRule.value || '…'}”`,
    contains: `contains “${normalizedRule.value || '…'}”`,
    greater_than: `is greater than ${normalizedRule.value || '…'}`,
    less_than: `is less than ${normalizedRule.value || '…'}`,
  };
  const iconMap = {
    jump: '↪',
    show: '👁',
    hide: '🙈',
    require: '✳',
    optional: '◌',
  };
  const targetLabel = getBranchRuleTargetLabel(normalizedRule);
  const actionLabel = actionLabels[normalizedRule.action] || 'Jump to';
  const conditionLabel = operatorLabels[normalizedRule.operator] || operatorLabels.answered;
  const questionLabel = question ? `When “${question.title || 'Untitled question'}”` : 'When this answer';
  //${iconMap[normalizedRule.action] || '↪'} 
  return {
    marker: `${actionLabel} ${targetLabel}`,
    summary: `${questionLabel} ${conditionLabel}, ${actionLabel.toLowerCase()} ${targetLabel}.`,
    actionClass: normalizedRule.action || 'jump',
    actionLabel,
    conditionLabel,
    targetLabel,
    icon: iconMap[normalizedRule.action] || '↪',
  };
}



function renderLogicSidebar() {
  const logicQuestions = state.questions.filter((question) => question && question.type !== 'section' && Array.isArray(question.branchingRules) && question.branchingRules.length);
  if (!logicQuestions.length) {
    return `
      <aside class="forms-sidebar forms-logic-sidebar">
        <div class="forms-badge">Logic map</div>
        <h2>Automation preview</h2>
        <p class="forms-subtle">Add branching to any question and the editor will summarize what happens here.</p>
        <div class="forms-empty-state forms-logic-sidebar-empty">
          <strong>No logic rules yet</strong>
          <p>Create a rule to jump, show, hide, or change whether a later question is required.</p>
        </div>
      </aside>
    `;
  }
  return `
    <aside class="forms-sidebar forms-logic-sidebar">
      <div class="forms-badge">Logic map</div>
      <h2>Automation preview</h2>
      <p class="forms-subtle">A live summary of how answers change the respondent flow.</p>
      <div class="forms-logic-legend">
        ${getBranchRuleActionOptions().map(([action, label]) => `<span class="forms-logic-legend-item is-${action}">${escapeHtml(label)}</span>`).join('')}
      </div>
      <div class="forms-logic-groups">
        ${logicQuestions.map((question) => `
          <section class="forms-logic-group">
            <div class="forms-logic-node is-source" data-bs-toggle="collapse" href="#branch-${escapeAttribute(question.questionId)}">${escapeHtml(question.title || 'Untitled question')}</div>
            <div class="forms-logic-branches collapse" id="branch-${escapeAttribute(question.questionId)}">
              ${(question.branchingRules || []).map((rule) => {
                const info = describeBranchRule(rule, question);
                return `
                  <div class="forms-logic-branch is-${escapeAttribute(info.actionClass)}">
                    <div class="forms-logic-branch-condition">${escapeHtml(info.conditionLabel)}</div>
                    <div class="forms-logic-branch-arrow">→</div>
                    <div class="forms-logic-node is-${escapeAttribute(info.actionClass)}">${escapeHtml(info.actionLabel)} ${escapeHtml(info.targetLabel)}</div>
                  </div>
                `;
              }).join('')}
            </div>
          </section>
        `).join('')}
      </div>
    </aside>
  `;
}

  function renderEditorShell() {
    return `
    <div class="forms-editor-shell" style="--forms-accent:${escapeHtml(state.metadataStyles.accentColor)}; --forms-bg:${escapeHtml(state.metadataStyles.background.style)};">
      <main class="forms-center forms-center-wide">
        ${renderHeaderBanner('edit')}
        <section class="forms-card forms-center-header">
          <div class="forms-title-wrap">
            <div class="forms-question-type">
              <span class="forms-badge">${state.isQuiz ? t('apps.applications.forms.quiz', 'Quiz') : t('apps.applications.forms.form', 'Form')}</span>
              <span class="forms-pill">Form ID: ${escapeHtml(state.formId)}</span>
              <span class="forms-pill">${state.questions.filter((q) => q.type !== 'section').length} ${t('apps.applications.forms.' + (state.questions.filter((q) => q.type !== 'section').length === 1 ? 'question' : 'questions'), state.questions.filter((q) => q.type !== 'section').length === 1 ? 'question' : 'questions')}</span>
            </div>
            <input class="forms-title-input form-control" data-action="form-meta-field" data-field="title" value="${escapeHtml(state.title)}" ${state.editorMode ? '' : 'readonly'} aria-label="${t('apps.applications.forms.form_title', 'Form Title')}">
            <textarea class="forms-description-input form-control" data-action="form-meta-field" data-field="description" placeholder="${t('apps.applications.forms.form_description', 'Add a description')}" ${state.editorMode ? '' : 'readonly'}>${escapeHtml(state.description)}</textarea>
          </div>
        </section>

        <section class="forms-sticky-toolbar">
          <div class="forms-toolbar-group">
            ${['edit', 'preview', 'publish'].map((mode) => `
              <button type="button" class="forms-mode-btn ${state.mode === mode ? 'is-active' : ''}" data-action="set-mode" data-mode="${mode}">${capitalize(t('apps.applications.forms.' + mode, capitalize(mode)))}</button>
            `).join('')}
          </div>

          <div class="forms-toolbar-group">
            <div class="dropdown">
              <button type="button" class="forms-toolbar-btn dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">${t('apps.applications.forms.editor.add_block', 'Add block')}</button>
              <ul class="dropdown-menu forms-toolbar-dropdown">
                ${QUESTION_TYPES.map(([value, label]) => `
                  <li><button type="button" class="dropdown-item" data-action="add-question" data-type="${value}">+ ${escapeHtml(typeof label === 'function' ? label() : label)}</button></li>
                `).join('')}
              </ul>
            </div>
            <button type="button" class="forms-toolbar-btn ${state.templatesExpanded ? 'is-active' : ''}" data-bs-toggle="collapse" data-bs-target="#forms-templates-collapse" aria-expanded="${state.templatesExpanded ? 'true' : 'false'}" aria-controls="forms-templates-collapse">${t('apps.applications.forms.editor.templates', 'Templates')}</button>
            <button type="button" class="forms-toolbar-btn ${state.inspectorExpanded ? 'is-active' : ''}" data-bs-toggle="collapse" data-bs-target="#forms-inspector-collapse" aria-expanded="${state.inspectorExpanded ? 'true' : 'false'}" aria-controls="forms-inspector-collapse">${t('apps.applications.forms.editor.inspector', 'Inspector')}</button>
          </div>

          <div id="forms-save-status" class="forms-save-status">${t('apps.applications.forms.all_changes_saved', 'All changes saved')}</div>
        </section>

        <section id="forms-templates-collapse" class="collapse ${state.templatesExpanded ? 'show' : ''} forms-collapse-card" data-collapse-state="templates">
          <div class="forms-collapse-header">
            <div>
              <span class="forms-badge">${t('apps.applications.forms.editor.templates', 'Templates')}</span>
              <h2>${t('apps.applications.forms.editor.build_faster', 'Build faster')}</h2>
              <p class="forms-subtle">${t('apps.applications.forms.editor.templates_description', 'Apply starter layouts inspired by modern form builders.')}</p>
            </div>
          </div>
          <div class="forms-template-list forms-template-list-collapse">
            ${TEMPLATE_SHOWCASE_ORDER.map((templateId) => { const tpl = TEMPLATES.find((item) => item.id === templateId); return tpl ? renderTemplateShowcaseCard(tpl) : ''; }).join('')}
          </div>
        </section>

        <section id="forms-inspector-collapse" class="collapse ${state.inspectorExpanded ? 'show' : ''} forms-collapse-card" data-collapse-state="inspector">
          <div class="forms-collapse-header">
            <div>
              <span class="forms-badge">${t('apps.applications.forms.editor.inspector', 'Inspector')}</span>
              <h2>${t('apps.applications.forms.editor.tabs', 'Tabs')}</h2>
              <p class="forms-subtle">${t('apps.applications.forms.editor.inspector_description', 'Style, settings, preview, and responses live together here.')}</p>
            </div>
          </div>
          <div class="forms-panel-tabs">
            ${['style', 'settings', 'preview', 'responses'].map((tab) => `
              <button type="button" class="forms-tab ${state.activePanel === tab ? 'is-active' : ''}" data-action="set-panel" data-panel="${tab}">${capitalize(t('apps.applications.forms.panels.' + tab, capitalize(tab)))}</button>
            `).join('')}
          </div>
          ${renderPanelContent()}
        </section>

        <section class="forms-builder-list">
          ${state.questions.length ? state.questions.map((question, index) => renderQuestionCard(question, index)).join('') : `<div class="forms-empty-state"><h3>${t('apps.applications.forms.editor.no_questions', 'No questions yet')}</h3><p>${t('apps.applications.forms.editor.add_first_block', 'Add your first block to start building.')}</p></div>`}
        </section>
      </main>
      ${renderLogicSidebar()}
    </div>
    `;
  }

  function renderBlockPalette() {
    return `
      <section class="forms-card forms-blocks-card">
        <div class="forms-blocks-header">
          <div>
            <span class="forms-badge">${t('apps.applications.forms.editor.question_blocks', 'Question blocks')}</span>
            <h2>${t('apps.applications.forms.editor.add_blocks', 'Add blocks')}</h2>
            <p class="forms-subtle">${t('apps.applications.forms.editor.blocks_description', 'Insert blocks from a dedicated area so templates stay separate and easier to scan.')}</p>
          </div>
          <label class="forms-field-label forms-block-picker">
            ${t('apps.applications.forms.editor.block_picker_label', 'Quick add')}
            <select class="forms-select form-select" data-action="quick-add-question">
              <option value="">${t('apps.applications.forms.editor.choose_block', 'Choose a block…')}</option>
              ${QUESTION_TYPES.map(([value, label]) => `<option value="${value}">${escapeHtml(typeof label === 'function' ? label() : label)}</option>`).join('')}
            </select>
          </label>
        </div>
        <div class="forms-block-actions">
          ${QUESTION_TYPES.map(([value, label]) => `<button type="button" class="forms-toolbar-btn" data-action="add-question" data-type="${value}">+ ${escapeHtml(typeof label === 'function' ? label() : label)}</button>`).join('')}
        </div>
      </section>
    `;
  }

  function renderQuestionCard(question, index) {
  const labelFunc = QUESTION_TYPES.find(([value]) => value === question.type)?.[1];
  const typeLabel = typeof labelFunc === 'function' ? labelFunc() : (labelFunc || capitalize(question.type));
  const logicCount = Array.isArray(question.branchingRules) ? question.branchingRules.length : 0;

  return `
    <article class="forms-question-card ${question.type === 'section' ? 'is-section' : ''}" draggable="true" data-question-id="${question.questionId}">
      <div class="forms-question-head">
        <div class="forms-question-index" title="Drag to reorder">${question.type === 'section' ? '§' : index + 1}</div>
        <div>
          <div class="forms-question-type">
            <span class="forms-badge">${escapeHtml(typeLabel)}</span>
            ${question.required ? '<span class="forms-chip">Required</span>' : ''}
            ${question.branching ? `<span class="forms-chip forms-chip-logic">${logicCount} logic rule${logicCount === 1 ? '' : 's'}</span>` : ''}
            ${state.isQuiz && question.type !== 'section' ? `<span class="forms-pill">${Number(question.pointValue || 0)} pts</span>` : ''}
          </div>
          <input class="forms-input form-control" data-action="question-field" data-question-id="${question.questionId}" data-field="title" value="${escapeHtml(question.title)}" placeholder="Question title">
          <div class="forms-question-body">
            ${renderQuestionEditorBody(question, index)}
          </div>
        </div>
        <div class="forms-question-actions">
          <button type="button" class="forms-icon-btn" title="Move up" data-action="move-question" data-direction="up" data-question-id="${question.questionId}">↑</button>
          <button type="button" class="forms-icon-btn" title="Move down" data-action="move-question" data-direction="down" data-question-id="${question.questionId}">↓</button>
          <button type="button" class="forms-icon-btn" title="Copy" data-action="duplicate-question" data-question-id="${question.questionId}">⧉</button>
          <button type="button" class="forms-icon-btn" title="Delete" data-action="delete-question" data-question-id="${question.questionId}">✕</button>
          <div class="forms-dots-wrap">
            <button type="button" class="forms-icon-btn" title="Question menu" data-action="toggle-menu" data-question-id="${question.questionId}">⋯</button>
            ${state.openMenuId === question.questionId ? renderQuestionMenu(question) : ''}
          </div>
        </div>
      </div>
    </article>
  `;
}

  function renderQuestionMenu(question) {
    const textMenu = question.type === 'text' ? `
      <div class="forms-menu-item">
        <label>Restrictions</label>
        ${renderSwitch(question.restrictionEnabled, 'question-field', { questionId: question.questionId, field: 'restrictionEnabled' })}
      </div>
    ` : '';
    const shuffleMenu = (question.type === 'choice' || question.type === 'ranking') ? `
      <div class="forms-menu-item">
        <label>Shuffle options</label>
        ${renderSwitch(question.shuffle, 'question-field', { questionId: question.questionId, field: 'shuffle' })}
      </div>
    ` : '';
    const choiceMenu = question.type === 'choice' ? `
      <div class="forms-menu-item">
        <label>Multiple answers</label>
        ${renderSwitch(question.isMultiple, 'question-field', { questionId: question.questionId, field: 'isMultiple' })}
      </div>
      <div class="forms-menu-item">
        <label>Dropdown</label>
        ${renderSwitch(question.isDropdown && !question.isMultiple, 'question-field', { questionId: question.questionId, field: 'isDropdown', disabled: question.isMultiple ? '1' : '' })}
      </div>
    ` : '';
    return `
      <div class="forms-dots-menu">
        <div class="forms-menu-item">
          <label>Required</label>
          ${renderSwitch(question.required, 'question-field', { questionId: question.questionId, field: 'required', disabled: question.type === 'section' ? '1' : '' })}
        </div>
        <div class="forms-menu-item">
          <label>Subtitle</label>
          ${renderSwitch(!!question.subtitle, 'toggle-optional-text', { questionId: question.questionId, field: 'subtitle' })}
        </div>
        ${textMenu}
        ${shuffleMenu}
        ${choiceMenu}
        <div class="forms-menu-item">
          <label>Branching</label>
          ${renderSwitch(question.branching, 'question-field', { questionId: question.questionId, field: 'branching', disabled: question.type === 'section' ? '1' : '' })}
        </div>
        <button type="button" class="forms-toolbar-btn" data-action="close-menu">Close</button>
      </div>
    `;
  }

  function renderSwitch(checked, action, attrs = {}) {
    const attrString = Object.entries(attrs).map(([key, value]) => `data-${camelToKebab(key)}="${escapeHtml(String(value))}"`).join(' ');
    return `
      <button type="button" class="forms-switch ${checked ? 'is-on' : ''} ${attrs.disabled === '1' ? 'is-disabled' : ''}" ${attrs.disabled === '1' ? 'disabled' : ''} data-action="${action}" ${attrString} aria-pressed="${checked ? 'true' : 'false'}">
        <span class="forms-switch-track"><span class="forms-switch-thumb"></span></span>
      </button>
    `;
  }


  function renderChoiceAnswerKeyEditor(question) {
    if (!state.isQuiz) return '';
    return `
      <div class="forms-answer-key-box">
        <div class="forms-inline-banner"><strong>Answer key</strong> &middot; Select the correct answer${question.isMultiple ? 's' : ''} for automatic scoring.</div>
        <div class="forms-answer-key-list">
          ${question.options.map((option, index) => `
            <label class="forms-choice-pill form-check">
              <input class="form-check-input" type="checkbox" data-action="choice-answer-key" data-question-id="${question.questionId}" value="${escapeAttribute(option)}" ${Array.isArray(question.correctAnswers) && question.correctAnswers.includes(option) ? 'checked' : ''}>
              <span class="form-check-label">${escapeHtml(option || `Option ${index + 1}`)}</span>
            </label>
          `).join('') || '<div class="forms-subtle">Add options to set the answer key.</div>'}
        </div>
      </div>
    `;
  }

  function renderTextAnswerKeyEditor(question) {
    if (!state.isQuiz) return '';
    return `
      <div class="forms-answer-key-box">
        <div class="forms-inline-banner"><strong>Accepted answers</strong> &middot; Enter one acceptable answer per line for automatic scoring.</div>
        <label class="forms-field-label">Accepted answers
          <textarea class="forms-textarea form-control" data-action="text-answer-key" data-question-id="${question.questionId}" placeholder="One accepted answer per line">${escapeHtml((question.acceptedAnswers || []).join('\n'))}</textarea>
        </label>
        <span class="forms-field-help">Matching is case-insensitive and trims extra spaces.</span>
      </div>
    `;
  }

  function renderQuestionEditorBody(question, index) {
    if (question.type === 'section') {
      return `
        <label class="forms-field-label">Section description
          <textarea class="forms-textarea form-control" data-action="question-field" data-question-id="${question.questionId}" data-field="description" placeholder="Section description">${question.description ? escapeHtml(question.description) : ''}</textarea>
        </label>
        ${renderMediaEditor(question)}
      `;
    }
    const common = `
      ${question.subtitle !== false ? `<label class="forms-field-label">Subtitle
        <input class="forms-input form-control" data-action="question-field" data-question-id="${question.questionId}" data-field="subtitle" value="${escapeHtml(question.subtitle || '')}" placeholder="Helpful context for respondents">
      </label>` : ''}
      <label class="forms-field-label">Description
        <textarea class="forms-textarea form-control" data-action="question-field" data-question-id="${question.questionId}" data-field="description" placeholder="Description or help text">${question.description ? escapeHtml(question.description) : ''}</textarea>
      </label>
      ${renderMediaEditor(question)}
      <div class="forms-grid-2">
        <div class="forms-setting-row">
          <div class="forms-setting-copy"><h4>Required</h4><p>Respondents must answer before continuing.</p></div>
          ${renderSwitch(question.required, 'question-field', { questionId: question.questionId, field: 'required' })}
        </div>
        ${state.isQuiz ? `<label class="forms-field-label">Points
          <input class="forms-input form-control" type="number" min="0" step="1" data-action="question-field" data-question-id="${question.questionId}" data-field="pointValue" value="${escapeHtml(String(question.pointValue || 0))}">
        </label>` : ''}
      </div>
      ${question.branching ? renderBranchingEditor(question) : ''}
    `;

    switch (question.type) {
      case 'choice':
        return `${renderChoiceEditor(question)}${common}`;
      case 'text':
        return `${renderTextEditor(question)}${common}`;
      case 'rating':
        return `${renderRatingEditor(question)}${common}`;
      case 'date':
        return `${renderDateEditor(question)}${common}`;
      case 'ranking':
        return `${renderRankingEditor(question)}${common}`;
      case 'likert':
        return `${renderLikertEditor(question)}${common}`;
      case 'upload':
        return `${renderUploadEditor(question)}${common}`;
      case 'nps':
        return `${renderNpsEditor(question)}${common}`;
      default:
        return common;
    }
  }

  function renderMediaEditor(question) {
    return `
      <div class="forms-media-panel">
        <div class="forms-inline-banner"><strong>Media</strong> &middot; Add an image, video, or audio URL to this question.</div>
        <div class="forms-grid-3">
          <label class="forms-field-label">Media type
            <select class="forms-select form-select" data-action="question-field" data-question-id="${question.questionId}" data-field="mediaType">
              ${['image', 'video', 'audio'].map((type) => `<option value="${type}" ${question.mediaType === type ? 'selected' : ''}>${capitalize(type)}</option>`).join('')}
            </select>
          </label>
          <label class="forms-field-label" style="grid-column: span 2;">Media URL
            <input class="forms-input form-control" data-action="question-field" data-question-id="${question.questionId}" data-field="mediaUrl" value="${escapeHtml(question.mediaUrl || '')}" placeholder="https://...">
          </label>
        </div>
        <label class="forms-field-label">Alt text / caption
          <input class="forms-input form-control" data-action="question-field" data-question-id="${question.questionId}" data-field="mediaAlt" value="${escapeHtml(question.mediaAlt || '')}" placeholder="Describe the media">
        </label>
      </div>
    `;
  }

  function renderChoiceEditor(question) {
    return `
      <div class="forms-inline-banner"><strong>Choice options</strong> &middot; Use drag & drop, arrows, copy, or delete.</div>
      <div class="forms-option-list">
        ${question.options.map((option, index) => renderOptionRow(question.questionId, option, index, 'options')).join('')}
      </div>
      <div class="forms-add-row">
        <button type="button" class="forms-toolbar-btn" data-action="add-option" data-question-id="${question.questionId}" data-collection="options">+ Add option</button>
      </div>
      ${renderChoiceAnswerKeyEditor(question)}
    `;
  }

  function renderTextEditor(question) {
    return `
      <div class="forms-grid-3">
        <label class="forms-field-label">Response type
          <select class="forms-select form-select" data-action="question-field" data-question-id="${question.questionId}" data-field="textMode">
            <option value="short" ${question.textMode === 'short' ? 'selected' : ''}>Short answer</option>
            <option value="long" ${question.textMode === 'long' ? 'selected' : ''}>Long answer</option>
          </select>
        </label>
        <label class="forms-field-label">Restriction type
          <select class="forms-select form-select" data-action="question-field" data-question-id="${question.questionId}" data-field="restrictionType">
            ${['text', 'email', 'number', 'length', 'regex'].map((type) => `<option value="${type}" ${question.restrictionType === type ? 'selected' : ''}>${capitalize(type)}</option>`).join('')}
          </select>
        </label>
        <label class="forms-field-label">Operator
          <select class="forms-select form-select" data-action="question-field" data-question-id="${question.questionId}" data-field="restrictionOperator">
            ${[
              ['','None'], ['valid','Valid'], ['equals','Equals'], ['contains','Contains'], ['min','Minimum'], ['max','Maximum'], ['between','Between'], ['pattern','Pattern']
            ].map(([value, label]) => `<option value="${value}" ${question.restrictionOperator === value ? 'selected' : ''}>${escapeHtml(label)}</option>`).join('')}
          </select>
        </label>
      </div>
      <div class="forms-grid-2">
        <label class="forms-field-label">Primary value
          <input class="forms-input form-control" data-action="question-field" data-question-id="${question.questionId}" data-field="restrictionValue" value="${escapeHtml(question.restrictionValue || '')}" placeholder="Example: 5, ^[A-Z], etc.">
        </label>
        <label class="forms-field-label">Secondary value
          <input class="forms-input form-control" data-action="question-field" data-question-id="${question.questionId}" data-field="restrictionValueSecondary" value="${escapeHtml(question.restrictionValueSecondary || '')}" placeholder="Used for Between">
        </label>
      </div>
      ${renderTextAnswerKeyEditor(question)}
    `;
  }

  function renderRatingEditor(question) {
    return `
      <div class="forms-grid-3">
        <label class="forms-field-label">Scale max
          <input class="forms-input form-control" type="number" min="3" max="10" data-action="question-field" data-question-id="${question.questionId}" data-field="maxRating" value="${escapeHtml(String(question.maxRating || 5))}">
        </label>
      </div>
    `;
  }

  function renderDateEditor(question) {
    return `
      <div class="forms-inline-banner"><strong>Date question</strong> &middot; Validation checks the required state and any active time window.</div>
    `;
  }

  function renderRankingEditor(question) {
    return `
      <div class="forms-inline-banner"><strong>Ranking items</strong> &middot; Respondents drag items into their preferred order.</div>
      <div class="forms-ranking-list">
        ${question.options.map((option, index) => renderOptionRow(question.questionId, option, index, 'options')).join('')}
      </div>
      <div class="forms-add-row"><button type="button" class="forms-toolbar-btn" data-action="add-option" data-question-id="${question.questionId}" data-collection="options">+ Add item</button></div>
    `;
  }

  function renderLikertEditor(question) {
    return `
      <div class="forms-grid-2">
        <div>
          <div class="forms-inline-banner"><strong>Statements</strong></div>
          <div class="forms-option-list">
            ${question.statements.map((statement, index) => renderOptionRow(question.questionId, statement, index, 'statements')).join('')}
          </div>
          <div class="forms-add-row"><button type="button" class="forms-toolbar-btn" data-action="add-option" data-question-id="${question.questionId}" data-collection="statements">+ Add statement</button></div>
        </div>
        <div>
          <div class="forms-inline-banner"><strong>Scale columns</strong></div>
          <div class="forms-option-list">
            ${question.columns.map((column, index) => renderOptionRow(question.questionId, column, index, 'columns')).join('')}
          </div>
          <div class="forms-add-row"><button type="button" class="forms-toolbar-btn" data-action="add-option" data-question-id="${question.questionId}" data-collection="columns">+ Add column</button></div>
        </div>
      </div>
    `;
  }

  function renderUploadEditor(question) {
    return `
      <div class="forms-upload-settings">
        <div class="forms-grid-2">
          <label class="forms-field-label">Accepted file types
            <input class="forms-input form-control" data-action="question-field" data-question-id="${question.questionId}" data-field="fileAccept" value="${escapeHtml(question.fileAccept || '')}" placeholder=".pdf,.docx,.png">
          </label>
          <label class="forms-field-label">Maximum file size
            <select class="forms-select form-select" data-action="question-field" data-question-id="${question.questionId}" data-field="fileMaxSize">
              ${FILE_SIZE_PRESETS.map((preset) => `<option value="${escapeAttribute(preset.value)}" ${String(question.fileMaxSize || '') === preset.value ? 'selected' : ''}>${escapeHtml(preset.label)}</option>`).join('')}
            </select>
          </label>
        </div>
        <div class="forms-grid-2">
          <div class="forms-setting-row">
            <div class="forms-setting-copy"><h4>Allow multiple files</h4><p>Respondents can attach more than one file.</p></div>
            ${renderSwitch(question.multipleFiles, 'question-field', { questionId: question.questionId, field: 'multipleFiles' })}
          </div>
          <div class="forms-inline-banner"><strong>Size enforcement</strong> &middot; The selected limit is checked when respondents click Next or Submit.</div>
        </div>
      </div>
    `;
  }

  function renderNpsEditor(question) {
    return `
      <div class="forms-grid-2">
        <label class="forms-field-label">Min label
          <input class="forms-input form-control" data-action="question-field" data-question-id="${question.questionId}" data-field="minLabel" value="${escapeHtml(question.minLabel || '')}" placeholder="Not likely">
        </label>
        <label class="forms-field-label">Max label
          <input class="forms-input form-control" data-action="question-field" data-question-id="${question.questionId}" data-field="maxLabel" value="${escapeHtml(question.maxLabel || '')}" placeholder="Very likely">
        </label>
      </div>
    `;
  }

  function renderBranchingEditor(question) {
  return `
    <div class="forms-inline-banner"><strong>Logic rules</strong> &middot; Jump, show or hide a later question, or change whether it is required.</div>
    <div class="forms-branch-list">
      ${(question.branchingRules || []).map((rawRule, index) => {
        const rule = normalizeBranchRule(rawRule);
        const targetChoices = getBranchRuleTargetChoices(question, rule);
        const info = describeBranchRule(rule, question);
        return `
          <div class="forms-branch-rule is-${escapeAttribute(info.actionClass)}">
            <div class="forms-branch-summary">
              
              <span class="forms-subtle">${escapeHtml(info.summary)}</span>
            </div>
            <div class="forms-branch-grid">
              <label class="forms-field-label">When answer
                <select class="forms-select form-select" data-action="branch-rule-field" data-question-id="${question.questionId}" data-index="${index}" data-field="operator">
                  ${getBranchRuleOperatorOptions().map(([op, label]) => `<option value="${op}" ${rule.operator === op ? 'selected' : ''}>${escapeHtml(label)}</option>`).join('')}
                </select>
              </label>
              <label class="forms-field-label ${shouldBranchRuleHaveValue(rule.operator) ? '' : 'is-disabled'}">Value
                <input class="forms-input form-control" data-action="branch-rule-field" data-question-id="${question.questionId}" data-index="${index}" data-field="value" value="${escapeHtml(rule.value || '')}" placeholder="Match value" ${shouldBranchRuleHaveValue(rule.operator) ? '' : 'disabled'}>
              </label>
            </div>
            <div class="forms-branch-grid">
              <label class="forms-field-label">Do this
                <select class="forms-select form-select" data-action="branch-rule-field" data-question-id="${question.questionId}" data-index="${index}" data-field="action">
                  ${getBranchRuleActionOptions().map(([value, label]) => `<option value="${value}" ${rule.action === value ? 'selected' : ''}>${escapeHtml(label)}</option>`).join('')}
                </select>
              </label>
              <label class="forms-field-label">Target
                <select class="forms-select form-select" data-action="branch-rule-field" data-question-id="${question.questionId}" data-index="${index}" data-field="${rule.action === 'jump' ? 'target' : 'targetQuestionId'}">
                  ${targetChoices.length ? targetChoices.map((target) => `<option value="${target.value}" ${(rule.action === 'jump' ? rule.target : rule.targetQuestionId) === target.value ? 'selected' : ''}>${escapeHtml(target.label)}</option>`).join('') : '<option value="">No target questions available</option>'}
                </select>
              </label>
            </div>
            <div class="forms-logic-inline-diagram">
              <div class="forms-logic-node is-source">${escapeHtml(question.title || 'Untitled question')}</div>
              <div class="forms-logic-branch-arrow">→</div>
              <div class="forms-logic-node is-${escapeAttribute(info.actionClass)}">${escapeHtml(info.actionLabel)} ${escapeHtml(info.targetLabel)}</div>
            </div>
            <div class="forms-add-row">
              <button type="button" class="forms-icon-btn" data-action="delete-branch-rule" data-question-id="${question.questionId}" data-index="${index}">✕</button>
            </div>
          </div>
        `;
      }).join('')}
      <div><button type="button" class="forms-toolbar-btn" data-action="add-branch-rule" data-question-id="${question.questionId}">+ Add logic rule</button></div>
    </div>
  `;
}

  function renderOptionRow(questionId, value, index, collection) {
    return `
      <div class="forms-option-row" draggable="true" data-option-drag="1" data-question-id="${questionId}" data-index="${index}" data-collection="${collection}">
        <button type="button" class="forms-option-handle" title="Drag">⋮⋮</button>
        <input class="forms-input form-control" data-action="option-field" data-question-id="${questionId}" data-index="${index}" data-collection="${collection}" value="${escapeHtml(value)}" placeholder="Item ${index + 1}">
        <div style="display:flex; gap:8px;">
          <button type="button" class="forms-icon-btn" data-action="move-option" data-question-id="${questionId}" data-index="${index}" data-collection="${collection}" data-direction="up">↑</button>
          <button type="button" class="forms-icon-btn" data-action="move-option" data-question-id="${questionId}" data-index="${index}" data-collection="${collection}" data-direction="down">↓</button>
          <button type="button" class="forms-icon-btn" data-action="copy-option" data-question-id="${questionId}" data-index="${index}" data-collection="${collection}">⧉</button>
          <button type="button" class="forms-icon-btn" data-action="delete-option" data-question-id="${questionId}" data-index="${index}" data-collection="${collection}">✕</button>
        </div>
      </div>
    `;
  }

  function renderPanelContent() {
    switch (state.activePanel) {
      case 'style':
        return renderStylePanel();
      case 'settings':
        return renderSettingsPanel();
      case 'preview':
        return renderPreviewPanel();
      case 'responses':
        return renderResponsesPanel();
      default:
        return '';
    }
  }

  function renderStylePanel() {
    return `
      <div class="forms-panel-section">
        <label class="forms-field-label">Accent color
          <input class="forms-input form-control form-control-color" type="color" data-action="style-field" data-group="metadataStyles" data-path="accentColor" value="${escapeHtml(state.metadataStyles.accentColor || '#2563eb')}">
        </label>
        <div class="forms-inline-banner"><strong>Background gradient</strong> · Pick the start color, end color, and direction. The middle gradient stop is generated automatically.</div>
        <div class="forms-grid-2">
          <label class="forms-field-label">Start color
            <input class="forms-input form-control form-control-color" type="color" data-action="style-field" data-group="metadataStyles" data-path="background.startColor" value="${escapeHtml(state.metadataStyles.background.startColor || '#f5f8fc')}">
          </label>
          <label class="forms-field-label">End color
            <input class="forms-input form-control form-control-color" type="color" data-action="style-field" data-group="metadataStyles" data-path="background.endColor" value="${escapeHtml(state.metadataStyles.background.endColor || '#f7f9fd')}">
          </label>
        </div>
        <label class="forms-field-label">Direction
          <select class="forms-select form-select" data-action="style-field" data-group="metadataStyles" data-path="background.direction">
            ${[
              ['180deg', 'Top to bottom'],
              ['0deg', 'Bottom to top'],
              ['90deg', 'Left to right'],
              ['270deg', 'Right to left'],
              ['135deg', 'Top left to bottom right'],
              ['45deg', 'Bottom left to top right'],
            ].map(([value, label]) => `<option value="${value}" ${state.metadataStyles.background.direction === value ? 'selected' : ''}>${escapeHtml(label)}</option>`).join('')}
          </select>
          <span class="forms-field-help">Current CSS: ${escapeHtml(state.metadataStyles.background.style || '')}</span>
        </label>

<div class="forms-inline-banner"><strong>Header banner</strong> · Manage the card header media here instead of attaching it to a question.</div>
<div class="forms-setting-row">
  <div class="forms-setting-copy"><h4>Enable header banner</h4><p>Show a dedicated media banner above the form card header.</p></div>
  ${renderSwitch(!!state.metadataStyles.headerBanner.enable, 'style-toggle', { group: 'metadataStyles', path: 'headerBanner.enable' })}
</div>
<div class="forms-grid-3">
  <label class="forms-field-label">Banner type
    <select class="forms-select form-select" data-action="style-field" data-group="metadataStyles" data-path="headerBanner.type">
      <option value="image" ${state.metadataStyles.headerBanner.type === 'image' ? 'selected' : ''}>Image</option>
      <option value="video" ${state.metadataStyles.headerBanner.type === 'video' ? 'selected' : ''}>Video</option>
      <option value="audio" ${state.metadataStyles.headerBanner.type === 'audio' ? 'selected' : ''}>Audio</option>
    </select>
  </label>
  <label class="forms-field-label" style="grid-column: span 2;">Banner URL
    <input class="forms-input form-control" data-action="style-field" data-group="metadataStyles" data-path="headerBanner.src" value="${escapeHtml(state.metadataStyles.headerBanner.src || '')}" placeholder="https://...">
  </label>
</div>
<label class="forms-field-label">Banner alt text / caption
  <input class="forms-input form-control" data-action="style-field" data-group="metadataStyles" data-path="headerBanner.alt" value="${escapeHtml(state.metadataStyles.headerBanner.alt || '')}" placeholder="Describe the banner media">
</label>
        <div class="forms-grid-2">
          <label class="forms-field-label">Card radius
            <input class="forms-input form-control" type="number" min="8" max="32" data-action="style-field" data-group="metadataStyles" data-path="cardRadius" value="${escapeHtml(String(state.metadataStyles.cardRadius || 18))}">
          </label>
          <label class="forms-field-label">Form width (%)
            <input class="forms-input form-control" type="number" min="60" max="100" data-action="style-field" data-group="metadataStyles" data-path="formWidth" value="${escapeHtml(String(state.metadataStyles.formWidth || 80))}">
          </label>
        </div>
        <div class="forms-setting-row">
          <div class="forms-setting-copy"><h4>Background music</h4><p>Optional audio URL for publish mode.</p></div>
          ${renderSwitch(!!state.metadataStyles.backgroundMusic.enable, 'style-toggle', { group: 'metadataStyles', path: 'backgroundMusic.enable' })}
        </div>
        <label class="forms-field-label">Background music source
          <input class="forms-input form-control" data-action="style-field" data-group="metadataStyles" data-path="backgroundMusic.src" value="${escapeHtml(state.metadataStyles.backgroundMusic.src || '')}" placeholder="https://...">
        </label>
      </div>
    `;
  }

  function renderSettingsPanel() {
    const durationLocked = isDurationLockedByEndDate();
    const scheduledDuration = getScheduledDurationMinutes();
    const durationHelp = durationLocked
        ? t('apps.applications.forms.editor_i18n.duration_help_locked', 'Calculated automatically from the start and end dates ({minutes} minute{suffix}).').replace('{minutes}', String(scheduledDuration ?? 0)).replace('{suffix}', scheduledDuration === 1 ? '' : t('plural', 's'))
        : t('apps.applications.forms.editor_i18n.duration_help_editable', 'Leave the end date empty to keep this value editable.');

    return `
      <div class="forms-panel-section">
        <div class="forms-setting-row">
          <div class="forms-setting-copy"><h4>Quiz mode</h4><p>Show points for each question and save as quiz metadata.</p></div>
          ${renderSwitch(state.isQuiz, 'toggle-quiz')}
        </div>
        <label class="forms-field-label">Who can fill
          <select class="forms-select form-select" data-action="settings-field" data-path="who_can_fill">
            <option value="logged_in" ${state.metadataSettings.who_can_fill === 'logged_in' ? 'selected' : ''}>Logged in users</option>
            <option value="anyone" ${state.metadataSettings.who_can_fill === 'anyone' ? 'selected' : ''}>Anyone with the link</option>
            <option value="organization" ${state.metadataSettings.who_can_fill === 'organization' ? 'selected' : ''}>Organization only</option>
          </select>
        </label>
        ${[
          ['accepted_responses.enabled', 'Accept responses', 'Turn submissions on or off.'],
          ['shuffle_questions.enabled', 'Shuffle questions', 'Randomize question order for respondents.'],
          ['disable_question_number_for_respondents.enabled', 'Hide question numbers', 'Publish without numbering prompts.'],
          ['show_progress_bar.enabled', 'Show progress bar', 'Display progress across section pages.'],
          ['hide_submit_another_response.enabled', 'Hide re-submit', 'Hide submit another response action after completion.'],
          ['allow_respondents_to_save_their_responses.enable', 'Allow save progress', 'Respondents can return later.'],
          ['allow_respondents_to_edit_their_responses.enable', 'Allow edit responses', 'Respondents can update submitted answers.'],
          ['allow_receipt_of_responses_after_submission.enable', 'Send receipt after submit', 'Store a receipt preference in settings.'],
          ['get_email_notification_of_each_response.enable', 'Notify on each response', 'Store email notification preference.'],
          ['showRequiredAsterisk', 'Show required asterisk', 'Display the required indicator in publish mode.', 'ui'],
          ['show_score_in_thank_you.enabled', 'Show score in thank you section', 'Display the quiz score after submission in the thank you section.'],
        ].map(([path, title, copy, domain]) => renderSettingToggle(path, title, copy, domain || 'settings')).join('')}
        <div class="forms-grid-2">
          <label class="forms-field-label">Start date
            <input class="forms-input form-control" type="datetime-local" data-action="settings-field" data-path="start_date.datetime" value="${escapeHtml(toDatetimeLocal(state.metadataSettings.start_date.datetime || ''))}">
          </label>
          <label class="forms-field-label">End date
            <input class="forms-input form-control" type="datetime-local" data-action="settings-field" data-path="end_date.datetime" value="${escapeHtml(toDatetimeLocal(state.metadataSettings.end_date.datetime || ''))}">
          </label>
        </div>
        <label class="forms-field-label">Time duration (minutes)
          <input class="forms-input form-control" type="number" min="0" step="1" data-action="settings-field" data-path="time_duration.minutes" value="${escapeHtml(String(state.metadataSettings.time_duration.minutes ?? 0))}" ${durationLocked ? 'disabled' : ''}>
          <span class="forms-field-help">${escapeHtml(durationHelp)}</span>
        </label>
        <label class="forms-field-label">Text answer similarity threshold (%)
          <input class="forms-input form-control" type="number" min="0" max="100" step="1" data-action="settings-field" data-path="text_similarity_leniency.percent" value="${escapeHtml(String(state.metadataSettings.text_similarity_leniency?.percent ?? '70'))}" placeholder="70">
          <span class="forms-field-help">Used for both short and long text quiz answers. Leave blank to use the default of 70%.</span>
        </label>
        <label class="forms-field-label">Submit button label
          <input class="forms-input form-control" data-action="ui-field" data-path="submitLabel" value="${escapeHtml(state.metadataUi.submitLabel || 'Submit')}">
        </label>
        <label class="forms-field-label">Publish mode label
          <input class="forms-input form-control" data-action="ui-field" data-path="publishModeLabel" value="${escapeHtml(state.metadataUi.publishModeLabel || 'Publish')}">
        </label>
        <label class="forms-field-label">Thank you title
          <input class="forms-input form-control" data-action="ui-field" data-path="thankYouTitle" value="${escapeHtml(state.metadataUi.thankYouTitle || 'Response submitted')}">
        </label>
        <label class="forms-field-label">Thank you message
          <textarea class="forms-textarea form-control" data-action="settings-field" data-path="customize_thank_you_message.message">${escapeHtml(state.metadataSettings.customize_thank_you_message.message || '')}</textarea>
        </label>
      </div>
    `;
  }

  function renderSettingToggle(path, title, copy, domain = 'settings') {
    const value = domain === 'ui' ? getPath(state.metadataUi, path) : getPath(state.metadataSettings, path);
    return `
      <div class="forms-setting-row">
        <div class="forms-setting-copy"><h4>${escapeHtml(title)}</h4><p>${escapeHtml(copy)}</p></div>
        ${renderSwitch(!!value, domain === 'ui' ? 'ui-toggle' : 'settings-toggle', { path })}
      </div>
    `;
  }

  function onResponsePage(event) {
    const direction = event.currentTarget.dataset.direction;
    if (direction === 'prev') {
      state.responsePageIndex = Math.max(0, Number(state.responsePageIndex || 0) - 1);
    } else {
      state.responsePageIndex = Math.min(
        Math.max(state.responses.length - 1, 0),
        Number(state.responsePageIndex || 0) + 1
      );
    }
    render();
  }

  function renderPreviewPanel() {
    const totalPages = getPublishSections().sections.length;
    return `
      <div class="forms-panel-section">
        <div class="forms-preview-banner"><strong>Preview summary</strong> &middot; ${totalPages} page${totalPages === 1 ? '' : 's'} when published.</div>
        <div class="forms-metrics-grid">
          <div class="forms-metric-card"><h4>Questions</h4><strong>${state.questions.filter((q) => q.type !== 'section').length}</strong></div>
          <div class="forms-metric-card"><h4>Responses</h4><strong>${state.responses.length}</strong></div>
          <div class="forms-metric-card"><h4>Required</h4><strong>${state.questions.filter((q) => q.required).length}</strong></div>
          <div class="forms-metric-card"><h4>Quiz points</h4><strong>${state.isQuiz ? state.questions.reduce((sum, q) => sum + (q.type === 'section' ? 0 : Number(q.pointValue || 0)), 0) : 0}</strong></div>
        </div>
        <div class="forms-inline-banner">Preview uses the same validation, branching, progress, and section pagination as publish mode.</div>
        <button type="button" class="forms-primary-btn" data-action="set-mode" data-mode="preview">Open interactive preview</button>
      </div>
    `;
  }

  function renderResponsesPanel() {
    const metrics = summarizeResponses();
    const totalPages = Math.max(state.responses.length, 1);
    const safeIndex = Math.min(Math.max(Number(state.responsePageIndex || 0), 0), totalPages - 1);
    state.responsePageIndex = safeIndex;
    const currentResponse = state.responses[safeIndex] || null;

    return `
      <div class="forms-panel-section">
        <div class="forms-metrics-grid">
          <div class="forms-metric-card"><h4>Total responses</h4><strong>${metrics.count}</strong></div>
          <div class="forms-metric-card"><h4>Latest</h4><strong>${escapeHtml(metrics.latest || '—')}</strong></div>
        </div>

        <div class="forms-response-list">
          ${currentResponse
            ? renderResponseCard(currentResponse, safeIndex)
            : `<div class="forms-empty-state"><h3>No responses yet</h3><p>Responses will appear here as soon as somebody submits the form.</p></div>`}
        </div>

        ${state.responses.length ? `
          <div class="forms-response-pagination">
            <button type="button" class="forms-secondary-btn" data-action="response-page" data-direction="prev" ${safeIndex <= 0 ? 'disabled' : ''}>Previous</button>
            <span class="forms-pill">${safeIndex + 1} / ${totalPages}</span>
            <button type="button" class="forms-secondary-btn" data-action="response-page" data-direction="next" ${safeIndex >= totalPages - 1 ? 'disabled' : ''}>Next</button>
          </div>` : ''}
      </div>
    `;
  }

  function renderResponseCard(response, index) {
    const responseId = response.id;
    const gradeOverrides = response.gradeOverrides || {};
    const recalculatedScore = calculateResponseScore(response, gradeOverrides);
    const originalScore = response.score;
    
    return `
      <article class="forms-response-item">
        <div class="forms-response-head">
          <strong>Response ${index + 1}</strong>
          <span class="forms-pill">${escapeHtml(formatDateTime(response.timestamp))}</span>
          ${recalculatedScore ? `
            <span class="forms-pill ${Object.keys(gradeOverrides).length > 0 ? 'forms-pill-edited' : ''}">
              Score: ${escapeHtml(String(recalculatedScore.earned))}/${escapeHtml(String(recalculatedScore.possible))}
              ${originalScore && (recalculatedScore.earned !== originalScore.earned) ? `<span class="forms-subtle"> (was: ${originalScore.earned})</span>` : ''}
            </span>
          ` : ''}
          ${state.editorMode && state.isQuiz ? `<button type="button" class="forms-subtle-btn" data-action="toggle-response-editor" data-response-id="${escapeAttribute(responseId)}">Edit grades</button>` : ''}
        </div>
        ${(response.answers || []).map((answer) => {
          const question = state.questions.find((item) => item.questionId === answer.questionId);
          const isQuizQuestion = state.isQuiz && question && question.type !== 'section';
          const override = gradeOverrides[answer.questionId];
          const autoGraded = isQuizQuestion ? isCorrectAnswer(question, answer.answers[0]) : null;
          const isMarkedCorrect = override !== undefined ? override : autoGraded;
          
          return `
            <div class="forms-response-answer ${state.editorMode && isQuizQuestion ? 'forms-response-answer-editable' : ''}">
              <div style="display:flex; justify-content:space-between; align-items:flex-start;">
                <div style="flex:1;">
                  <strong>${escapeHtml(question ? question.title : answer.questionId)}</strong>
                  <div class="forms-response-value-wrap">${renderResponseAnswerValues(answer.answers || [])}</div>
                </div>
                ${state.editorMode && isQuizQuestion ? `
                  <div style="display:flex; gap:8px; margin-left:12px; flex-shrink:0;">
                    <button type="button" 
                      class="forms-grade-toggle ${isMarkedCorrect ? 'is-correct' : ''}" 
                      data-action="toggle-answer-grade" 
                      data-response-id="${escapeAttribute(responseId)}" 
                      data-question-id="${escapeAttribute(answer.questionId)}"
                      data-grade="correct"
                      title="Mark as correct">
                      ${isMarkedCorrect ? '✓' : '○'} Correct
                    </button>
                    <button type="button" 
                      class="forms-grade-toggle ${!isMarkedCorrect ? 'is-incorrect' : ''}" 
                      data-action="toggle-answer-grade" 
                      data-response-id="${escapeAttribute(responseId)}" 
                      data-question-id="${escapeAttribute(answer.questionId)}"
                      data-grade="incorrect"
                      title="Mark as incorrect">
                      ${!isMarkedCorrect ? '✕' : '○'} Incorrect
                    </button>
                  </div>
                ` : ''}
              </div>
            </div>
          `;
        }).join('')}
      </article>
    `;
  }

  function calculateResponseScore(response, overrides = {}) {
    if (!state.isQuiz) return null;
    let earned = 0;
    let possible = 0;
    (response.answers || []).forEach((answer) => {
      const question = state.questions.find((q) => q.questionId === answer.questionId);
      if (!question || question.type === 'section') return;
      const points = Number(question.pointValue || 0);
      possible += points;
      
      // Check if there's a grade override
      const override = overrides[answer.questionId];
      let isCorrect;
      if (override !== undefined) {
        isCorrect = override === true || override === 'correct' || override === '1';
      } else {
        isCorrect = isCorrectAnswer(question, answer.answers[0]);
      }
      
      if (points > 0 && isCorrect) earned += points;
    });
    return { earned, possible };
  }


  function getScheduleStartDate() {
    return parseDate(state.metadataSettings.start_date.datetime);
  }

  function getScheduleEndDate() {
    return parseDate(state.metadataSettings.end_date.datetime);
  }

  function isDurationLockedByEndDate() {
    return !!getScheduleEndDate();
  }

  function getScheduledDurationMinutes() {
    const start = getScheduleStartDate();
    const end = getScheduleEndDate();
    if (!start || !end) return null;
    return Math.max(0, Math.round((end.getTime() - start.getTime()) / 60000));
  }

  function syncTimeDurationWithSchedule() {
    const scheduledMinutes = getScheduledDurationMinutes();
    if (scheduledMinutes === null) return false;
    state.metadataSettings.time_duration.minutes = scheduledMinutes;
    return true;
  }

  function shouldGateQuizUntilOpened() {
    return state.isQuiz
      && state.mode === 'publish'
      && !!getScheduleStartDate()
      && !getScheduleEndDate();
  }

  function shouldShowPublishQuestions() {
    const unavailable = getPublishAvailability();
    if (unavailable && !state.submissionComplete) return false;
    return !shouldGateQuizUntilOpened() || state.quizOpened || state.submissionComplete;
  }

  function getFormTimerDurationSeconds() {
    return Math.max(0, Number(state.metadataSettings.time_duration.minutes || 0) * 60);
  }


  function ensurePublishTimer() {
    const duration = getFormTimerDurationSeconds();
    const unavailable = getPublishAvailability();
    const shouldRun = state.mode === 'publish'
        && !state.submissionComplete
        && !unavailable
        && duration > 0
        && (!shouldGateQuizUntilOpened() || state.quizOpened);
    if (!shouldRun) {
      stopPublishTimer();
      if (unavailable || (shouldGateQuizUntilOpened() && !state.quizOpened)) state.timerStartedAt = null;
      return;
    }
    if (!state.timerStartedAt) state.timerStartedAt = Date.now();
    if (timerInterval) return;
    timerAutoSubmitting = false;
    timerInterval = window.setInterval(() => {
      const remaining = getTimerRemainingSeconds();
      updateTimerDisplay();
      if (remaining <= 0 && !timerAutoSubmitting) {
        timerAutoSubmitting = true;
        state.timerExpired = true;
        state.autoSubmitted = true;
        completeSubmission({ skipValidation: true, autoSubmitted: true });
      }
    }, 1000);
    window.setTimeout(updateTimerDisplay, 0);
  }

  function stopPublishTimer() {
    if (timerInterval) {
      window.clearInterval(timerInterval);
      timerInterval = null;
    }
    timerAutoSubmitting = false;
  }

  function getTimerRemainingSeconds() {
    const duration = getFormTimerDurationSeconds();
    if (!duration || !state.timerStartedAt) return duration;
    return Math.max(0, duration - Math.floor((Date.now() - state.timerStartedAt) / 1000));
  }

  function formatTimerSeconds(totalSeconds) {
    const safe = Math.max(0, Number(totalSeconds || 0));
    const hours = Math.floor(safe / 3600);
    const minutes = Math.floor((safe % 3600) / 60);
    const seconds = safe % 60;
    if (hours > 0) return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
    return `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
  }

  function renderTimerBadge() {
    const duration = getFormTimerDurationSeconds();
    const unavailable = getPublishAvailability();
    if (!duration || unavailable || state.submissionComplete || (shouldGateQuizUntilOpened() && !state.quizOpened)) return '';
    const remaining = getTimerRemainingSeconds();
    const dangerClass = remaining <= 60 ? ' is-danger' : '';
    return `<div class="forms-timer-badge${dangerClass}" data-role="forms-timer"><span class="forms-timer-label">Time left</span><strong>${escapeHtml(formatTimerSeconds(remaining))}</strong></div>`;
  }

  function updateTimerDisplay() {
    const node = root.querySelector('[data-role="forms-timer"]');
    if (!node) return;
    const remaining = getTimerRemainingSeconds();
    node.classList.toggle('is-danger', remaining <= 60);
    node.innerHTML = `<span class="forms-timer-label">Time left</span><strong>${escapeHtml(formatTimerSeconds(remaining))}</strong>`;
  }

  function normalizeAnswerForScoring(answer) {
    if (Array.isArray(answer)) return answer.map((item) => String(item ?? '').trim().toLowerCase()).filter(Boolean).sort();
    return String(answer ?? '').trim().toLowerCase();
  }


function getTextSimilarityThreshold() {
  const rawValue = state?.metadataSettings?.text_similarity_leniency?.percent;
  const fallback = Number(boot?.defaultTextSimilarityThreshold ?? 70);
  if (rawValue === '' || rawValue === null || typeof rawValue === 'undefined') return Number.isFinite(fallback) ? fallback : 70;
  const parsed = Number(rawValue);
  if (!Number.isFinite(parsed)) return Number.isFinite(fallback) ? fallback : 70;
  return Math.max(0, Math.min(100, parsed));
}

function calculateTextSimilarityPercent(expected, actual) {
  const left = String(expected ?? '').trim().toLowerCase();
  const right = String(actual ?? '').trim().toLowerCase();
  if (!left && !right) return 100;
  if (!left || !right) return 0;

  const rows = left.length + 1;
  const cols = right.length + 1;
  const matrix = Array.from({ length: rows }, () => Array(cols).fill(0));
  for (let i = 0; i < rows; i += 1) matrix[i][0] = i;
  for (let j = 0; j < cols; j += 1) matrix[0][j] = j;

  for (let i = 1; i < rows; i += 1) {
    for (let j = 1; j < cols; j += 1) {
      const cost = left[i - 1] === right[j - 1] ? 0 : 1;
      matrix[i][j] = Math.min(
        matrix[i - 1][j] + 1,
        matrix[i][j - 1] + 1,
        matrix[i - 1][j - 1] + cost,
      );
    }
  }

  const distance = matrix[left.length][right.length];
  const maxLen = Math.max(left.length, right.length);
  if (!maxLen) return 100;
  const similarity = (1 - (distance / maxLen)) * 100;
  return Math.max(0, Math.min(100, Math.round(similarity * 100) / 100));
}

function isTextAnswerCorrect(answer, acceptedAnswers, threshold = getTextSimilarityThreshold()) {
  const normalizedAnswer = String(answer ?? '').trim();
  if (!normalizedAnswer) return false;
  const accepted = Array.isArray(acceptedAnswers)
    ? acceptedAnswers.map((item) => String(item ?? '').trim()).filter(Boolean)
    : [String(acceptedAnswers ?? '').trim()].filter(Boolean);
  if (!accepted.length) return false;
  return accepted.some((expected) => calculateTextSimilarityPercent(expected, normalizedAnswer) >= threshold);
}

  function isCorrectAnswer(question, answer) {
    if (!question || question.type === 'section') return false;
    if (question.type === 'choice') {
      const selected = normalizeAnswerForScoring(answer);
      const expected = normalizeAnswerForScoring(question.correctAnswers || []);
      if (!Array.isArray(selected) && selected) return JSON.stringify([selected]) === JSON.stringify(expected);
      return JSON.stringify(Array.isArray(selected) ? selected : []) === JSON.stringify(expected);
    }
    if (question.type === 'text') {
      return isTextAnswerCorrect(answer, question.acceptedAnswers || [], getTextSimilarityThreshold());
    }
    return false;
  }

  function computeQuizScoreFromDraft(draft = state.responseDraft) {
    if (!state.isQuiz) return null;
    let earned = 0;
    let possible = 0;
    state.questions.filter((question) => question.type !== 'section').forEach((question) => {
      const points = Number(question.pointValue || 0);
      possible += points;
      if (points > 0 && isCorrectAnswer(question, draft[question.questionId])) earned += points;
    });
    return { earned, possible };
  }

  function renderQuizScoreSummary() {
    if (!state.isQuiz || !state.metadataSettings.show_score_in_thank_you.enabled || !state.lastSubmissionScore) return '';
    return `
      <div class="forms-score-card">
        <span class="forms-badge">Quiz score</span>
        <div class="forms-score-value">${escapeHtml(String(state.lastSubmissionScore.earned))} / ${escapeHtml(String(state.lastSubmissionScore.possible))}</div>
      </div>
    `;
  }

  function renderPublishShell(isPreview) {
    const publishState = getPublishSections();
    const sections = publishState.sections;
    const logicState = publishState.logicState;
    const disabledReason = getPublishAvailability();
    const publishLabel = isPreview ? 'Preview' : (state.metadataUi.publishModeLabel || 'Publish');
    const progress = sections.length > 1 ? Math.round(((state.currentPageIndex + 1) / sections.length) * 100) : 100;
    const hasValidationErrors = Object.keys(state.validationErrors || {}).length > 0;
    const questionsVisible = shouldShowPublishQuestions();
    const timerBadge = renderTimerBadge();
  if (state.submissionComplete) {
    const thankYouTitle = state.metadataUi.thankYouTitle || 'Response submitted';
    const thankYouMessage =
      state.metadataSettings.customize_thank_you_message.message ||
      'Your response has been stored successfully.';

    return `
      <div class="forms-publish-outer" style="background:${escapeHtml(state.metadataStyles.background.style)}; --forms-accent:${escapeHtml(state.metadataStyles.accentColor)};">
        <div class="forms-publish-shell ${isPreview ? 'is-preview' : ''}" style="border-radius:${Number(state.metadataStyles.cardRadius || 18)}px; width:min(100%, ${Number(state.metadataStyles.formWidth || 80)}%);">
        ${getPublishHeaderAudioMarkup()}
          <div class="forms-publish-header ${(getHeaderBannerConfig() && getHeaderBannerConfig().src && getHeaderBannerConfig().type !== 'audio') ? 'has-banner' : ''}" data-tone="light">${getPublishHeaderBackgroundMarkup()}
            ${state.editorMode ? `<div class="forms-question-type" style="margin-bottom:14px;">
              ${['edit', 'preview', 'publish'].map((mode) => `<button type="button" class="forms-mode-btn ${state.mode === mode ? 'is-active' : ''}" data-action="set-mode" data-mode="${mode}"></button>`).join('')}
              <span class="forms-pill">${escapeHtml(publishLabel)}</span>
            </div>` : ''}
            <h1>${escapeHtml(state.title)}</h1>
            <p>${escapeHtml(state.description || '')}</p>
          </div>

          <div class="forms-page-card forms-thankyou-card">
            <div class="forms-thankyou-icon">✓</div>
            <h2>${escapeHtml(thankYouTitle)}</h2>
            <p class="forms-page-description">${escapeHtml(thankYouMessage)}</p>
            ${state.autoSubmitted ? `<div class="forms-inline-banner"><strong>Time is up.</strong> Your answers were submitted automatically.</div>` : ''}
            ${renderQuizScoreSummary()}

            ${
              state.metadataSettings.hide_submit_another_response.enabled
                ? ''
                : `
                  <div class="forms-thankyou-actions">
                    <button type="button" class="forms-primary-btn" data-action="reset-submission">Submit another response</button>
                  </div>
                `
            }
          </div>
        </div>
      </div>
    `;
  }

  
const currentPage = sections[state.currentPageIndex]
  || sections[0]
  || { title: state.title, description: state.description, questions: state.questions.filter((q) => q.type !== 'section' && !isQuestionHiddenByLogic(q.questionId, logicState)) };

  if (!questionsVisible) {
    const isUnavailable = !!disabledReason;
    const hiddenIcon = isUnavailable ? '⏸' : '▶';
    const hiddenTitle = isUnavailable ? 'This form is not open right now' : 'Ready to begin?';
    const hiddenDescription = isUnavailable
      ? disabledReason
      : 'Questions stay hidden until the quiz or form is opened. Your timer will begin only after you start.';
    const hiddenActions = isUnavailable
      ? ''
      : `<div class="forms-thankyou-actions">
              <button type="button" class="forms-primary-btn" data-action="start-quiz">Start ${state.isQuiz ? 'quiz' : 'form'}</button>
            </div>`;
    return `
      <div class="forms-publish-outer" style="background:${escapeHtml(state.metadataStyles.background.style)}; --forms-accent:${escapeHtml(state.metadataStyles.accentColor)};">
        <div class="forms-publish-shell ${isPreview ? 'is-preview' : ''}" style="border-radius:${Number(state.metadataStyles.cardRadius || 18)}px; width:min(100%, ${Number(state.metadataStyles.formWidth || 80)}%);">
        ${getPublishHeaderAudioMarkup()}
          <div class="forms-publish-header ${(getHeaderBannerConfig() && getHeaderBannerConfig().src && getHeaderBannerConfig().type !== 'audio') ? 'has-banner' : ''}" data-tone="light">${getPublishHeaderBackgroundMarkup()}
            ${isPreview ? `<div class="forms-preview-banner"><div><strong>Preview mode</strong> · Answers are locked here so you can safely review layout, validation, branching, and pagination without changing the form.</div></div>` : ''}
            ${state.editorMode ? `<div class="forms-question-type" style="margin-bottom:14px;">
              ${['edit', 'preview', 'publish'].map((mode) => `<button type="button" class="forms-mode-btn ${state.mode === mode ? 'is-active' : ''}" data-action="set-mode" data-mode="${mode}">${capitalize(mode)}</button>`).join('')}
            </div>` : ''}
            <h1>${escapeHtml(state.title)}</h1>
            <p>${escapeHtml(state.description || '')}</p>
            ${disabledReason ? `<div class="forms-inline-banner"><strong>Notice:</strong> ${escapeHtml(disabledReason)}</div>` : ''}
          </div>

          <div class="forms-page-card forms-thankyou-card">
            <div class="forms-thankyou-icon">${hiddenIcon}</div>
            <h2>${hiddenTitle}</h2>
            <p class="forms-page-description">${escapeHtml(hiddenDescription)}</p>
            ${(!isUnavailable && getFormTimerDurationSeconds()) ? `<div class="forms-pill">Timed for ${escapeHtml(String(state.metadataSettings.time_duration.minutes || 0))} minute${Number(state.metadataSettings.time_duration.minutes || 0) === 1 ? '' : 's'}</div>` : ''}
            ${hiddenActions}
          </div>
        </div>
      </div>
    `;
  }
  return `
    <div class="forms-publish-outer" style="background:${escapeHtml(state.metadataStyles.background.style)}; --forms-accent:${escapeHtml(state.metadataStyles.accentColor)};">
      <div class="forms-publish-shell ${isPreview ? 'is-preview' : ''}" style="border-radius:${Number(state.metadataStyles.cardRadius || 18)}px; width:min(100%, ${Number(state.metadataStyles.formWidth || 80)}%);">
        ${getPublishHeaderAudioMarkup()}
        <div class="forms-publish-header ${(getHeaderBannerConfig() && getHeaderBannerConfig().src && getHeaderBannerConfig().type !== 'audio') ? 'has-banner' : ''}" data-tone="light">${getPublishHeaderBackgroundMarkup()}
          ${isPreview ? `<div class="forms-preview-banner"><div><strong>Preview mode</strong> · Answers are locked here so you can safely review layout, validation, branching, and pagination without changing the form.</div></div>` : ''}
          ${state.editorMode ? `<div class="forms-question-type" style="margin-bottom:14px;">
            ${['edit', 'preview', 'publish'].map((mode) => `<button type="button" class="forms-mode-btn ${state.mode === mode ? 'is-active' : ''}" data-action="set-mode" data-mode="${mode}"></button>`).join('')}
            </div>` : ''}
          <h1>${escapeHtml(state.title)}</h1>
          <p>${escapeHtml(state.description || '')}</p>
          <div class="forms-publish-meta">${timerBadge}</div>
          ${state.metadataSettings.show_progress_bar.enabled ? (() => { const progressMeta = getPublishProgressMeta(currentPage); return `<div class="forms-progress-wrap"><div class="forms-progress-meta"><span class="forms-progress-label" data-role="forms-progress-label">${escapeHtml(progressMeta.label)}</span><span class="forms-progress-value" data-role="forms-progress-value">${escapeHtml(progressMeta.valueText)}</span></div><div class="forms-progress" data-has-required="${progressMeta.totalRequired > 0 ? '1' : '0'}"><div class="forms-progress-bar forms-progress-bar-filled" data-role="forms-progress-bar-filled" style="width:${progressMeta.percentFilled}%;"></div><div class="forms-progress-bar forms-progress-bar-required" data-role="forms-progress-bar-required" style="width:${progressMeta.percentRequired}%;"></div></div></div>`; })() : ''}
          ${disabledReason ? `<div class="forms-inline-banner"><strong>Notice:</strong> ${escapeHtml(disabledReason)}</div>` : ''}
        </div>

        <div class="forms-page-card">
          <div>
            <h2>${escapeHtml(currentPage.title || state.title)}</h2>
            ${currentPage.description ? `<div class="forms-page-description">${escapeHtml(currentPage.description)}</div>` : ''}
          </div>

          <div class="forms-question-view">
            ${currentPage.questions.length
              ? currentPage.questions.map((question, pageIndex) => renderPublishQuestion(question, pageIndex, sections, isPreview, logicState)).join('')
              : `<div class="forms-empty-state"><h3>No questions on this page</h3><p>Add a question inside this section to collect responses.</p></div>`}
          </div>

          ${state.previewMessage && !hasValidationErrors ? `<div class="forms-inline-banner forms-inline-banner-error"><strong>Please review:</strong> ${escapeHtml(state.previewMessage)}</div>` : ''}
        </div>

        <div class="forms-nav-shell">
          <div class="forms-toolbar-group">
            ${state.currentPageIndex > 0 ? `<button type="button" class="forms-secondary-btn" data-action="prev-page">Previous</button>` : ''}
            <span class="forms-pill">${state.currentPageIndex + 1} of ${Math.max(sections.length, 1)}</span>
          </div>
          <div class="forms-toolbar-group">
            ${state.currentPageIndex < sections.length - 1
              ? `<button type="button" class="forms-primary-btn" data-action="next-or-submit">Next</button>`
              : `<button type="button" class="forms-primary-btn" data-action="next-or-submit">${isPreview ? 'Back to edit' : 'Submit'}</button>`}
          </div>
        </div>
      </div>
    </div>
  `;
  }


  function renderPublishQuestion(question, pageIndex, sections, isReadonly = isPreviewReadonly(), logicState = null) {
    const answer = state.responseDraft[question.questionId];
    const showNumber = !state.metadataSettings.disable_question_number_for_respondents.enabled;
    const prefix = showNumber ? `${pageIndex + 1}. ` : '';
    const questionIsRequired = isQuestionRequiredByLogic(question, logicState);
    const requiredMark = state.metadataUi.showRequiredAsterisk && questionIsRequired ? '<span class="forms-required-mark">*</span>' : '';
    const media = renderQuestionMedia(question);
    const subtitle = question.subtitle ? `<div class="forms-subtle">${escapeHtml(question.subtitle)}</div>` : '';
    const description = question.description ? `<div class="forms-subtle">${escapeHtml(question.description)}</div>` : '';
    const points = state.isQuiz ? `<span class="forms-pill">${Number(question.pointValue || 0)} points</span>` : '';
    const fieldError = (state.validationErrors || {})[question.questionId] || '';
    if (isQuestionHiddenByLogic(question.questionId, logicState)) return '';

    let control = '';
    switch (question.type) {
      case 'choice': control = renderPublishChoice(question, answer, isReadonly); break;
      case 'text': control = renderPublishText(question, answer, isReadonly); break;
      case 'rating': control = renderPublishRating(question, answer, isReadonly); break;
      case 'date': control = renderPublishDate(question, answer, isReadonly); break;
      case 'ranking': control = renderPublishRanking(question, answer, isReadonly); break;
      case 'likert': control = renderPublishLikert(question, answer, isReadonly); break;
      case 'upload': control = renderPublishUpload(question, answer, isReadonly); break;
      case 'nps': control = renderPublishNps(question, answer, isReadonly); break;
      default: control = '';
    }
    return `
      <div class="forms-question-view" data-question-id="${question.questionId}">
        <div class="forms-question-type">${points}</div>
        <div class="forms-question-title">${prefix}${escapeHtml(question.title)} ${requiredMark}</div>
        ${subtitle}
        ${description}
        ${media}
        <div class="forms-response-control ${fieldError ? 'has-error' : ''}">
          ${control}
          ${fieldError ? `<div class="forms-field-error-text">${escapeHtml(fieldError)}</div>` : ''}
        </div>
      </div>
    `;
  }



function renderQuestionMedia(question) {
  if (!question.mediaUrl) return '';
  if (question.mediaType === 'video') {
    return `<div class="forms-question-media"><video controls src="${escapeAttribute(question.mediaUrl)}"></video></div>`;
  }
  if (question.mediaType === 'audio') {
    return `<div class="forms-question-media"><audio controls src="${escapeAttribute(question.mediaUrl)}"></audio></div>`;
  }
  return `<div class="forms-question-media"><img src="${escapeAttribute(question.mediaUrl)}" alt="${escapeAttribute(question.mediaAlt || question.title)}"></div>`;
}

  
function renderPublishChoice(question, answer, isReadonly = isPreviewReadonly()) {
  if (question.isDropdown) {
    return `
      <div>
        <label class="form-label">Select an option</label>
        <select class="forms-select form-select" data-action="publish-answer" data-question-id="${question.questionId}" ${isReadonly ? 'disabled' : ''}>
          <option value="">Choose…</option>
          ${getQuestionOptions(question).map((option) => `<option value="${escapeAttribute(option)}" ${answer === option ? 'selected' : ''}>${escapeHtml(option)}</option>`).join('')}
        </select>
      </div>
    `;
  }
  const selected = Array.isArray(answer) ? answer : (answer ? [answer] : []);
  const inputType = question.isMultiple ? 'checkbox' : 'radio';
  return `
    <div class="forms-choice-stack">
      ${getQuestionOptions(question).map((option, index) => `
        <label class="forms-choice-pill form-check ${isReadonly ? 'is-readonly' : ''}">
          <input class="form-check-input" type="${inputType}" name="${question.questionId}" id="${question.questionId}-${index}" value="${escapeAttribute(option)}" ${selected.includes(option) ? 'checked' : ''} data-action="publish-choice" data-question-id="${question.questionId}" ${isReadonly ? 'disabled' : ''}>
          <span class="form-check-label">${escapeHtml(option)}</span>
        </label>
      `).join('')}
    </div>
  `;
}


function renderPublishText(question, answer, isReadonly = isPreviewReadonly()) {
  return question.textMode === 'long'
    ? `<textarea class="forms-textarea form-control" data-action="publish-answer" data-question-id="${question.questionId}" placeholder="Type your answer" ${isReadonly ? 'readonly' : ''}>${escapeHtml(answer || '')}</textarea>`
    : `<input class="forms-input form-control" data-action="publish-answer" data-question-id="${question.questionId}" value="${escapeHtml(answer || '')}" placeholder="Type your answer" ${isReadonly ? 'readonly' : ''}>`;
}


function renderPublishRating(question, answer, isReadonly = isPreviewReadonly()) {
  const current = Number(answer || 0);
  return `<div class="forms-rating-row">${Array.from({ length: question.maxRating || 5 }, (_, idx) => idx + 1).map((value) => `<button type="button" class="forms-rating-value ${current === value ? 'is-selected' : ''}" data-action="publish-rating" data-question-id="${question.questionId}" data-value="${value}" ${isReadonly ? 'disabled' : ''}>${value}</button>`).join('')}</div>`;
}


function renderPublishDate(question, answer, isReadonly = isPreviewReadonly()) {
  return `<input class="forms-input form-control" type="date" data-action="publish-answer" data-question-id="${question.questionId}" value="${escapeHtml(answer || '')}" ${isReadonly ? 'disabled' : ''}>`;
}


function renderPublishRanking(question, answer, isReadonly = isPreviewReadonly()) {
  const current = Array.isArray(answer) && answer.length ? answer : (Array.isArray(state.responseDraft[question.questionId]) && state.responseDraft[question.questionId].length ? state.responseDraft[question.questionId] : getQuestionOptions(question));
  return `
    <div class="forms-publish-ranking ${isReadonly ? 'is-readonly' : ''}">
      <div class="forms-inline-banner">Drag items into the preferred order.</div>
      ${current.map((option, index) => `
        <div class="forms-ranking-item" draggable="${isReadonly ? 'false' : 'true'}" data-publish-rank="${isReadonly ? '0' : '1'}" data-question-id="${question.questionId}" data-index="${index}">
          <button type="button" class="forms-option-handle" ${isReadonly ? 'disabled' : ''}>⋮⋮</button>
          <input class="forms-input form-control" value="${escapeHtml(option)}" readonly>
          <div style="display:flex; gap:8px;">
            <button type="button" class="forms-icon-btn" data-action="move-ranking-answer" data-question-id="${question.questionId}" data-index="${index}" data-direction="up" ${isReadonly ? 'disabled' : ''}>↑</button>
            <button type="button" class="forms-icon-btn" data-action="move-ranking-answer" data-question-id="${question.questionId}" data-index="${index}" data-direction="down" ${isReadonly ? 'disabled' : ''}>↓</button>
          </div>
        </div>
      `).join('')}
    </div>
  `;
}


function renderPublishLikert(question, answer, isReadonly = isPreviewReadonly()) {
  const answers = answer && typeof answer === 'object' ? answer : {};
  return `
    <div class="forms-likert-grid ${isReadonly ? 'is-readonly' : ''}">
      <table>
        <thead>
          <tr>
            <th>Statement</th>
            ${question.columns.map((column) => `<th>${escapeHtml(column)}</th>`).join('')}
          </tr>
        </thead>
        <tbody>
          ${question.statements.map((statement) => `
            <tr>
              <td>${escapeHtml(statement)}</td>
              ${question.columns.map((column) => `
                <td>
                  <input class="form-check-input" type="radio" name="${question.questionId}-${slugify(statement)}" value="${escapeAttribute(column)}" ${answers[statement] === column ? 'checked' : ''} data-action="publish-likert" data-question-id="${question.questionId}" data-statement="${escapeAttribute(statement)}" ${isReadonly ? 'disabled' : ''}>
                </td>
              `).join('')}
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;
}


function renderPublishUpload(question, answer, isReadonly = isPreviewReadonly()) {
  const uploads = Array.isArray(answer) ? answer : (answer ? [answer] : []);
  return `
    <div class="forms-file-drop ${isReadonly ? 'is-readonly' : ''}">
      <strong>Upload file</strong>
      <span class="forms-subtle">Accepted: ${escapeHtml(question.fileAccept || 'Any file type')}${question.fileMaxSize ? ` · Max size: ${escapeHtml(question.fileMaxSize)}` : ''}</span>
      <input class="form-control" type="file" ${question.multipleFiles ? 'multiple' : ''} accept="${escapeAttribute(question.fileAccept || '')}" data-action="publish-file" data-question-id="${question.questionId}" ${isReadonly ? 'disabled' : ''}>
      ${uploads.length ? `<div class="forms-subtle">Selected: ${escapeHtml(uploads.map((item) => typeof item === 'string' ? item : item.name).join(', '))}</div>` : ''}
    </div>
  `;
}


function renderPublishNps(question, answer, isReadonly = isPreviewReadonly()) {
  const current = Number(answer || 0);
  return `
    <div class="forms-nps-row">
      <div class="forms-grid-2"><span class="forms-subtle">${escapeHtml(question.minLabel || 'Not likely')}</span><span class="forms-subtle" style="text-align:right;">${escapeHtml(question.maxLabel || 'Very likely')}</span></div>
      <div class="forms-rating-row">${Array.from({ length: 11 }, (_, idx) => idx).map((value) => `<button type="button" class="forms-nps-pill ${current === value ? 'is-selected' : ''}" data-action="publish-rating" data-question-id="${question.questionId}" data-value="${value}" ${isReadonly ? 'disabled' : ''}>${value}</button>`).join('')}</div>
    </div>
  `;
}

function getQuestionOptions(question) {
    const items = Array.isArray(question.options) ? question.options.slice() : [];
    if (question.shuffle) {
      return items
        .map((item) => ({ item, sort: seededOrder(`${state.formId}-${question.questionId}-${item}`) }))
        .sort((a, b) => a.sort - b.sort)
        .map((entry) => entry.item);
    }
    return items;
  }

  function seededOrder(input) {
    let hash = 0;
    for (let i = 0; i < input.length; i += 1) hash = ((hash << 5) - hash) + input.charCodeAt(i);
    return Math.abs(hash);
  }

  function getSections() {
  const sections = [];
  let current = { id: 'section-0', title: state.title, description: state.description, questions: [] };
  state.questions.forEach((question) => {
    if (question.type === 'section') {
      if (current.questions.length || sections.length === 0) sections.push(current);
      current = { id: question.questionId, title: question.title || 'Section', description: question.description || question.subtitle || '', questions: [] };
    } else {
      current.questions.push(question);
    }
  });
  if (current.questions.length || !sections.length) sections.push(current);
  return sections.filter((section) => section.questions.length || sections.length === 1);
}

function buildPublishLogicState() {
  const hiddenQuestionIds = new Set();
  const requiredQuestionIds = new Set();
  const optionalQuestionIds = new Set();
  state.questions.filter((question) => question && question.type !== 'section').forEach((question) => {
    const answer = state.responseDraft[question.questionId];
    (question.branchingRules || []).forEach((rawRule) => {
      const rule = normalizeBranchRule(rawRule);
      if (!matchesBranchRule(answer, rule)) return;
      if (rule.action === 'hide' && rule.targetQuestionId) hiddenQuestionIds.add(rule.targetQuestionId);
      if (rule.action === 'show' && rule.targetQuestionId) hiddenQuestionIds.delete(rule.targetQuestionId);
      if (rule.action === 'require' && rule.targetQuestionId) { requiredQuestionIds.add(rule.targetQuestionId); optionalQuestionIds.delete(rule.targetQuestionId); }
      if (rule.action === 'optional' && rule.targetQuestionId) { optionalQuestionIds.add(rule.targetQuestionId); requiredQuestionIds.delete(rule.targetQuestionId); }
    });
  });
  return { hiddenQuestionIds, requiredQuestionIds, optionalQuestionIds };
}

function isQuestionHiddenByLogic(questionId, logicState = null) {
  const activeState = logicState || buildPublishLogicState();
  return activeState.hiddenQuestionIds.has(questionId);
}

function isQuestionRequiredByLogic(question, logicState = null) {
  const activeState = logicState || buildPublishLogicState();
  if (!question || question.type === 'section') return false;
  if (activeState.optionalQuestionIds.has(question.questionId)) return false;
  if (activeState.requiredQuestionIds.has(question.questionId)) return true;
  return !!question.required;
}

function getPublishSections() {
  const logicState = buildPublishLogicState();
  const rawSections = getSections();
  const sections = rawSections
    .map((section) => ({ ...section, questions: (section.questions || []).filter((question) => question && question.type !== 'section' && !isQuestionHiddenByLogic(question.questionId, logicState)) }))
    .filter((section, index) => section.questions.length > 0 || (index === 0 && rawSections.length === 1));
  if (!sections.length) sections.push({ id: 'section-visible-0', title: state.title, description: state.description, questions: [] });
  return { sections, logicState };
}


  function getPublishAvailability() {
    if (!state.metadataSettings.accepted_responses.enabled) return 'This form is not currently accepting responses.';
    const now = Date.now();
    const start = parseDate(state.metadataSettings.start_date.datetime);
    const end = parseDate(state.metadataSettings.end_date.datetime);
    if (start && now < start.getTime()) return `Responses open on ${formatDateTime(start.toISOString())}.`;
    if (end && now > end.getTime()) return `Responses closed on ${formatDateTime(end.toISOString())}.`;
    return '';
  }
  function isPreviewReadonly() {
    return state.mode === 'preview';
  }

  function summarizeResponses() {
    const count = state.responses.length;
    const latest = count ? formatDateTime(state.responses[0].timestamp) : '';
    return { count, latest };
  }

  function renderHeaderStatus() {
    const target = document.getElementById('forms-save-status');
    if (!target) return;
    target.textContent = state.saveMessage || t('apps.applications.forms.all_changes_saved', 'All changes saved');
    target.className = `forms-save-status ${state.savingState === 'saving' ? 'is-saving' : state.savingState === 'success' ? 'is-success' : state.savingState === 'error' ? 'is-error' : ''}`;
    const fullDateTime = state.lastSavedAt ? formatSaveBadgeDateTime(state.lastSavedAt) : '';
    target.setAttribute('title', fullDateTime || 'No recent save yet');
    target.setAttribute('aria-label', fullDateTime ? `Last saved ${fullDateTime}` : (state.saveMessage || t('apps.applications.forms.all_changes_saved', 'All changes saved')));
  }

  function attachHandlers() {
    root.querySelectorAll('[data-action]').forEach((element) => {
      const action = element.dataset.action;
      if (!action) return;
      if (isPreviewReadonly() && (action.startsWith('publish-') || action === 'move-ranking-answer')) return;
      const handler = getActionHandler(action);
      if (!handler) return;
      if (element.matches('button')) {
        element.addEventListener('click', handler);
        return;
      }
      if (element.matches('input, textarea, select')) {
        element.addEventListener('change', handler);
        if (action === 'publish-answer') {
          element.addEventListener('input', handler);
        }
        return;
      }
      element.addEventListener('click', handler);
    });

    root.querySelectorAll('[data-question-id][draggable="true"]').forEach((card) => {
      if (card.dataset.optionDrag === '1' || card.dataset.publishRank === '1') return;
      card.addEventListener('dragstart', handleQuestionDragStart);
      card.addEventListener('dragover', handleQuestionDragOver);
      card.addEventListener('drop', handleQuestionDrop);
      card.addEventListener('dragend', handleQuestionDragEnd);
    });

    root.querySelectorAll('[data-option-drag="1"]').forEach((row) => {
      row.addEventListener('dragstart', handleOptionDragStart);
      row.addEventListener('dragover', handleOptionDragOver);
      row.addEventListener('drop', handleOptionDrop);
      row.addEventListener('dragend', handleOptionDragEnd);
    });

    root.querySelectorAll('[data-publish-rank="1"]').forEach((row) => {
      row.addEventListener('dragstart', handlePublishRankStart);
      row.addEventListener('dragover', handlePublishRankOver);
      row.addEventListener('drop', handlePublishRankDrop);
      row.addEventListener('dragend', handlePublishRankEnd);
    });

    root.querySelectorAll('[data-collapse-state]').forEach((element) => {
      const key = `${element.dataset.collapseState}Expanded`;
      element.addEventListener('shown.bs.collapse', () => { state[key] = true; });
      element.addEventListener('hidden.bs.collapse', () => { state[key] = false; });
    });
    document.addEventListener('click', handleOutsideClick, { once: true });
  }

  function getActionHandler(action) {
    const map = {
      'set-mode': onSetMode,
      'set-panel': onSetPanel,
      'form-meta-field': onFormMetaField,
      'quick-add-question': onQuickAddQuestion,
      'add-question': onAddQuestion,
      'question-field': onQuestionField,
      'toggle-optional-text': onToggleOptionalText,
      'option-field': onOptionField,
      'add-option': onAddOption,
      'delete-option': onDeleteOption,
      'copy-option': onCopyOption,
      'move-option': onMoveOption,
      'move-question': onMoveQuestion,
      'delete-question': onDeleteQuestion,
      'duplicate-question': onDuplicateQuestion,
      'toggle-menu': onToggleMenu,
      'close-menu': () => { state.openMenuId = null; render(); },
      'branch-rule-field': onBranchRuleField,
      'add-branch-rule': onAddBranchRule,
      'delete-branch-rule': onDeleteBranchRule,
      'style-field': onStyleField,
      'style-toggle': onStyleToggle,
      'settings-field': onSettingsField,
      'settings-toggle': onSettingsToggle,
      'ui-field': onUiField,
      'ui-toggle': onUiToggle,
      'toggle-quiz': onToggleQuiz,
      'choice-answer-key': onChoiceAnswerKey,
      'text-answer-key': onTextAnswerKey,
      'publish-answer': onPublishAnswer,
      'publish-choice': onPublishChoice,
      'publish-rating': onPublishRating,
      'publish-file': onPublishFile,
      'publish-likert': onPublishLikert,
      'prev-page': onPrevPage,
      'response-page': onResponsePage,
      'next-or-submit': onNextOrSubmit,
      'apply-template': onApplyTemplate,
      'move-ranking-answer': onMoveRankingAnswer,
      'reset-submission': onResetSubmission,
      'start-quiz': onStartQuiz,
      'toggle-answer-grade': onToggleAnswerGrade
    };
    return map[action];
  }

  function findQuestion(questionId) {
    return state.questions.find((question) => question.questionId === questionId);
  }

  function clearValidationError(questionId) {
    if (!questionId || !state.validationErrors || !state.validationErrors[questionId]) return;
    const nextErrors = { ...state.validationErrors };
    delete nextErrors[questionId];
    state.validationErrors = nextErrors;
    if (!Object.keys(state.validationErrors).length && state.previewMessage === 'Please fix the highlighted fields.') {
      state.previewMessage = '';
    }
  }

  function focusFirstValidationError() {
    const firstQuestionId = Object.keys(state.validationErrors || {})[0];
    if (!firstQuestionId) return;
    const target = root.querySelector(`[data-question-id="${CSS.escape(firstQuestionId)}"] .forms-response-control`);
    if (target) target.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }

  function onResetSubmission() {
    state.responseDraft = {};
    state.previewMessage = '';
    state.validationErrors = {};
    state.currentPageIndex = 0;
    state.submissionComplete = false;
    state.quizOpened = !shouldGateQuizUntilOpened();
    state.timerStartedAt = state.mode === 'publish' && state.quizOpened ? Date.now() : null;
    state.timerExpired = false;
    state.autoSubmitted = false;
    state.lastSubmissionScore = null;
    stopPublishTimer();
    render();
  }

  function onStartQuiz() {
    if (!shouldGateQuizUntilOpened() || getPublishAvailability()) return;
    state.quizOpened = true;
    state.timerStartedAt = getFormTimerDurationSeconds() > 0 ? Date.now() : null;
    state.timerExpired = false;
    state.autoSubmitted = false;
    render();
  }

  function onToggleAnswerGrade(event) {
    const responseId = event.currentTarget.dataset.responseId;
    const questionId = event.currentTarget.dataset.questionId;
    const grade = event.currentTarget.dataset.grade;
    
    if (!responseId || !questionId) return;
    
    // Find the response
    const response = state.responses.find((r) => r.id === responseId);
    if (!response) return;
    
    // Initialize gradeOverrides if not exists
    if (!response.gradeOverrides) {
      response.gradeOverrides = {};
    }
    
    // Toggle the grade (correct, incorrect, or clear)
    const currentOverride = response.gradeOverrides[questionId];
    if (grade === 'correct') {
      if (currentOverride === true) {
        delete response.gradeOverrides[questionId]; // Clear override
      } else {
        response.gradeOverrides[questionId] = true; // Mark as correct
      }
    } else if (grade === 'incorrect') {
      if (currentOverride === false) {
        delete response.gradeOverrides[questionId]; // Clear override
      } else {
        response.gradeOverrides[questionId] = false; // Mark as incorrect
      }
    }
    
    // Save the override to the backend
    saveGradeOverride(responseId, questionId, response.gradeOverrides[questionId]);
    
    // Re-render the response
    render();
  }

  async function saveGradeOverride(responseId, questionId, gradeValue) {
    try {
      const payload = {
        formId: state.formId,
        responseId: responseId,
        questionId: questionId,
        grade: gradeValue !== undefined ? (gradeValue === true ? 'correct' : gradeValue === false ? 'incorrect' : 'clear') : 'clear',
      };
      
      const response = await postForm('./saveGrade.php', payload);
      if (!response.success) {
        toast('Failed to save grade override', true);
      }
    } catch (error) {
      console.error('Grade save error:', error);
      toast(error.message || 'Failed to save grade', true);
    }
  }

  function onFormMetaField(event) {
    const field = event.currentTarget.dataset.field;
    if (!field) return;
    state[field] = event.currentTarget.value;
    scheduleSave(field);
  }

  function onSetMode(event) {
    const mode = event.currentTarget.dataset.mode;
    if (!state.editorMode && mode !== 'publish') return;

    const existingDraft = Object.keys(state.responseDraft || {}).length
      ? structuredClone(state.responseDraft)
      : buildDraftFromCurrentAnswers(state.questions, state.currentAnswers || {});

    state.mode = mode;
    state.previewMessage = '';
    state.validationErrors = {};
    state.submissionComplete = false;
    state.responseDraft = (mode === 'publish' || mode === 'preview') ? existingDraft : {};
    state.timerExpired = false;
    state.autoSubmitted = false;
    state.lastSubmissionScore = null;
    state.quizOpened = mode === 'publish' ? !shouldGateQuizUntilOpened() : true;
    state.timerStartedAt = mode === 'publish' && state.quizOpened ? Date.now() : null;

    stopPublishTimer();

    if (mode === 'publish' || mode === 'preview') state.currentPageIndex = 0;
    render();
  }

  function onSetPanel(event) {
    state.activePanel = event.currentTarget.dataset.panel || 'style';
    render();
  }

  function createQuestionByType(type) {
    switch (type) {
      case 'choice': return choiceQ('Question', ['Option 1', 'Option 2'], false);
      case 'text': return textQ('Question', 'short', false);
      case 'rating': return ratingQ('Question', 5, false);
      case 'date': return dateQ('Question', false);
      case 'ranking': return rankingQ('Question', ['Item 1', 'Item 2', 'Item 3'], false);
      case 'likert': return baseQuestion('likert', { title: 'Question', options: [], statements: ['Statement 1', 'Statement 2'], columns: ['Strongly disagree', 'Disagree', 'Neutral', 'Agree', 'Strongly agree'] });
      case 'upload': return uploadQ('Question', false);
      case 'nps': return npsQ('How likely are you to recommend us?', false);
      case 'section': return section(`Section ${state.questions.filter((q) => q.type === 'section').length + 1}`, 'Section description');
      default: return choiceQ('Question', ['Option 1', 'Option 2'], false);
    }
  }

  function onQuickAddQuestion(event) {
    const type = event.currentTarget.value;
    if (!type) return;
    addQuestion(type);
    event.currentTarget.value = '';
  }

  function onAddQuestion(event) {
    addQuestion(event.currentTarget.dataset.type || 'choice');
  }

  function addQuestion(type) {
    state.questions.push(createQuestionByType(type));
    recomputeSections();
    state.openMenuId = null;
    scheduleSave(type);
    render();
  }

  function onQuestionField(event) {
    const question = findQuestion(event.currentTarget.dataset.questionId);
    if (!question) return;
    const field = event.currentTarget.dataset.field;
    let value;
    if (event.currentTarget.classList.contains('forms-switch')) {
      if (event.currentTarget.dataset.disabled === '1') return;
      value = !question[field];
    } else if (event.currentTarget.type === 'number') {
      value = Number(event.currentTarget.value || 0);
    } else {
      value = event.currentTarget.value;
    }
    question[field] = value;
    if (field === 'isMultiple' && value) question.isDropdown = false;
    if (field === 'branching' && !value) question.branchingRules = [];
    if (field === 'type') Object.assign(question, normalizeQuestion(question));
    if (field === 'required' && question.type === 'section') question.required = false;
    if (field === 'maxRating') question.maxRating = Math.max(3, Math.min(10, Number(value || 5)));
    if (field === 'title' || field === 'description') recomputeSections();
    scheduleSave(field);
    render();
  }

  function onToggleOptionalText(event) {
    const question = findQuestion(event.currentTarget.dataset.questionId);
    if (!question) return;
    const field = event.currentTarget.dataset.field;
    question[field] = question[field] === false ? '' : false;
    scheduleSave(field);
    render();
  }

  function onOptionField(event) {
    const question = findQuestion(event.currentTarget.dataset.questionId);
    if (!question) return;
    const collection = event.currentTarget.dataset.collection;
    const index = Number(event.currentTarget.dataset.index);
    const previousValue = question[collection][index];
    question[collection][index] = event.currentTarget.value;
    if (collection === 'options') {
      question.maxRank = Math.max(question.maxRank || 0, question.options.length);
      question.correctAnswers = (question.correctAnswers || []).map((answer) => answer === previousValue ? event.currentTarget.value : answer).filter((answer) => question.options.includes(answer));
    }
    scheduleSave('options');
  }

  function onAddOption(event) {
    const question = findQuestion(event.currentTarget.dataset.questionId);
    if (!question) return;
    const collection = event.currentTarget.dataset.collection;
    question[collection].push(collection === 'columns' ? `Column ${question[collection].length + 1}` : collection === 'statements' ? `Statement ${question[collection].length + 1}` : `Option ${question[collection].length + 1}`);
    scheduleSave('option');
    render();
  }

  function onDeleteOption(event) {
    const question = findQuestion(event.currentTarget.dataset.questionId);
    if (!question) return;
    const collection = event.currentTarget.dataset.collection;
    const index = Number(event.currentTarget.dataset.index);
    const removed = question[collection][index];
    question[collection].splice(index, 1);
    if (collection === 'options') question.correctAnswers = (question.correctAnswers || []).filter((answer) => answer !== removed);
    scheduleSave('option');
    render();
  }

  function onCopyOption(event) {
    const question = findQuestion(event.currentTarget.dataset.questionId);
    if (!question) return;
    const collection = event.currentTarget.dataset.collection;
    const index = Number(event.currentTarget.dataset.index);
    question[collection].splice(index + 1, 0, `${question[collection][index]} copy`);
    scheduleSave('option');
    render();
  }

  function onMoveOption(event) {
    const question = findQuestion(event.currentTarget.dataset.questionId);
    if (!question) return;
    const collection = event.currentTarget.dataset.collection;
    moveInArray(question[collection], Number(event.currentTarget.dataset.index), event.currentTarget.dataset.direction === 'up' ? -1 : 1);
    scheduleSave('option');
    render();
  }

  function onMoveQuestion(event) {
    const index = state.questions.findIndex((q) => q.questionId === event.currentTarget.dataset.questionId);
    if (index < 0) return;
    moveInArray(state.questions, index, event.currentTarget.dataset.direction === 'up' ? -1 : 1);
    recomputeSections();
    scheduleSave('question');
    render();
  }

  function onDeleteQuestion(event) {
    state.questions = state.questions.filter((question) => question.questionId !== event.currentTarget.dataset.questionId);
    recomputeSections();
    scheduleSave('question');
    render();
  }

  function onDuplicateQuestion(event) {
    const index = state.questions.findIndex((question) => question.questionId === event.currentTarget.dataset.questionId);
    if (index < 0) return;
    const copy = normalizeQuestion({ ...JSON.parse(JSON.stringify(state.questions[index])), questionId: uid('Q'), title: `${state.questions[index].title} copy` });
    state.questions.splice(index + 1, 0, copy);
    recomputeSections();
    scheduleSave('question');
    render();
  }

  function onToggleMenu(event) {
    event.stopPropagation();
    const questionId = event.currentTarget.dataset.questionId;
    state.openMenuId = state.openMenuId === questionId ? null : questionId;
    render();
  }

  function handleOutsideClick(event) {
    if (event.target.closest('.forms-dots-wrap')) return;
    if (state.openMenuId !== null) {
      state.openMenuId = null;
      render();
    }
  }

  function onBranchRuleField(event) {
  const question = findQuestion(event.currentTarget.dataset.questionId);
  if (!question) return;
  const index = Number(event.currentTarget.dataset.index);
  const field = event.currentTarget.dataset.field;
  const currentRule = normalizeBranchRule(question.branchingRules[index] || {});
  currentRule[field] = event.currentTarget.value;
  if (field === 'operator' && !shouldBranchRuleHaveValue(currentRule.operator)) currentRule.value = '';
  if (field === 'action') {
    if (currentRule.action === 'jump') {
      currentRule.target = currentRule.target || '__next__';
      if (!currentRule.targetQuestionId && currentRule.target && !String(currentRule.target).startsWith('__')) currentRule.targetQuestionId = currentRule.target;
    } else {
      if (!currentRule.targetQuestionId && currentRule.target && !String(currentRule.target).startsWith('__')) currentRule.targetQuestionId = currentRule.target;
      currentRule.target = '';
    }
  }
  question.branchingRules[index] = normalizeBranchRule(currentRule);
  question.branching = question.branchingRules.length > 0;
  scheduleSave('logic');
  render();
}

  function onAddBranchRule(event) {
  const question = findQuestion(event.currentTarget.dataset.questionId);
  if (!question) return;
  question.branching = true;
  question.branchingRules.push(normalizeBranchRule({ operator: 'answered', value: '', action: 'jump', target: '__next__', targetQuestionId: '' }));
  scheduleSave('logic');
  render();
}

  function onDeleteBranchRule(event) {
    const question = findQuestion(event.currentTarget.dataset.questionId);
    if (!question) return;
    question.branchingRules.splice(Number(event.currentTarget.dataset.index), 1);
    question.branching = question.branchingRules.length > 0;
    scheduleSave('branching');
    render();
  }

  function onStyleField(event) {
    const path = event.currentTarget.dataset.path;
    const value = event.currentTarget.type === 'number' ? Number(event.currentTarget.value || 0) : event.currentTarget.value;
    setPath(state.metadataStyles, path, value);

    if (path && path.startsWith('background.')) {
      state.metadataStyles.background.style = buildBackgroundStyle(
        state.metadataStyles.background.startColor,
        state.metadataStyles.background.endColor,
        state.metadataStyles.background.direction,
      );
    }

    if (path === 'headerBanner.src') {
      const src = String(value || '').trim();
      setPath(state.metadataStyles, path, src);
      if (src) state.metadataStyles.headerBanner.enable = true;
    }

    if (path === 'headerBanner.type') {
      const safeType = ['image', 'video', 'audio'].includes(String(value || '').toLowerCase())
        ? String(value).toLowerCase()
        : 'image';
      setPath(state.metadataStyles, path, safeType);
    }

    state.metadataStyles = normalizeStyles(state.metadataStyles);
    scheduleSave('styles');
    render();
  }

  function onStyleToggle(event) {
    const path = event.currentTarget.dataset.path;
    const current = !!getPath(state.metadataStyles, path);
    setPath(state.metadataStyles, path, !current);
    state.metadataStyles = normalizeStyles(state.metadataStyles);
    scheduleSave('styles');
    render();
  }

  
function onSettingsField(event) {
    const path = event.currentTarget.dataset.path;
    let value;

    if (event.currentTarget.type === 'number') {
      if (path === 'text_similarity_leniency.percent' && String(event.currentTarget.value).trim() === '') {
        value = '';
      } else {
        value = Number(event.currentTarget.value || 0);
      }
    } else {
      value = event.currentTarget.type === 'datetime-local'
        ? fromDatetimeLocal(event.currentTarget.value)
        : event.currentTarget.value;
    }

    if (path === 'text_similarity_leniency.percent' && value !== '') {
      value = Math.max(0, Math.min(100, Number(value || 0)));
    }

    setPath(state.metadataSettings, path, value);

    if (path === 'start_date.datetime' || path === 'end_date.datetime') {
      syncTimeDurationWithSchedule();

      if (state.mode === 'publish') {
        state.quizOpened = !shouldGateQuizUntilOpened();
        state.timerStartedAt = state.quizOpened && getFormTimerDurationSeconds() > 0
          ? Date.now()
          : null;
      }
    }

    scheduleSave('settings');
    render();
  }

  function onSettingsToggle(event) {
    const path = event.currentTarget.dataset.path;
    setPath(state.metadataSettings, path, !getPath(state.metadataSettings, path));
    scheduleSave('settings');
    render();
  }

  function onUiField(event) {
    setPath(state.metadataUi, event.currentTarget.dataset.path, event.currentTarget.value);
    scheduleSave('settings');
    render();
  }

  function onUiToggle(event) {
    const path = event.currentTarget.dataset.path;
    setPath(state.metadataUi, path, !getPath(state.metadataUi, path));
    scheduleSave('settings');
    render();
  }

  function onToggleQuiz() {
    state.isQuiz = !state.isQuiz;
    scheduleSave('quiz');
    render();
  }

  function onChoiceAnswerKey(event) {
    const question = findQuestion(event.currentTarget.dataset.questionId);
    if (!question) return;
    const checked = Array.from(root.querySelectorAll(`[data-action="choice-answer-key"][data-question-id="${CSS.escape(question.questionId)}"]:checked`)).map((input) => input.value);
    question.correctAnswers = checked;
    scheduleSave('answer key');
  }

  function onTextAnswerKey(event) {
    const question = findQuestion(event.currentTarget.dataset.questionId);
    if (!question) return;
    question.acceptedAnswers = String(event.currentTarget.value || '').split(/\\r?\\n/).map((item) => item.trim()).filter(Boolean);
    scheduleSave('accepted answers');
  }

  

function shouldRerenderAfterAnswer(questionId) {
  const question = findQuestion(questionId);
  return !!(question && Array.isArray(question.branchingRules) && question.branchingRules.length > 0);
}

function onPublishAnswer(event) {
  if (isPreviewReadonly()) return;
  const questionId = event.currentTarget.dataset.questionId;
  state.responseDraft[questionId] = event.currentTarget.value;
  clearValidationError(questionId);
  if (shouldRerenderAfterAnswer(questionId)) {
    render();
    return;
  }
  updatePublishProgressUI();
}

  function onPublishChoice(event) {
  if (isPreviewReadonly()) return;
  const question = findQuestion(event.currentTarget.dataset.questionId);
  if (!question) return;
  if (question.isMultiple) {
    const checked = Array.from(root.querySelectorAll(`[data-action="publish-choice"][data-question-id="${CSS.escape(question.questionId)}"]:checked`)).map((input) => input.value);
    state.responseDraft[question.questionId] = checked;
  } else {
    state.responseDraft[question.questionId] = event.currentTarget.value;
  }
  clearValidationError(question.questionId);
  if (shouldRerenderAfterAnswer(question.questionId)) {
    render();
    return;
  }
  updatePublishProgressUI();
}

  function onPublishRating(event) {
    event.preventDefault();
    if (isPreviewReadonly()) return;
    const questionId = event.currentTarget.dataset.questionId;
    state.responseDraft[questionId] = Number(event.currentTarget.dataset.value || 0);
    clearValidationError(questionId);
    render();
  }

  function onPublishFile(event) {
  if (isPreviewReadonly()) return;
  const questionId = event.currentTarget.dataset.questionId;
  const question = findQuestion(questionId);
  const files = Array.from(event.currentTarget.files || []);
  const validationError = validateUploadSelection(question, files);

  if (validationError) {
    state.responseDraft[questionId] = [];
    state.validationErrors = { ...(state.validationErrors || {}), [questionId]: validationError };
    event.currentTarget.value = '';
    render();
    return;
  }

  state.responseDraft[questionId] = files;
  clearValidationError(questionId);
  if (shouldRerenderAfterAnswer(questionId)) {
    render();
    return;
  }
  updatePublishProgressUI();
}

  function onPublishLikert(event) {
  if (isPreviewReadonly()) return;
  const questionId = event.currentTarget.dataset.questionId;
  const statement = event.currentTarget.dataset.statement;
  const current = state.responseDraft[questionId] && typeof state.responseDraft[questionId] === 'object' ? state.responseDraft[questionId] : {};
  state.responseDraft[questionId] = { ...current, [statement]: event.currentTarget.value };
  clearValidationError(questionId);
  if (shouldRerenderAfterAnswer(questionId)) {
    render();
    return;
  }
  updatePublishProgressUI();
}

  function onMoveRankingAnswer(event) {
    if (isPreviewReadonly()) return;
    const questionId = event.currentTarget.dataset.questionId;
    const direction = event.currentTarget.dataset.direction === 'up' ? -1 : 1;
    const question = findQuestion(questionId);
    if (!question) return;
    const current = Array.isArray(state.responseDraft[questionId]) && state.responseDraft[questionId].length ? state.responseDraft[questionId] : getQuestionOptions(question);
    moveInArray(current, Number(event.currentTarget.dataset.index), direction);
    state.responseDraft[questionId] = current.slice();
    clearValidationError(questionId);
    render();
  }

  function onPrevPage() {
    state.previewMessage = '';
    state.validationErrors = {};
    state.currentPageIndex = Math.max(0, state.currentPageIndex - 1);
    render();
  }

  async function onNextOrSubmit() {
    state.previewMessage = '';
    state.validationErrors = {};

    const sections = getPublishSections().sections;

    if (isPreviewReadonly()) {
      if (state.currentPageIndex < sections.length - 1) {
        state.currentPageIndex += 1;
        render();
        return;
      }
      state.mode = 'edit';
      state.currentPageIndex = 0;
      render();
      return;
    }

    const validationErrors = validateCurrentPage();
    if (validationErrors.length) {
      state.validationErrors = validationErrors.reduce((acc, error) => {
        acc[error.questionId] = error.message;
        return acc;
      }, {});
      state.previewMessage = 'Please fix the highlighted fields.';
      render();
      focusFirstValidationError();
      return;
    }

    const branchingTarget = resolveBranchingForCurrentPage();
    if (branchingTarget === '__submit__') {
      await completeSubmission();
      return;
    }

    const targetPageIndex = branchingTarget ? findPageIndexForQuestion(branchingTarget) : null;
    if (targetPageIndex !== null && targetPageIndex > state.currentPageIndex) {
      state.currentPageIndex = targetPageIndex;
      render();
      return;
    }

    if (state.currentPageIndex < sections.length - 1) {
      state.currentPageIndex += 1;
      render();
      return;
    }

    await completeSubmission();
  }

  function validateCurrentPage() {
  const { sections, logicState } = getPublishSections();
  const page = sections[state.currentPageIndex];
  if (!page) return [];
  const errors = [];
  page.questions.forEach((question) => {
    if (isQuestionHiddenByLogic(question.questionId, logicState)) return;
    const answer = state.responseDraft[question.questionId];
    const required = isQuestionRequiredByLogic(question, logicState);
    if (required && !hasAnswer(question, answer)) {
      errors.push({ questionId: question.questionId, message: `${question.title} is required.` });
      return;
    }
    const extraError = validateQuestionRestriction(question, answer);
    if (extraError) errors.push({ questionId: question.questionId, message: extraError });
  });
  return errors;
}

  function getPublishProgressQuestions(page = null) {
  const publishSections = getPublishSections();
  const activePage = page || publishSections.sections[state.currentPageIndex] || { questions: state.questions.filter((question) => question.type !== 'section') };
  return (activePage.questions || []).filter((question) => question && question.type !== 'section' && !isQuestionHiddenByLogic(question.questionId, publishSections.logicState));
}

function getPublishProgressMeta(page = null) {
  const publishSections = getPublishSections();
  const activePage = page || publishSections.sections[state.currentPageIndex] || { questions: state.questions.filter((question) => question.type !== 'section') };
  const trackedQuestions = (activePage.questions || []).filter((question) => question && question.type !== 'section' && !isQuestionHiddenByLogic(question.questionId, publishSections.logicState));
  const totalQuestions = trackedQuestions.length;
  const requiredQuestions = trackedQuestions.filter((question) => isQuestionRequiredByLogic(question, publishSections.logicState));

  if (!totalQuestions) {
    return {
      totalQuestions: 0,
      totalRequired: 0,
      answeredQuestions: 0,
      answeredRequired: 0,
      percentFilled: 0,
      percentRequired: 0,
      label: 'Answered 0/0',
      valueText: '0%',
    };
  }

  const answeredQuestions = trackedQuestions.filter((question) =>
    hasAnswer(question, state.responseDraft[question.questionId])
  );

  const answeredRequired = requiredQuestions.filter((question) =>
    hasAnswer(question, state.responseDraft[question.questionId])
  );

  const percentFilled = Math.max(
    0,
    Math.min(100, Math.round((answeredQuestions.length / totalQuestions) * 100))
  );

  const percentRequired = requiredQuestions.length
    ? Math.max(
      0,
      Math.min(100, Math.round((answeredRequired.length / requiredQuestions.length) * 100))
    )
    : 0;

  const label = requiredQuestions.length
    ? `Required ${answeredRequired.length}/${requiredQuestions.length} • Answered ${answeredQuestions.length}/${totalQuestions}`
    : `Answered ${answeredQuestions.length}/${totalQuestions}`;

  return {
    totalQuestions,
    totalRequired: requiredQuestions.length,
    answeredQuestions: answeredQuestions.length,
    answeredRequired: answeredRequired.length,
    percentFilled,
    percentRequired,
    label,
    valueText: `${percentFilled}%`,
  };
}

function updatePublishProgressUI() {
  const meta = getPublishProgressMeta();

  const progress = root.querySelector('.forms-progress');
  const requiredBar = root.querySelector('[data-role="forms-progress-bar-required"]');
  const filledBar = root.querySelector('[data-role="forms-progress-bar-filled"]');
  const value = root.querySelector('[data-role="forms-progress-value"]');
  const label = root.querySelector('[data-role="forms-progress-label"]');

  if (progress) {
    progress.dataset.hasRequired = meta.totalRequired > 0 ? '1' : '0';
    progress.setAttribute('aria-valuemin', '0');
    progress.setAttribute('aria-valuemax', '100');
    progress.setAttribute('aria-valuenow', String(meta.percentFilled));
  }

  if (requiredBar) {
    requiredBar.style.width = `${meta.percentRequired}%`;
    requiredBar.setAttribute('aria-hidden', 'true');
  }

  if (filledBar) {
    filledBar.style.width = `${meta.percentFilled}%`;
  }

  if (value) value.textContent = meta.valueText;
  if (label) label.textContent = meta.label;
}

  function hasAnswer(question, answer) {
    if (question.type === 'likert') return answer && typeof answer === 'object' && question.statements.every((statement) => !!answer[statement]);
    if (question.type === 'upload') return Array.isArray(answer) ? answer.length > 0 : !!answer;
    if (question.type === 'ranking') return Array.isArray(answer) ? answer.length > 0 : false;
    if (Array.isArray(answer)) return answer.length > 0;
    if (answer && typeof answer === 'object') return Object.keys(answer).length > 0;
    return answer !== null && typeof answer !== 'undefined' && String(answer).trim() !== '';
  }

  function validateQuestionRestriction(question, answer) {
    if (question.type === 'upload' && hasAnswer(question, answer)) {
      const files = Array.isArray(answer) ? answer : [answer];
      const uploadError = validateUploadSelection(question, files);
      if (uploadError) return uploadError;
      return '';
    }
    if (question.type !== 'text' || !question.restrictionEnabled || !hasAnswer(question, answer)) return '';
    const value = String(answer || '');
    const operator = question.restrictionOperator || '';
    const primary = question.restrictionValue || '';
    const secondary = question.restrictionValueSecondary || '';
    if (question.restrictionType === 'email' && !/^\S+@\S+\.\S+$/.test(value)) return `${question.title} must be a valid email address.`;
    if (question.restrictionType === 'number' || operator === 'min' || operator === 'max' || operator === 'between') {
      const numeric = Number(value);
      if (Number.isNaN(numeric)) return `${question.title} must be a number.`;
      if (operator === 'min' && numeric < Number(primary)) return `${question.title} must be at least ${primary}.`;
      if (operator === 'max' && numeric > Number(primary)) return `${question.title} must be at most ${primary}.`;
      if (operator === 'between') {
        const min = Number(primary); const max = Number(secondary);
        if (numeric < min || numeric > max) return `${question.title} must be between ${primary} and ${secondary}.`;
      }
    }
    if (question.restrictionType === 'length') {
      if (operator === 'min' && value.length < Number(primary)) return `${question.title} must be at least ${primary} characters.`;
      if (operator === 'max' && value.length > Number(primary)) return `${question.title} must be at most ${primary} characters.`;
      if (operator === 'between') {
        const min = Number(primary); const max = Number(secondary);
        if (value.length < min || value.length > max) return `${question.title} must be between ${primary} and ${secondary} characters.`;
      }
    }
    if (operator === 'equals' && value !== primary) return `${question.title} must equal ${primary}.`;
    if (operator === 'contains' && !value.includes(primary)) return `${question.title} must contain ${primary}.`;
    if ((question.restrictionType === 'regex' || operator === 'pattern') && primary) {
      try {
        const regex = new RegExp(primary);
        if (!regex.test(value)) return `${question.title} does not match the required pattern.`;
      } catch {
        return `${question.title} uses an invalid pattern.`;
      }
    }
    return '';
  }

  function resolveBranchingForCurrentPage() {
  const { sections } = getPublishSections();
  const page = sections[state.currentPageIndex];
  if (!page) return null;
  for (const question of page.questions) {
    if (!question.branching || !question.branchingRules.length) continue;
    const answer = state.responseDraft[question.questionId];
    for (const rawRule of question.branchingRules) {
      const rule = normalizeBranchRule(rawRule);
      if (rule.action !== 'jump') continue;
      if (matchesBranchRule(answer, rule)) return rule.target || '__next__';
    }
  }
  return null;
}

  function matchesBranchRule(answer, rule) {
  const normalizedRule = normalizeBranchRule(rule);
  const tokens = Array.isArray(answer)
    ? answer.map((item) => String(item ?? '').trim()).filter(Boolean)
    : (answer && typeof answer === 'object')
      ? Object.values(answer).map((item) => String(item ?? '').trim()).filter(Boolean)
      : [String(answer ?? '').trim()].filter(Boolean);
  const normalizedAnswer = tokens.join(' | ');
  const compareValue = String(normalizedRule.value || '').trim();
  switch (normalizedRule.operator) {
    case 'answered': return tokens.length > 0;
    case 'not_answered': return tokens.length === 0;
    case 'equals': return tokens.some((token) => token.toLowerCase() === compareValue.toLowerCase()) || normalizedAnswer.toLowerCase() === compareValue.toLowerCase();
    case 'not_equals': return tokens.length ? tokens.every((token) => token.toLowerCase() !== compareValue.toLowerCase()) && normalizedAnswer.toLowerCase() !== compareValue.toLowerCase() : true;
    case 'contains': return normalizedAnswer.toLowerCase().includes(compareValue.toLowerCase());
    case 'greater_than': return Number(tokens[0] ?? normalizedAnswer) > Number(compareValue);
    case 'less_than': return Number(tokens[0] ?? normalizedAnswer) < Number(compareValue);
    default: return false;
  }
}

  function findPageIndexForQuestion(questionId) {
  const publishSections = getPublishSections().sections;
  let index = publishSections.findIndex((section) => section.questions.some((question) => question.questionId === questionId));
  if (index >= 0) return index;
  const sections = getSections();
  index = sections.findIndex((section) => section.questions.some((question) => question.questionId === questionId));
  return index >= 0 ? index : null;
}

  async function completeSubmission(options = {}) {
    const { skipValidation = false, autoSubmitted = false } = options;
    const unavailable = getPublishAvailability();
    if (unavailable) {
      state.previewMessage = unavailable;
      render();
      return;
    }
    if (state.mode === 'preview') {
      state.submissionComplete = true;
      state.previewMessage = '';
      state.lastSubmissionScore = computeQuizScoreFromDraft();
      stopPublishTimer();
      render();
      return;
    }
    try {
      const formData = new FormData();
      const score = computeQuizScoreFromDraft();
      formData.set('formId', state.formId);
      formData.set('csrfToken', boot.csrfToken || '');
      if (state.editingResponseId) formData.set('responseId', state.editingResponseId);
      formData.set('responses', JSON.stringify(serializeResponsesForSubmit()));
      if (score) formData.set('score', JSON.stringify(score));
      Object.entries(state.responseDraft).forEach(([questionId, answer]) => {
        if (!Array.isArray(answer) || !answer.length || !(answer[0] instanceof File)) return;
        answer.forEach((file) => formData.append(`files[${questionId}][]`, file, file.name));
      });
      const response = await fetch(boot.submitUrl, { method: 'POST', body: formData, credentials: 'same-origin' });
      const payload = await response.json();
      if (!response.ok || !payload.success) throw new Error(payload.error || 'Submission failed');
      if (payload.responseId) state.editingResponseId = payload.responseId;
      if (payload.response) {
        payload.response.score = score;
        payload.response.autoSubmitted = autoSubmitted;
        const normalizedResponse = normalizeResponsesForEditor([payload.response], state.questions)[0] || payload.response;
        const existingIndex = state.responses.findIndex((item) => item.id === normalizedResponse.id);
        if (existingIndex >= 0) state.responses.splice(existingIndex, 1, normalizedResponse);
        else state.responses.unshift(normalizedResponse);
      }
      state.responseDraft = {};
      state.currentPageIndex = 0;
      state.previewMessage = '';
      state.submissionComplete = true;
      state.lastSubmissionScore = score;
      state.timerExpired = !!autoSubmitted;
      state.autoSubmitted = !!autoSubmitted;
      stopPublishTimer();
      render();
    } catch (error) {
      console.error(error);
      state.previewMessage = error.message || 'Unable to submit response.';
      render();
      toast(error.message || 'Unable to submit response', true);
    }
  }

  function serializeResponsesForSubmit() {
    const payload = {};
    state.questions.filter((question) => question.type !== 'section').forEach((question) => {
      let answer = state.responseDraft[question.questionId];
      if (typeof answer === 'undefined') return;
      if (question.type === 'upload') {
        if (Array.isArray(answer) && answer.length && answer[0] instanceof File) {
          payload[question.questionId] = answer.map((file) => ({ name: file.name, size: file.size, type: file.type }));
        } else {
          payload[question.questionId] = answer;
        }
      } else if (question.type === 'likert' && answer && typeof answer === 'object' && !Array.isArray(answer)) {
        payload[question.questionId] = Object.entries(answer).map(([statement, value]) => ({ statement, value }));
      } else {
        payload[question.questionId] = answer;
      }
    });
    return payload;
  }

  function onApplyTemplate(event) {
  const template = TEMPLATES.find((tpl) => tpl.id === event.currentTarget.dataset.templateId);
  if (!template) return;
  state.templateId = template.id;
  if (!confirm(`Replace current questions with the ${template.title} template?`)) return;

  state.questions = template.build().map(normalizeQuestion);
  state.isQuiz = !!template.quizMode;
  state.editorMode = true;
  state.mode = 'edit';

  const cardConfig = getTemplateCardConfig(template.id, template.quizMode ? 'quiz' : 'form');
  state.metadataStyles.accentColor = cardConfig.accentColor || state.metadataStyles.accentColor;
  state.metadataStyles.cardRadius = Number(cardConfig.cardRadius || state.metadataStyles.cardRadius || 18);
  state.metadataStyles.formWidth = Number(cardConfig.formWidth || state.metadataStyles.formWidth || 80);
  state.metadataStyles.background.startColor = cardConfig.backgroundStart || state.metadataStyles.background.startColor;
  state.metadataStyles.background.endColor = cardConfig.backgroundEnd || state.metadataStyles.background.endColor;
  if (typeof buildBackgroundStyle === 'function') {
    state.metadataStyles.background.style = buildBackgroundStyle(
      state.metadataStyles.background.startColor,
      state.metadataStyles.background.endColor,
      state.metadataStyles.background.direction || '180deg'
    );
  }
  state.metadataStyles.headerBanner = {
    enable: !!cardConfig.bannerImage,
    src: cardConfig.bannerImage || '',
    type: 'image',
    alt: cardConfig.bannerAlt || `${template.title} banner`,
  };

  recomputeSections();
  scheduleSave('template');
  render();
}

  function handleQuestionDragStart(event) {
    dragQuestionId = event.currentTarget.dataset.questionId;
    event.currentTarget.classList.add('is-dragging');
    event.dataTransfer.effectAllowed = 'move';
  }

  function handleQuestionDragOver(event) {
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
  }

  function handleQuestionDrop(event) {
    event.preventDefault();
    const targetId = event.currentTarget.dataset.questionId;
    if (!dragQuestionId || dragQuestionId === targetId) return;
    const from = state.questions.findIndex((q) => q.questionId === dragQuestionId);
    const to = state.questions.findIndex((q) => q.questionId === targetId);
    if (from < 0 || to < 0) return;
    const [item] = state.questions.splice(from, 1);
    state.questions.splice(to, 0, item);
    recomputeSections();
    scheduleSave('question order');
    render();
  }

  function handleQuestionDragEnd(event) {
    event.currentTarget.classList.remove('is-dragging');
    dragQuestionId = null;
  }

  function handleOptionDragStart(event) {
    dragOptionContext = {
      questionId: event.currentTarget.dataset.questionId,
      collection: event.currentTarget.dataset.collection,
      index: Number(event.currentTarget.dataset.index),
    };
    event.dataTransfer.effectAllowed = 'move';
  }

  function handleOptionDragOver(event) { event.preventDefault(); }

  function handleOptionDrop(event) {
    event.preventDefault();
    if (!dragOptionContext) return;
    const question = findQuestion(event.currentTarget.dataset.questionId);
    if (!question) return;
    const targetIndex = Number(event.currentTarget.dataset.index);
    if (question.questionId !== dragOptionContext.questionId || event.currentTarget.dataset.collection !== dragOptionContext.collection) return;
    const collection = question[dragOptionContext.collection];
    const [item] = collection.splice(dragOptionContext.index, 1);
    collection.splice(targetIndex, 0, item);
    scheduleSave('option order');
    render();
  }

  function handleOptionDragEnd() { dragOptionContext = null; }

  function handlePublishRankStart(event) {
    dragOptionContext = {
      questionId: event.currentTarget.dataset.questionId,
      collection: 'responseDraft',
      index: Number(event.currentTarget.dataset.index),
    };
    event.dataTransfer.effectAllowed = 'move';
  }

  function handlePublishRankOver(event) { event.preventDefault(); }

  function handlePublishRankDrop(event) {
    event.preventDefault();
    if (!dragOptionContext) return;
    const questionId = event.currentTarget.dataset.questionId;
    const targetIndex = Number(event.currentTarget.dataset.index);
    const question = findQuestion(questionId);
    if (!question || dragOptionContext.questionId !== questionId) return;
    const current = Array.isArray(state.responseDraft[questionId]) && state.responseDraft[questionId].length ? state.responseDraft[questionId] : getQuestionOptions(question);
    const [item] = current.splice(dragOptionContext.index, 1);
    current.splice(targetIndex, 0, item);
    state.responseDraft[questionId] = current;
    render();
  }

  function handlePublishRankEnd() { dragOptionContext = null; }

  function moveInArray(list, index, delta) {
    const target = index + delta;
    if (index < 0 || target < 0 || target >= list.length) return;
    const [item] = list.splice(index, 1);
    list.splice(target, 0, item);
  }

  function setPath(target, path, value) {
    const keys = path.split('.');
    let cursor = target;
    while (keys.length > 1) {
      const key = keys.shift();
      if (!(key in cursor) || typeof cursor[key] !== 'object' || cursor[key] === null) cursor[key] = {};
      cursor = cursor[key];
    }
    cursor[keys[0]] = value;
  }

  function getPath(target, path) {
    return path.split('.').reduce((acc, key) => acc && typeof acc === 'object' ? acc[key] : undefined, target);
  }

  async function postJSON(url, body) {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest' },
      credentials: 'same-origin',
      body: new URLSearchParams(Object.entries(body).map(([key, value]) => [key, typeof value === 'string' ? value : JSON.stringify(value)])),
    });
    const payload = await response.json();
    if (!response.ok || !payload.success) throw new Error(payload.error || 'Request failed');
    return payload;
  }

  async function postForm(url, data) {
    const formData = new FormData();
    Object.entries(data).forEach(([key, value]) => {
      if (key === 'questions' && Array.isArray(value)) {
        value.forEach((question, qIndex) => {
          Object.entries(question).forEach(([field, fieldValue]) => {
            if (Array.isArray(fieldValue)) {
              formData.append(`questions[${qIndex}][${field}]`, JSON.stringify(fieldValue));
            } else {
              formData.append(`questions[${qIndex}][${field}]`, fieldValue);
            }
          });
        });
      } else {
        formData.append(key, value);
      }
    });
    const response = await fetch(url, { method: 'POST', body: formData, credentials: 'same-origin' });
    return response.json();
  }

  function parseDate(value) {
    if (!value) return null;
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? null : date;
  }

  function formatDateTime(value) {
    const date = parseDate(value);
    return date ? date.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }) : '';
  }

  function toDatetimeLocal(value) {
    const date = parseDate(value);
    if (!date) return '';
    const pad = (num) => String(num).padStart(2, '0');
    return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(date.getHours())}:${pad(date.getMinutes())}`;
  }

  function fromDatetimeLocal(value) {
    if (!value) return '';
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? '' : date.toISOString();
  }

  function isPlainObjectValue(value) {
    return !!value && typeof value === 'object' && !Array.isArray(value);
  }

  function isIsoDateString(value) {
    if (typeof value !== 'string') return false;
    const raw = value.trim();
    if (!raw) return false;
    return /^\d{4}-\d{2}-\d{2}$/.test(raw)
      || /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(:\d{2}(?:\.\d{1,3})?)?(?:Z|[+-]\d{2}:?\d{2})?$/.test(raw);
  }

  function formatDateOnly(value) {
    if (!value) return '';
    const raw = String(value).trim();
    if (!raw) return '';
    const date = /^\d{4}-\d{2}-\d{2}$/.test(raw) ? new Date(`${raw}T00:00:00`) : parseDate(raw);
    return date ? date.toLocaleDateString([], { dateStyle: 'medium' }) : raw;
  }

  function formatBytes(value) {
    const bytes = Number(value || 0);
    if (!Number.isFinite(bytes) || bytes <= 0) return '';
    const units = ['B', 'KB', 'MB', 'GB', 'TB'];
    let index = 0;
    let size = bytes;
    while (size >= 1024 && index < units.length - 1) {
      size /= 1024;
      index += 1;
    }
    const precision = size >= 10 || index === 0 ? 0 : 1;
    return `${size.toFixed(precision)} ${units[index]}`;
  }

  function getUploadLink(value) {
    if (!isPlainObjectValue(value)) return '';
    const candidates = ['url', 'href', 'destination', 'downloadUrl', 'path', 'src'];
    for (const key of candidates) {
      const current = value[key];
      if (typeof current === 'string' && current.trim()) return current.trim();
    }
    return '';
  }

  function getFileIconInfo(name = '', mimeType = '') {
    const safeName = String(name || '').toLowerCase();
    const safeMime = String(mimeType || '').toLowerCase();
    const extension = safeName.includes('.') ? safeName.split('.').pop() : '';

    if (safeMime.includes('pdf') || extension === 'pdf') return { label: 'PDF', className: 'is-pdf' };
    if (safeMime.includes('word') || ['doc', 'docx', 'odt', 'rtf'].includes(extension)) return { label: 'DOC', className: 'is-doc' };
    if (safeMime.includes('sheet') || safeMime.includes('excel') || ['xls', 'xlsx', 'csv', 'ods'].includes(extension)) return { label: 'XLS', className: 'is-sheet' };
    if (safeMime.includes('presentation') || ['ppt', 'pptx', 'odp'].includes(extension)) return { label: 'PPT', className: 'is-slide' };
    if (safeMime.startsWith('image/') || ['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'bmp'].includes(extension)) return { label: 'IMG', className: 'is-image' };
    if (safeMime.startsWith('audio/') || ['mp3', 'wav', 'aac', 'ogg', 'm4a'].includes(extension)) return { label: 'AUD', className: 'is-audio' };
    if (safeMime.startsWith('video/') || ['mp4', 'mov', 'avi', 'webm', 'mkv'].includes(extension)) return { label: 'VID', className: 'is-video' };
    if (safeMime.includes('zip') || safeMime.includes('compressed') || ['zip', 'rar', '7z', 'tar', 'gz'].includes(extension)) return { label: 'ZIP', className: 'is-archive' };
    if (safeMime.includes('text/') || ['txt', 'md', 'log'].includes(extension)) return { label: 'TXT', className: 'is-text' };
    return { label: 'FILE', className: 'is-file' };
  }

  function renderPrimitiveAnswer(value) {
    const formatted = formatAnswerValue(value);
    return formatted ? `<span class="forms-response-inline-text">${escapeHtml(formatted)}</span>` : '';
  }

  function renderLikertAnswerList(items) {
    const rows = items
      .map((item) => {
        const statement = formatAnswerValue(item?.statement ?? '');
        const selected = formatAnswerValue(item?.value ?? '');
        if (!statement && !selected) return '';
        return `
          <div class="forms-response-kv-item">
            <span class="forms-response-kv-key">${escapeHtml(statement || 'Response')}</span>
            <span class="forms-response-kv-value">${escapeHtml(selected || '—')}</span>
          </div>
        `;
      })
      .filter(Boolean)
      .join('');

    return rows ? `<div class="forms-response-kv-list">${rows}</div>` : '';
  }

  function renderUploadItem(file) {
    if (!isPlainObjectValue(file)) return '';

    const fileName = formatAnswerValue(file.name || file.fileName || 'Attachment');
    const fileType = formatAnswerValue(file.type || file.mimeType || '');
    const sizeLabel = formatBytes(file.size || file.fileSize || 0);
    const meta = [fileType, sizeLabel].filter(Boolean).join(' • ');
    const link = getUploadLink(file);
    const icon = getFileIconInfo(fileName, file.type || file.mimeType || '');

    const titleMarkup = link
      ? `<a class="forms-upload-name" href="${escapeAttribute(link)}" target="_blank" rel="noopener noreferrer" download>${escapeHtml(fileName)}</a>`
      : `<span class="forms-upload-name">${escapeHtml(fileName)}</span>`;

    const actionMarkup = link
      ? `<a class="forms-upload-action" href="${escapeAttribute(link)}" target="_blank" rel="noopener noreferrer" download>Download</a>`
      : '';

    return `
      <div class="forms-upload-item">
        <div class="forms-upload-main">
          <span class="forms-file-icon ${icon.className}" aria-hidden="true">${escapeHtml(icon.label)}</span>
          <div class="forms-upload-copy">
            ${titleMarkup}
            ${meta ? `<div class="forms-upload-meta">${escapeHtml(meta)}</div>` : ''}
          </div>
        </div>
        ${actionMarkup}
      </div>
    `;
  }

  function renderUploadAnswerList(items) {
    const markup = items.map(renderUploadItem).filter(Boolean).join('');
    return markup ? `<div class="forms-upload-list">${markup}</div>` : '';
  }

  function renderObjectAnswer(value) {
    if (!isPlainObjectValue(value)) return '';

    const rows = Object.entries(value)
      .map(([key, item]) => {
        const label = formatAnswerValue(key);
        const renderedValue = renderPrimitiveAnswer(item);
        if (!label && !renderedValue) return '';
        return `
          <div class="forms-response-kv-item">
            <span class="forms-response-kv-key">${escapeHtml(label || 'Response')}</span>
            <span class="forms-response-kv-value">${renderedValue || '<span class=\"forms-response-empty\">—</span>'}</span>
          </div>
        `;
      })
      .filter(Boolean)
      .join('');

    return rows ? `<div class="forms-response-kv-list">${rows}</div>` : '';
  }

  function renderResponseAnswerValue(value) {
    if (value === null || typeof value === 'undefined') return '';

    if (Array.isArray(value)) {
      const uploadMarkup = value.length && value.every((item) => isPlainObjectValue(item) && (item.name || item.fileName));
      if (uploadMarkup) return renderUploadAnswerList(value);

      const likertMarkup = value.length && value.every((item) => isPlainObjectValue(item) && (Object.prototype.hasOwnProperty.call(item, 'statement') || Object.prototype.hasOwnProperty.call(item, 'value')));
      if (likertMarkup) return renderLikertAnswerList(value);

      const primitiveOnly = value.every((item) => !Array.isArray(item) && !isPlainObjectValue(item));
      if (primitiveOnly) return renderPrimitiveAnswer(value.map((item) => formatAnswerValue(item)).filter(Boolean).join(', '));

      const nestedMarkup = value.map((item) => renderResponseAnswerValue(item)).filter(Boolean).join('');
      return nestedMarkup ? `<div class="forms-response-nested-list">${nestedMarkup}</div>` : '';
    }

    if (isPlainObjectValue(value)) {
      if (value.name || value.fileName) return renderUploadAnswerList([value]);
      return renderObjectAnswer(value);
    }

    return renderPrimitiveAnswer(value);
  }

  function renderResponseAnswerValues(values) {
    const list = Array.isArray(values) ? values : [values];
    const primitiveOnly = list.every((item) => !Array.isArray(item) && !isPlainObjectValue(item));

    if (primitiveOnly) {
      const joined = list.map((item) => formatAnswerValue(item)).filter(Boolean).join(', ');
      return joined ? `<span class="forms-response-inline-text">${escapeHtml(joined)}</span>` : '<span class="forms-response-empty">—</span>';
    }

    const rendered = list.map((item) => renderResponseAnswerValue(item)).filter(Boolean).join('');
    return rendered || '<span class="forms-response-empty">—</span>';
  }

  function formatAnswerValue(value) {
    if (value === null || typeof value === 'undefined') return '';

    if (typeof value === 'string') {
      const trimmed = value.trim();
      if (!trimmed) return '';
      if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) return formatDateOnly(trimmed);
      if (isIsoDateString(trimmed)) return formatDateTime(trimmed);
      return trimmed;
    }

    if (typeof value === 'number' || typeof value === 'boolean') return String(value);
    if (value instanceof Date) return formatDateTime(value.toISOString());

    if (isPlainObjectValue(value) && (value.statement || value.value || value.name || value.fileName)) {
      return [value.statement, value.value, value.name || value.fileName].map((item) => formatAnswerValue(item)).filter(Boolean).join(': ');
    }

    try {
      return JSON.stringify(value);
    } catch {
      return String(value ?? '');
    }
  }

  function slugify(value) {
    return String(value || '').toLowerCase().replace(/[^a-z0-9]+/g, '-');
  }

  function escapeHtml(value) {
    return String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function escapeAttribute(value) {
    return escapeHtml(value).replace(/`/g, '&#96;');
  }

  function camelToKebab(value) {
    return value.replace(/[A-Z]/g, (match) => `-${match.toLowerCase()}`);
  }

  function capitalize(value) {
    return String(value || '').charAt(0).toUpperCase() + String(value || '').slice(1);
  }

  function toast(title, isError = false, description = '') {
    if (els.toast) els.toast.remove();
    clearTimeout(toastTimer);
    const node = document.createElement('div');
    node.className = `forms-toast ${isError ? 'is-error' : 'is-success'}`;
    node.innerHTML = `<div style="font-size:22px;">${isError ? '⚠️' : '✅'}</div><div><strong>${escapeHtml(title)}</strong>${description ? `<div class="forms-subtle" style="margin-top:4px;">${escapeHtml(description)}</div>` : ''}</div>`;
    document.body.appendChild(node);
    els.toast = node;
    toastTimer = setTimeout(() => {
      node.remove();
      if (els.toast === node) els.toast = null;
    }, 4200);
  }
})();

