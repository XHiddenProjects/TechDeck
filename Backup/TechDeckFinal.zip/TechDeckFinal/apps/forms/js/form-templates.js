(() => {
  const TEMPLATE_CARD_SELECTOR = '.forms-index-template-card[data-template-id]';
  const TEMPLATE_USE_SELECTOR = '[data-template-use]';
  const NEW_FORM_SELECTOR = '.form-btn-new-form';
  const NEW_QUIZ_SELECTOR = '.form-btn-new-quiz';
  const ACTIVE_CLASS = 'is-active';
  const STYLE_ID = 'forms-template-runtime-styles';

  const TEMPLATE_LIBRARY = {
    feedback: {
      kind: 'form',
      title: 'Customer feedback',
      description: 'Collect experience, rating, NPS, and open feedback.',
      accentColor: '#2563eb',
      backgroundStart: '#f5f8fc',
      backgroundEnd: '#eef2ff',
      cardRadius: 18,
      formWidth: 80,
      previewBanner: 'feedback',
      bannerImage: 'https://images.unsplash.com/photo-1556740749-887f6717d7e4?auto=format&fit=crop&w=1600&q=80',
      bannerAlt: 'Customer service banner image',
      previewFields: ['choice', 'rating', 'textarea', 'chips'],
      questions: [
        { type: 'section', title: 'Visit overview', description: 'Tell us about your recent visit and how things felt.' },
        { type: 'choice', title: 'Which service did you use today?', required: true, options: ['Support', 'Sales', 'Billing', 'Other'], mediaUrl: '', mediaType: 'image', mediaAlt: '' },
        { type: 'rating', title: 'How would you rate your experience?', required: true, maxRating: 5 },
        { type: 'nps', title: 'How likely are you to recommend us?', required: true },
        { type: 'text', title: 'What could we improve?', textMode: 'long' }
      ]
    },
    event: {
      kind: 'form',
      title: 'Event registration',
      description: 'Register attendees, collect uploads, and capture preferences.',
      accentColor: '#f97316',
      backgroundStart: '#fff8f1',
      backgroundEnd: '#fff1e6',
      cardRadius: 20,
      formWidth: 82,
      previewBanner: 'event',
      bannerImage: 'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=1600&q=80',
      bannerAlt: 'Event registration banner image',
      previewFields: ['text', 'date', 'upload', 'chips'],
      questions: [
        { type: 'section', title: 'Attendee details', description: 'The essentials for your registration.' },
        { type: 'text', title: 'Full name', required: true, mediaUrl: '', mediaType: 'image', mediaAlt: '' },
        { type: 'text', title: 'Email address', required: true, restrictionEnabled: true, restrictionType: 'email', restrictionOperator: 'valid' },
        { type: 'date', title: 'Preferred session date', required: true },
        { type: 'upload', title: 'Upload your attendee document', required: false, fileAccept: '.pdf,.doc,.docx,.png,.jpg,.jpeg' },
        { type: 'choice', title: 'Meal preference', options: ['Standard', 'Vegetarian', 'Vegan', 'Gluten-free'] }
      ]
    },
    'support-ticket': {
      kind: 'form',
      title: 'Support ticket',
      description: 'Capture issue details, priority, screenshots, and routing info.',
      accentColor: '#1d4ed8',
      backgroundStart: '#f6f9ff',
      backgroundEnd: '#eef4ff',
      cardRadius: 18,
      formWidth: 78,
      previewBanner: 'support',
      bannerImage: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1600&q=80',
      bannerAlt: 'Support ticket banner image',
      previewFields: ['select', 'textarea', 'upload', 'cta'],
      questions: [
        {type: 'section',title: 'Issue details',description: 'Help the team triage the issue faster.'},
        {questionId: 'support_requester_name',type: 'text',title: 'Requester name',required: true,mediaUrl: '',mediaType: 'image',mediaAlt: ''},
        {questionId: 'support_contact_email',type: 'text',title: 'Contact email',required: true,restrictionEnabled: true,restrictionType: 'email',restrictionOperator: 'valid'},
        {questionId: 'support_priority',type: 'choice',title: 'Priority',required: true,options: ['Low', 'Medium', 'High', 'Critical']},
        {questionId: 'support_affected_area',type: 'choice',title: 'Affected area',required: true,options: ['Login', 'Billing', 'Reporting', 'Integrations', 'Other'],branching: true,
          branchingRules: [
            {
              operator: 'not_answered',
              action: 'hide',
              targetQuestionId: 'support_other_affected_area'
            },
            {
              operator: 'not_equals',
              value: 'Other',
              action: 'hide',
              targetQuestionId: 'support_other_affected_area'
            },
            {
              operator: 'equals',
              value: 'Other',
              action: 'show',
              targetQuestionId: 'support_other_affected_area'
            }
          ]
        },
        {questionId: 'support_other_affected_area',type: 'text',title: 'Other affected area',required: true},
        {questionId: 'support_issue_description',type: 'text',title: 'Describe the issue',required: true,textMode: 'long'},
        {questionId: 'support_attachment',type: 'upload',title: 'Attach screenshot or log file',multipleFiles: true,fileAccept: '.png,.jpg,.jpeg,.pdf,.txt,.log,.zip',fileMaxSize: '100MB'}
      ]
    },
    'employee-pulse': {
      kind: 'form',
      title: 'Employee pulse',
      description: 'Quick engagement, workload, and manager support check-in.',
      accentColor: '#10b981',
      backgroundStart: '#f0fdf8',
      backgroundEnd: '#ecfdf3',
      cardRadius: 20,
      formWidth: 76,
      previewBanner: 'pulse',
      bannerImage: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1600&q=80',
      bannerAlt: 'Employee pulse banner image',
      previewFields: ['rating', 'choice', 'textarea', 'cta'],
      questions: [
        { type: 'section', title: 'How work feels this week', description: 'A lightweight pulse survey for your team.' },
        { type: 'rating', title: 'How manageable is your workload right now?', required: true, maxRating: 5 },
        { type: 'choice', title: 'How connected do you feel to team priorities?', required: true, options: ['Very connected', 'Mostly connected', 'Somewhat connected', 'Not connected'], mediaUrl: '', mediaType: 'image', mediaAlt: '' },
        { type: 'rating', title: 'How supported do you feel by your manager?', required: true, maxRating: 5 },
        { type: 'text', title: 'What is making your work harder?', textMode: 'long' }
      ]
    },
    contact: {
      kind: 'form',
      title: 'Contact request',
      description: 'Lead capture with routing, message, and preferred contact method.',
      accentColor: '#ec4899',
      backgroundStart: '#fff7fb',
      backgroundEnd: '#fdf2f8',
      cardRadius: 22,
      formWidth: 74,
      previewBanner: 'contact',
      bannerImage: 'https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=1600&q=80',
      bannerAlt: 'Contact request banner image',
      previewFields: ['text', 'textarea', 'chips', 'cta'],
      questions: [
        { type: 'section', title: 'Contact request', description: 'A polished intake flow for demo requests or contact pages.' },
        { type: 'text', title: 'Full name', required: true, mediaUrl: '', mediaType: 'image', mediaAlt: '' },
        { type: 'text', title: 'Work email', required: true, restrictionEnabled: true, restrictionType: 'email', restrictionOperator: 'valid' },
        { type: 'choice', title: 'What can we help with?', required: true, options: ['Request a demo', 'Pricing question', 'Technical question', 'Partnership'] },
        { type: 'text', title: 'Message', required: true, textMode: 'long' },
        { type: 'choice', title: 'Preferred contact method', options: ['Email', 'Phone', 'Teams meeting'] }
      ]
    },
    'job-application': {
      kind: 'form',
      title: 'Job application',
      description: 'Collect candidate information, resume uploads, and start dates.',
      accentColor: '#0f172a',
      backgroundStart: '#f8fafc',
      backgroundEnd: '#f1f5f9',
      cardRadius: 18,
      formWidth: 80,
      previewBanner: 'job',
      bannerImage: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=1600&q=80',
      bannerAlt: 'Job application banner image',
      previewFields: ['text', 'upload', 'date', 'cta'],
      questions: [
        { type: 'section', title: 'Candidate profile', description: 'The essentials for a fast first review.' },
        { type: 'text', title: 'Full name', required: true, mediaUrl: '', mediaType: 'image', mediaAlt: '' },
        { type: 'text', title: 'Email address', required: true, restrictionEnabled: true, restrictionType: 'email', restrictionOperator: 'valid' },
        { type: 'text', title: 'LinkedIn or portfolio URL' },
        { type: 'upload', title: 'Resume / CV', required: true, fileAccept: '.pdf,.doc,.docx' },
        { type: 'choice', title: 'Years of experience', required: true, options: ['0–2', '3–5', '6–8', '9+'] },
        { type: 'date', title: 'When could you start?' }
      ]
    },
    'order-request': {
      kind: 'form',
      title: 'Order request',
      description: 'Capture request details, priorities, and delivery timing.',
      accentColor: '#f59e0b',
      backgroundStart: '#fffbeb',
      backgroundEnd: '#fef3c7',
      cardRadius: 18,
      formWidth: 78,
      previewBanner: 'order',
      bannerImage: 'https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=1600&q=80',
      bannerAlt: 'Order request banner image',
      previewFields: ['select', 'chips', 'textarea', 'cta'],
      questions: [
        { type: 'section', title: 'Request details', description: 'A structured request form for products or internal orders.' },
        { type: 'text', title: 'Requester name', required: true },
        { type: 'choice', title: 'Department', required: true, options: ['Operations', 'Sales', 'Finance', 'Marketing', 'IT'], mediaUrl: '', mediaType: 'image', mediaAlt: '' },
        { type: 'choice', title: 'Request type', required: true, options: ['New order', 'Replacement', 'Restock', 'Urgent request'] },
        { type: 'ranking', title: 'Which items are highest priority?', options: ['Laptop', 'Monitor', 'Dock', 'Headset', 'Accessories'] },
        { type: 'text', title: 'Order details', required: true, textMode: 'long' }
      ]
    },

    'vendor-onboarding': {
      kind: 'form',
      title: 'Vendor onboarding',
      description: 'Collect compliance docs, service scope, approvers, and launch details.',
      accentColor: '#0ea5e9',
      backgroundStart: '#f0f9ff',
      backgroundEnd: '#e0f2fe',
      cardRadius: 20,
      formWidth: 82,
      previewBanner: 'contact',
      bannerImage: 'https://images.unsplash.com/photo-1556742502-ec7c0e9f34b1?auto=format&fit=crop&w=1600&q=80',
      bannerAlt: 'Vendor onboarding banner image',
      previewFields: ['text', 'upload', 'chips', 'cta'],
      questions: [
        { type: 'section', title: 'Supplier profile', description: 'Capture the legal, operational, and launch details for a new supplier.' },
        { type: 'text', title: 'Legal company name', required: true, mediaUrl: '', mediaType: 'image', mediaAlt: '' },
        { type: 'text', title: 'Primary contact email', required: true, restrictionEnabled: true, restrictionType: 'email', restrictionOperator: 'valid' },
        { type: 'choice', title: 'Vendor category', required: true, options: ['Software', 'Professional services', 'Logistics', 'Manufacturing', 'Other'] },
        { type: 'upload', title: 'Upload W-9, COI, or compliance packet', required: true, multipleFiles: true, fileAccept: '.pdf,.doc,.docx,.png,.jpg,.jpeg' },
        { type: 'ranking', title: 'Rank the launch priorities', options: ['Security review', 'Procurement approval', 'Legal review', 'Systems access', 'Go-live date'] },
        { type: 'text', title: 'Statement of work / onboarding notes', required: true, textMode: 'long' }
      ]
    },
    'incident-report': {
      kind: 'form',
      title: 'Incident report',
      description: 'Capture severity, impacted systems, evidence, and follow-up actions.',
      accentColor: '#dc2626',
      backgroundStart: '#fef2f2',
      backgroundEnd: '#fee2e2',
      cardRadius: 18,
      formWidth: 80,
      previewBanner: 'support',
      bannerImage: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1600&q=80',
      bannerAlt: 'Incident report banner image',
      previewFields: ['choice', 'textarea', 'upload', 'cta'],
      questions: [
        { type: 'section', title: 'Incident intake', description: 'A detailed intake for operational, IT, or security incidents.' },
        { type: 'text', title: 'Reporter name', required: true, mediaUrl: '', mediaType: 'image', mediaAlt: '' },
        { type: 'text', title: 'Reporter email', required: true, restrictionEnabled: true, restrictionType: 'email', restrictionOperator: 'valid' },
        { type: 'date', title: 'Date discovered', required: true },
        { type: 'choice', title: 'Severity level', required: true, options: ['Low', 'Medium', 'High', 'Critical'] },
        { type: 'choice', title: 'Was customer data involved?', required: true, options: ['No', 'Unsure', 'Yes'] },
        { type: 'ranking', title: 'Rank impacted systems by urgency', options: ['Authentication', 'Billing', 'Reporting', 'API / Integrations', 'End-user devices'] },
        { type: 'upload', title: 'Attach screenshots, logs, or evidence', multipleFiles: true, fileAccept: '.png,.jpg,.jpeg,.pdf,.txt,.log,.zip' },
        { type: 'text', title: 'Incident narrative and containment steps', required: true, textMode: 'long' }
      ]
    },
    'travel-request': {
      kind: 'form',
      title: 'Travel request',
      description: 'Collect itinerary details, estimated cost, approvals, and support needs.',
      accentColor: '#0f766e',
      backgroundStart: '#f0fdfa',
      backgroundEnd: '#ccfbf1',
      cardRadius: 22,
      formWidth: 78,
      previewBanner: 'event',
      bannerImage: 'https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&w=1600&q=80',
      bannerAlt: 'Travel request banner image',
      previewFields: ['date', 'text', 'chips', 'textarea'],
      questions: [
        { type: 'section', title: 'Trip request', description: 'An approval-ready template for internal travel planning.' },
        { type: 'text', title: 'Traveler name', required: true, mediaUrl: '', mediaType: 'image', mediaAlt: '' },
        { type: 'text', title: 'Work email', required: true, restrictionEnabled: true, restrictionType: 'email', restrictionOperator: 'valid' },
        { type: 'date', title: 'Departure date', required: true },
        { type: 'date', title: 'Return date', required: true },
        { type: 'choice', title: 'Primary trip purpose', required: true, options: ['Client meeting', 'Conference', 'Training', 'Site visit', 'Internal offsite'] },
        { type: 'choice', title: 'Travel support needed', options: ['Flight', 'Hotel', 'Rental car', 'Visa support', 'None'] },
        { type: 'ranking', title: 'Rank the booking priorities', options: ['Lowest cost', 'Shortest travel time', 'Preferred airline', 'Refundable fare', 'Hotel near venue'] },
        { type: 'upload', title: 'Attach agenda, quote, or invitation', fileAccept: '.pdf,.doc,.docx,.png,.jpg,.jpeg' },
        { type: 'text', title: 'Business justification', required: true, textMode: 'long' }
      ]
    },
    'maintenance-request': {
      kind: 'form',
      title: 'Maintenance request',
      description: 'Log facility issues, access constraints, photos, and desired completion timing.',
      accentColor: '#7c3aed',
      backgroundStart: '#f5f3ff',
      backgroundEnd: '#ede9fe',
      cardRadius: 19,
      formWidth: 76,
      previewBanner: 'order',
      bannerImage: 'https://images.unsplash.com/photo-1581092921461-eab62e97a780?auto=format&fit=crop&w=1600&q=80',
      bannerAlt: 'Maintenance request banner image',
      previewFields: ['select', 'upload', 'textarea', 'cta'],
      questions: [
        { type: 'section', title: 'Issue details', description: 'A flexible request form with lighter restrictions for facilities teams.' },
        { type: 'text', title: 'Requester name', required: true, mediaUrl: '', mediaType: 'image', mediaAlt: '' },
        { type: 'choice', title: 'Building / location', required: true, options: ['HQ', 'Warehouse', 'Storefront', 'Remote office', 'Other'] },
        { type: 'text', title: 'Other location details (floor, room number, etc.)', required: true },
        { type: 'choice', title: 'Issue category', required: true, options: ['Electrical', 'HVAC', 'Plumbing', 'Safety', 'Furniture', 'Other'] },
        { type: 'text', title: 'Room, zone, or equipment ID' },
        { type: 'choice', title: 'Can work be completed after hours?', options: ['Yes', 'No', 'Either works'] },
        { type: 'upload', title: 'Upload photos or reference files', multipleFiles: true, fileAccept: '.png,.jpg,.jpeg,.pdf' },
        { type: 'date', title: 'Preferred completion date' },
        { type: 'text', title: 'Describe the issue', required: true, textMode: 'long' }
      ]
    },
    'training-evaluation': {
      kind: 'form',
      title: 'Training evaluation',
      description: 'Measure relevance, confidence, follow-up topics, and practical readiness.',
      accentColor: '#14b8a6',
      backgroundStart: '#f0fdfa',
      backgroundEnd: '#e6fffb',
      cardRadius: 20,
      formWidth: 74,
      previewBanner: 'pulse',
      bannerImage: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1600&q=80',
      bannerAlt: 'Training evaluation banner image',
      previewFields: ['rating', 'choice', 'textarea', 'chips'],
      questions: [
        { type: 'section', title: 'Session feedback', description: 'A lower-friction evaluation for workshops, enablement, and onboarding sessions.' },
        { type: 'text', title: 'Session or workshop name', required: true, mediaUrl: '', mediaType: 'image', mediaAlt: '' },
        { type: 'rating', title: 'How relevant was the content to your role?', required: true, maxRating: 5 },
        { type: 'rating', title: 'How confident do you feel applying what you learned?', required: true, maxRating: 5 },
        { type: 'choice', title: 'Would you recommend this training to teammates?', required: true, options: ['Definitely', 'Maybe', 'Not right now'] },
        { type: 'ranking', title: 'Rank the topics you want more of', options: ['Hands-on practice', 'Reference materials', 'Advanced examples', 'Troubleshooting', 'Manager coaching'] },
        { type: 'text', title: 'What should change for the next session?', textMode: 'long' }
      ]
    },
    'advanced-it-assessment': {
      kind: 'quiz',
      title: 'Advanced IT sectioned assessment',
      description: 'An advanced multi-part IT quiz with sections for networking, hardware, software, IoT, cloud, cybersecurity, help desk, databases, and privacy.',
      previewTitle: 'Advanced IT assessment',
      previewDescription: 'Networking, hardware, cloud, security, databases, and privacy.',
      accentColor: '#1d4ed8',
      backgroundStart: '#eff6ff',
      backgroundEnd: '#dbeafe',
      cardRadius: 22,
      formWidth: 82,
      previewBanner: 'advanced-it',
      bannerImage: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=1600&q=80',
      bannerAlt: 'Advanced IT sectioned assessment banner image',
      previewFields: ['choice', 'rating', 'textarea', 'cta'],
      questions: [
        { type: 'section', title: 'Section 1 · Networking', description: 'Advanced routing, segmentation, and network operations fundamentals.' },
        { type: 'choice', title: 'Which protocol is primarily used to dynamically assign IP addresses on enterprise networks?', required: true, options: ['DNS', 'DHCP', 'NTP', 'SNMP'], pointValue: 10, correctAnswers: ['DHCP'], mediaUrl: '', mediaType: 'image', mediaAlt: '' },
        { type: 'choice', title: 'Which design most effectively reduces broadcast traffic between departments?', required: true, options: ['Flat network', 'VLAN segmentation', 'Shared hub', 'Single SSID without segmentation'], pointValue: 10, correctAnswers: ['VLAN segmentation'] },
        { type: 'text', title: 'A remote site reports intermittent packet loss during peak hours. What would you check first and why?', required: true, textMode: 'long', pointValue: 20, acceptedAnswers: ['Review interface utilization, errors, and congestion on the WAN path before escalating'] },

        { type: 'section', title: 'Section 2 · Hardware', description: 'Enterprise endpoints, diagnostics, and component planning.' },
        { type: 'choice', title: 'Which storage medium is best aligned with fast boot times and low-latency endpoint performance?', required: true, options: ['Mechanical HDD', 'SSD / NVMe', 'Optical media', 'Tape'], pointValue: 10, correctAnswers: ['SSD / NVMe'], mediaUrl: '', mediaType: 'image', mediaAlt: '' },
        { type: 'choice', title: 'What is the safest first step before replacing memory in a workstation?', required: true, options: ['Increase fan speed', 'Ground yourself to prevent ESD', 'Disable Bluetooth', 'Change monitor input'], pointValue: 10, correctAnswers: ['Ground yourself to prevent ESD'] },
        { type: 'text', title: 'A workstation randomly reboots under load. Outline an advanced hardware triage plan.', required: true, textMode: 'long', pointValue: 20, acceptedAnswers: ['Check thermal conditions, power stability, memory diagnostics, event logs, and component isolation'] },

        { type: 'section', title: 'Section 3 · Software', description: 'Patch management, deployment risk, and application support.' },
        { type: 'choice', title: 'Which practice most reduces enterprise software vulnerability exposure?', required: true, options: ['Delay all updates', 'Apply updates and patches promptly', 'Duplicate security agents', 'Disable logging'], pointValue: 10, correctAnswers: ['Apply updates and patches promptly'] },
        { type: 'choice', title: 'Which rollout strategy best limits blast radius for a major application update?', required: true, options: ['Global deployment at once', 'Pilot deployment with rollback plan', 'Manual install without testing', 'Disable monitoring during rollout'], pointValue: 10, correctAnswers: ['Pilot deployment with rollback plan'] },
        { type: 'text', title: 'A business-critical app crashes after a patch. Describe your immediate stabilization workflow.', required: true, textMode: 'long', pointValue: 20, acceptedAnswers: ['Confirm impact, collect logs, isolate the patch relationship, consider rollback, and communicate status'] },

        { type: 'section', title: 'Section 4 · IoT', description: 'Connected device risk, segmentation, and operational governance.' },
        { type: 'choice', title: 'Why must default credentials be changed on IoT devices during deployment?', required: true, options: ['To improve battery life', 'To reduce unauthorized access risk', 'To increase bandwidth', 'To enable guest access'], pointValue: 10, correctAnswers: ['To reduce unauthorized access risk'] },
        { type: 'choice', title: 'Which network approach is best for isolating smart devices from critical systems?', required: true, options: ['Flat shared network', 'Segmented VLAN or separate network', 'Shared admin subnet', 'Printer-only network'], pointValue: 10, correctAnswers: ['Segmented VLAN or separate network'] },
        { type: 'text', title: 'What controls would you require before onboarding a new IoT fleet into a corporate environment?', required: true, textMode: 'long', pointValue: 20, acceptedAnswers: ['Asset inventory, credential rotation, segmentation, patch strategy, monitoring, and vendor risk review'] },

        { type: 'section', title: 'Section 5 · Cloud', description: 'Shared responsibility, access design, and resilient cloud operations.' },
        { type: 'choice', title: 'Under the shared responsibility model, which control typically remains the customer’s responsibility in SaaS and cloud environments?', required: true, options: ['Physical datacenter security', 'Identity and access management', 'Rack power redundancy', 'Building fire suppression'], pointValue: 10, correctAnswers: ['Identity and access management'] },
        { type: 'choice', title: 'Which design best improves cloud resilience for a production workload?', required: true, options: ['Single-zone dependency', 'Multi-zone or multi-region architecture where appropriate', 'Manual backups only', 'Disable health checks'], pointValue: 10, correctAnswers: ['Multi-zone or multi-region architecture where appropriate'] },
        { type: 'text', title: 'An application shows rising cloud costs with no traffic increase. What would you analyze first?', required: true, textMode: 'long', pointValue: 20, acceptedAnswers: ['Review resource utilization, autoscaling behavior, storage growth, idle instances, and cost anomalies'] },

        { type: 'section', title: 'Section 6 · Cybersecurity', description: 'Defense-in-depth, incident response, and threat reduction.' },
        { type: 'choice', title: 'Which control most directly reduces account takeover risk for privileged users?', required: true, options: ['Longer monitor timeout', 'Multi-factor authentication', 'Shared admin account', 'Disabled audit logs'], pointValue: 10, correctAnswers: ['Multi-factor authentication'] },
        { type: 'choice', title: 'Which action should occur first after confirming a compromised endpoint on the corporate network?', required: true, options: ['Ignore until the next patch window', 'Isolate the device and begin incident response', 'Reboot without capturing details', 'Delete all logs'], pointValue: 10, correctAnswers: ['Isolate the device and begin incident response'] },
        { type: 'text', title: 'Summarize a mature response plan for a phishing-driven credential compromise.', required: true, textMode: 'long', pointValue: 20, acceptedAnswers: ['Contain the account, reset credentials, review session activity, notify security stakeholders, and document remediation'] },

        { type: 'section', title: 'Section 7 · Help Desk', description: 'Triage quality, communication, and service operations.' },
        { type: 'choice', title: 'Which ticket detail most improves first-contact resolution quality?', required: true, options: ['Only the user name', 'Clear symptoms, impact, and steps already attempted', 'A vague title only', 'Closing notes before diagnosis'], pointValue: 10, correctAnswers: ['Clear symptoms, impact, and steps already attempted'] },
        { type: 'choice', title: 'Which escalation path is best when a VIP user cannot access a core business system during an outage?', required: true, options: ['Wait for next shift', 'Follow incident priority and escalate immediately', 'Close as duplicate without confirmation', 'Ask the user to retry tomorrow'], pointValue: 10, correctAnswers: ['Follow incident priority and escalate immediately'] },
        { type: 'text', title: 'Write the key elements of an advanced help desk handoff note for a complex case.', required: true, textMode: 'long', pointValue: 20, acceptedAnswers: ['Problem summary, business impact, diagnostics performed, evidence gathered, current status, and next recommended action'] },

        { type: 'section', title: 'Section 8 · Databases', description: 'Integrity, performance, backup strategy, and access control.' },
        { type: 'choice', title: 'Which practice best protects database confidentiality and limits misuse?', required: true, options: ['Shared admin logins', 'Least-privilege access controls', 'Disable backups', 'Store credentials in plain text'], pointValue: 10, correctAnswers: ['Least-privilege access controls'] },
        { type: 'choice', title: 'Which action most directly supports recovery after accidental data loss?', required: true, options: ['Disable transaction logging', 'Validated backups and restore testing', 'Expanding all user permissions', 'Turning off monitoring'], pointValue: 10, correctAnswers: ['Validated backups and restore testing'] },
        { type: 'text', title: 'A database-backed app slows down dramatically after a release. What advanced checks would you perform first?', required: true, textMode: 'long', pointValue: 20, acceptedAnswers: ['Review query plans, indexes, connection saturation, recent schema changes, and resource contention'] },

        { type: 'section', title: 'Section 9 · Privacy', description: 'Data handling, minimization, and governance decisions.' },
        { type: 'choice', title: 'Which principle best reduces privacy risk when building internal systems?', required: true, options: ['Collect all possible data', 'Data minimization', 'Use shared credentials for convenience', 'Store data indefinitely without review'], pointValue: 10, correctAnswers: ['Data minimization'] },
        { type: 'choice', title: 'Which response is most appropriate when a team wants production customer data copied into a test environment?', required: true, options: ['Approve immediately', 'Require masking, approvals, and necessity review', 'Send it by email', 'Post it in a shared chat'], pointValue: 10, correctAnswers: ['Require masking, approvals, and necessity review'] },
        { type: 'text', title: 'Describe the controls you would expect for a privacy-conscious analytics workflow.', required: true, textMode: 'long', pointValue: 20, acceptedAnswers: ['Purpose limitation, minimization, masking, access controls, retention rules, and auditability'] },

        { type: 'section', title: 'Section 10 · Advanced readiness', description: 'Confidence, depth, and next-step capability planning.' },
        { type: 'rating', title: 'How confident are you in troubleshooting issues across these advanced IT domains?', required: true, maxRating: 5, pointValue: 5 },
        { type: 'text', title: 'Which advanced IT domain should be emphasized next in your training plan and why?', required: true, textMode: 'long', pointValue: 15, acceptedAnswers: ['Networking, cloud, cybersecurity, privacy, databases, help desk, software, hardware, or IoT based on skill gaps'] }
      ]
    },
    quiz: {
      kind: 'quiz',
      title: 'Quick quiz',
      description: 'Starter quiz with answer keys, ratings, and scoreable responses.',
      accentColor: '#7c3aed',
      backgroundStart: '#f5f3ff',
      backgroundEnd: '#ede9fe',
      cardRadius: 20,
      formWidth: 76,
      previewBanner: 'quiz',
      bannerImage: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=1600&q=80',
      bannerAlt: 'Quick quiz banner image',
      previewFields: ['choice', 'rating', 'textarea', 'cta'],
      questions: [
        { type: 'choice', title: 'Which answer is correct?', required: true, options: ['Option A', 'Option B', 'Option C'], pointValue: 10, correctAnswers: ['Option B'], mediaUrl: '', mediaType: 'image', mediaAlt: '' },
        { type: 'rating', title: 'Confidence level', maxRating: 5, pointValue: 5 },
        { type: 'text', title: 'Explain your reasoning', textMode: 'long', pointValue: 15, acceptedAnswers: ['Because option B is correct'] }
      ]
    },
    blank: {
      kind: 'form',
      title: 'Blank form',
      description: 'Start from scratch with a polished layout.',
      accentColor: '#2563eb',
      backgroundStart: '#f8fbff',
      backgroundEnd: '#eef4ff',
      cardRadius: 18,
      formWidth: 80,
      previewBanner: 'blank',
      bannerImage: '',
      bannerAlt: '',
      previewFields: ['text', 'choice', 'cta'],
      questions: [] }
  };

  function ensureRuntimeStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement('style');
    style.id = STYLE_ID;
    style.textContent = `
      .forms-template-shot{padding:0!important;min-height:220px!important;background:linear-gradient(180deg,#f8fbff 0%,#eef4ff 100%)!important}
      .forms-template-shot::before{display:none!important}
      .template-preview-shell{position:relative;min-height:220px;overflow:hidden;background:linear-gradient(180deg,var(--template-surface-start) 0%,var(--template-surface-end) 100%)}
      .template-preview-banner{position:relative;height:92px;background-size:cover;background-position:center}
      .template-preview-feedback .template-preview-banner,.template-preview-shell.template-preview-feedback .template-preview-banner{background-image:linear-gradient(135deg,rgba(14,165,233,.18),rgba(124,58,237,.24)),url('https://images.unsplash.com/photo-1556740749-887f6717d7e4?auto=format&fit=crop&w=1200&q=80')}
      .template-preview-event .template-preview-banner,.template-preview-shell.template-preview-event .template-preview-banner{background-image:linear-gradient(135deg,rgba(249,115,22,.18),rgba(250,204,21,.22)),url('https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=1200&q=80')}
      .template-preview-support .template-preview-banner,.template-preview-shell.template-preview-support .template-preview-banner{background-image:linear-gradient(135deg,rgba(17,24,39,.22),rgba(59,130,246,.22)),url('https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1200&q=80')}
      .template-preview-pulse .template-preview-banner,.template-preview-shell.template-preview-pulse .template-preview-banner{background-image:linear-gradient(135deg,rgba(16,185,129,.18),rgba(52,211,153,.20)),url('https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=1200&q=80')}
      .template-preview-contact .template-preview-banner,.template-preview-shell.template-preview-contact .template-preview-banner{background-image:linear-gradient(135deg,rgba(236,72,153,.18),rgba(139,92,246,.22)),url('https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=1200&q=80')}
      .template-preview-job .template-preview-banner,.template-preview-shell.template-preview-job .template-preview-banner{background-image:linear-gradient(135deg,rgba(15,23,42,.22),rgba(71,85,105,.22)),url('https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=1200&q=80')}
      .template-preview-order .template-preview-banner,.template-preview-shell.template-preview-order .template-preview-banner{background-image:linear-gradient(135deg,rgba(245,158,11,.20),rgba(249,115,22,.18)),url('https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&w=1200&q=80')}
      .template-preview-quiz .template-preview-banner,.template-preview-shell.template-preview-quiz .template-preview-banner{background-image:linear-gradient(135deg,rgba(37,99,235,.18),rgba(124,58,237,.24)),url('https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=1200&q=80')}
      .template-preview-blank .template-preview-banner,.template-preview-shell.template-preview-blank .template-preview-banner{background-image:linear-gradient(135deg,rgba(191,219,254,.8),rgba(199,210,254,.8))}
      .template-preview-banner-overlay{position:absolute;inset:0;background:linear-gradient(180deg,rgba(15,23,42,.02) 0%,rgba(15,23,42,.42) 100%)}
      .template-preview-banner-copy{position:absolute;inset:auto 14px 12px 14px;z-index:1;display:grid;gap:4px;color:#fff}
      .template-preview-badge{display:inline-flex;align-items:center;width:max-content;min-height:22px;padding:2px 8px;border-radius:999px;background:rgba(255,255,255,.16);font-size:.7rem;font-weight:800;letter-spacing:.02em}
      .template-preview-banner-copy{max-width:calc(100% - 28px)} .template-preview-banner-copy strong{font-size:.95rem;line-height:1.2;display:-webkit-box;-webkit-line-clamp:1;-webkit-box-orient:vertical;overflow:hidden;text-overflow:ellipsis;max-width:100%}.template-preview-banner-copy small{font-size:.72rem;color:rgba(255,255,255,.88);display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;max-width:100%}
      .template-preview-canvas{padding:0 16px 16px;margin-top:-22px}.template-preview-card{width:min(100%,var(--template-width));min-height:132px;margin:0 auto;padding:14px;border-radius:var(--template-radius);background:rgba(255,255,255,.96);border:1px solid rgba(215,226,242,.9);box-shadow:0 16px 32px rgba(15,23,42,.10)}
      .template-preview-card-head,.template-preview-card-body{display:grid;gap:10px}
      .template-mock-heading,.template-mock-line,.template-mock-box,.template-mock-button,.template-mock-chips span,.template-mock-circle,.template-mock-upload-icon,.template-mock-rating span{display:block}
      .template-mock-heading,.template-mock-line,.template-mock-box,.template-mock-button,.template-mock-chips span{border-radius:999px;background:linear-gradient(180deg,#f8fbff 0%,#eef4ff 100%);box-shadow:inset 0 0 0 1px rgba(148,163,184,.12)}
      .template-mock-heading.is-wide{width:72%;height:12px}.template-mock-heading.is-short{width:44%;height:10px}.template-mock-line{height:10px}.template-mock-line.is-medium{width:72%}.template-mock-line.is-short{width:50%}
      .template-mock-box{width:100%;height:26px;border-radius:10px}.template-mock-box.is-tall{height:44px}.template-mock-box.is-compact{width:46%}.template-mock-box.is-select{width:58%}
      .template-mock-row{display:flex;align-items:center;gap:8px}.template-mock-circle{width:12px;height:12px;border-radius:999px;background:rgba(255,255,255,.95);box-shadow:inset 0 0 0 2px rgba(37,99,235,.24)}
      .template-mock-rating{display:flex;gap:6px}.template-mock-rating span{width:18px;height:18px;border-radius:8px;background:rgba(37,99,235,.12);box-shadow:inset 0 0 0 1px rgba(37,99,235,.24)}
      .template-mock-chips{display:flex;gap:8px;flex-wrap:wrap}.template-mock-chips span{width:54px;height:20px}
      .template-mock-upload{display:flex;align-items:center;gap:8px;padding:10px 12px;border-radius:12px;border:1px dashed rgba(37,99,235,.28);background:rgba(37,99,235,.06)}
      .template-mock-upload-icon{width:14px;height:14px;border-radius:5px;background:rgba(37,99,235,.22)}
      .template-mock-actions{display:flex;justify-content:flex-end}.template-mock-button{width:74px;height:28px;background:linear-gradient(135deg,var(--template-accent) 0%,#7c3aed 100%);box-shadow:none}
      .forms-index-template-card.is-active{border-color:rgba(124,58,237,.3)!important;box-shadow:0 24px 48px rgba(124,58,237,.16)!important}
      .template-hotfix-toast{position:fixed;right:18px;bottom:18px;z-index:1200;padding:12px 14px;border-radius:14px;background:#111827;color:#fff;font-weight:700;box-shadow:0 20px 40px rgba(15,23,42,.24);transform:translateY(12px);opacity:0;transition:transform .18s ease,opacity .18s ease}
      .template-hotfix-toast.is-error{background:#b42318}.template-hotfix-toast.is-visible{transform:translateY(0);opacity:1}
      .forms-template-live-banner{position:relative;overflow:hidden;border-radius:22px 22px 0 0;background:#0f172a;min-height:220px;border-bottom:1px solid rgba(215,226,242,.9)}
      .forms-template-live-banner img,.forms-template-live-banner video{display:block;width:100%;height:220px;object-fit:cover}
      .forms-template-live-banner audio{width:min(100%,560px)}
      .forms-template-live-banner.is-audio{display:grid;gap:14px;padding:22px;background:linear-gradient(135deg,#0f172a 0%,#1d4ed8 100%);color:#fff}
      .forms-template-live-banner-overlay{position:absolute;inset:auto 0 0 0;padding:18px 22px;background:linear-gradient(180deg,rgba(15,23,42,0) 0%,rgba(15,23,42,.7) 100%);color:#fff}
      .forms-template-live-banner-overlay strong{display:block;font-size:1rem;line-height:1.2}.forms-template-live-banner-overlay span{display:block;font-size:.82rem;color:rgba(255,255,255,.88);margin-top:4px}
      .forms-template-banner-source-hidden{display:none!important}
    `;
    document.head.appendChild(style);
  }

  function escapeXml(value) {
    return String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&apos;');
  }

  function slugify(value) {
    return String(value || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  }

  function getSelectedCard() {
    return document.querySelector(`${TEMPLATE_CARD_SELECTOR}.${ACTIVE_CLASS}`) || document.querySelector(TEMPLATE_CARD_SELECTOR);
  }

  function selectCard(card) {
    if (!(card instanceof HTMLElement)) return;
    document.querySelectorAll(TEMPLATE_CARD_SELECTOR).forEach((node) => node.classList.toggle(ACTIVE_CLASS, node === card));
  }

  function getTemplateConfig(id, mode = 'form') {
    return TEMPLATE_LIBRARY[id] || (mode === 'quiz' ? TEMPLATE_LIBRARY.quiz : TEMPLATE_LIBRARY.blank);
  }


function getTemplateHeaderBanner(template) {
  return {
    enable: !!(template && template.bannerImage),
    src: template?.bannerImage || '',
    type: 'image',
    alt: template?.bannerAlt || template?.title || 'Form banner',
  };
}
function getTemplateQuestionsForExport(template) {
  // Keep question-level media separate from the template header banner.
  // Export questions exactly as defined so a matching media URL does not get removed.
  return (template?.questions || []).map((question) => (
    question ? { ...question } : question
  ));
}


  function buildQuestionXml(question, index) {
    const defaults = {
      questionId: `Q-${slugify(question.title || `Question ${index + 1}`)}-${index + 1}`,
      type: 'choice',
      title: `Question ${index + 1}`,
      subtitle: '',
      description: '',
      required: false,
      isMultiple: false,
      isDropdown: false,
      shuffle: false,
      branching: false,
      otherOptionEnabled: false,
      otherOptionLabel: '',
      pointValue: 0,
      sectionTitle: '',
      sectionOrder: String(index),
      options: [],
      columns: [],
      statements: [],
      limit: ['noLimit', '0'],
      textMode: 'short',
      restrictionEnabled: false,
      restrictionType: 'text',
      restrictionOperator: '',
      restrictionValue: '',
      restrictionValueSecondary: '',
      mediaUrl: '',
      mediaType: 'image',
      mediaAlt: '',
      maxRating: 5,
      minLabel: 'Not likely',
      maxLabel: 'Very likely',
      maxRank: Math.max((question.options || []).length || 0, 4),
      fileAccept: '',
      fileMaxSize: '',
      multipleFiles: false,
      branchingRules: [],
      correctAnswers: [],
      acceptedAnswers: []
    };
    const q = { ...defaults, ...question };
    const branchRules = Array.isArray(q.branchingRules) ? q.branchingRules.filter(Boolean) : [];
    const listXml = (tag, values) => {
      const items = Array.isArray(values) ? values.filter(Boolean) : [];
      return `<${tag}>${items.map((value) => `<item>${escapeXml(value)}</item>`).join('')}</${tag}>`;
    };
    return `
      <question>
        <questionId>${escapeXml(q.questionId)}</questionId>
        <type>${escapeXml(q.type)}</type>
        <title>${escapeXml(q.title)}</title>
        <subtitle>${escapeXml(q.subtitle)}</subtitle>
        <description>${escapeXml(q.description)}</description>
        <required>${q.required ? 'true' : 'false'}</required>
        <isMultiple>${q.isMultiple ? 'true' : 'false'}</isMultiple>
        <isDropdown>${q.isDropdown ? 'true' : 'false'}</isDropdown>
        <shuffle>${q.shuffle ? 'true' : 'false'}</shuffle>
        <branching>${(q.branching || branchRules.length > 0) ? 'true' : 'false'}</branching>
        <branchingRules>${branchRules.map((rule) => escapeXml(JSON.stringify(rule))).join(',')}</branchingRules>
        <branchingRulesJson>${escapeXml(JSON.stringify(branchRules))}</branchingRulesJson>
        <otherOptionEnabled>${q.otherOptionEnabled ? 'true' : 'false'}</otherOptionEnabled>
        <otherOptionLabel>${escapeXml(q.otherOptionLabel)}</otherOptionLabel>
        <pointValue>${escapeXml(q.pointValue)}</pointValue>
        <sectionTitle>${escapeXml(q.sectionTitle)}</sectionTitle>
        <sectionOrder>${escapeXml(q.sectionOrder)}</sectionOrder>
        ${listXml('options', q.options)}
        ${listXml('columns', q.columns)}
        ${listXml('statements', q.statements)}
        ${listXml('limit', q.limit)}
        <textMode>${escapeXml(q.textMode)}</textMode>
        <restrictionEnabled>${q.restrictionEnabled ? 'true' : 'false'}</restrictionEnabled>
        <restrictionType>${escapeXml(q.restrictionType)}</restrictionType>
        <restrictionOperator>${escapeXml(q.restrictionOperator)}</restrictionOperator>
        <restrictionValue>${escapeXml(q.restrictionValue)}</restrictionValue>
        <restrictionValueSecondary>${escapeXml(q.restrictionValueSecondary)}</restrictionValueSecondary>
        <mediaUrl>${escapeXml(q.mediaUrl)}</mediaUrl>
        <mediaType>${escapeXml(q.mediaType)}</mediaType>
        <mediaAlt>${escapeXml(q.mediaAlt)}</mediaAlt>
        <maxRating>${escapeXml(q.maxRating)}</maxRating>
        <minLabel>${escapeXml(q.minLabel)}</minLabel>
        <maxLabel>${escapeXml(q.maxLabel)}</maxLabel>
        <maxRank>${escapeXml(q.maxRank)}</maxRank>
        <fileAccept>${escapeXml(q.fileAccept)}</fileAccept>
        <fileMaxSize>${escapeXml(q.fileMaxSize)}</fileMaxSize>
        <multipleFiles>${q.multipleFiles ? 'true' : 'false'}</multipleFiles>
        ${listXml('correctAnswers', q.correctAnswers)}
        ${listXml('acceptedAnswers', q.acceptedAnswers)}
      </question>
    `.trim();
  }

  
function buildTemplateXml(templateId, mode) {
  const template = getTemplateConfig(templateId, mode);
  const type = template.kind === 'quiz' || mode === 'quiz' ? 'quiz' : 'form';

  const exportQuestions = typeof getTemplateQuestionsForExport === 'function'
    ? getTemplateQuestionsForExport(template)
    : (template.questions || []);

  const questionsXml = exportQuestions
    .map((question, index) => buildQuestionXml(question, index))
    .join('');

  const midpoint = template.backgroundEnd || template.backgroundStart || '#eef2ff';
  const gradient = `linear-gradient(180deg, ${template.backgroundStart} 0%, ${midpoint} 48%, ${template.backgroundEnd} 100%)`;

  const headerBanner = typeof getTemplateHeaderBanner === 'function'
    ? getTemplateHeaderBanner(template)
    : {
        enable: !!template.bannerImage,
        src: template.bannerImage || '',
        type: 'image',
        alt: template.bannerAlt || template.title || 'Form banner',
      };

  return `<?xml version="1.0" encoding="UTF-8"?>
<formExport>
  <metadata>
    <type>${escapeXml(type)}</type>
    <title>${escapeXml(template.title)}</title>
    <description>${escapeXml(template.description)}</description>

    <styles>
      <layout>default</layout>
      <background style="${escapeXml(gradient)}"></background>
      <background-music enable="0" src=""></background-music>

      <headerBanner
        enable="${headerBanner.enable ? '1' : '0'}"
        src="${escapeXml(headerBanner.src)}"
        type="${escapeXml(headerBanner.type)}"
        alt="${escapeXml(headerBanner.alt)}"
      ></headerBanner>

      <headerBannerEnable>${headerBanner.enable ? '1' : '0'}</headerBannerEnable>
      <headerBannerSrc>${escapeXml(headerBanner.src)}</headerBannerSrc>
      <headerBannerType>${escapeXml(headerBanner.type)}</headerBannerType>
      <headerBannerAlt>${escapeXml(headerBanner.alt)}</headerBannerAlt>

      <!-- compatibility fallback -->
      <bannerImage>${escapeXml(headerBanner.src)}</bannerImage>
      <bannerAlt>${escapeXml(headerBanner.alt)}</bannerAlt>

      <accentColor>${escapeXml(template.accentColor)}</accentColor>
      <cardRadius>${escapeXml(template.cardRadius)}</cardRadius>
      <formWidth>${escapeXml(template.formWidth)}</formWidth>
    </styles>

    <settings>
      <who_can_fill>logged_in</who_can_fill>
      <accepted_responses enabled="1"></accepted_responses>
      <start_date datetime=""></start_date>
      <end_date datetime=""></end_date>
      <time_duration minutes="0"></time_duration>
      <shuffle_questions enabled="0"></shuffle_questions>
      <disable_question_number_for_respondents enabled="0"></disable_question_number_for_respondents>
      <show_progress_bar enabled="1"></show_progress_bar>
      <hide_submit_another_response enabled="0"></hide_submit_another_response>
      <customize_thank_you_message message=""></customize_thank_you_message>
      <show_score_in_thank_you enabled="${type === 'quiz' ? '1' : '0'}"></show_score_in_thank_you>
      <allow_respondents_to_save_their_responses enable="0"></allow_respondents_to_save_their_responses>
      <allow_respondents_to_edit_their_responses enable="0"></allow_respondents_to_edit_their_responses>
      <allow_receipt_of_responses_after_submission enable="0"></allow_receipt_of_responses_after_submission>
      <get_email_notification_of_each_response enable="0"></get_email_notification_of_each_response>
    </settings>

    <ui>
      <show_required_asterisk enabled="1"></show_required_asterisk>
      <publish_functional enabled="1"></publish_functional>
      <submit_label value="${escapeXml(type === 'quiz' ? 'Submit quiz' : 'Submit')}"></submit_label>
      <publish_mode_label value="Publish"></publish_mode_label>
      <thank_you_title value="${escapeXml(type === 'quiz' ? 'Quiz submitted' : 'Response submitted')}"></thank_you_title>
    </ui>
  </metadata>

  <questions>${questionsXml}</questions>
  <responses></responses>
</formExport>`;
}

  function renderPreviewMarkup(templateId) {
    const template = getTemplateConfig(templateId);
    const fieldMarkup = (template.previewFields || []).map((field) => {
      if (field === 'choice') return '<div class="template-mock-row"><span class="template-mock-circle"></span><span class="template-mock-line is-medium"></span></div><div class="template-mock-row"><span class="template-mock-circle"></span><span class="template-mock-line is-short"></span></div>';
      if (field === 'rating') return '<div class="template-mock-rating"><span></span><span></span><span></span><span></span><span></span></div>';
      if (field === 'textarea') return '<div class="template-mock-box is-tall"></div>';
      if (field === 'upload') return '<div class="template-mock-upload"><span class="template-mock-upload-icon"></span><span class="template-mock-line is-medium"></span></div>';
      if (field === 'date') return '<div class="template-mock-box is-compact"></div>';
      if (field === 'select') return '<div class="template-mock-box is-select"></div>';
      if (field === 'chips') return '<div class="template-mock-chips"><span></span><span></span><span></span></div>';
      if (field === 'cta') return '<div class="template-mock-actions"><span class="template-mock-button"></span></div>';
      return '<div class="template-mock-box"></div>';
    }).join('');
    return `
      <div class="template-preview-shell template-preview-${template.previewBanner}" style="--template-accent:${template.accentColor}; --template-surface-start:${template.backgroundStart}; --template-surface-end:${template.backgroundEnd}; --template-radius:${template.cardRadius}px; --template-width:${template.formWidth}%;">
        <div class="template-preview-banner" style="${template.bannerImage? `background-image: linear-gradient(135deg,rgba(37,99,235,.18),rgba(124,58,237,.24)), url('${template.bannerImage}')`: ''}">
          <div class="template-preview-banner-overlay"></div>
          <div class="template-preview-banner-copy">
            <span class="template-preview-badge">${template.kind === 'quiz' ? 'Quiz' : 'Form'}</span>
            <strong>${template.previewTitle || template.title}</strong>
            <small>${template.previewDescription || template.description}</small>
          </div>
        </div>
        <div class="template-preview-canvas">
          <div class="template-preview-card">
            <div class="template-preview-card-head">
              <span class="template-mock-heading is-wide"></span>
              <span class="template-mock-heading is-short"></span>
            </div>
            <div class="template-preview-card-body">${fieldMarkup}</div>
          </div>
        </div>
      </div>
    `.trim();
  }

  function showToast(message, isError = false) {
    const node = document.createElement('div');
    node.className = `template-hotfix-toast ${isError ? 'is-error' : 'is-success'}`;
    node.textContent = message;
    document.body.appendChild(node);
    requestAnimationFrame(() => node.classList.add('is-visible'));
    window.setTimeout(() => {
      node.classList.remove('is-visible');
      window.setTimeout(() => node.remove(), 200);
    }, 3000);
  }

  async function importTemplate(templateId, mode, trigger) {
    const template = getTemplateConfig(templateId, mode);
    if (!template) return;
    const xml = buildTemplateXml(templateId, mode);
    const blob = new Blob([xml], { type: 'application/xml' });
    const formData = new FormData();
    formData.append('xmlFile', blob, `${slugify(template.title || templateId)}.xml`);

    const original = trigger ? trigger.innerHTML : '';
    if (trigger) {
      trigger.disabled = true;
      trigger.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i><span>Creating…</span>';
    }

    try {
      const response = await fetch('./import.php', { method: 'POST', body: formData, credentials: 'same-origin' });
      const payload = await response.json();
      if (!response.ok || !payload.success || !payload.formId) {
        throw new Error(payload.error || 'Unable to create this template.');
      }
      showToast(`Opening “${payload.title || template.title}”…`);
      window.setTimeout(() => {
        try {
          window.sessionStorage.setItem(
            'forms.templateEditIntent.v1',
            JSON.stringify({
              formId: payload.formId,
              createdAt: Date.now()
            })
          );

          const banner = typeof getTemplateHeaderBanner === 'function'
            ? getTemplateHeaderBanner(template)
            : {
                enable: !!template.bannerImage,
                src: template.bannerImage || '',
                type: 'image',
                alt: template.bannerAlt || template.title || 'Form banner'
              };

          if (banner && banner.enable && banner.src) {
            window.sessionStorage.setItem(
              'forms.templateBannerIntent.v1',
              JSON.stringify({
                formId: payload.formId,
                createdAt: Date.now(),
                banner
              })
            );
          }


          const exportQuestions = typeof getTemplateQuestionsForExport === 'function'
            ? getTemplateQuestionsForExport(template)
            : (template.questions || []);
          window.sessionStorage.setItem(
            'forms.templateQuestionsIntent.v1',
            JSON.stringify({
              formId: payload.formId,
              createdAt: Date.now(),
              questions: exportQuestions
            })
          );        } catch (_) {}

        window.location.href = `./live?formId=${encodeURIComponent(payload.formId)}`;
      }, 260);
    } catch (error) {
      console.error(error);
      showToast(error.message || 'Template creation failed.', true);
      if (trigger) {
        trigger.disabled = false;
        trigger.innerHTML = original;
      }
    }
  }

  function bindCards() {
    const cards = Array.from(document.querySelectorAll(TEMPLATE_CARD_SELECTOR));
    cards.forEach((card) => {
      if (card.dataset.templateHotfixBound === '1') return;
      card.dataset.templateHotfixBound = '1';
      const shot = card.querySelector('.forms-template-shot');
      if (shot) shot.innerHTML = renderPreviewMarkup(card.dataset.templateId || 'blank');
      card.addEventListener('click', (event) => {
        if (event.target.closest(TEMPLATE_USE_SELECTOR)) return;
        selectCard(card);
      });
      card.addEventListener('keydown', (event) => {
        if (event.key !== 'Enter' && event.key !== ' ') return;
        event.preventDefault();
        selectCard(card);
      });
    });
  }

  function bindUseTemplate() {
    document.querySelectorAll(TEMPLATE_USE_SELECTOR).forEach((button) => {
      if (button.dataset.templateUseBound === '1') return;
      button.dataset.templateUseBound = '1';
      button.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        const card = button.closest(TEMPLATE_CARD_SELECTOR);
        const templateId = button.dataset.templateUse || card?.dataset.templateId || 'blank';
        const mode = button.dataset.templateMode || card?.dataset.templateMode || 'form';
        if (card) selectCard(card);
        importTemplate(templateId, mode, button);
      });
    });
  }

  function bindCreateButtons() {
    const bind = (selector, mode) => {
      const button = document.querySelector(selector);
      if (!(button instanceof HTMLElement) || button.dataset.templateCreateBound === '1') return;
      button.dataset.templateCreateBound = '1';
      button.addEventListener('click', (event) => {
        event.preventDefault();
        event.stopPropagation();
        const templateId = 'blank';
        importTemplate(templateId, mode, button);
      });
    };
    bind(NEW_FORM_SELECTOR, 'form');
    bind(NEW_QUIZ_SELECTOR, 'quiz');
  }

  function enableIndexPage() {
    if (!document.querySelector(TEMPLATE_CARD_SELECTOR)) return false;
    bindCards();
    bindUseTemplate();
    bindCreateButtons();
    const first = getSelectedCard();
    if (first) selectCard(first);
    return true;
  }

  function getLiveBannerSource() {
    const candidates = Array.from(document.querySelectorAll('.forms-publish-shell .forms-question-media'));
    return candidates.find((node) => node.querySelector('img,video,audio')) || null;
  }

  function buildLiveBannerFromSource(source) {
    if (!source) return '';
    const img = source.querySelector('img');
    const video = source.querySelector('video');
    const audio = source.querySelector('audio');
    if (img) {
      return `<div class="forms-template-live-banner" data-template-live-banner="1"><img src="${img.getAttribute('src') || ''}" alt="${img.getAttribute('alt') || 'Form banner'}"><div class="forms-template-live-banner-overlay"><strong>${img.getAttribute('alt') || 'Form banner'}</strong><span>Template header media</span></div></div>`;
    }
    if (video) {
      return `<div class="forms-template-live-banner" data-template-live-banner="1"><video src="${video.getAttribute('src') || ''}" autoplay muted loop playsinline></video><div class="forms-template-live-banner-overlay"><strong>${video.getAttribute('aria-label') || 'Form banner video'}</strong><span>Template header media</span></div></div>`;
    }
    if (audio) {
      return `<div class="forms-template-live-banner is-audio" data-template-live-banner="1"><strong>Template header audio</strong><span>${audio.getAttribute('aria-label') || 'Audio banner attached to this template.'}</span><audio controls src="${audio.getAttribute('src') || ''}"></audio></div>`;
    }
    return '';
  }

  function syncLiveBanner() {
    const params = new URLSearchParams(window.location.search || '');
    if (params.get('templateCreated') !== '1') return;
    const shell = document.querySelector('.forms-publish-shell');
    const header = shell?.querySelector('.forms-publish-header');
    if (!shell || !header) return;
    const source = getLiveBannerSource();
    if (!source) return;
    const markup = buildLiveBannerFromSource(source);
    if (!markup) return;
    shell.querySelectorAll('[data-template-live-banner="1"]').forEach((node) => node.remove());
    header.insertAdjacentHTML('beforebegin', markup);
    source.classList.add('forms-template-banner-source-hidden');
      if (attempts < 30) {
        window.setTimeout(tick, 250);
      }
      return false;
    
    tick();
  }

  function enableLivePage() {
    if (!document.getElementById('forms-app')) return false;
    
    const observer = new MutationObserver(() => {
      
      syncLiveBanner();
    });
    observer.observe(document.body, { childList: true, subtree: true });
    window.setTimeout(syncLiveBanner, 350);
    window.setTimeout(syncLiveBanner, 900);
    return true;
  }

  function init() {
    ensureRuntimeStyles();
    enableIndexPage();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();
