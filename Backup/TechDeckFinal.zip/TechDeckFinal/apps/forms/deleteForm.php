<?php
declare(strict_types=1);

include_once dirname(__DIR__, 2) . "/init.php";
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed'
    ]);
    exit;
}

$action = $_POST['action'] ?? '';
$formId = isset($_POST['formId'])
    ? preg_replace('/[^a-zA-Z0-9_-]/', '_', (string) $_POST['formId'])
    : '';

if ($action !== 'delete_form') {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Invalid delete action'
    ]);
    exit;
}

if ($formId === '') {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Missing form id'
    ]);
    exit;
}

$filePath = __DIR__ . "/database/{$formId}.xml";

if (!file_exists($filePath)) {
    http_response_code(404);
    echo json_encode([
        'success' => false,
        'error' => 'Form file does not exist'
    ]);
    exit;
}

if (!@unlink($filePath)) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Unable to delete form file'
    ]);
    exit;
}

echo json_encode([
    'success' => true,
    'formId' => $formId
]);
exit;