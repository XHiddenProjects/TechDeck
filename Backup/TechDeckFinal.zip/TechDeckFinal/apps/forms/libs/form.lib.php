<?php
declare(strict_types=1);

namespace TechDeck\Addons\Form;

use TechDeck\Data;
use TechDeck\Users;

/**
 * Class FormUtils
 *
 * Manages XML-backed forms stored as individual files in a database directory.
 * Each form is stored as "<formId>.xml" under: dirname(__DIR__) . "/database".
 *
 * Features:
 * - Load an existing form by ID when its file exists.
 * - Create a form file when it does not exist.
 * - Generate a collision-safe unique ID for new forms when no ID is provided.
 *
 * XML operations (create/load/save) are delegated to {@see Data}. 
 */
class FormUtils{
    /**
     * Data helper used for XML operations.
     *
     * @var Data
     */
    private Data $form;

    private Users $user;

    /**
     * Directory used to store form XML files.
     *
     * @var string
     */
    private string $dbPath;

    /**
     * Currently active form identifier.
     *
     * @var string|null
     */
    private ?string $formId = null;

    /**
     * Initializes the form manager.
     *
     * If an ID is provided, the manager loads the existing form file if present,
     * otherwise creates it.
     *
     * @param string|null $formId Optional form identifier to load or create.
     */
    public function __construct(?string $formId = null){
        $this->dbPath = rtrim(dirname(__DIR__) . '/database', "/\\");
        $this->ensureDatabaseDir($this->dbPath);

        // Configure Data to use the database directory for file operations. 
        $this->form = new Data(null, null, [], $this->dbPath); 

        if ($formId !== null && trim($formId) !== '') $this->loadOrCreate($formId);
        $this->user = new Users();
    }

    /**
     * Loads a form if it exists; otherwise creates it.
     *
     * If no ID is provided, a new unique form is created and returned.
     *
     * @param string|null $formId Form identifier (filename without extension).
     * @return string The active form identifier.
     * @throws \Exception If secure random generation fails during ID creation.
     */
    public function loadOrCreate(?string $formId = null): string{
        if ($formId === null || trim($formId) === '') return $this->createNew();
        

        $formId = $this->normalizeId($formId);

        if ($this->fileExists($formId)) {
            $this->form->get($formId, null, [], $this->dbPath); 
            $this->formId = $formId;
            return $formId;
        }

        $this->createWithId($formId);
        return $formId;
    }

    /**
     * Creates a brand-new form with a collision-safe unique identifier.
     *
     * @return string The new unique form identifier.
     * @throws \Exception If secure random generation fails.
     */
    public function createNew(): string{
        $id = $this->generateUniqueId();
        $this->createWithId($id);
        return $id;
    }

    /**
     * Returns the currently active form identifier.
     *
     * @return string|null Active form identifier or null if none initialized.
     */
    public function id(): ?string{
        return $this->formId;
    }

    /**
     * Returns the underlying Data instance for advanced XML operations.
     *
     * @return Data
     */
    public function data(): Data{
        return $this->form;
    }

    /**
     * Returns the current XML document, if one is loaded/created.
     *
     * @return \SimpleXMLElement|null
     */
    public function xml(): ?\SimpleXMLElement{
        return $this->form->xml(); 
    }

    /**
     * Ensures the database directory exists.
     *
     * @param string $path Directory path.
     * @return void
     */
    private function ensureDatabaseDir(string $path): void{
        if (!is_dir($path)) @mkdir($path, 0777, true);
    }

    /**
     * Normalizes a provided ID to a filesystem-safe identifier.
     *
     * - Removes a trailing ".xml" extension if provided.
     * - Replaces non [a-zA-Z0-9_-] characters with underscores.
     *
     * @param string $id Input identifier.
     * @return string Normalized identifier.
     */
    private function normalizeId(string $id): string{
        $id = trim($id);
        $id = preg_replace('/\.xml$/i', '', $id) ?? $id;
        $id = preg_replace('/[^a-zA-Z0-9_-]/', '_', $id) ?? $id;
        return $id;
    }

    /**
     * Determines whether the form file exists for the given ID.
     *
     * @param string $id Normalized identifier.
     * @return bool True when "<id>.xml" exists; otherwise false.
     */
    private function fileExists(string $id): bool{
        $sep = \defined('DS') ? DS : DIRECTORY_SEPARATOR;
        $path = "$this->dbPath$sep$id.xml";
        return is_file($path);
    }

    /**
     * Generates a unique identifier and verifies it does not collide with an existing file.
     *
     * @return string Unique identifier.
     * @throws \Exception If random_bytes() fails.
     */
    private function generateUniqueId(): string{
        do {
            $id = bin2hex(random_bytes(16));
        } while ($this->fileExists($id));

        return $id;
    }

    /**
     * Creates a form with a specific ID if it does not already exist.
     *
     * If the file exists, the existing form is loaded instead of overwritten.
     *
     * @param string $id Normalized identifier.
     * @return void
     */
    private function createWithId(string $id): void{
        if ($this->fileExists($id)) {
            $this->form->get($id, null, [], $this->dbPath);
            $this->formId = $id;
            return;
        }

        // Root <form id="...">
        $this->form->create('form', ['id' => $id]);

        // Build default metadata
        $now = (new \DateTimeImmutable('now', new \DateTimeZone('UTC')))->format(\DateTimeInterface::ATOM);

        // Pick a reasonable author value; customize as needed
        $author = $this->user->getUsername();

        // <metadata>...</metadata>
        $this->form->addElement('/', 'metadata');
        $this->form->addElement('/form/metadata', 'type',[], "form");
        $this->form->addElement('/form/metadata', 'title', [], 'Untitled form');
        $this->form->addElement('/form/metadata', 'description', [], '');
        $this->form->addElement('/form/metadata', 'author', [], (string)$author);
        $this->form->addElement('/form/metadata', 'created', [], $now);
        $this->form->addElement('/form/metadata', 'edited', [], $now);
        $this->form->addElement('/form/metadata', 'styles');
        $this->form->addElement('/form/metadata/styles', 'layout',[],'default');
        $this->form->addElement('/form/metadata/styles', 'background',['style'=>'linear-gradient(180deg, #ffffff 0%, #d9ecff 100%)']);
        $this->form->addElement('/form/metadata/styles', 'background-music',['enable'=>false,'src'=>'']);
        $this->form->addElement('/form/metadata', 'settings');
        $this->form->addElement('/form/metadata/settings', 'who_can_fill', [], 'logged_in');
        $this->form->addElement('/form/metadata/settings', 'accepted_responses', ['enabled'=>true]);
        $this->form->addElement('/form/metadata/settings', 'start_date', ['datetime'=>'']);
        $this->form->addElement('/form/metadata/settings', 'end_date', ['datetime'=>'']);
        $this->form->addElement('/form/metadata/settings', 'time_duration', ['minutes'=>0]); //0 Minutes is no time
        $this->form->addElement('/form/metadata/settings', 'shuffle_questions', ['enabled'=>false]);
        $this->form->addElement('/form/metadata/settings', 'disable_question_number_for_respondents', ['enabled'=>false]);
        $this->form->addElement('/form/metadata/settings', 'show_progress_bar', ['enabled'=>false]);
        $this->form->addElement('/form/metadata/settings', 'hide_submit_another_response', ['enabled'=>false]);
        $this->form->addElement('/form/metadata/settings', 'customize_thank_you_message', ['message'=>'']);
$this->form->addElement('/form/metadata/settings', 'show_score_in_thank_you', ['enabled'=>false]);
        $this->form->addElement('/form/metadata/settings', 'allow_respondents_to_save_their_responses', ['enable'=>true]);
        $this->form->addElement('/form/metadata/settings', 'allow_respondents_to_edit_their_responses', ['enable'=>false]);
        $this->form->addElement('/form/metadata/settings', 'allow_receipt_of_responses_after_submission', ['enable'=>false]);
        $this->form->addElement('/form/metadata/settings', 'get_email_notification_of_each_response', ['enable'=>false]);
        $this->form->addElement('/form/metadata', 'favorites', [], "");

        // <questions></questions> and <responses></responses>
        $this->form->addElement('/form', 'questions');
        $this->form->addElement('/form', 'responses');

        // Save pretty formatted
        $this->form->save($id, null, $this->dbPath, Data::SAVE_PRETTY);

        $this->formId = $id;
    }
    /**
     * Check if the author exists to go into editor mode
     * @return bool TRUE if it is, else FALSE
     */
    public function isEditorMode(): bool{
        $xml = $this->form->xml();
        return (string)$xml->metadata->author===$this->user->getUsername();
    }
    /**
     * Checks if the form is a quiz
     * @return bool TRUE if quiz, else FALSE
     */
    public function isQuiz(): bool{
        $xml = $this->form->xml();
        return strtolower((string)$xml->metadata->type)==='quiz';
    }
    /**
     * Saves the form
     * @param string  $id ID
     * @param string $xpath XPath to save
     * @param string $newValue Updated path
     * @return FormUtils
     */
    public function save(string $id, string $xpath, string $newValue): static{
        $this->form->updateElementValue($xpath,$newValue);
        $this->form->save($id, null, $this->dbPath, Data::SAVE_PRETTY);
        return $this;
    }
    /**
     * Returns the questions
     * @return array List of questions
     */
    public function getQuestions(): array{
        return $this->form->toArray()['questions'];
    }

/**
 * Returns form metadata in a simple array shape.
 *
 * @return array<string, mixed>
 */
public function getMetadataArray(): array{
    $xml = $this->xml();
    if ($xml === null || !isset($xml->metadata)) return [];
    $meta = $this->xmlNodeToArray($xml->metadata);
    return is_array($meta) ? $meta : [];
}

/**
 * Returns questions normalized for the editor/front-end.
 *
 * @return array<int, array<string, mixed>>
 */
public function getQuestionsNormalized(): array{
    $xml = $this->xml();
    if ($xml === null || !isset($xml->questions)) return [];

    $raw = $this->xmlNodeToArray($xml->questions);
    $items = [];

    if (is_array($raw)) {
        if (array_key_exists('question', $raw)) {
            $items = $raw['question'];
        } elseif ($this->isListArray($raw)) {
            $items = $raw;
        } else {
            foreach ($raw as $key => $value) {
                if (is_numeric((string)$key) || is_array($value)) {
                    $items[] = $value;
                }
            }
        }
    }

    if (!is_array($items)) $items = [$items];
    if (!$this->isListArray($items)) $items = array_values($items);

    $normalized = [];
    foreach ($items as $index => $item) {
        if (!is_array($item)) {
            if ($item === null || $item === '') continue;
            $item = ['title' => (string)$item];
        }
        $normalized[] = $this->normalizeQuestionArray($item, (int)$index);
    }

    return $normalized;
}

/**
 * Returns the complete payload used by the editor loader.
 *
 * @return array<string, mixed>
 */
public function toEditorPayload(): array{
    $meta = $this->getMetadataArray();
    $title = (string)($meta['title'] ?? 'Untitled form');
    $description = (string)($meta['description'] ?? '');
    $edited = (string)($meta['edited'] ?? $meta['created'] ?? '');

    return [
        'formId' => $this->id(),
        'title' => $title,
        'description' => $description,
        'edited' => $edited,
        'metadata' => $meta,
        'questions' => $this->getQuestionsNormalized(),
    ];
}

/**
 * Recursively converts a SimpleXML node to an array/scalar preserving attributes.
 *
 * @param \SimpleXMLElement $node
 * @return mixed
 */
private function xmlNodeToArray(\SimpleXMLElement $node): mixed{
    $attributes = [];
    foreach ($node->attributes() as $attrName => $attrValue) {
        $attributes[(string)$attrName] = (string)$attrValue;
    }

    $children = $node->children();
    if ($children->count() === 0) {
        $text = trim((string)$node);
        if ($attributes === []) return $text;
        if ($text === '') return ['@attributes' => $attributes];
        return ['@attributes' => $attributes, '@value' => $text];
    }

    $result = $attributes === [] ? [] : ['@attributes' => $attributes];
    foreach ($children as $childName => $child) {
        $value = $this->xmlNodeToArray($child);
        if (array_key_exists($childName, $result)) {
            if (!is_array($result[$childName]) || !$this->isListArray($result[$childName])) {
                $result[$childName] = [$result[$childName]];
            }
            $result[$childName][] = $value;
        } else {
            $result[$childName] = $value;
        }
    }

    $text = trim((string)$node);
    if ($text !== '') $result['@value'] = $text;
    return $result;
}

/**
 * Normalizes a raw saved question into the JS editor shape.
 *
 * @param array<string, mixed> $item
 * @param int $index
 * @return array<string, mixed>
 */
private function normalizeQuestionArray(array $item, int $index): array{
    $questionId = (string)($this->firstValue($item, ['questionId', 'question_id', 'id']) ?? ('q' . ($index + 1)));
    $type = strtolower((string)($this->firstValue($item, ['type', 'question_type']) ?? 'choice'));
    $title = (string)($this->firstValue($item, ['title', 'label', 'question']) ?? 'Question');
    $subtitle = $this->firstValue($item, ['subtitle']);
    $description = $this->firstValue($item, ['description']);
    $options = $this->normalizeList($this->firstValue($item, ['options', 'option', 'choices']) ?? []);
    $columns = $this->normalizeList($this->firstValue($item, ['columns', 'column']) ?? []);
    $statements = $this->normalizeList($this->firstValue($item, ['statements', 'statement', 'rows']) ?? []);
    $branchingRules = $this->normalizeBranchingRules($this->firstValue($item, ['branchingRulesJson', 'branchingRules', 'branchRulesJson', 'branchRules']) ?? []);
    $branching = $this->toBool($this->firstValue($item, ['branching'])) || !empty($branchingRules);
    $limitRaw = $this->firstValue($item, ['limit']);
    $limit = ['noLimit', 0];

    if (is_array($limitRaw)) {
        $limitMode = (string)($limitRaw[0] ?? $limitRaw['mode'] ?? 'noLimit');
        $limitCount = (int)($limitRaw[1] ?? $limitRaw['count'] ?? 0);
        $limit = [$limitMode !== '' ? $limitMode : 'noLimit', $limitCount];
    }

    return [
        'questionId' => $questionId,
        'type' => $type,
        'title' => $title,
        'subtitle' => $this->normalizeDisplayValue($subtitle),
        'description' => $this->normalizeDisplayValue($description),
        'options' => $options,
        'required' => $this->toBool($this->firstValue($item, ['required'])),
        'isMultiple' => $this->toBool($this->firstValue($item, ['isMultiple', 'multiple', 'multiple_answers'])),
        'isDropdown' => $this->toBool($this->firstValue($item, ['isDropdown', 'dropdown'])),
        'shuffle' => $this->toBool($this->firstValue($item, ['shuffle', 'shuffle_options'])),
        'branching' => $branching,
        'branchingRules' => $branchingRules,
        'branchingRulesJson' => $branchingRules,
        'branchRules' => $branchingRules,
        'branchRulesJson' => $branchingRules,
        'pointValue' => (int)($this->firstValue($item, ['pointValue', 'points', 'point_value']) ?? 0),
        'limit' => $limit,
        'sectionTitle' => (string)($this->firstValue($item, ['sectionTitle', 'section_title']) ?? ''),
        'sectionOrder' => (int)($this->firstValue($item, ['sectionOrder', 'section_order']) ?? 0),
        'textMode' => (string)($this->firstValue($item, ['textMode', 'text_mode']) ?? 'short'),
        'restrictionEnabled' => $this->toBool($this->firstValue($item, ['restrictionEnabled', 'restriction_enabled'])),
        'restrictionType' => (string)($this->firstValue($item, ['restrictionType', 'restriction_type']) ?? 'text'),
        'restrictionOperator' => (string)($this->firstValue($item, ['restrictionOperator', 'restriction_operator']) ?? ''),
        'restrictionValue' => (string)($this->firstValue($item, ['restrictionValue', 'restriction_value']) ?? ''),
        'restrictionValueSecondary' => (string)($this->firstValue($item, ['restrictionValueSecondary', 'restriction_value_secondary']) ?? ''),
        'columns' => $columns,
        'statements' => $statements,
    ];
}

/**
 * @param array<string, mixed> $item
 * @param array<int, string> $keys
 * @return mixed
 */
private function firstValue(array $item, array $keys): mixed{
    foreach ($keys as $key) {
        if (array_key_exists($key, $item)) return $item[$key];
    }
    return null;
}

/**
 * @param mixed $value
 * @return array<int, array<string, string>>
 */
private function normalizeBranchingRules(mixed $value): array{
    if ($value === null || $value === '') return [];

    if (is_array($value)) {
        if ($this->isListArray($value)) {
            return array_values(array_filter(array_map(function ($item) {
                if (!is_array($item)) return null;
                return [
                    'operator' => (string)($item['operator'] ?? 'answered'),
                    'value' => (string)($item['value'] ?? ''),
                    'target' => (string)($item['target'] ?? $item['goto'] ?? $item['targetQuestion'] ?? '__next__'),
                ];
            }, $value)));
        }

        if (isset($value['operator']) || isset($value['target']) || isset($value['goto'])) {
            return [[
                'operator' => (string)($value['operator'] ?? 'answered'),
                'value' => (string)($value['value'] ?? ''),
                'target' => (string)($value['target'] ?? $value['goto'] ?? $value['targetQuestion'] ?? '__next__'),
            ]];
        }

        return [];
    }

    $raw = trim((string)$value);
    if ($raw === '') return [];

    $decoded = json_decode($raw, true);
    if (is_array($decoded)) {
        return $this->normalizeBranchingRules($decoded);
    }

    $parts = preg_split('/\s*,\s*(?=\{)/', $raw) ?: [];
    $rules = [];
    foreach ($parts as $part) {
        $item = json_decode((string)$part, true);
        if (is_array($item) && !empty($item)) {
            $rules[] = [
                'operator' => (string)($item['operator'] ?? 'answered'),
                'value' => (string)($item['value'] ?? ''),
                'target' => (string)($item['target'] ?? $item['goto'] ?? $item['targetQuestion'] ?? '__next__'),
            ];
        }
    }

    return $rules;
}

/**
 * @param mixed $value
 * @return array<int, string>
 */
private function normalizeDisplayValue(mixed $value): string|false{
    if ($value === null) return false;
    $normalized = trim((string)$value);
    if ($normalized === '') return false;
    if (in_array(strtolower($normalized), ['false', 'null', 'undefined'], true)) return false;
    return $normalized;
}

/**
 * @param string $value
 * @return array<int, string>
 */
private function splitListScalar(string $value): array{
    $normalized = trim($value);
    if ($normalized === '') return [];
    $decoded = json_decode($normalized, true);
    if (is_array($decoded)) {
        return $this->normalizeList($decoded);
    }
    if (str_contains($normalized, ',') || preg_match('/\r?\n/', $normalized)) {
        $parts = preg_split('/\s*,\s*|\r?\n/', $normalized) ?: [];
        return array_values(array_filter(array_map(static fn($item) => trim((string)$item), $parts), static fn($item) => $item !== ''));
    }
    return [$normalized];
}

/**
 * @param mixed $value
 * @return array<int, string>
 */
private function normalizeList(mixed $value): array{
    if ($value === null || $value === '') return [];
    if (!is_array($value)) return $this->splitListScalar((string)$value);

    if (array_key_exists('@value', $value) && count($value) <= 2) {
        return $this->splitListScalar((string)$value['@value']);
    }

    $list = [];
    $append = function(string $entry) use (&$list): void {
        foreach ($this->splitListScalar($entry) as $item) {
            if ($item !== '') $list[] = $item;
        }
    };

    if ($this->isListArray($value)) {
        foreach ($value as $entry) {
            if (is_array($entry)) {
                if (array_key_exists('@value', $entry)) $append((string)$entry['@value']);
                elseif (array_key_exists('value', $entry)) $append((string)$entry['value']);
                else {
                    $encoded = trim((string)json_encode($entry));
                    if ($encoded !== '') $list[] = $encoded;
                }
            } else {
                $append((string)$entry);
            }
        }
        return array_values(array_filter($list, static fn($v) => $v !== ''));
    }

    foreach ($value as $entry) {
        if (is_array($entry)) {
            if (array_key_exists('@value', $entry)) $append((string)$entry['@value']);
            elseif (array_key_exists('value', $entry)) $append((string)$entry['value']);
        } elseif ($entry !== null && $entry !== '') {
            $append((string)$entry);
        }
    }
    return array_values(array_filter($list, static fn($v) => $v !== ''));
}

/**
 * @param mixed $value
 * @return bool
 */
private function toBool(mixed $value): bool{
    if (is_bool($value)) return $value;
    if (is_numeric($value)) return (int)$value === 1;
    $normalized = strtolower(trim((string)$value));
    return in_array($normalized, ['1', 'true', 'yes', 'on', 'enabled'], true);
}

/**
 * @param array<mixed> $array
 * @return bool
 */
private function isListArray(array $array): bool{
    if ($array === []) return true;
    return array_keys($array) === range(0, count($array) - 1);
}

}