<?php
/**
 * Text similarity helper used by quiz grading.
 *
 * The configured leniency threshold can be passed either as a raw percentage
 * or inside the metadata settings array under:
 *   text_similarity_leniency.percent
 *
 * If the threshold is missing or blank, the default is 70%.
 */
class Similarity {
    public const DEFAULT_THRESHOLD = 70.0;

    public static function calculate(string $correctAnswer, string $userAnswer): float {
        $correct = mb_strtolower(trim($correctAnswer));
        $user = mb_strtolower(trim($userAnswer));

        if ($correct === '' && $user === '') {
            return 100.0;
        }

        if ($correct === '' || $user === '') {
            return 0.0;
        }

        $distance = levenshtein($correct, $user);
        $maxLen = max(mb_strlen($correct), mb_strlen($user));

        if ($maxLen === 0) {
            return 100.0;
        }

        $similarity = (1 - ($distance / $maxLen)) * 100;
        return max(0.0, min(100.0, round($similarity, 2)));
    }

    public static function resolveThreshold(mixed $settingsOrThreshold = null): float {
        if (is_array($settingsOrThreshold)) {
            $candidate = $settingsOrThreshold['text_similarity_leniency']['percent'] ?? null;
        } else {
            $candidate = $settingsOrThreshold;
        }

        if ($candidate === '' || $candidate === null || !is_numeric($candidate)) {
            return self::DEFAULT_THRESHOLD;
        }

        return max(0.0, min(100.0, (float)$candidate));
    }

    public static function bestSimilarity(string $userAnswer, array|string $acceptedAnswers): float {
        $acceptedList = is_array($acceptedAnswers) ? $acceptedAnswers : [$acceptedAnswers];
        $best = 0.0;

        foreach ($acceptedList as $acceptedAnswer) {
            $acceptedAnswer = (string)$acceptedAnswer;
            if (trim($acceptedAnswer) === '') {
                continue;
            }
            $best = max($best, self::calculate($acceptedAnswer, $userAnswer));
            if ($best >= 100.0) {
                break;
            }
        }

        return $best;
    }

    public static function isTextAnswerCorrect(string $userAnswer, array|string $acceptedAnswers, mixed $settingsOrThreshold = null): bool {
        $normalizedUserAnswer = trim($userAnswer);
        if ($normalizedUserAnswer === '') {
            return false;
        }

        $threshold = self::resolveThreshold($settingsOrThreshold);
        return self::bestSimilarity($normalizedUserAnswer, $acceptedAnswers) >= $threshold;
    }
}
