<?php
declare(strict_types=1);
use TechDeck\Addons\Form\FormUtils;
include_once dirname(__DIR__, 2) . '/init.php';
include_once 'libs/form.lib.php';
header('Content-Type: application/json; charset=utf-8');
if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}
function response_error(int $status, string $message): never {
    http_response_code($status);
    echo json_encode(['success' => false, 'error' => $message], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}
function ensure_upload_dir(string $path): void {
    if (!is_dir($path) && !@mkdir($path, 0777, true) && !is_dir($path)) {
        throw new RuntimeException('Unable to create upload directory.');
    }
}
function normalize_nested_uploads(array $files): array {
    $mapped = [];
    if (!isset($files['name']) || !is_array($files['name'])) return $mapped;
    foreach ($files['name'] as $questionId => $names) {
        $questionId = (string)$questionId;
        if (!is_array($names)) continue;
        $mapped[$questionId] = [];
        foreach ($names as $index => $name) {
            $error = $files['error'][$questionId][$index] ?? UPLOAD_ERR_NO_FILE;
            if ($error === UPLOAD_ERR_NO_FILE) continue;
            $mapped[$questionId][] = [
                'name' => (string)$name,
                'type' => (string)($files['type'][$questionId][$index] ?? ''),
                'tmp_name' => (string)($files['tmp_name'][$questionId][$index] ?? ''),
                'error' => (int)$error,
                'size' => (int)($files['size'][$questionId][$index] ?? 0),
            ];
        }
        if (!$mapped[$questionId]) unset($mapped[$questionId]);
    }
    return $mapped;
}
function append_submit_answer(DOMDocument $dom, DOMElement $questionEl, mixed $value, array &$answerSummary): void {
    $answerEl = $dom->createElement('answer');
    if (is_array($value)) {
        $encoded = json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        $answerEl->appendChild($dom->createTextNode($encoded === false ? '' : $encoded));
        $answerSummary[] = $value;
    } else {
        $text = trim((string)$value);
        $answerEl->appendChild($dom->createTextNode($text));
        $answerSummary[] = $text;
    }
    $questionEl->appendChild($answerEl);
}
try {
    $formId = trim((string)($_POST['formId'] ?? ''));
    $csrfToken = trim((string)($_POST['csrfToken'] ?? ''));
    $responseId = trim((string)($_POST['responseId'] ?? ''));
    if ($formId === '') response_error(400, 'Missing formId');
    $expectedToken = $_SESSION['forms_csrf_tokens'][$formId] ?? '';
    if (!is_string($expectedToken) || $expectedToken === '' || !hash_equals($expectedToken, $csrfToken)) {
        response_error(403, 'Invalid CSRF token');
    }
    $formUtils = new FormUtils($formId);
    $xml = $formUtils->xml();
    if (!$xml) response_error(404, 'Form not found');

    $responses = json_decode((string)($_POST['responses'] ?? '{}'), true);
    if (!is_array($responses)) response_error(400, 'Invalid responses payload');
    if ($responseId === '') {
        $responseId = str_replace('.', '', uniqid('response_', true));
    }
    $timestamp = gmdate(DATE_ATOM);

    $uploadSummary = [];
    if (isset($_FILES['files']) && is_array($_FILES['files'])) {
        foreach (normalize_nested_uploads($_FILES['files']) as $questionId => $normalized) {
            if (!$normalized) continue;
            $savedFiles = [];
            $baseDir = dirname(__FILE__) . '/uploads/forms/' . basename($formId) . '/' . basename($responseId) . '/' . basename((string)$questionId);
            ensure_upload_dir($baseDir);
            foreach ($normalized as $file) {
                if ($file['error'] !== UPLOAD_ERR_OK) continue;
                $safeName = preg_replace('/[^a-zA-Z0-9._-]/', '_', $file['name']) ?: 'upload.bin';
                $target = $baseDir . '/' . uniqid('file_', true) . '_' . $safeName;
                if (!@move_uploaded_file($file['tmp_name'], $target)) {
                    throw new RuntimeException('Unable to save uploaded file.');
                }
                $savedFiles[] = [
                    'name' => $file['name'],
                    'type' => $file['type'],
                    'size' => $file['size'],
                    'path' => str_replace(dirname(__FILE__) . '/', '', $target),
                ];
            }
            if ($savedFiles) {
                $uploadSummary[(string)$questionId] = $savedFiles;
            }
        }
    }
    foreach ($uploadSummary as $questionId => $files) {
        $responses[$questionId] = $files;
    }

    $dom = new DOMDocument('1.0', 'UTF-8');
    $dom->preserveWhiteSpace = false;
    $dom->formatOutput = true;
    $dom->loadXML($xml->asXML());
    $responsesNode = $dom->getElementsByTagName('responses')->item(0);
    if (!$responsesNode instanceof DOMElement) {
        $responsesNode = $dom->createElement('responses');
        $dom->documentElement->appendChild($responsesNode);
    }

    $existing = null;
    foreach ($responsesNode->getElementsByTagName('response') as $responseNode) {
        if ($responseNode instanceof DOMElement && $responseNode->getAttribute('id') === $responseId) {
            $existing = $responseNode;
            break;
        }
    }

    $responseEl = $dom->createElement('response');
    $responseEl->setAttribute('id', $responseId);
    $responseEl->setAttribute('timestamp', $timestamp);
    $responsePayload = [
        'id' => $responseId,
        'timestamp' => $timestamp,
        'answers' => [],
    ];

    foreach ($responses as $questionId => $answer) {
        $questionId = trim((string)$questionId);
        if ($questionId === '') continue;
        $questionEl = $dom->createElement('question');
        $questionEl->setAttribute('id', $questionId);
        $values = is_array($answer) ? $answer : [$answer];
        $answerSummary = [];
        foreach ($values as $value) {
            append_submit_answer($dom, $questionEl, $value, $answerSummary);
        }
        $responseEl->appendChild($questionEl);
        $responsePayload['answers'][] = [
            'questionId' => $questionId,
            'answers' => $answerSummary,
        ];
    }

    if ($existing instanceof DOMElement) {
        $responsesNode->replaceChild($responseEl, $existing);
        $mode = 'updated';
    } else {
        $responsesNode->appendChild($responseEl);
        $mode = 'created';
    }

    $filePath = dirname(__FILE__) . '/database/' . basename($formId) . '.xml';
    $dom->save($filePath);
    echo json_encode([
        'success' => true,
        'mode' => $mode,
        'responseId' => $responseId,
        'response' => $responsePayload,
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
    response_error(500, $e->getMessage());
}
