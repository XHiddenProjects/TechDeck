<?php
declare(strict_types=1);

use TechDeck\Addons\Form\FormUtils;
include_once dirname(__DIR__,2)."/init.php";
include_once dirname(__FILE__)."/libs/form.lib.php";
header('Content-Type: application/json; charset=utf-8');

try {
    // Only allow POST requests for creation
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        http_response_code(405);
        echo json_encode([
            'success' => false,
            'error'   => 'Method not allowed. Use POST.'
        ]);
        exit;
    }

    // Optional inputs (you can expand later)
    $type  = isset($_POST['type']) ? strtolower(trim((string)$_POST['type'])) : 'form'; // form|quiz
    $title = isset($_POST['title']) ? trim((string)$_POST['title']) : '';

    if (!in_array($type, ['form', 'quiz'], true)) {
        http_response_code(400);
        echo json_encode([
            'success' => false,
            'error'   => 'Invalid type. Allowed: form, quiz.'
        ]);
        exit;
    }

    // Create new item (your FormUtils already creates the XML structure and returns the id)
    $utils = new FormUtils();
    $formId = $utils->createNew(); // returns string id 

    // OPTIONAL: if you want to store title/type in XML metadata, you can update it here.
    // Your XML template includes /form/metadata/title by default. 
    if ($title !== '') {
        $utils->data()->updateElementValue('/form/metadata/title', $title);
        $utils->data()->save($formId, null, null); // uses dbPath set in Data constructor
    }

    // OPTIONAL: store "quiz" vs "form" in metadata (only if you want)
    // If you do, make sure you have a place for it; example adds <type>:
    if ($type === 'quiz') {
        // Add type node if missing (safe attempt)
        $xml = $utils->xml();
        $hasType = false;
        if ($xml && isset($xml->metadata->type)) {
            $hasType = true;
        }
        if (!$hasType) {
            $utils->data()->addElement('/form/metadata', 'type', [], 'quiz');
            $utils->data()->save($formId, null, null);
        } else {
            $utils->data()->updateElementValue('/form/metadata/type', 'quiz');
            $utils->data()->save($formId, null, null);
        }
    }

    echo json_encode([
        'success' => true,
        'formId'  => $formId,
        'type'    => $type
    ]);
    exit;

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error'   => 'Server error: ' . $e->getMessage()
    ]);
    exit;
}