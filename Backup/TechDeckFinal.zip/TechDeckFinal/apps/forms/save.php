<?php
declare(strict_types=1);
use TechDeck\Addons\Form\FormUtils;
include_once dirname(__DIR__, 2) . '/init.php';
include_once 'libs/form.lib.php';
header('Content-Type: application/json; charset=utf-8');
if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}
function save_response_error(int $status, string $message): never {
    http_response_code($status);
    echo json_encode(['success' => false, 'error' => $message], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}
function append_answer_node(DOMDocument $owner, DOMElement $questionEl, mixed $value): void {
    $answerEl = $owner->createElement('answer');
    if (is_array($value)) {
        $encoded = json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        $answerEl->appendChild($owner->createTextNode($encoded === false ? '' : $encoded));
    } else {
        $answerEl->appendChild($owner->createTextNode(trim((string)$value)));
    }
    $questionEl->appendChild($answerEl);
}
$formId = isset($_POST['formId']) ? trim((string)$_POST['formId']) : '';
$csrfToken = isset($_POST['csrfToken']) ? trim((string)$_POST['csrfToken']) : '';
$responseId = trim((string)($_POST['responseId'] ?? ''));
if ($formId === '') {
    save_response_error(400, 'Missing formId');
}
$expectedToken = $_SESSION['forms_csrf_tokens'][$formId] ?? '';
if (!is_string($expectedToken) || $expectedToken === '' || !hash_equals($expectedToken, $csrfToken)) {
    save_response_error(403, 'Invalid CSRF token');
}
$formUtils = new FormUtils($formId);
$data = $formUtils->xml();
if (!$data) {
    save_response_error(404, 'Form not found');
}
$responses = json_decode((string)($_POST['responses'] ?? '[]'), true);
if (!is_array($responses)) {
    save_response_error(400, 'Invalid responses payload');
}
if ($responseId === '') {
    $responseId = str_replace('.', '', uniqid('response_', true));
}
$timestamp = gmdate(DATE_ATOM);
$formDom = new DOMDocument('1.0', 'UTF-8');
$formDom->preserveWhiteSpace = false;
$formDom->formatOutput = true;
$formDom->loadXML($data->asXML());
$responsesElement = $formDom->getElementsByTagName('responses')->item(0);
if (!$responsesElement instanceof DOMElement) {
    $responsesElement = $formDom->createElement('responses');
    $formDom->documentElement->appendChild($responsesElement);
}
$existing = null;
foreach ($responsesElement->getElementsByTagName('response') as $responseNode) {
    if ($responseNode instanceof DOMElement && $responseNode->getAttribute('id') === $responseId) {
        $existing = $responseNode;
        break;
    }
}
$responseElement = $formDom->createElement('response');
$responseElement->setAttribute('id', $responseId);
$responseElement->setAttribute('timestamp', $timestamp);
foreach ($responses as $questionId => $answer) {
    $questionId = trim((string)$questionId);
    if ($questionId === '') {
        continue;
    }
    $questionElement = $formDom->createElement('question');
    $questionElement->setAttribute('id', $questionId);
    $values = is_array($answer) ? $answer : [$answer];
    foreach ($values as $value) {
        append_answer_node($formDom, $questionElement, $value);
    }
    $responseElement->appendChild($questionElement);
}
if ($existing instanceof DOMElement) {
    $responsesElement->replaceChild($responseElement, $existing);
    $mode = 'updated';
} else {
    $responsesElement->appendChild($responseElement);
    $mode = 'created';
}
$filePath = dirname(__FILE__) . '/database/' . basename($formId) . '.xml';
$formDom->save($filePath);
echo json_encode(['success' => true, 'responseId' => $responseId, 'mode' => $mode], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
