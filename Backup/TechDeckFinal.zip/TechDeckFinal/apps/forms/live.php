<?php
declare(strict_types=1);
use TechDeck\Storage;
use TechDeck\Addons;
use TechDeck\Addons\Form\FormUtils;

include_once dirname(__DIR__, 2) . '/init.php';
include_once dirname(__FILE__) . '/libs/form.lib.php';

$addon = new Addons();
$storage = new Storage();
if (!$storage->session('TechDeck_auth', action: 'Get') && !$storage->cookie(name: 'TechDeck_auth', action: 'load')) {
    header('Location: ' . URL . DS . 'auth');
    exit;
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}

$formId = isset($_GET['formId']) ? preg_replace('/[^a-zA-Z0-9_-]/', '_', (string) $_GET['formId']) : '';
if ($formId === '') {
    http_response_code(400);
    echo '<!doctype html><html><body><h1>Missing form id.</h1></body></html>';
    exit;
}

$responseId = isset($_GET['responseId']) ? trim((string) $_GET['responseId']) : '';
$requestedMode = isset($_GET['mode']) ? strtolower(trim((string) $_GET['mode'])) : '';
$forceEditorMode = $requestedMode === 'edit';

$formUtils = new FormUtils($formId);
$xml = $formUtils->xml();
if (!$xml) {
    http_response_code(404);
    echo '<!doctype html><html><body><h1>Form not found.</h1></body></html>';
    exit;
}

if (!isset($_SESSION['forms_csrf_tokens']) || !is_array($_SESSION['forms_csrf_tokens'])) {
    $_SESSION['forms_csrf_tokens'] = [];
}
if (!isset($_SESSION['forms_csrf_tokens'][$formId]) || !is_string($_SESSION['forms_csrf_tokens'][$formId]) || $_SESSION['forms_csrf_tokens'][$formId] === '') {
    $_SESSION['forms_csrf_tokens'][$formId] = bin2hex(random_bytes(32));
}

$boot = [
    'formId' => $formId,
    'editorMode' => ($forceEditorMode || $formUtils->isEditorMode()),
    'requestedMode' => $requestedMode,
    'isQuiz' => $formUtils->isQuiz(),
    'csrfToken' => $_SESSION['forms_csrf_tokens'][$formId],
    'loadUrl' => './loadSave.php',
    'saveUrl' => './saveForm.php',
    'submitUrl' => './submit.php',
    'deleteUrl' => './deleteForm.php',
    'indexUrl' => './',
    'responseId' => $responseId,
    'editingResponse' => $responseId !== '',
    'currentUser' => (string)($xml->metadata->author ?? ''),
    'defaultTextSimilarityThreshold' => 70,
];
?>
<!doctype html>
<html lang="en">
<head>
    <?=preg_replace('/<title>(.*?)<\/title>/','',$addon->hook('head'));?>
    <title><?= htmlspecialchars((string)($xml->metadata->title ?? 'Form'), ENT_QUOTES, 'UTF-8') ?></title>
    <?=$addon->hook('css');?>
    <link rel="stylesheet" href="./css/live.css?v=20260408-template-branching-filelimit">
</head>
<body>
    <div id="forms-app" class="forms-app-shell" data-boot='<?= htmlspecialchars(json_encode($boot, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE), ENT_QUOTES, 'UTF-8') ?>'>
        <div class="forms-app-loading">
            <div class="spinner-border text-primary" role="status" aria-hidden="true"></div>
            <div>Loading form editor…</div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="js/forms-template-enhancements.js?v=20260408-template-branching-filelimit"></script>
    <script src="js/forms-script.js?v=20260408-template-branching-filelimit"></script>
    <script src="js/forms-export-ui.js?v=20260408-template-branching-filelimit"></script>
    <script src="js/form-templates.js?v=20260408-template-branching-filelimit"></script>
</body>
</html>
