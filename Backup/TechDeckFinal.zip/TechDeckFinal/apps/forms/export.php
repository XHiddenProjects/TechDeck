<?php
declare(strict_types=1);

use TechDeck\Addons\Form\FormUtils;

include_once dirname(__DIR__, 2) . '/init.php';
include_once dirname(__FILE__) . '/libs/form.lib.php';

header('X-Content-Type-Options: nosniff');

function request_bool(string $key, bool $default = true): bool {
    $value = $_POST[$key] ?? $_GET[$key] ?? null;
    if ($value === null) return $default;
    if (is_bool($value)) return $value;
    $normalized = strtolower(trim((string)$value));
    return in_array($normalized, ['1', 'true', 'yes', 'on'], true);
}

function respond_error(string $message, int $status = 400): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['success' => false, 'error' => $message], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

$formId = trim((string)($_POST['formId'] ?? $_GET['formId'] ?? ''));
if ($formId === '') {
    respond_error('Missing formId.');
}

$formUtils = new FormUtils($formId);
$xml = $formUtils->xml();
if ($xml === null) {
    respond_error('Form not found.', 404);
}

$filePath = dirname(__FILE__) . '/database/' . basename($formId) . '.xml';
if (!is_file($filePath)) {
    respond_error('Saved form file not found.', 404);
}

$format = strtolower(trim((string)($_POST['format'] ?? $_GET['format'] ?? 'xml')));
if (!in_array($format, ['xml', 'json'], true)) {
    $format = 'xml';
}

$includeMetadata  = request_bool('includeMetadata', true);
$includeStyles    = request_bool('includeStyles', true);
$includeSettings  = request_bool('includeSettings', true);
$includeUi        = request_bool('includeUi', true);
$includeQuestions = request_bool('includeQuestions', true);
$includeResponses = request_bool('includeResponses', true);
$includeScoring   = request_bool('includeScoring', true);
$includeBranching = request_bool('includeBranching', true);
$includeMedia     = request_bool('includeMedia', true);

$dom = new DOMDocument('1.0', 'UTF-8');
$dom->preserveWhiteSpace = false;
$dom->formatOutput = true;
$dom->load($filePath);
$xpath = new DOMXPath($dom);

$removeNode = static function (?DOMNode $node): void {
    if ($node instanceof DOMNode && $node->parentNode instanceof DOMNode) {
        $node->parentNode->removeChild($node);
    }
};

if (!$includeMetadata) {
    $removeNode($xpath->query('/form/metadata')->item(0));
} else {
    if (!$includeStyles) {
        $removeNode($xpath->query('/form/metadata/styles')->item(0));
    }
    if (!$includeSettings) {
        $removeNode($xpath->query('/form/metadata/settings')->item(0));
    }
    if (!$includeUi) {
        $removeNode($xpath->query('/form/metadata/ui')->item(0));
    }
}

if (!$includeQuestions) {
    $removeNode($xpath->query('/form/questions')->item(0));
} else {
    foreach ($xpath->query('/form/questions/*') as $questionNode) {
        if (!$includeScoring) {
            foreach (['pointValue', 'correctAnswers', 'correctAnswersJson', 'acceptedAnswers', 'acceptedAnswersJson'] as $field) {
                $removeNode($xpath->query('./' . $field, $questionNode)->item(0));
            }
        }
        if (!$includeBranching) {
            foreach (['branching', 'branchingRules', 'branchingRulesJson'] as $field) {
                $removeNode($xpath->query('./' . $field, $questionNode)->item(0));
            }
        }
        if (!$includeMedia) {
            foreach (['mediaUrl', 'mediaType', 'mediaAlt'] as $field) {
                $removeNode($xpath->query('./' . $field, $questionNode)->item(0));
            }
        }
    }
}

if (!$includeResponses) {
    $removeNode($xpath->query('/form/responses')->item(0));
}

$baseName = basename($formId) . '-export.' . $format;

if ($format === 'json') {
    $simple = simplexml_load_string($dom->saveXML(), 'SimpleXMLElement', LIBXML_NOCDATA);
    if ($simple === false) {
        respond_error('Failed to convert export XML to JSON.', 500);
    }
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $baseName . '"');
    echo json_encode($simple, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

header('Content-Type: application/xml; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $baseName . '"');
echo $dom->saveXML();
