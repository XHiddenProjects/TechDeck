# Privacy Policy for TechDeck

_Last Updated: 10.12.2025_

TechDeck is an open-source administrative, network, and server tools suite designed for use on personalized devices and localhost servers. Since TechDeck operates locally and does not transmit or collect user data, this Privacy Policy reflects that.

## 1. Data Collection and Usage

- **No Data Collection:** TechDeck does not collect, store, or transmit any personal or system data.
- **Local Use:** All data processed by TechDeck remains on your local device and server.
- **No External Communication:** The software does not communicate with external servers or services unless explicitly added through custom configurations by the user.

## 2. Data Security

- Since no user data is collected or transmitted, TechDeck does not pose risks related to data privacy.
- Users are responsible for securing their own systems and data.

## 3. Cookies and Tracking

- TechDeck does not use cookies or tracking technologies outside of the software.
- TechDeck does use cookies and tracking technologies for administrative/users uses. 

## 4. Third-Party Integrations

- If third-party plugins or tools are integrated, review their privacy policies accordingly.
- TechDeck itself does not manage or control third-party data policies.

## 5. Changes to this Privacy Policy

- This Privacy Policy may be updated from time to time. Changes will be posted on this page with an updated date.

## 6. Contact Us

- For questions about this Privacy Policy, please contact us at [https://github.com/XHiddenProjects/TechDeck](https://github.com/XHiddenProjects/TechDeck).