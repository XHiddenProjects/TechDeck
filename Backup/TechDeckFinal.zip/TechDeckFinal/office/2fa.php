<?php
use TechDeck\Locales, TechDeck\Addons, TechDeck\Security, TechDeck\tools\Markdown,TechDeck\Storage;
$addon = new Addons();
$l = implode('-',LANGUAGE);
$lang = new Locales($l);
$security = new Security();
$md = new Markdown();
$storage = new Storage();

if($storage->session('TechDeck_auth', action: 'Get')||$storage->cookie(name: 'TechDeck_auth',action: 'load')){
    header('Location: '.URL.DS.'dashboard');
}
?>
<!DOCTYPE html>
<html lang="<?=$l?>">
    <head>
        <?php
        echo $addon->hook('head');
        echo $addon->hook('css');
        ?>
    </head>
    <body class="tfa-panel-page">
        <div class="tfa-panel d-block m-auto">
            <h1 class='text-center'><?php echo $lang->load(['mfa','_form']);?></h1>
            <form method="post" novalidate>
                <div class="alert alert-danger d-none"></div>
                <input type="hidden" name="main" value="<?php echo $security->safe_base64_encode(URL);?>"/>
                <input type="hidden" name="token" value="<?php echo $security->CSRF()?>"/>

                <div class="tfa-mode-group">
                    <label class="form-label" for="mfa_mode">Verification method</label>
                    <select class="form-select" id="mfa_mode" name="mfa_mode">
                        <option value="totp" selected>Authenticator code</option>
                        <option value="recovery">Use recovery code</option>
                    </select>
                    <small class="tfa-mode-help">If you can't access your authenticator, switch to a recovery code in the format <strong>xxxxx-xxxxx</strong>.</small>
                </div>

                <input
                    type="text"
                    autocomplete="off"
                    autocorrect="off"
                    spellcheck="false"
                    autofocus
                    class="form-control text-center"
                    placeholder="000000"
                    name="mfa_code"
                    inputmode="numeric"
                    maxlength="6"
                    required
                />
                <span class="error-msg alert alert-danger"><?php echo $lang->load(['errors','emptyInput']);?></span>
                <button type="submit" class="btn btn-primary mt-2"><?php echo $lang->load(['buttons','submit']);?></button>
            </form>
        </div>

        <footer><?php echo $addon->hook('footer');?></footer>
        <?php
        echo $addon->hook('scripts');
        ?>
    </body>
</html>
