<?php
declare(strict_types=1);

namespace TechDeck;

/**
 * Class Data
 *
 * A lightweight XML importer + builder utility.
 *
 * Supports:
 *  - Importing XML from a file located in a custom directory (fallback to DATA_PATH)
 *  - Importing XML from a raw XML string
 *  - Creating a brand-new XML document in memory (builder mode)
 *  - Mutating XML via XPath: add/remove/update
 *  - Saving XML back into the selected directory (fallback to DATA_PATH)
 *
 * Notes:
 *  - `get()` is optional. You can call `create()` to start building from scratch.
 *  - If `get()` fails, you can optionally auto-create a root by providing `$rootIfMissing`.
 *
 * Requirements:
 *  - Constants DATA_PATH and DS should be defined in your project.
 */
class Data {
    public const SAVE_RAW    = 'raw';    // current behavior
    public const SAVE_PRETTY = 'pretty'; // formatted/indented
    public const SAVE_MINIFY = 'minify'; // compact (no extra whitespace)

    /**
     * The currently loaded or created XML document.
     *
     * @var \SimpleXMLElement|null
     */
    private ?\SimpleXMLElement $xml = null;

    /**
     * Name of the file that was loaded (without .xml extension), if any.
     * Used as a default save target when calling save() without a name.
     *
     * @var string|null
     */
    private ?string $loadedName = null;

    /**
     * Optional base directory for file operations. When null/empty, falls back to DATA_PATH.
     *
     * @var string|null
     */
    private ?string $basePath = null;

    /**
     * Data constructor.
     *
     * Optional convenience behavior:
     *  - If $fileOrXmlString is provided, attempts to import it:
     *      (1) as <basePath>/<name>.xml (basePath can be custom, falling back to DATA_PATH)
     *      (2) as a raw XML string
     *  - If import fails and $rootIfMissing is provided, creates a new XML document.
     *  - If no $fileOrXmlString but $rootIfMissing is provided, creates a new XML document.
     *
     * @param string|null $fileOrXmlString File name (without .xml) OR raw XML string.
     * @param string|null $rootIfMissing Root name to create if import fails / not provided.
     * @param array<string, scalar|null> $rootAttributes Attributes for the root when creating.
     * @param string|null $basePath Optional custom directory path for file operations; falls back to DATA_PATH if empty.
     */
    public function __construct(?string $fileOrXmlString = null, ?string $rootIfMissing = null, array $rootAttributes = [], ?string $basePath = null) {
        $this->setBasePath($basePath);
        if ($fileOrXmlString !== null) {
            $this->get($fileOrXmlString, $rootIfMissing, $rootAttributes);
        } elseif ($rootIfMissing !== null) {
            $this->create($rootIfMissing, $rootAttributes);
        }
    }

    /**
     * Set a custom directory used for reading/writing XML files.
     * If null/empty, the class will fall back to DATA_PATH.
     *
     * @param string|null $basePath Custom directory path.
     * @return self Fluent self for chaining.
     */
    public function setBasePath(?string $basePath = null): self {
        $basePath = $basePath !== null ? trim($basePath) : null;
        if ($basePath === null || $basePath === '') {
            $this->basePath = null;
            return $this;
        }
        $this->basePath = rtrim($basePath, "\\/");
        return $this;
    }

    /**
     * Get the effective base directory for file operations.
     * Uses the per-call override first, then the object's basePath, then DATA_PATH.
     *
     * @param string|null $overridePath Optional per-call directory override.
     * @return string The resolved base directory.
     */
    private function resolveBasePath(?string $overridePath = null): string {
        $overridePath = $overridePath !== null ? trim($overridePath) : null;
        if ($overridePath !== null && $overridePath !== '') {
            return rtrim($overridePath, "\\/");
        }
        if ($this->basePath !== null && $this->basePath !== '') {
            return $this->basePath;
        }
        return DATA_PATH;
    }

    /**
     * Build an XML file path for a given name in a resolved base directory.
     *
     * @param string $name File name with or without .xml.
     * @param string|null $basePath Optional per-call base directory.
     * @return string Absolute/relative file path.
     */
    private function buildFilePath(string $name, ?string $basePath = null): string {
        $name = preg_replace('/\.xml$/i', '', trim($name));
        return $this->resolveBasePath($basePath) . DS . $name . '.xml';
    }

    /**
     * Create a brand-new XML document in memory (builder mode).
     *
     * @param string $rootName Root element name. Defaults to "root" if empty.
     * @param array<string, scalar|null> $attributes Root element attributes.
     * @param string $version XML version string (default "1.0").
     * @param string $encoding XML encoding (default "UTF-8").
     * @return self Fluent self for chaining.
     */
    public function create(string $rootName = 'root', array $attributes = [], string $version = '1.0', string $encoding = 'UTF-8'): self {
        $rootName = trim($rootName) !== '' ? $rootName : 'root';
        $this->xml = new \SimpleXMLElement(sprintf('<?xml version="%s" encoding="%s"?><%s/>', $version, $encoding, $rootName));
        foreach ($attributes as $k => $v) {
            $this->xml->addAttribute((string)$k, (string)$v);
        }
        $this->loadedName = null;
        return $this;
    }

    /**
     * Import XML from:
     *  1) a file located at <basePath>/<name>.xml (basePath can be custom; falls back to DATA_PATH), or
     *  2) a raw XML string.
     *
     * If import fails and $rootIfMissing is provided, a new XML document is created instead.
     *
     * @param string $fileOrXmlString File name (without .xml) OR raw XML string.
     * @param string|null $rootIfMissing Root name to create if file/string import fails.
     * @param array<string, scalar|null> $rootAttributes Root attributes used when auto-creating.
     * @param string|null $basePath Optional per-call directory override; falls back to DATA_PATH if empty.
     * @return \SimpleXMLElement|false Loaded/created XML on success; false on failure if not auto-creating.
     */
    public function get(string $fileOrXmlString, ?string $rootIfMissing = null, array $rootAttributes = [], ?string $basePath = null): bool|\SimpleXMLElement {
        $candidate = trim($fileOrXmlString);

        // (1) Attempt file load: <basePath>/<name>.xml
        $filePath = $this->buildFilePath($candidate, $basePath);
        if (is_file($filePath)) {
            $xml = simplexml_load_file($filePath);
            if ($xml !== false) {
                $this->xml = $xml;
                $this->loadedName = preg_replace('/\.xml$/i', '', $candidate);
                return $this->xml;
            }
        }

        // (2) Attempt parse as raw XML string
        libxml_use_internal_errors(true);
        $xml = simplexml_load_string($candidate);
        if ($xml !== false) {
            $this->xml = $xml;
            $this->loadedName = null;
            return $this->xml;
        }

        // (3) Auto-create if requested
        if ($rootIfMissing !== null) {
            $this->create($rootIfMissing, $rootAttributes);
            return $this->xml;
        }

        return false;
    }

    /**
     * Get the currently loaded/created XML document.
     *
     * @return \SimpleXMLElement|null The current XML document or null if none.
     */
    public function xml(): ?\SimpleXMLElement {
        return $this->xml;
    }

    /**
     * Save XML to <basePath>/<name>.xml.
     *
     * - If $xml is not provided, saves the internally stored document.
     * - If $name is not provided, attempts to use the last loaded file name.
     * - If $basePath is not provided/empty, uses the object's basePath; if that is empty, falls back to DATA_PATH.
     *
     * @param string|null $name Target file name (with or without .xml). If null, uses last loaded file name.
     * @param \SimpleXMLElement|null $xml XML object to save. If null, uses internal document.
     * @param string|null $basePath Optional per-call directory override; falls back to DATA_PATH if empty.
     * @param string $format Optional to save the XML file as raw, minify, or pretty
     * @return bool True on success, false on failure.
     */
    
    public function save(?string $name = null,?\SimpleXMLElement $xml = null,?string $basePath = null,string $format = self::SAVE_RAW): bool {
        $xml ??= $this->xml;

        // strict null check
        if ($xml === null) {
            return false;
        }

        if (!$name || trim($name) === '') {
            return false;
        }

        $path = $this->buildFilePath($name, $basePath);
        $dir = dirname($path);

        if (!is_dir($dir)) {
            if (!@mkdir($dir, 0777, true) && !is_dir($dir)) {
                return false;
            }
        }

        // RAW: keep existing behavior
        if ($format === self::SAVE_RAW) {
            return (bool) $xml->asXML($path);
        }

        // PRETTY / MINIFY: use DOMDocument
        $dom = new \DOMDocument('1.0', 'UTF-8');

        // If you want to preserve meaningful whitespace inside text nodes,
        // do NOT set preserveWhiteSpace=false. But most config-style XML wants trimming.
        $dom->preserveWhiteSpace = false;

        // Pretty mode indents; minify does not.
        $dom->formatOutput = ($format === self::SAVE_PRETTY);

        // Load the XML string into DOM
        $loaded = $dom->loadXML($xml->asXML(), LIBXML_NOBLANKS);
        if ($loaded === false) {
            return false;
        }

        // Save to disk
        $bytes = $dom->save($path);
        return ($bytes !== false);
    }



    /**
     * Add a child element to the first node matching the given parent XPath.
     *
     * Builder-friendly behavior:
     *  - If no XML is loaded yet:
     *      - If $rootIfMissing is provided, it will create the document and then attempt the add.
     *      - Otherwise returns false.
     *
     * Root selector support:
     *  - "/", ".", "" and "/<rootName>" are treated as the document root.
     *
     * @param string $parentXPath XPath to the parent node (e.g. "/users", "/users/user[@id='1']", "/", ".").
     * @param string $elementName Name of new element (e.g. "user").
     * @param array<string, scalar|null> $attributes Attributes to apply to the new element.
     * @param string|null $value Optional text value for the new element.
     * @param string|null $rootIfMissing Root to create if no document exists.
     * @param array<string, scalar|null> $rootAttributes Root attributes to use if creating the document.
     * @return bool True if element was added, false otherwise.
     */
    
    public function addElement(string $parentXPath,string $elementName,array $attributes = [],?string $value = null,?string $rootIfMissing = null,array $rootAttributes = []): bool {
        // ✅ FIX: strict null check (NOT boolean check)
        if ($this->xml === null) {
            if ($rootIfMissing !== null) {
                $this->create($rootIfMissing, $rootAttributes);
            } else {
                return false;
            }
        }

        $parentXPath = trim($parentXPath);
        $rootName = $this->xml->getName();

        if ($parentXPath === '' || $parentXPath === '/' || $parentXPath === '.' || $parentXPath === ('/' . $rootName)) {
            $parentNode = $this->xml;
        } else {
            $parents = $this->xml->xpath($parentXPath);
            if (empty($parents)) {
                return false;
            }
            $parentNode = $parents[0];
        }

        $new = $parentNode->addChild($elementName, $value ?? null);
        foreach ($attributes as $attr => $val) {
            $new->addAttribute((string)$attr, (string)$val);
        }

        return true;
    }


    /**
     * Remove all elements matching the given XPath.
     *
     * @param string $xpath XPath to the elements to remove (e.g. "/users/user[@id='2']").
     * @return bool True if at least one element was removed; false if none matched or no XML loaded.
     */
    public function removeElement(string $xpath): bool {
        if (!$this->xml) {
            return false;
        }

        $elements = $this->xml->xpath($xpath);
        if (empty($elements)) {
            return false;
        }

        foreach ($elements as $element) {
            $dom = dom_import_simplexml($element);
            if ($dom && $dom->parentNode) {
                $dom->parentNode->removeChild($dom);
            }
        }

        return true;
    }

    /**
     * Ensure a simple XPath exists by creating any missing child nodes.
     *
     * Supported paths are simple element paths such as:
     * - /form/questions/q1/title
     * - form/questions/q1/title
     *
     * If the current document root is included as the first segment, it is skipped.
     * Complex XPath expressions (predicates, attributes, wildcards, functions, etc.)
     * are not auto-created and will return null when no node exists.
     *
     * @param string $xpath XPath to create if missing.
     * @return \SimpleXMLElement|null The resolved/final node, or null if the path cannot be created.
     */
    private function ensurePathExists(string $xpath): ?\SimpleXMLElement {
        if ($this->xml === null) {
            return null;
        }

        $xpath = trim($xpath);
        if ($xpath === '' || $xpath === '/' || $xpath === '.') {
            return $this->xml;
        }

        $segments = array_values(array_filter(explode('/', trim($xpath, '/')), static fn(string $segment): bool => $segment !== ''));
        if ($segments === []) {
            return $this->xml;
        }

        $rootName = $this->xml->getName();
        if ($segments[0] === $rootName) {
            array_shift($segments);
        }

        $current = $this->xml;
        foreach ($segments as $segment) {
            // Auto-create only simple node names; leave complex XPath expressions untouched.
            if (preg_match('/[\[\]@\*\(\)="\'\s:]/', $segment)) {
                return null;
            }

            $matches = $current->xpath("./$segment");
            if (!empty($matches)) {
                $current = $matches[0];
                continue;
            }

            $created = $current->addChild($segment);
            if ($created === null) {
                return null;
            }

            $current = $created;
        }

        return $current;
    }

    /**
     * Update the text value of all elements matching the given XPath.
     * If the XPath does not exist and it is a simple element path,
     * the missing nodes are created and the final node is assigned the value.
     *
     * @param string $xpath XPath to target elements (e.g. "/users/user[@id='1']").
     * @param string $newValue Replacement text value.
     * @return bool True if at least one element was updated/created; false otherwise.
     */
    public function updateElementValue(string $xpath, string $newValue): bool {
        if ($this->xml === null) {
            return false;
        }

        $elements = $this->xml->xpath($xpath);
        if (!empty($elements)) {
            foreach ($elements as $element) {
                $element[0] = $newValue;
            }

            return true;
        }

        $element = $this->ensurePathExists($xpath);
        if ($element === null) {
            return false;
        }

        $element[0] = $newValue;
        return true;
    }

    /**
     * Export the current XML document to a PHP array.
     *
     * @return array<string, mixed>|false Array representation, or false if no XML is loaded.
     */
    public function toArray(): array|false {
        if (!$this->xml) {
            return false;
        }
        return json_decode(json_encode($this->xml), true);
    }

    /**
     * Export the current XML document to an XML string.
     *
     * @return string|false XML string or false if no XML is loaded.
     */
    public function toString(): string|false {
        if (!$this->xml) {
            return false;
        }
        return $this->xml->asXML();
    }
    /**
     * Get and clear the last libxml errors.
     *
     * @return array<int, string> Error messages.
     */
    public function lastXmlErrors(): array {
        $errors = libxml_get_errors();
        libxml_clear_errors();
        return array_map(static fn($e) => trim($e->message), $errors);
    }
}