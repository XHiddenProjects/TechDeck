<?php
namespace TechDeck;

use ErrorException,
TechDeck\Security\JWT,
TechDeck\Security\MFA,
TechDeck\Security\CSRF,
TechDeck\Security\Rate,
TechDeck\Server,
DateTime, 
DateInterval,
TransportModesKPH,
TechDeck\Device,
TechDeck\Security\Captcha,
TechDeck\Config,
TechDeck\Database,
TechDeck\Users,
TechDeck\Security\Recovery,
TechDeck\Utils;
class Security{
    public const SANITIZE_DEFAULT = "/[^a-zA-Z0-9\s!@#$%^&*()\-_=+\[\]{}|;:\'\",.<>\/?`~]/",
    SANITIZE_EMAIL = "/[^a-zA-Z0-9._@]/",
    SANITIZE_PHONE = "/[^+\d]/",
    SANITIZE_INT = "/[^\d]/",
    SANITIZE_FLOAT = "/[^\d.]/",
    SANITIZE_STRING = "/[^a-zA-Z0-9\s]/",
    SANITIZE_SPECIAL_CHARS = "/[^.*+?\\\^$()\[\]\/{}|@!#%&<>,.~`=-_\s]/",
    SANITIZE_URL = "/[^a-zA-Z0-9\-_\.\~\/\?\=\&\:\%\;]/",
    FILTER_DEFAULT = "/[a-zA-Z0-9\s!@#$%^&*\(\)\-_=\+\[\]\{\}|;:\'\",.<\/?`~]+/",
    FILTER_EMAIL = "/[a-z0-9!#$%&'*+\/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+\/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/",
    FILTER_PHONE = "/^\s*(?:\+?\d{1,3}[\s.-]?)?(?:\(?\d{3}\)?[\s.-]?)?\d{3}[\s.-]?\d{4}(?:[\s.-]?\d{3,4})*\s*$/",
    FILTER_INT = "/^[+-]?\d+$/",
    FILTER_FLOAT = "/^[+-]?(\d+(\.\d*)?|\.\d+)$/",
    FILTER_DATE = "/(?:(?:\b\d{4}[-\/\.](?:0?[1-9]|1[0-2])[-\/\.](?:0?[1-9]|[12][0-9]|3[01])\b)|(?:\b(?:0?[1-9]|[12][0-9]|3[01])[-\/\.](?:0?[1-9]|1[0-2])[-\/\.]\d{4}\b)|(?:\b\d{4}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{4}\b)|(?:\b(?:0?[1-9]|[12][0-9]|3[01])\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{4}\b)|(?:\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2},?\s+\d{4}\b)|(?:\b\d{1,2}\s+(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*,?\s+\d{4}\b))/",
    FILTER_TIME = "/^(?:(?:0?[1-9]|1[0-2])(?:\:[0-5]\d){1,2}(?:\:[0-5]\d)?\s?(?:AM|PM|am|pm)?|(?:[01]?\d|2[0-3])(?:\:[0-5]\d){1,2}(?:\:[0-5]\d)?)$/",
    FILTER_IPV4 = "/^(?:(?:25[0-5]|2[0-4]\d|1?\d{1,2})\.){3}(?:25[0-5]|2[0-4]\d|1?\d{1,2})$/",
    FILTER_IPV6 = "/^((?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|:(?::[0-9a-fA-F]{1,4}){1,7}|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:(:|[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){0,5})|fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(?:ffff:(?:25[0-5]|2[0-4]\d|1?\d{1,2})(?:\.(?:25[0-5]|2[0-4]\d|1?\d{1,2})){3})|(?:[0-9a-fA-F]{1,4}:){1,4}:(?:25[0-5]|2[0-4]\d|1?\d{1,2})(?:\.(?:25[0-5]|2[0-4]\d|1?\d{1,2})){3})$/i",
    FILTER_ADDR = "/(?:(?:\d+\s+[A-Za-z0-9\s.,'-]+)\s*,?\s*)?(?:[A-Za-z\s]+)?\s*,?\s*(?:[A-Za-z\s]+)?\s*,?\s*(?:[A-Z]{2,}|[A-Za-z\s]+)?\s*,?\s*(?:\d{5}|\d{4,6}|[A-Za-z0-9\s-]+)?\s*,?\s*(?:[A-Za-z\s]+)?/",
    FILTER_SSN = "/^(?!000|666|9\d{2})\d{3}-(?!00)\d{2}-(?!0000)\d{4}$/",
    FILTER_URL = "/[(http(s)?):\/\/(www\.)?a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&\/\/=]*)/",
    FILTER_LOCALHOST_URL = "/https?:\/\/localhost(\/(.*))?/",
    MASK_SSN = "/(\d{3})-(\d{2})/",
    MASK_CARD_PAN = "/(\d{12})|(\d{4}) ?(\d{4}) ?(\d{4})/",
    MASK_PHONE_NUMBER = "/(\d{4})$/",
    # Location Spoofing threshold
    LOCATION_SPOOF_THRESHOLD = 1;
    public function __construct() {
        
    }
    /**
     * Sets security headers
     * @param array{header:string} $headers List of headers
     * @return void Sets the header of the website
     */
    public function setSecurityHeaders(array $headers=[]): void{
        header("Content-Security-Policy: img-src 'self' data:; default-src 'self'; script-src 'self' https://code.jquery.com/jquery-3.7.1.min.js https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js; object-src 'none';");
        header("X-Content-Type-Options: nosniff");
        header("X-Frame-Options: DENY");
        header("X-XSS-Protection: 1; mode=block");
        header("Referrer-Policy: no-referrer");
        header("Content-Security-Policy: frame-ancestors 'none'");
        if(!empty($headers)){
            foreach($headers as $header){
                $header = $this->preventXSS($header);
                if($this->preventRequestSmuggling($header)) header($header);
            }
        }
    }
    /**
     * Audits the code in the 
     * @param string $directory Directory path to audit
     * @return void
     */
    public function auditCode(string $directory = ADDONS_PATH): void {
        $issues = [];
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($directory)
        );
        foreach ($iterator as $file) {
            if ($file->isFile() && pathinfo($file->getFilename(), PATHINFO_EXTENSION) === 'php') {
                $content = file_get_contents($file->getRealPath());
                
                $dangerousFunctions = [
                    'shell_exec(',
                    'eval(',
                    'exec(',
                    'system(',
                    'passthru(',
                    'popen(',
                    'proc_open(',
                    'create_function(',
                    'assert('
                ];

                foreach ($dangerousFunctions as $func) {
                    if (strpos($content, $func) !== false) {
                        $issueMsg = "Potential unsafe usage of '{$func}' in: " . $file->getRealPath();
                        $issues[] = $issueMsg;
                        $this->logSecurityEvent('code_audit', $issueMsg);
                        break;
                    }
                }

                // Check for usage of $_GET, $_POST without sanitization
                if (preg_match('/\$_(GET|POST|REQUEST)/', $content) && !strpos($content, 'filter_input') && !strpos($content, 'sanitize')) {
                    $issueMsg = "Possible unsafe input handling in: " . $file->getRealPath();
                    $issues[] = $issueMsg;
                    $this->logSecurityEvent('code_audit', $issueMsg);
                }

                // Check if error_reporting is not set
                if (strpos($content, 'error_reporting') === false) {
                    $issueMsg = "Error reporting not configured in: " . $file->getRealPath();
                    $issues[] = $issueMsg;
                    $this->logSecurityEvent('code_audit', $issueMsg);
                }
            }
        }

        if (!empty($issues)) {
            foreach ($issues as $issue) {
                $this->logSecurityEvent('code_audit', $issue);
            }
        }
    }
    /**
     * Removes script tag to prevent XSS
     * @param string $str String to sanitize
     * @param bool $preventQuotes Prevents the quotes from being encoded
     * @return string|null Sanitized string
     */
    public function preventXSS(string $str, bool $preventQuotes=false): string|null {
        return htmlspecialchars($str,$preventQuotes ? ENT_NOQUOTES : ENT_QUOTES);
    }
    /**
     * Sanitizes the string
     * @param string $input String to sanitize
     * @param string $pattern RegExp to sanitize
     * @return string Sanitized string
     */
    public function sanitize(string $input, string $pattern=self::SANITIZE_DEFAULT): string{
        return htmlspecialchars(preg_replace($pattern,'',$input),ENT_QUOTES);
    }
    /**
     * Filters the string to proper format
     * @param string $input Input to filter
     * @param string $pattern RegExp to filter
     * @return string Filtered string
     */
    public function filter(string $input, string $pattern=self::FILTER_DEFAULT): string{
        if(preg_match($pattern,$input,$matches)) {
            return match($pattern){
                self::FILTER_FLOAT=>(float)$matches[0],
                self::FILTER_INT=>(int)$matches[0],
                default=>htmlspecialchars($matches[0],ENT_QUOTES)
            };
        }
        else return '';
    }
    /**
     * Checks the version of the application against the latest version
     * @return bool|int Returns true if the current version is less than the latest version, false otherwise
     */
    public function checkVersion(): bool{
        $v1 = file_get_contents(VERSION);
        $u = new Utils();
        $v2 = $u->request('https://raw.githubusercontent.com/XHiddenProjects/TechDeck/refs/heads/master/VERSION',
        'GET',
        ['headers'=>['User-Agent'=>'TechDeck/1.0']]);
        return @version_compare(trim($v1), trim($v2['response']), '<');
    }
    /**
     * Creates/Verifies CSRF token
     * @param string $action Actions: "Load", "verify", "Generate"
     * @param string $token Token input, **if verify**
     * @param bool $forceGenerate forces to regenerate
     * @return bool|string|null Returns token if loaded, else TRUE/FALSE on verify
     * @throws ErrorException Invalid action
     */
    public function CSRF(string $action='load', string $token='', bool $forceGenerate=false): bool|string|null{
        $c = new CSRF();
        $action = strtolower($action);
        if($action==='load') return $c->getToken();
        elseif($action==='verify') return $c->verify($token);
        elseif($action==='generate') return $c->generate($forceGenerate);
        else throw new ErrorException('Must be a load or verify action');
    }
    /**
     * Multi-factor authentication
     * @param string $user Username
     * @param string $action GET or VERIFY or SEND
     * @param string|int $code  Verification code
     * @return bool|string TRUE if verified, else FALSE. Returns TOTP URL if action="get"
     */
    public function MFA(string $secret, string|int $code=0, string $action='GET'): bool|string{
        $m = new MFA();
        $action = strtolower($action);
        if($action==='get')
            return $m->getTOTP($secret);
        if($action==='send')
            return $m->getCurrentCode($_SESSION['temp_user']??'');
        else
            return $m->verify($secret,$code);
    }
    /**
     * Checks for JSON Web Token
     * @param string $secret Secret
     * @param array $payload Payload
     * @param string $token Token(Encoded payload)
     * @param string $action Encode/Decode
     * @param int|null $exp Expiration in seconds
     * @return array|bool|string Results of the key
     */
    public function JWT(string $secret, array $payload = [], string $token = '', string $action = 'encode', ?int $exp = null): array|bool|string {
        // Instantiate JWT class
        $jwt = new JWT($secret);
        $action = strtolower($action);
        if ($action === 'encode') {
            // Encode payload with expiration
            return $jwt->encode($payload, [], $exp);
        } elseif ($action === 'decode') {
            // Decode token
            return $jwt->decode($token);
        } else {
            return false; // Invalid action
        }
    }
    /**
     * Prevents request smuggling and header injection
     * @param string|null $header Optional header string to validate before setting
     * @return bool TRUE if safe, otherwise FALSE
     */
    public function preventRequestSmuggling(?string $header = null): bool {
        if ($header === null) {
            // Check all existing headers for CRLF injection
            $headers = headers_list();
            foreach ($headers as $hdr) {
                if (preg_match('/\r\n|\n|\r||\\\\r|\\\\n/', $hdr)) {
                    // Log the incident
                    $this->logSecurityEvent("Potential request smuggling attempt detected: header contains CRLF characters");
                    return false;
                }
            }
        } else {
            // Validate the header string before setting
            // Detect dangerous CR, LF characters that could indicate injection
            if (preg_match('/\r\n|\n|\r|\\\\r|\\\\n/', $header)) {
                $this->logSecurityEvent("Header injection attempt detected in header string");
                return false;
            }
            // You can sanitize or encode the header here if needed before setting
        }

        // Check for conflicting Content-Length and Transfer-Encoding headers
        if (isset($_SERVER['HTTP_CONTENT_LENGTH']) && isset($_SERVER['HTTP_TRANSFER_ENCODING'])) {
            $contentLength = intval($_SERVER['HTTP_CONTENT_LENGTH']);
            $transferEncoding = $_SERVER['HTTP_TRANSFER_ENCODING'];

            if ($contentLength > 0 && strcasecmp($transferEncoding, 'chunked') === 0) {
                $this->logSecurityEvent("Conflicting Content-Length and Transfer-Encoding headers");
                return false;
            }
        }

        // All checks passed
        return true;
    }

    /**
     * Security event
     * @param string $name Log name
     * @param string $event Event to log
     * @return void
     */
    public function logSecurityEvent(string $name='security', string $event=''): void {
        if (error_reporting() === 0) return;
        if (!ini_get('log_errors')) return;
        
        $log = LOG.DS."$name.log";

        // Read entire log file content
        $content = '';
        if (file_exists($log)) $content = file_get_contents($log);
        // Get the last line
        $lines = explode("\n", trim($content));
        $lastLine = end($lines);

        // Extract the timestamp from the last log line
        $lastTimestamp = null;
        if (!empty($lastLine)) {
            // Assuming log format: [YYYY-MM-DD HH:MM:SS.ssssss] message
            if (preg_match('/\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}\.\d+)\]/', $lastLine, $matches)) {
                $lastTimestamp = $matches[1];
            }
        }

        // Get the current timestamp with microseconds
        $currentTimestamp = date('Y-m-d H:i:s.u');

        // Compare the timestamps
        if ($lastTimestamp === $currentTimestamp) {
            // Last log entry is at the same timestamp; skip logging
            return;
        }

        // Log the event
        error_log("[".$currentTimestamp."] $event".PHP_EOL, 3, $log);
    }
    /**
     * Hits the user base on the rate limit
     * @return bool TRUE if the rate is good, else false
     */
    public function rateLimit(): bool{
        $rate = new Rate();
        if($rate->hit()) return true;
        else {
            header("HTTP/1.1 429 Too Many Requests");
            return false;
        } 
    }
    /**
     * Enforces HTTPS unless on localhost
     * @return void
     */
    public function enforceHTTPS(): void {
        $host = $_SERVER['HTTP_HOST'] ?? '';
        // Check if running on localhost
        if (strpos($host, 'localhost') !== false || $host === '127.0.0.1') return;
        if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] !== 'on') {
            $httpsUrl = "https://$host{$_SERVER['REQUEST_URI']}";
            header("Location: $httpsUrl");
            exit();
        }
    }
    /**
     * Regenerates a new session
     * @param bool $deleteOldCookie Deletes any old cookies
     * @return bool TRUE on success, else FALSE
     */
    public function regenerateSession(bool $deleteOldCookie=false): bool{
        return @session_regenerate_id($deleteOldCookie);
    }
    /**
     * Prevents session fixation
     * @return bool TRUE on success, else FALSE
     */
    public function preventSessionFixation(): bool{
        $this->regenerateSession(true);
        $params = session_get_cookie_params();
        return @session_set_cookie_params([
            'lifetime'=>$params['lifetime'],
            'path'=>$params['path'],
            'domain'=>$params['domain'],
            'secure'=>true,
            'httponly'=>true,
            'samesite'=>'Strict'
        ]);
    }
    /**
     * Performing a penetration test
     * @return array{disabled_functions: bool|string, php_version: string, port_443_open: string, port_80_open: string}
     */
    public function penTest(): array{
        $server = new Server();
        $results = [
            'port_80_open'=>$server->checkPort('127.0.0.1', 80)[0]['status'],
            'port_443_open'=>$server->checkPort('127.0.0.1', 443)[0]['status'],
            'php_version'=>PHP_VERSION,
            'disabled_functions'=>ini_get('disable_functions')
        ];
        return $results;
    }
    /**
     * Generate an SRI hash for a local file.
     *
     * @param string $filePath Path to the file
     * @param string $algorithm Hash algorithm (default: 'sha384')
     * @return string|false The SRI hash string or false on failure
     */
    public function generateSRI($filePath, $algorithm = 'sha384'): bool|string {
        if (!file_exists($filePath)) {
            return false; // File does not exist
        }
        // Get the file contents
        $fileData = file_get_contents($filePath);
        if ($fileData === false) {
            return false;
        }
        $hash = hash($algorithm, $fileData, true);
        $base64Hash = base64_encode($hash);
        return "$algorithm-$base64Hash";
    }
    /**
     * Masks a specific part of the string based on a regex, replacing only the matched digits with mask characters.
     * @param string $input String to mask
     * @param string $regExp RegExp to match and mask
     * @param string $mask Mask character (default: *)
     * @return string|null Masked string or null if no match
     */
    public function mask(string $input, string $regExp, string $mask='*'): ?string {
        // Use preg_replace_callback to process each match
        $result = preg_replace_callback($regExp, function($matches) use ($mask): mixed {
            // $matches[0] is the full match, $matches[1], $matches[2], ... are groups
            // We'll replace only the groups (e.g., digits) with the mask, keeping the original parts intact
            $maskedGroups = [];
            for ($i = 1; $i < \count($matches); $i++) {
                // For each group, replace its characters with the mask character
                $maskedGroups[$i] = \is_string($matches[$i]) ? str_repeat($mask, \strlen($matches[$i])) : $matches[$i];
            }
            $maskedString = $matches[0];
            foreach ($maskedGroups as $index => $maskedPart) {
                $originalGroup = $matches[$index];
                $maskedString = str_replace($originalGroup, $maskedPart, $maskedString);
            }
            return $maskedString;
        }, $input);
        if ($result !== $input) {
            return $result;
        } else {
            return null; // no match found
        }
    }
    /**
     * Hash your password
     * @param string $input Password
     * @param string $algo Algorithm
     * @param array $options Options
     * @return string Hashed password
     */
    public function hashPsw(string $input, string $algo=PASSWORD_DEFAULT, array $options=[]): string{
        return password_hash($input,$algo,$options);
    }
    /**
     * Verifies the raw password with the hashed password 
     * @param string $input Password
     * @param string $hash Hashed password
     * @return bool TRUE if password matches, else FALSE
     */
    public function verify(string $input, string $hash): bool{
        return password_verify($input,$hash);
    }
    /**
     * Starts the session
     * @return bool
     */
    public function sessionStart(): bool{
        if (session_status() !== PHP_SESSION_ACTIVE) return session_start();
        else return true;
    }
    /**
     * Checks if the location has been spoofed.
     * 
     * @param string $lastTimestamp Last timestamp to check.
     * @param float $lat1 Start Latitude.
     * @param float $lon1 Start Longitude.
     * @param float $lat2 End Latitude.
     * @param float $lon2 End Longitude.
     * @param int $speed Speed (100kph Car speed, in urban areas).
     * @param float $threshold How many hours difference to count as spoof.
     * @return array{isSpoofed: bool, interval: string, distanceDifference: float, estimateTime: string, intervalSpec: string} An associative array containing spoofing detection results and related info.
     * - **isSpoofed**: TRUE if location is considered spoofed, FALSE otherwise
     * - **interval**: Human-readable time interval between timestamps
     * - **distanceDifference**: Calculated difference in distance between 2 points. **Measurement:** _km_
     * - **estimateTime**: Calculates the estimate time between 2 points. **Format:** _(hrs, min)_
     * - **intervalSpec**: Debugging purpose to get the interval format
     */
    
public function locationSpoofed(string $lastTimestamp,float $lat1,float $lon1,float $lat2,float $lon2,int $speed = TransportModesKPH::CAR_HIGHWAY,float $threshold = self::LOCATION_SPOOF_THRESHOLD): array {
    function getDistanceAndSeconds($latitudeFrom, $longitudeFrom, $latitudeTo, $longitudeTo, $speedKph = 50): array {
        if ($speedKph <= 0) 
            throw new \InvalidArgumentException('Speed must be greater than 0 km/h.');
        $earthRadius = 6371; // km
        $latFromRad = deg2rad($latitudeFrom);
        $lonFromRad = deg2rad($longitudeFrom);
        $latToRad   = deg2rad($latitudeTo);
        $lonToRad   = deg2rad($longitudeTo);

        $latDelta = $latToRad - $latFromRad;
        $lonDelta = $lonToRad - $lonFromRad;

        $angle = 2 * asin(sqrt(
            pow(sin($latDelta / 2), 2) +
            cos($latFromRad) * cos($latToRad) * pow(sin($lonDelta / 2), 2)
        ));

        $distanceKm = $angle * $earthRadius;
        $distanceMeters = $distanceKm * 1000;

        $speedKps = $speedKph / 3600.0; // km/s
        $timeSeconds = (int)max(0, round($distanceKm / $speedKps));

        return [
            'distance'    => $distanceMeters, // meters
            'timeSeconds' => $timeSeconds,
        ];
    }

    $calc = getDistanceAndSeconds($lat1, $lon1, $lat2, $lon2, $speed);

    $initialDate  = new DateTime($lastTimestamp);
    $timeSeconds  = (int)$calc['timeSeconds'];

    // Build interval directly from seconds
    $interval = new DateInterval("PT{$timeSeconds}S");

    $expectedDate = (clone $initialDate)->add($interval);
    $currentDate  = new DateTime();

    $diff = $currentDate->diff($expectedDate);

    // Absolute hours difference for threshold comparison
    $hoursDifference = $diff->days * 24 + $diff->h + ($diff->i / 60);

    // Spoof if expected is in the future by more than threshold hours
    $isSpoofed = ($currentDate < $expectedDate) && ($hoursDifference > $threshold);

    // For display, break total seconds into d/h/m
    $remaining = $timeSeconds;
    $days      = intdiv($remaining, 86400); $remaining %= 86400;
    $hours     = intdiv($remaining, 3600);  $remaining %= 3600;
    $minutes   = intdiv($remaining, 60);

    $estimateTime = \sprintf('%d days %d hours, %d minutes', $days, $hours, $minutes);

    return [
        'isSpoofed'          => $isSpoofed,
        'interval'           => $diff->format('%a days, %h hours, %i minutes, %s seconds'),
        'distanceDifference' => $calc['distance'], // meters
        'estimateTime'       => $estimateTime,
        'intervalSpec'       => "PT{$timeSeconds}S", // handy for debugging
    ];
}

    /**
     * Handles the upload of one or multiple files with security validations.
     *
     * @param array|array[] $file An element from the $_FILES superglobal, e.g., $_FILES['file'], or an array of such elements for multiple uploads.
     * @param array $options Optional. Configuration options for upload.
     *                       - 'uploadDir' (string): Directory where files will be saved. Default: 'uploads/'.
     *                       - 'allowedMimeTypes' (array): List of allowed MIME types. Default: ['image/jpeg', 'image/png', 'application/pdf'].
     *                       - 'maxFileSize' (int): Maximum allowed file size in bytes. Default: 5MB.
     *
     * @return array An array of result messages for each file.
     */
    public function upload($file, $options = []): array {
        $results = [];
        // Set default options
        $defaults = [
            'uploadDir' => UPLOAD_PATH,
            'allowedMimeTypes' => ['image/jpeg', 'image/png', 'application/pdf'],
            'maxFileSize' => 5 * 1024 * 1024, // 5MB
        ];
        $opts = array_merge($defaults, $options);

        // Check if multiple files
        if (isset($file['name']) && \is_array($file['name'])) {
            // Multiple files
            $fileCount = \count($file['name']);
            for ($i = 0; $i < $fileCount; $i++) {
                $singleFile = [
                    'name' => $file['name'][$i],
                    'type' => $file['type'][$i],
                    'tmp_name' => $file['tmp_name'][$i],
                    'error' => $file['error'][$i],
                    'size' => $file['size'][$i],
                    'path'=>$file['path'][$i],
                ];
                $results[] = $this->processSingleFile($singleFile, $opts);
            }
        } else 
            // Single file
            $results[] = $this->processSingleFile($file, $opts);
        return $results;
    }

    /**
     * Processes a single file upload with security validations.
     *
     * @param array $file Single file info array.
     * @param array $opts Options array.
     * @return string Result message.
     */
    private function processSingleFile($file, $opts): array {
        // Check for upload errors
        if ($file['error'] !== UPLOAD_ERR_OK) return ['status'=>false,'msg'=>"Error during file upload: {$file['name']}"];
        // Validate file size
        if ($file['size'] > $opts['maxFileSize']) return ['status'=>false,'msg'=>"File is too large: {$file['name']}"];
        // Validate MIME type
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mimeType = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);
        if (!\in_array($mimeType, $opts['allowedMimeTypes'])&&!empty($opts['allowedMimeTypes'])) return ['status'=>false,"Invalid file type: {$file['name']}"];
        

        // Generate a secure filename
        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $newFilename = bin2hex(random_bytes(16)) . '.' . $extension;

        // Ensure upload directory exists
        if (!is_dir($opts['uploadDir'])) mkdir($opts['uploadDir'], 0755, true);
            $destination = rtrim($opts['uploadDir'],'/')."/$newFilename";
        // Move the uploaded file
        if (move_uploaded_file($file['tmp_name'], $destination)) 
            return ['status'=>true,'msg'=>"File uploaded successfully: $destination",'destination'=>preg_replace('/\/submissions/','',UPLOAD_URL)."/$newFilename",'name'=>$newFilename];
        else 
            return ['status'=>false,'msg'=>"Failed to move uploaded file: {$file['name']}"];
    }
    /**
     * Checks if the device has matching mac address
     * @param string $device_name Device name
     * @return bool TRUE if the device mac is matched, else FALSE
     */
    public function compareSerial(string $device_name): bool{
        $d = new Device();
        return $d->getSerial()===$d->getSerial($device_name);
    }
    /**
     * Creates a captcha
     * @param string $input Input to validate the captcha
     * @return bool|string  Create: image html; Verify: TRUE if valid captcha, else FALSE
     */
    public function Captcha(string $input=''): bool|string {
        $captcha = new Captcha();
        if ($input) {
            if($captcha->validate($input)) {
                $captcha->create();
                return true;
            }
            else {$captcha->create(); return false;}
        } else {
            $captcha->create();
            // Return the <img> tag pointing to this script
            return "<div class='input-group mt-2'>
                <img src='".URL.DS."temp".DS."captcha.png' alt='CAPTCHA' class='input-group-text'/>
                <input class='form-control' name='captcha' id='captcha_".uniqid()."' required/>
            </div>";
        }
    }
    /**
     * Generates a random secret key
     * @param int $length Length of the key, (Default 26)
     * @return string Secret key
     */
    public function randomSecret($length=26): string{
        $randomBytes = random_bytes($length);
        $base32Chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $binaryString = '';
        // Convert each byte to 8-bit binary
        foreach (str_split($randomBytes) as $byte) 
            $binaryString .= str_pad(decbin(\ord($byte)), 8, '0', STR_PAD_LEFT);
        $base32 = '';
        // Split into 5-bit chunks and map to Base32
        for ($i = 0; $i < \strlen($binaryString); $i += 5) {
            $chunk = substr($binaryString, $i, 5);
            if (\strlen($chunk) < 5) 
                $chunk = str_pad($chunk, 5, '0');
            $base32 .= $base32Chars[bindec($chunk)];
        }
        
        return $base32;
    }

    /**
     * Sanitize a string for safe Base64 operations.
     * - Converts to string
     * - Trims whitespace
     * - Normalizes line endings
     * - Removes most control characters except \r, \n, \t
     */
    private function sanitize_string_for_base64($input): string{
        if ($input===null) 
            return '';
        // Convert to string safely (handles scalars/objects with __toString)
        if (!\is_string($input)) {
            if (\is_scalar($input)) {
                $input = (string)$input;
            } elseif (\is_object($input) && method_exists($input, '__toString')) {
                $input = (string)$input;
            } else {
                throw new \InvalidArgumentException('Input is not convertible to string.');
            }
        }

        // Normalize line endings to \n
        $input = str_replace(["\r\n", "\r"], "\n", $input);

        // Remove all C0 control characters except \n, \r, \t
        $input = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $input);

        // Trim surrounding whitespace
        return trim($input);
    }

    /**
     * Base64 encode with sanitization.
     *
     * @param string|scalar|object $data        Data to encode (will be sanitized).
     * @param bool $urlSafe                    When true, uses URL-safe alphabet (-_) instead of +/
     * @param bool $stripPadding               When true, removes trailing "=" padding (common for URL tokens)
     * @return string
     */
    public function safe_base64_encode($data, bool $urlSafe = true, bool $stripPadding = false): string{
        // If you need to encode raw binary (e.g., file contents), skip sanitization:
        // here we sanitize for text inputs. For raw bytes, pass them directly and remove this line.
        $sanitized = $this->sanitize_string_for_base64($data);

        $b64 = base64_encode($sanitized);

        if ($urlSafe) {
            // Make it URL-safe: + -> -, / -> _
            $b64 = strtr($b64, '+/', '-_');
        }

        if ($stripPadding) {
            $b64 = rtrim($b64, '=');
        }

        return $b64;
    }

    /**
     * Base64 decode with sanitization and strict validation.
     *
     * @param string $b64           Base64 string to decode.
     * @param bool $urlSafe         If true, accepts URL-safe alphabet (-_) and normalizes it.
     * @param bool $strict          If true, validates characters and padding; throws on invalid input.
     * @return string               Decoded string (text). For binary data, treat the return as raw bytes.
     * @throws \InvalidArgumentException on invalid Base64 when $strict is true.
     */
    public function safe_base64_decode(string $b64, bool $urlSafe = true, bool $strict = true): string{
        // Sanitize input first
        $b64 = $this->sanitize_string_for_base64($b64);

        // Normalize URL-safe to standard alphabet if needed
        if ($urlSafe) {
            $b64 = strtr($b64, '-_', '+/');
        }

        // Restore padding if missing (Base64 requires length % 4 == 0)
        $mod = \strlen($b64) % 4;
        if ($mod !== 0) {
            $b64 .= str_repeat('=', 4 - $mod);
        }

        if ($strict) {
            // Validate allowed characters (A–Z, a–z, 0–9, +, /, =)
            if (!preg_match('/^[A-Za-z0-9+\/=]+$/', $b64)) {
                throw new \InvalidArgumentException('Invalid characters in Base64 input.');
            }
            // Validate padding rules: "=" only at the end, max two, and length % 4 == 0
            if (!preg_match('/^(?:[A-Za-z0-9+\/]{4})*(?:[A-Za-z0-9+\/]{2}==|[A-Za-z0-9+\/]{3}=)?$/', $b64)) {
                throw new \InvalidArgumentException('Invalid Base64 padding or structure.');
            }
        }

        $decoded = base64_decode($b64, $strict);

        if ($decoded === false) {
            if ($strict) {
                throw new \InvalidArgumentException('Failed to decode Base64 (invalid input).');
            }
            // In non-strict mode, return empty string on failure
            return '';
        }

        return $decoded;
    }
    
    /**
     * Access the recovery methods
     * @param string $method Recovery code method. **Expired**, **Verify**, and **Generate**
     * @param string $code If verify is enabled, then enter the code to check
     * @return array|bool|null Results of the output
     */
    public function recovery(string $method='expired',string $code=''): array|bool|null{
        $recovery = new Recovery();
        if(strtolower($method)==='expired') return $recovery->hasExpired();
        elseif(strtolower($method)=== 'verify') return $recovery->verify($code);
        elseif(strtolower($method)==='generate') return $recovery->generate();
        else return null;
    }

}