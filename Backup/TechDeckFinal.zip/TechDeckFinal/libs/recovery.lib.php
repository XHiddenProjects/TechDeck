<?php
namespace TechDeck\Security;

use TechDeck\Config, TechDeck\Database, TechDeck\Users, PDO;

class Recovery {
    private $users, $db, $userId;

    public function __construct(?string $username = null) {
        $sessionUsers = new Users();
        $resolvedUsername = trim((string)($username ?? ($_SESSION['temp_user'] ?? '') ?: $sessionUsers->getCurrentSession()));
        $user = $resolvedUsername !== '' ? new Users($resolvedUsername) : new Users();

        $config = new Config();
        $this->db = new Database(
            $config->read('mysql', 'host'),
            $config->read('mysql', 'user'),
            $config->read('mysql', 'psw'),
            $config->read('mysql', 'db')
        );

        $this->userId = $user->getID();
    }

    /**
     * Normalize a recovery code to xxxxx-xxxxx format.
     */
    private function normalizeCode(string $code): string {
        $clean = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', trim($code)));
        if ($clean === '') return '';
        if (strlen($clean) > 10) $clean = substr($clean, 0, 10);
        return strlen($clean) > 5 ? substr($clean, 0, 5) . '-' . substr($clean, 5) : $clean;
    }

    /**
     * Returns all recovery code rows for the current user.
     */
    private function getCodes(): array {
        if (!$this->userId) return [];
        return $this->db->fetchAll(
            'SELECT * FROM recovery_codes WHERE userId=:userId ORDER BY createdAt ASC',
            ['userId' => $this->userId],
            PDO::FETCH_ASSOC
        ) ?? [];
    }

    /**
     * Returns only unused and unexpired recovery code rows.
     */
    private function getUsableCodes(): array {
        $now = strtotime(date('Y-m-d H:i:s'));
        $usable = [];

        foreach ($this->getCodes() as $row) {
            $isUsed = (int)($row['isUsed'] ?? 0) === 1;
            $expireAt = $row['expireAt'] ?? null;
            $expiresAtTs = $expireAt ? strtotime("{$expireAt} 23:59:59") : null;

            if (!$isUsed && $expiresAtTs !== null && $now <= $expiresAtTs) {
                $usable[] = $row;
            }
        }

        return $usable;
    }

    /**
     * Returns TRUE when the current user already has at least one recovery code row.
     */
    public function hasCodes(): bool {
        return !empty($this->getCodes());
    }

    /**
     * Returns TRUE when the current user still has at least one unused, unexpired code.
     */
    public function hasUsableCodes(): bool {
        return !empty($this->getUsableCodes());
    }

    /**
     * Returns TRUE when no usable recovery codes remain.
     * "Usable" = unused and unexpired.
     */
    public function shouldRotateSet(): bool {
        if (!$this->userId) return false;

        $allCodes = $this->getCodes();
        if (empty($allCodes)) return false;

        return empty($this->getUsableCodes());
    }

    /**
     * Ensure the current user has a recovery-code set.
     * If none exist yet, create the initial set.
     */
    public function ensureActiveCodes(int $count = 16): array|null {
        if ($this->userId == 0) return null;

        $existing = $this->getCodes();
        if (empty($existing)) {
            return $this->generate($count, false);
        }

        return $existing;
    }

    /**
     * Generate a recovery-code set.
     *
     * Default behavior is conservative:
     * - if a set already exists, return it as-is
     * - only replace existing codes when $force = true
     */
    public function generate(int $count = 16, bool $force = false): array|null {
        if ($this->userId == 0) return null;

        $existing = $this->getCodes();
        if (!empty($existing) && !$force) {
            return array_map(static fn(array $row): string => (string)($row['code'] ?? ''), $existing);
        }

        if (!empty($existing) && $force) {
            $this->db->delete('recovery_codes', ['userId' => (int)$this->userId]);
        }

        $codes = [];
        for ($i = 0; $i < $count; $i++) {
            $part1 = substr(bin2hex(random_bytes(3)), 0, 5);
            $part2 = substr(bin2hex(random_bytes(3)), 0, 5);
            $code = strtoupper("{$part1}-{$part2}");

            $this->db->insert('recovery_codes', [
                'userId'    => $this->userId,
                'code'      => $code,
                'isUsed'    => 0,
                'createdAt' => date('Y-m-d'),
                'expireAt'  => date('Y-m-d 23:59:59', strtotime('+1 month'))
            ]);

            $codes[] = $code;
        }

        return $codes;
    }

    /**
     * Returns TRUE when the supplied input looks like a recovery code.
     */
    public function isRecoveryCodeFormat(string $code): bool {
        return preg_match('/^[A-Za-z0-9]{5}-?[A-Za-z0-9]{5}$/', trim($code)) === 1;
    }

    /**
     * Replace the current user's set only when no usable codes remain.
     */
    public function refreshDepletedOrExpiredSet(int $count = 16): array|null {
        if (!$this->shouldRotateSet()) return null;

        $this->db->delete('recovery_codes', ['userId' => (int)$this->userId]);
        return $this->generate($count, true);
    }

    /**
     * Verify a recovery code WITHOUT regenerating before validation.
     */
    public function verify(string $code): bool {
        if (!$this->userId) return false;
        if (!$this->isRecoveryCodeFormat($code)) return false;
        
        $normalizedInput = $this->normalizeCode($code) ?? '';
        if ($normalizedInput === '') return false;

        foreach ($this->getCodes() as $storedCode) {
            $storedValue = (string)($storedCode['code'] ?? '');
            if ($storedValue === '') continue;

            if ($this->normalizeCode($storedValue) !== $normalizedInput) {
                continue;
            }

            // Already used
            if ((int)($storedCode['isUsed'] ?? 0) === 1) {
                return false;
            }

            // Expired
            $expireAt = $storedCode['expireAt'] ?? null;
            if ($expireAt && strtotime(date('Y-m-d H:i:s')) > strtotime($expireAt)) {
                return false;
            }

            // Consume the code
            $this->db->update('recovery_codes', [
                'isUsed' => 1,
                'usedAt' => date('Y-m-d')
            ], [
                'userId' => $this->userId,
                'code'   => $storedValue
            ]);

            return true;
        }

        return false;
    }

    /**
     * Kept for backwards compatibility.
     * TRUE when no usable recovery codes remain.
     */
    public function hasExpired(): bool {
        return $this->shouldRotateSet();
    }
}