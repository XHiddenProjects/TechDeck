
<?php
use TechDeck\Mail,TechDeck\Security, TechDeck\Users, TechDeck\Locales, TechDeck\Storage, TechDeck\Config, TechDeck\Database, TechDeck\Device;
header('Content-Type: application/json; charset=utf-8');
$p = dirname(__DIR__).'/libs';
foreach(array_diff(scandir($p),['.','..']) as $f) if(is_file("$p/$f")) include_once "$p/$f";

// Read raw JSON input
$raw = file_get_contents('php://input');
$data = json_decode($raw, true);

// Validate
if (!is_array($data) || empty($data['username']) || empty($data['token'])) {
    echo json_encode(['error' => 'Invalid request: username and token required']);
    exit;
}
$security = new Security();
$users = new Users();
$lang= new Locales(implode('-',LANGUAGE));
$storage = new Storage();
$config = new Config();
$db = new Database(
    $config->read('mysql','host'),
    $config->read('mysql','user'),
    $config->read('mysql','psw'),
    $config->read('mysql','db')
);

$username = $security->preventXSS($data['username']); // sanitize
$token = $security->preventXSS($data['token']); // you can validate token here



$device = new Device();

$mail = new Mail();
$mail->setFrom('no-reply@TechDeck.com','TechDeck');
$mail->isHTML(true);

$failedAttempt=false;

$remember = false;
$main = $security->preventXSS($security->sanitize($security->safe_base64_decode($data['main']),$security::SANITIZE_URL));


$fetchedAttempts = $db->fetch("SELECT * FROM attempts WHERE ip_address=:ip", ['ip'=>$users->getIP()], PDO::FETCH_ASSOC)??[];


# reset attempts if time attempted_at is over a 15 minutes duration
if(isset($fetchedAttempts)&&!empty($fetchedAttempts)&&$config->read('security','psw_attempts')>0){
    $resetDays = $config->read('security','reset_time_days');
        $resetHrs = $config->read('security','reset_time_hours');
        $resetMins = $config->read('security','reset_time_minutes');
        $resetSecs = $config->read('security','reset_time_seconds');
        $totalSeconds = ($resetDays * 86400) + ($resetHrs * 3600) + ($resetMins * 60) + $resetSecs;
    if(strtotime($fetchedAttempts['attempted_at'])<time()-$totalSeconds){
        $db->delete('attempts',["ip_address"=>$users->getIP()]);
        $fetchedAttempts = null;
    }
    if(isset($fetchedAttempts)&&!empty($fetchedAttempts)){
        if($fetchedAttempts['attempt']>=$config->read('security','psw_attempts')){
            echo json_encode(['status'=>'error','msg'=>$lang->load(['errors','tooManyAttempts'])],JSON_UNESCAPED_SLASHES);
            exit;
        }
    }
}

if($security->CSRF('verify',$token)){
        $api = curl_init();
        $url = "$main/api/users?sel=username=$username||email=$username";
        curl_setopt($api,CURLOPT_URL,$url);
        curl_setopt($api,CURLOPT_CUSTOMREQUEST,'GET');
        curl_setopt($api, CURLOPT_RETURNTRANSFER, true);
        $response = curl_exec($api);
        if(curl_errno($api)) echo json_encode(['status'=>'error','msg'=>'cURL Error: ' . curl_error($api)],JSON_UNESCAPED_SLASHES);
        else{
            $checkIP = new Users($username);
            curl_close($api);
            $res = json_decode($response,true);
            $fname = $res[0]['first_name'];
            $lname = $res[0]['last_name'];
            $email= $res[0]['email'];
            $mail->setTo(['email'=>$email,'name'=>"$fname $lname"]);
            if($users->getIP()!==$checkIP->getIP()) $mail->send($lang->load(['security','account_access_foreign']), "{$users->getIP()}<br/>{$device->getUserAgent()}");
            if(!empty($res)){
                    if($security->compareSerial($device->deviceName())){
                        $mfa = $db->fetch("SELECT * FROM mfa WHERE username=:username",['username'=>$res[0]['username']],PDO::FETCH_ASSOC);
                        if($mfa['2fa_enabled']){
                            if(hash_equals('mail',$mfa['2fa_method']))
                                $mail->send($lang->load(['security','mfa','2fa_code']),$security->MFA($mfa['2fa_secret'],0,'SEND'));
                            $_SESSION['temp_user'] = $res[0]['username'];
                            $_SESSION['temp_remember'] = $remember;
                            $msg = ['2fa'=>true, 'logon_session'=>!$remember?true:false];
                        }else{
                            $query = http_build_query([
                                'username' => $res[0]['username'],
                                'status' => 'active',
                                'last_login' => date('Y-m-d H:i:s', time()),
                                'last_activity' => date('Y-m-d H:i:s', time())
                            ]);
                            $url = "$main/api/users?$query";
                            $api = curl_init();
                            curl_setopt($api, CURLOPT_URL, $url);
                            curl_setopt($api, CURLOPT_CUSTOMREQUEST, 'PUT');
                            curl_setopt($api, CURLOPT_RETURNTRANSFER, true);
                            $result = curl_exec($api);
                            if(curl_errno($api)) echo json_encode(['status'=>'error','msg'=>'cURL Error: ' . curl_error($api)],JSON_UNESCAPED_SLASHES);
                            curl_close($api);
                            if($remember) $storage->cookie('TechDeck_auth',$security->JWT('a-string-secret-at-least-256-bits-long',['username'=>$res[0]['username']]),'store',720);    
                            else $storage->session('TechDeck_auth',$security->JWT('a-string-secret-at-least-256-bits-long',['username'=>$res[0]['username']]));
                        }
                        $security->CSRF(action: 'generate', forceGenerate: true);
                        echo json_encode(['status'=>'success','msg'=>$msg??''],JSON_UNESCAPED_SLASHES);
                        # delete attempt
                        if(isset($fetchedAttempts)&&!empty($fetchedAttempts)) $db->delete('attempts',['ip_address'=>$users->getIP()]);
                    }else echo json_encode(['status'=>'error','msg'=>$lang->load(['errors','nonRegisteredDevices'])],JSON_UNESCAPED_SLASHES);
            }else {
                $failedAttempt = true;
                echo json_encode(['status'=>'error','msg'=>$lang->load(['errors','noUser'])],JSON_UNESCAPED_SLASHES);
            }
            if($failedAttempt&&$config->read('security','psw_attempts')>0){
                # insert or update attempts
                if(isset($fetchedAttempts)&&!empty($fetchedAttempts)){
                    $db->update('attempts',[
                        'attempt' => (int)$fetchedAttempts['attempt']+1,
                        'attempted_at' => date('Y-m-d H:i:s', time()),
                        'user_agent' => $device->getUserAgent()
                    ],[
                        'ip_address' => $users->getIP()
                    ]);
                }else{
                    $db->insert('attempts',[
                        'ip_address' => $users->getIP(),
                        'attempt' => 1,
                        'attempted_at' => date('Y-m-d H:i:s', time()),
                        'user_agent' => $device->getUserAgent()
                    ]);
                }
            }
        }  
}else echo json_encode(['status'=>'error','msg'=>$lang->load(['errors','csrfInvalid'])],JSON_UNESCAPED_SLASHES);         