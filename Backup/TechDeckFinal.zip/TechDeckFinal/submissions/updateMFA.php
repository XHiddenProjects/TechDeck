<?php
use TechDeck\Security, TechDeck\Users, TechDeck\Config, TechDeck\Database;
use TechDeck\Security\Recovery;

header('Content-Type: application/json; charset=utf-8');

$p = dirname(__DIR__).'/libs';
foreach (array_diff(scandir($p), ['.', '..']) as $f) {
    if (is_file("$p/$f")) include_once "$p/$f";
}

$security = new Security();
$users = new Users();
$config = new Config();
$db = new Database(
    $config->read('mysql', 'host'),
    $config->read('mysql', 'user'),
    $config->read('mysql', 'psw'),
    $config->read('mysql', 'db')
);

if (isset($_POST['selection'])) {
    if ($security->CSRF('verify', $_POST['token'] ?? '')) {
        $selection = (int)$security->filter((string)($_POST['selection'] ?? '0'), Security::FILTER_INT);
        $rawMethod = (string)($_POST['method'] ?? '');
        $method = strtolower(trim($rawMethod));
        $username = $users->getCurrentSession();

        $r = $db->update('mfa', [
            '2fa_enabled' => $selection,
            '2fa_method' => $security->preventXSS($rawMethod)
        ], [
            'username' => $username
        ]);

        $generatedRecoveryCodes = false;
        $recoveryReason = null;
        $authenticatorMethods = ['totp', 'authenticator', 'authenticator_app', 'authenticator app'];

        if ($r && $selection === 1 && in_array($method, $authenticatorMethods, true)) {
            $recovery = new Recovery($username);

            // Only generate the INITIAL batch once per user.
            // Do not silently refresh existing or expired sets here.
            if (!$recovery->hasCodes()) {
                $generatedCodes = $recovery->generate(16, false);
                $generatedRecoveryCodes = is_array($generatedCodes) && !empty($generatedCodes);
                if ($generatedRecoveryCodes) {
                    $recoveryReason = 'initial';
                }
            }
        }

        echo json_encode([
            'success' => (bool)$r,
            'recoveryCodesGenerated' => $generatedRecoveryCodes,
            'recoveryReason' => $recoveryReason
        ], JSON_UNESCAPED_SLASHES);
    } else {
        echo json_encode(['success' => false], JSON_UNESCAPED_SLASHES);
    }
}
