<?php
use TechDeck\Security, TechDeck\Locales, TechDeck\Storage, TechDeck\Database, TechDeck\Device;
use TechDeck\Config;
use TechDeck\Users;
use TechDeck\Security\Auditor;
use TechDeck\Security\MFA as MFAHandler;

header('Content-Type: application/json; charset=utf-8');

$p = dirname(__DIR__).'/libs';
foreach (array_diff(scandir($p), ['.', '..']) as $f) {
    if (is_file("$p/$f")) include_once "$p/$f";
}

$security = new Security();
$lang = new Locales(implode('-', LANGUAGE));
$storage = new Storage();
$config = new Config();
$device = new Device();
$auditor = new Auditor();
$db = new Database(
    $config->read('mysql', 'host'),
    $config->read('mysql', 'user'),
    $config->read('mysql', 'psw'),
    $config->read('mysql', 'db')
);

$main = $security->preventXSS(
    $security->sanitize(
        $security->safe_base64_decode($_POST['main'] ?? ''),
        $security::SANITIZE_URL
    )
);

if (!isset($_SESSION['temp_user'])) {
    echo json_encode(['status' => 'error', 'msg' => $lang->load(['errors', 'noAttemptLogin'])], JSON_UNESCAPED_SLASHES);
    exit();
}

$tempUser = $_SESSION['temp_user'];
$users1 = new Users();
$currentIP = $users1->getIP();
$users = new Users($tempUser);

if (!$security->CSRF('verify', $_POST['token'] ?? '')) {
    echo json_encode(['success' => false, 'msg' => $lang->load(['errors', 'csrfInvalid'])], JSON_UNESCAPED_SLASHES);
    exit();
}

$fetchedAttempts = $db->fetch("SELECT * FROM attempts WHERE ip_address=:ip", ['ip' => $users->getIP()], PDO::FETCH_ASSOC) ?? [];
if (isset($fetchedAttempts) && !empty($fetchedAttempts) && $config->read('security', 'psw_attempts') > 0) {
    $resetDays = $config->read('security', 'reset_time_days');
    $resetHrs = $config->read('security', 'reset_time_hours');
    $resetMins = $config->read('security', 'reset_time_minutes');
    $resetSecs = $config->read('security', 'reset_time_seconds');
    $totalSeconds = ($resetDays * 86400) + ($resetHrs * 3600) + ($resetMins * 60) + $resetSecs;

    if (strtotime($fetchedAttempts['attempted_at']) < time() - $totalSeconds) {
        $db->delete('attempts', ['ip_address' => $users->getIP()]);
        $fetchedAttempts = null;
    }

    if (isset($fetchedAttempts) && !empty($fetchedAttempts) && $fetchedAttempts['attempt'] >= $config->read('security', 'psw_attempts')) {
        echo json_encode(['status' => 'error', 'msg' => $lang->load(['errors', 'tooManyAttempts'])], JSON_UNESCAPED_SLASHES);
        exit;
    }
}

$failedAttempt = false;
$remember = $_SESSION['temp_remember'] ?? false;
$code = $security->preventXSS((string)($_POST['mfa_code'] ?? ''));
$mfaRecord = $db->fetch("SELECT 2fa_secret FROM mfa WHERE username=:user", ['user' => $tempUser], PDO::FETCH_ASSOC) ?? [];
$secret = (string)($mfaRecord['2fa_secret'] ?? '');
$mfa = new MFAHandler();
$verified = $mfa->verify($secret, $code);

if ($verified) {
    // IMPORTANT: do not silently regenerate recovery codes here.
    // Recovery codes are created once during initial enrollment and
    // should only be replaced by an explicit user/admin action.

    if ($remember) {
        $storage->cookie('TechDeck_auth', $security->JWT('a-string-secret-at-least-256-bits-long', ['username' => $tempUser]), 'store', 720);
    } else {
        $storage->session('TechDeck_auth', $security->JWT('a-string-secret-at-least-256-bits-long', ['username' => $tempUser]));
    }

    $params = [
        'username' => $tempUser,
        'status' => 'active',
        'last_login' => date('Y-m-d H:i:s', time()),
        'last_activity' => date('Y-m-d H:i:s', time()),
    ];

    $url = "$main/api/users?" . http_build_query(data: $params, arg_separator: '&', encoding_type: PHP_QUERY_RFC3986);
    $api = curl_init();
    curl_setopt($api, CURLOPT_URL, $url);
    curl_setopt($api, CURLOPT_CUSTOMREQUEST, 'PUT');
    curl_setopt($api, CURLOPT_RETURNTRANSFER, true);
    $result = curl_exec($api);

    if (curl_errno($api)) {
        echo json_encode(['status' => 'error', 'msg' => 'cURL Error: ' . curl_error($api)], JSON_UNESCAPED_SLASHES);
    } else {
        echo json_encode(['status' => 'success']);
    }

    curl_close($api);

    if (isset($fetchedAttempts) && !empty($fetchedAttempts)) {
        $db->delete('attempts', ['ip_address' => $users->getIP()]);
    }

    $auditor->record($currentIP, $tempUser, 'low', $lang->load(['success', 'logged_in']));
    exit();
}

$failedAttempt = true;
$auditor->record($currentIP, $tempUser, 'high', $lang->load(['errors', 'invalidMFA']));

if ($failedAttempt && $config->read('security', 'psw_attempts') > 0) {
    if (isset($fetchedAttempts) && !empty($fetchedAttempts)) {
        $db->update('attempts', [
            'attempt' => (int)$fetchedAttempts['attempt'] + 1,
            'attempted_at' => date('Y-m-d H:i:s', time()),
            'user_agent' => $device->getUserAgent()
        ], [
            'ip_address' => $users->getIP()
        ]);
    } else {
        $db->insert('attempts', [
            'ip_address' => $users->getIP(),
            'attempt' => 1,
            'attempted_at' => date('Y-m-d H:i:s', time()),
            'user_agent' => $device->getUserAgent()
        ]);
    }
}

echo json_encode(['status' => 'error', 'msg' => $lang->load(['errors', 'invalidMFA'])], JSON_UNESCAPED_SLASHES);
