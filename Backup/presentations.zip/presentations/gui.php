
<?php
include_once dirname(__DIR__, 2).'/init.php';
//use TechDeck\Addons;
//$addon = new Addons();

?>

<!doctype = "html">
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Presentations</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
        <link href="gui.css" rel="stylesheet">
        <?php
        //echo $addon->hook("css");
        ?>
    </head>
<body>
    <script src="https://unpkg.com/jspdf@latest/dist/jspdf.umd.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>

<script>

var slideData = [];
var slideDataIndex = 0;
var currentSlide = null;
var currentItem = null;
var currentItemData = null;

document.addEventListener("DOMContentLoaded", function() { 
    var startCon = document.getElementById("slidesList");
    var startBox = document.createElement("div");
    startBox.id = "preview" + slideDataIndex;
    startBox.className = "preview ratio ratio-16x9 w-75 bg-light shadow";
    startBox.style.maxWidth = "400px";
    startBox.dataset.index = slideDataIndex;
    startBox.oncontextmenu = function(e) {showSlideMenu(e, this);};
    startCon.appendChild(startBox);
    
    slideData[slideDataIndex] = {items: [], background: ''};
    slideNum();
    createSlideLayout();
    
    document.getElementById("addslide").addEventListener("click", function() {
        var container = document.getElementById("slidesList");
        var newSlide = startBox.cloneNode(true);
        newSlide.id = "preview" + slideData.length;
        var index = slideData.length;
        newSlide.dataset.index = index;
        newSlide.oncontextmenu = function(e) {showSlideMenu(e, this);};
        newSlide.innerHTML = "";
        container.appendChild(newSlide);

        newSlide.addEventListener("click", function() {
            saveSlideData();
            slideDataIndex = index;
            var mainSlide = document.getElementById("mainSlide");
            mainSlide.innerHTML = "";
            loadSlide(slideDataIndex);
            selectPreview(slideDataIndex);
        });
        
        slideData.push({items: [], background: ''});
        slideDataIndex = index;
        container.scrollTo(0, container.scrollHeight);
        slideNum();
        createSlideLayout();
        saveSlideData();
    });

    var slidesList = document.getElementById('slidesList');
    slidesList.addEventListener('click', function(e){
        var preview = e.target.closest('.preview');
        var index = parseInt(preview.dataset.index, 10);
        saveSlideData();
        slideDataIndex = index;
        loadSlide(index);
        selectPreview(index);
    });

    var colorChoice = document.getElementById('colorChoice');
    if (colorChoice) {
        colorChoice.addEventListener('input', function() {
            if (!currentItem) return;
            var col = this.value;
            var textEl = currentItem.querySelector('input.slide-input, textarea.slide-textarea');
            if (textEl) textEl.style.color = col;
            if (currentItemData) currentItemData.color = col;
            updatePreview(slideDataIndex);
            saveSlideData();
        });
    }
    var bgInput = document.getElementById('bgcolor');
    if (bgInput) {
        bgInput.addEventListener('input', function() {
            changeBackgroundColor(this.value);
        });
        var mainSlideEl = document.getElementById('mainSlide');
        if (mainSlideEl && bgInput.value) mainSlideEl.style.backgroundColor = bgInput.value;
    }
});

function createSlideLayout() {
    var slide = slideData[slideDataIndex];
    slide.items = [];
    if (slideDataIndex === 0) {
        slide.items.push({
            type: "title",
            text: "",
            x: 100,
            y: 150,
            width: 600
        });
    } 
    else {
        slide.items.push({
            type: "title",
            text: "",
            x: 80,
            y: 40,
            width: 600
    });
        slide.items.push({
            type: "body",
            text: "",
            x: 80,
            y: 150,
            width: 600
        });
    }
    
    renderSlide(slideDataIndex);
    updatePreview(slideDataIndex);
}
function selectPreview(index) {
    var previews = document.querySelectorAll('#slidesList .preview');
    previews.forEach(function(p){ p.classList.remove('selected'); });
    var target = document.querySelector("#slidesList .preview[data-index='" + index + "']");
    if (target) 
        target.classList.add('selected');
    saveSlideData();
}

function changeBackgroundColor(color) {
    var mainSlide = document.getElementById("mainSlide");
    if (mainSlide) mainSlide.style.setProperty('background-color', color, 'important');
    // persist on the slide data
    try { if (slideData[slideDataIndex]) slideData[slideDataIndex].background = color; } catch (err) {}
    renderSlide(slideDataIndex);
    updatePreview(slideDataIndex);
}

function slideNum() {
    var slide = document.querySelectorAll("#slidesList .preview");
    slide.forEach(function(slide, num) {
        slide.setAttribute("count", num + 1);
    });
}

function createTitleBox(initialText) {
    var slide = document.getElementById('mainSlide');

    var item = {
        type: 'title',
        text: initialText || '',
        x: 80,
        y: 40,
        width: 500,
        height: 80
    };
    slideData[slideDataIndex].items.push(item);
    renderSlide(slideDataIndex);
    updatePreview(slideDataIndex);
}

function createBodyBox(initialText) {
    var item = {
        type: "body",
        text: initialText || "",
        x: 80,
        y: 150,
        width: 500,
        height: 300
    };
    slideData[slideDataIndex].items.push(item);
    renderSlide(slideDataIndex);
    updatePreview(slideDataIndex);
}

function createTextBox() {
    var item = {
        type: "body",
        text: "",
        x: 50,
        y: 50,
        width: 300,
        height: 50
    };
    slideData[slideDataIndex].items.push(item);
    renderSlide(slideDataIndex);
    updatePreview(slideDataIndex);
}

function insertVideo() 
{ 
    var link = document.getElementById("link").value;
    var item = {
        type: "video",
        src: link,
        x: 50,
        y: 50,
        width: 320,
        height: 180
        
    };
    slideData[slideDataIndex].items.push(item);
    renderSlide(slideDataIndex);
    updatePreview(slideDataIndex);
}

function saveSlideData() {
    updatePreview(slideDataIndex);   
}

function showSlideMenu(event, slide) {
    event.preventDefault(); 
    currentSlide = slide;
    var menu = document.getElementById("slideMenu");
    menu.style.top = event.pageY + "px";
    menu.style.left = event.pageX + "px";
    menu.classList.remove("d-none");
}

function showItemMenu(event, item) {
    event.preventDefault(); 
    currentItem = item;
    currentItemData = null;
    var menu = document.getElementById("itemMenu");
    menu.style.top = event.pageY + "px";
    menu.style.left = event.pageX + "px";
    menu.classList.remove("d-none");
}

function showTextMenu(event, text) {
    event.preventDefault(); 
    currentItem = text;
    var menu = document.getElementById("textMenu");
    menu.style.zIndex = 20;
    menu.style.top = event.pageY + "px";
    menu.style.left = event.pageX + "px";
    menu.classList.remove("d-none");
    var picker = document.getElementById('colorChoice');
    if (picker) picker.value = (currentItemData && currentItemData.color) ? currentItemData.color : '#000000';
    var fontSelect = document.getElementById('fontSelect');
    if (fontSelect) {
        fontSelect.value = (currentItemData && currentItemData.font) ? currentItemData.font : fontSelect.value;
        fontSelect.onchange = function() {
            var f = this.value;
            if (currentItemData) currentItemData.font = f;
            var textEl = currentItem.querySelector('input.slide-input, textarea.slide-textarea');
            if (textEl) textEl.style.fontFamily = f;
            updatePreview(slideDataIndex);
            saveSlideData();
        };
    }
    var sizeSelect = document.getElementById('sizeSelect');
    if (sizeSelect) {
        sizeSelect.value = (currentItemData && currentItemData.fontSize) ? currentItemData.fontSize : sizeSelect.value;
        sizeSelect.onchange = function() {
            var s = this.value;
            if (currentItemData) currentItemData.fontSize = s;
            var textEl = currentItem.querySelector('input.slide-input, textarea.slide-textarea');
            if (textEl) textEl.style.fontSize = s;
            updatePreview(slideDataIndex);
            saveSlideData();
        };
    }
        var alignSelect = document.getElementById('alignSelect');
        if (alignSelect) {
            alignSelect.value = (currentItemData && currentItemData.alignment) ? currentItemData.alignment : alignSelect.value;
            alignSelect.onchange = function() {
                var a = this.value;
                if (currentItemData) currentItemData.alignment = a;
                var textEl = currentItem.querySelector('input.slide-input, textarea.slide-textarea');
                if (textEl) textEl.style.textAlign = a;
                updatePreview(slideDataIndex);
                saveSlideData();
            };
        }
}

document.addEventListener("click", (e) => {
    var slideMenu = document.getElementById("slideMenu");
    var itemMenu = document.getElementById("itemMenu");
    var textMenu = document.getElementById("textMenu");
    if ((slideMenu && slideMenu.contains(e.target)) ||
        (itemMenu && itemMenu.contains(e.target)) ||
        (textMenu && textMenu.contains(e.target))) {
        return;
    }
    if (slideMenu) slideMenu.classList.add("d-none");
    if (itemMenu) itemMenu.classList.add("d-none");
    if (textMenu) textMenu.classList.add("d-none");
});

function deleteSlide() {
    var index = parseInt(currentSlide.dataset.index, 10);
    slideData.splice(index, 1);
    currentSlide.remove();
    document.querySelectorAll("#slidesList .preview").forEach(function(element, i) {
        element.dataset.index = i;
        element.id = "preview" + i;
    });
    slideDataIndex = Math.min(index, slideData.length - 1);

    loadSlide(slideDataIndex);
    slideNum();
}

function deleteItem() {
    var menu = document.getElementById('itemMenu');
    var items = slideData[slideDataIndex].items;
    var index = items.indexOf(currentItem.__itemRef);
    if (!isNaN(index))
        items.splice(index, 1);
    currentItem.remove();
    currentItem = null;
    renderSlide(slideDataIndex);
    updatePreview(slideDataIndex);
    saveSlideData();
    menu.classList.add('d-none');
}

function duplicateItem() {
    var clone = currentItem.cloneNode(true);
    currentItem.parentNode.appendChild(clone);
    var menu = document.getElementById('itemMenu');
    var box = currentItem;
    var items = slideData[slideDataIndex].items;
    var srcItem = null;
    if (box.__itemRef) srcItem = box.__itemRef;
    else if (box.dataset && box.dataset.itemIndex !== undefined) {
        var digit = parseInt(box.dataset.itemIndex, 10);
        if (!isNaN(digit)) 
            srcItem = items[digit];
            }
    if (srcItem) {
        var newItem = JSON.parse(JSON.stringify(srcItem));
        newItem.x = (newItem.x || 0) + 10;
        newItem.y = (newItem.y || 0) + 10;
        items.splice(items.indexOf(srcItem)+1,0,newItem);
    }
        menu.classList.add('d-none');
        currentItem = null;
        renderSlide(slideDataIndex);
        updatePreview(slideDataIndex);
        saveSlideData();
    var header = clone.querySelector('div');
    dragElement(clone, header, document.getElementById("mainSlide"));
    saveSlideData();
}

function loadSlide(index) {
    slideDataIndex = index;
    renderSlide(index);
    selectPreview(index);
}

function duplicateSlide() {
    if (!currentSlide) return;
    var container = document.getElementById("slidesList");
    var sourceIndex = parseInt(currentSlide.dataset.index);
    var newIndex = slideData.length;
    var clone = currentSlide.cloneNode(true);
    clone.id = "preview" + newIndex;
    clone.dataset.index = newIndex;
    clone.oncontextmenu = function(e) { showSlideMenu(e, this); };
    clone.addEventListener('click', function() {
        saveSlideData();
        slideDataIndex = newIndex;
        var mainSlide = document.getElementById("mainSlide");
        renderSlide(index);
        selectPreview(newIndex);
    });
    
    container.appendChild(clone);
    slideData.push({ content: String(slideData[sourceIndex].content) });
    slideDataIndex = newIndex;
    container.scrollTo(0, container.scrollHeight);
    slideNum();
    selectPreview(newIndex);
}

function snap(position, gridSize = 5) {
    return Math.round(position / gridSize) * gridSize;
}

function dragElement(element, head, container) {
    var posX = 0;
    var posY = 0;
    var pointerId = null;

    function getClientCoords(e) {
        if (e.clientX !== undefined) return { x: e.clientX, y: e.clientY };
        if (e.touches && e.touches[0]) return { x: e.touches[0].clientX, y: e.touches[0].clientY };
        return { x: 0, y: 0 };
    }

    function startDrag(e) {
        e.preventDefault();
        var coords = getClientCoords(e);
        var containerRect = container.getBoundingClientRect();
        var left = element.offsetLeft;
        var top = element.offsetTop;
        element.style.left = left + 'px';
        element.style.top = top + 'px';
        posX = coords.x - containerRect.left - left;
        posY = coords.y - containerRect.top - top;
        if (e.pointerId && head && head.setPointerCapture) {
            pointerId = e.pointerId;
            head.setPointerCapture(pointerId); 
        }
        document.addEventListener('pointermove', elementDrag);
        document.addEventListener('pointerup', endDrag);
    }
    
    function elementDrag(e) {
        var coords = getClientCoords(e);
        var containerRect = container.getBoundingClientRect();

        var newX = coords.x - containerRect.left - posX;
        var newY = coords.y - containerRect.top - posY;

        var boundX = container.clientWidth - element.offsetWidth;
        var boundY = container.clientHeight - element.offsetHeight;

        element.style.left = (Math.max(0, Math.min(snap(newX), boundX))) + "px";
        element.style.top = (Math.max(0, Math.min(snap(newY), boundY))) + "px";
    }

    function endDrag() {
        document.removeEventListener('pointermove', elementDrag);
        document.removeEventListener('pointerup', endDrag);
        if (pointerId && head && head.releasePointerCapture) {
            try { head.releasePointerCapture(pointerId); } catch (err) {}
            pointerId = null;
        }
        saveSlideData();
    }

    if (!element.classList.contains('move-only')) {
        head.addEventListener('pointerdown', startDrag);
    }
}
var movingElement = null;
var movePosX = 0, movePosY = 0;
var movePointerId = null;

function startMoveMode(element, startEvent) {
    if (!element) return;
    var container = document.getElementById('mainSlide');
    movingElement = element;
    element.classList.add('moving');
    element.style.width = element.offsetWidth + 'px';
    element.style.height = element.offsetHeight + 'px';
    var containerRect = container.getBoundingClientRect();
    var rect = element.getBoundingClientRect();
    if (startEvent) {
        var x = (startEvent.clientX !== undefined) ? startEvent.clientX : (startEvent.touches && startEvent.touches[0] && startEvent.touches[0].clientX) || 0;
        var y = (startEvent.clientY !== undefined) ? startEvent.clientY : (startEvent.touches && startEvent.touches[0] && startEvent.touches[0].clientY) || 0;
        movePosX = x - containerRect.left - (parseFloat(element.style.left) || (rect.left - containerRect.left));
        movePosY = y - containerRect.top - (parseFloat(element.style.top) || (rect.top - containerRect.top));
        if (startEvent.pointerId && element.setPointerCapture) {
            movePointerId = startEvent.pointerId;
            try { element.setPointerCapture(movePointerId); } catch (err) {}
        }
    } else {
        movePosX = Math.round(element.offsetWidth/2);
        movePosY = Math.round(element.offsetHeight/2);
    }
    document.addEventListener('pointermove', moveModePointer);
    document.addEventListener('pointerup', stopMoveMode);
}

function moveModePointer(e) {
    if (!movingElement) return;
    var container = document.getElementById('mainSlide');
    var containerRect = container.getBoundingClientRect();
    var coords = { x: e.clientX, y: e.clientY };
    var newX = coords.x - containerRect.left - movePosX;
    var newY = coords.y - containerRect.top - movePosY;
    var boundX = container.clientWidth - movingElement.offsetWidth;
    var boundY = container.clientHeight - movingElement.offsetHeight;
    movingElement.style.left = (Math.max(0, Math.min(snap(newX), boundX))) + 'px';
    movingElement.style.top = (Math.max(0, Math.min(snap(newY), boundY))) + 'px';
}

function stopMoveMode(e) {
    if (!movingElement) return;
    document.removeEventListener('pointermove', moveModePointer);
    document.removeEventListener('pointerup', stopMoveMode);
    if (movePointerId && movingElement.releasePointerCapture) {
        try { movingElement.releasePointerCapture(movePointerId); } catch (err) {}
        movePointerId = null;
    }
    try {
        var idx = slideDataIndex;
        var items = slideData[idx].items;
        var oi = movingElement.dataset.itemIndex;
        if (oi !== undefined) {
            var ii = parseInt(oi, 10);
            if (!isNaN(ii) && items[ii]) {
                items[ii].x = parseInt(movingElement.style.left, 10) || items[ii].x;
                items[ii].y = parseInt(movingElement.style.top, 10) || items[ii].y;
                updatePreview(idx);
            }
        }
    } catch (err) {}
    try { movingElement.style.width = ''; movingElement.style.height = ''; } catch (err) {}
    movingElement.classList.remove('moving');
    movingElement = null;
    saveSlideData();
}

function initDrag() {
    var slide = document.getElementById('mainSlide');

    slide.querySelectorAll('.title-box').forEach(function(box){
        if (box.dataset.draggable) return;
        var head = box.querySelector('.titlebox-header');
        if (!head) {
            head = document.createElement('div');
            head.className = 'titlebox-header';
            box.insertBefore(head, box.firstChild);
        }
        dragElement(box, head, slide);
        box.dataset.draggable = 1;
    });

    slide.querySelectorAll('.body-box').forEach(function(box){
        if (box.dataset.draggable) return;
        var head = box.querySelector('.bodybox-header');
        if (!head) {
            head = document.createElement('div');
            head.className = 'bodybox-header';
            box.insertBefore(head, box.firstChild);
        }
        dragElement(box, head, slide);
        box.dataset.draggable = 1;
    });

    slide.querySelectorAll('.textbox').forEach(function(box){
        if (box.dataset.draggable) return;
        var head = box.querySelector('.textbox-header');
        if (!head) head = box;
        dragElement(box, head, slide);
        box.dataset.draggable = 1;
    });

    slide.querySelectorAll('.videobox').forEach(function(box){
        if (box.dataset.draggable) return;
        var head = box.querySelector('.videobox-header');
        if (!head) head = box;
        dragElement(box, head, slide);
        box.dataset.draggable = 1;
    });
}
function renderSlide(index) {
    var main = document.getElementById("mainSlide");
    main.innerHTML = "";
    var s = slideData[index] 
    if (s && s.background) main.style.setProperty('background-color', s.background, 'important');

    var slide = slideData[index];
    if (!slide || !slide.items) return;

    slide.items.forEach((item, i) => {
        var box = document.createElement("div");
        box.className = "position-absolute " + item.type + "-box";
        box.classList.add('move-only');
        box.style.left = item.x + "px";
        box.style.top = item.y + "px";
        box.dataset.itemIndex = i;
        box.style.width = (item.width || 300) + "px";
        box.style.height = item.height + "px";
        box.style.zIndex = 10;

        if (item.type === 'title' || item.type === 'text' || item.type === 'body') {
            box.oncontextmenu = (e) => {
                currentItemData = item;
                showTextMenu(e, box);
            }
}

        var header = document.createElement("div");
        if (item.type === "title") header.className = 'titlebox-header';
        else if (item.type === "body") header.className = 'bodybox-header';
        else if (item.type === "text") header.className = 'textbox-header';
        else if (item.type === "video") header.className = 'videobox-header';
        box.style.paddingTop = '26px';
        if (item.type === "title" || item.type === "text") {
            var input = document.createElement("input");
            input.value = item.text;
            input.className = "slide-input";
            input.placeholder = "Click to edit text";
            input.contentEditable = true;
            if (item.alignment) input.style.textAlign = item.alignment;
            else if (slideDataIndex === 0) input.style.textAlign = "center";   
            if (item.color) input.style.color = item.color;
            if (item.font) input.style.fontFamily = item.font;
            if (item.fontSize) input.style.fontSize = item.fontSize;
            input.addEventListener("input", () => {
                item.text = input.value;
                updatePreview(index);
            });

            var colorInput = document.createElement('input');
            colorInput.type = 'color';
            colorInput.className = 'slide-colorpicker';
            colorInput.value = item.color || '#000000';
            colorInput.style.marginLeft = '6px';
            colorInput.title = 'Text color';
                item.color = colorInput.value;
                input.style.color = colorInput.value;
                updatePreview(index);
            

            var controls = document.createElement('div');
            controls.style.display = 'flex';
            controls.style.alignItems = 'center';
            controls.appendChild(input);

            box.appendChild(header);
            box.appendChild(controls);
        }

        if (item.type === "body") {
            var ta = document.createElement("textarea");
            ta.value = item.text;
            ta.style.width = "100%";
            ta.style.height = "100%";
            ta.style.resize = "none";
            ta.className = "slide-textarea";
            ta.placeholder = "Click to edit text";
            if (item.color) ta.style.color = item.color;
            if (item.font) ta.style.fontFamily = item.font;
            if (item.fontSize) ta.style.fontSize = item.fontSize;
            if (item.alignment) ta.style.textAlign = item.alignment;
            ta.addEventListener("input", () => {
                item.text = ta.value;
                updatePreview(index);
            });
            
            var colorInput = document.createElement('input');
            colorInput.type = 'color';
            colorInput.className = 'slide-colorpicker';
            colorInput.value = item.color || '#000000';
            colorInput.style.marginTop = '6px';
            colorInput.title = 'Text color';
            colorInput.addEventListener('input', function() {
                item.color = colorInput.value;
                ta.style.color = colorInput.value;
                updatePreview(index);
            });

            box.appendChild(header);
            box.appendChild(ta);
        }
        if (item.type === "video") {
            var iframe = document.createElement("iframe");
            iframe.src = item.src;
            iframe.width = "320";
            iframe.height = "180";
            iframe.referrerPolicy = "strict-origin-when-cross-origin";
            box.appendChild(header);
            box.appendChild(iframe);
           
        }

        main.appendChild(box);
        dragElement(box, header, main);

        box.addEventListener('dblclick', function(e){
            if (e.target.closest('input, textarea')) return;
            startMoveMode(box, e);
        });

        box.addEventListener("pointerup", () => {
            item.x = parseInt(box.style.left);
            item.y = parseInt(box.style.top);ssssssssss
            updatePreview(index);
        });
}); 
}
function presentFromCurrentSlide() {
    main = document.getElementById("mainSlide");
     if(main.requestFullscreen){
            main.requestFullscreen();
        }
        else if(main.mozRequestFullScreen){
            main.mozRequestFullScreen();
        }
        else if(main.webkitRequestFullscreen){
            main.webkitRequestFullscreen();
        }
        else if(main.msRequestFullscreen){
            main.msRequestFullscreen();
        }
}
function updatePreview(index) {
    var preview = document.querySelector(`#slidesList .preview[data-index='${index}']`);
    var s = slideData[index]; 
    if (s && s.background) preview.style.setProperty('background-color', s.background, 'important'); 
    preview.innerHTML = "";
    var slide = slideData[index];
    var wrapper = document.createElement("div");
    wrapper.style.position = "absolute";
    slide.items.forEach(item => {
        var box = document.createElement("div");
        box.style.position = "absolute";
        // scale from mainslide to preview
        scale = 1.7722116536;
        box.style.left = item.x / scale + "px";
        box.style.top = item.y / scale + "px";
        if (item.color) box.style.color = item.color;
        if (item.font) box.style.fontFamily = item.font;
        if (item.fontSize) box.style.fontSize = item.fontSize;
        if (item.fontSize) {
            var n = parseFloat(item.fontSize);
            if (!isNaN(n)) box.style.fontSize = (n / scale) + 'px';
            else box.style.fontSize = item.fontSize;
        }
            if (item.alignment) box.style.textAlign = item.alignment;

        if (item.type === "title" || item.type === "text" || item.type === "body") {
            box.innerText = item.text;
        }

        if (item.type === "video") {
            box.innerText = "[Video]";
        }
        wrapper.appendChild(box);
    });
    preview.appendChild(wrapper);
}

    </script>
<header>

<!-- headers, first is mobile resolution hamburger menu, second is desktop resolution taskbar -->

    <nav class ="navbar navbar-expand-lg bg-body-tertiary fixed-top" style="background-color: white;" data-bs-theme="dark">
      
     <div class = "container">
        <div class = "dropdown ms-auto">
            <button class="btn btn-secondary dropdown-toggle navbar-toggler" type="button" 
            data-bs-toggle="dropdown" 
            data-bs-target="#navbarNav"
            aria-controls="navbarNav">
            <span class="navbar-toggler-icon"></span>
    </button>
    <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="#">Design</a></li>
                <li><a class="dropdown-item" href="#">Insert</a></li>
                <li><a class="dropdown-item" href="#">Preview</a></li>
                <li><a class="dropdown-item" href="#">Export</a></li>
                <li><a class="dropdown-item" href="#">Transitions</a></li>
    </ul>
            
    </div>
        <div class="collapse navbar-collapse justify-content-center">
        <ul class = "navbar-nav">
            <li class = "nav-item">
                <a class = "nav-link dropdown-toggle" data-bs-toggle="dropdown" role="button" href="#">Design</a>
                <ul class="dropdown-menu w-100">
                    <div class="d-flex justify-content-center">
                    <li><p class="dropdown-item">Background Color</p> <input type="color" id="bgcolor" class="dropdown-item"></li>
                    </li>
                    </div>
                </ul>
            </li>
            <li class = "nav-item">
                <a class = "nav-link dropdown-toggle" data-bs-toggle="dropdown" role="button" href="#">Insert</a>
                <ul class="dropdown-menu w-100">
                    <div class="d-flex justify-content-center">
                    <li><a class="dropdown-item" href="#" onclick="createTextBox()">Text Box</a></li>
                    <li><a class="dropdown-item" href="#">Image</a></li>
                    <li><a class="dropdown-item" href="#" onclick="insertVideo()">Video</a>
                    </li>
                    <span class="videoPopup">Enter link: <input id="link" type="text"></span>
                    </div>
                </ul>
            </li>
            
            <li class = "nav-item">
                <a class = "nav-link dropdown-toggle" data-bs-toggle="dropdown" role="button" href="#">Preview</a>
                <ul class="dropdown-menu w-100">
                    <div class="d-flex justify-content-center">
                            <li><a class="dropdown-item" href="#" onclick="presentFromCurrentSlide()">Present From Current Slide</a></li>
                            <li><a class="dropdown-item" href="#" onclick="presentFromBeginning()">Present from Beginning</a></li>
                </ul>
            </li>
            <li class = "nav-item">
                <a class = "nav-link dropdown-toggle" data-bs-toggle="dropdown" role="button" href="#">Export</a>
                <ul class="dropdown-menu w-100">
                    <div class="d-flex justify-content-center">
                            <li><a class="dropdown-item" href="#" onclick="exportToPDF()">PDF</a></li>
                            <li><a class="dropdown-item" href="#" onclick="exportToPPTX()">PPTX</a></li>
                </ul>
            </li>
            <li class = "nav-item">
                <a class = "nav-link dropdown-toggle" data-bs-toggle="dropdown" role="button" href="#">Transitions</a>
                <ul class="dropdown-menu w-100">
                    <div class="d-flex justify-content-center">
                    <li><a class="dropdown-item" href="#">Option 1</a></li>
                    <li><a class="dropdown-item" href="#">Option 2</a></li>
                    <li><a class="dropdown-item" href="#">Option 3</a></li>
                    </div>
                </ul>
            </li>
       </ul>       
       
     </div>
    </nav>        
    </header>

<!-- slide list -->

<div class="container-fluid vh-100 d-flex align-items-center">
    <div class="col-md-3 d-flex flex-column justify-content-center align-items-center gap-3 h-100">
        <div id="slidesList" class="d-flex flex-column align-items-center gap-3 w-100 overflow-auto" style="max-height: 70vh;">
        </div>
        <div class="d-flex gap-2 align-items-center mt-2">
            <button id="addslide" class="btn btn-primary">+</button>
        </div>
    </div>

<!-- main slide display -->

<div class = "col-md-9 d-flex justify-content-center align-items-center">
    <div id="mainSlide" class="ratio ratio-16x9 w-100 bg-light shadow-lg border position-relative overflow-hidden" style="max-width: 800px;">
          
    </div>
</div>


<div id="slideMenu" class="card position-absolute d-none">
    <ul class="list-group list-group-flush mb-0">
        <li class="list-group-item list-group-item-action" onclick="deleteSlide()">Delete</li>
        <li class="list-group-item list-group-item-action" onclick="duplicateSlide()">Duplicate</li>
    </ul>
</div>
</div>

<div id="itemMenu" class="card position-absolute d-none">
    <ul class="list-group list-group-flush mb-0">
        
    </ul>
</div>

<div id="textMenu" class="card position-absolute d-none">
    <ul class="list-group mb-0 list-group-horizontal">
        <li class="list-group-item list-group-item-action"><input type="color" id="colorChoice"></li>
        <li class="list-group-item list-group-item-action">
            <select id="fontSelect">  
                <option value="Arial">Arial</option>
                <option value="Times New Roman">Times New Roman</option>
                <option value="Courier New">Courier New</option>
                <option value="Georgia">Georgia</option>
                <option value="Verdana">Verdana</option>
            </select>
        </li>
        <li class="list-group-item list-group-item-action">
            <select id="sizeSelect">  
                <option value="12px">12</option>
                <option value="14px">14</option>
                <option value="16px">16</option>
                <option value="20px">20</option>
                <option value="24px">24</option>
                <option value="28px">28</option>
                <option value="32px">32</option>
            </select>
        </li>
        <li class="list-group-item list-group-item-action">
            <select id="alignSelect">
                <option value="left">Left</option>
                <option value="center">Center</option>
                <option value="right">Right</option>
            </select>
        </li>
        <li class="list-group-item list-group-item-action" onclick="deleteItem()">Delete</li>
        <li class="list-group-item list-group-item-action" onclick="duplicateItem()">Duplicate</li>
    </ul>
</div>



</body>

</html>

