document.getElementById("addslide").addEventListener("click", function() {
    var container = document.getElementById("otherslides");
    var preview = container.querySelector("preview");
    
    var dupe = preview.cloneNode(true);
    container.appendChild(dupe)
});