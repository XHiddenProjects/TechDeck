<?php
require_once __DIR__ . '/includes/storage.php';
$user = require_auth();
$token = trim((string)($_GET['token'] ?? ''));
if ($token === '') { http_response_code(400); exit('Missing share token.'); }
?><!doctype html>
<html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Join Shared Workbook - Excelish Pro V4</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/css/styles.css" rel="stylesheet">
</head><body class="auth-body"><div class="auth-card card shadow-lg border-0 rounded-4"><div class="card-body p-4 p-md-5"><h1 class="h4 mb-3">Join Shared Workbook</h1><p class="text-secondary">Choose access level for this shared workbook link.</p><div class="d-flex gap-2"><button class="btn btn-outline-secondary" id="joinViewer">Join as Viewer</button><button class="btn btn-success" id="joinEditor">Join as Editor</button></div><div id="joinMessage" class="mt-3 text-secondary small"></div></div></div><script>
async function join(role) {
  const form = new FormData();
  form.append('token', <?= json_encode($token) ?>);
  form.append('role', role);
  const res = await fetch('api.php?action=join_token', { method:'POST', body: form, headers:{ 'Accept':'application/json' } });
  const data = await res.json();
  if (data.success) window.location.href = 'live.php?id=' + encodeURIComponent(data.id); else document.getElementById('joinMessage').textContent = data.message || 'Unable to join.';
}
document.getElementById('joinViewer').addEventListener('click', () => join('viewer'));
document.getElementById('joinEditor').addEventListener('click', () => join('editor'));
</script></body></html>
