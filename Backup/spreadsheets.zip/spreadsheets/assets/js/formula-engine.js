(function () {
    const FUNCTION_META = {
        SUM: { syntax: 'SUM(number1, [number2], ...)', desc: 'Adds numbers or ranges.' },
        AVERAGE: { syntax: 'AVERAGE(number1, [number2], ...)', desc: 'Returns the arithmetic mean.' },
        MIN: { syntax: 'MIN(value1, [value2], ...)', desc: 'Returns the smallest numeric value.' },
        MAX: { syntax: 'MAX(value1, [value2], ...)', desc: 'Returns the largest numeric value.' },
        COUNT: { syntax: 'COUNT(value1, [value2], ...)', desc: 'Counts numeric cells.' },
        COUNTA: { syntax: 'COUNTA(value1, [value2], ...)', desc: 'Counts non-empty cells.' },
        IF: { syntax: 'IF(condition, value_if_true, value_if_false)', desc: 'Returns one value if a condition is true, another if false.' },
        AND: { syntax: 'AND(logical1, [logical2], ...)', desc: 'Returns TRUE if all arguments are TRUE.' },
        OR: { syntax: 'OR(logical1, [logical2], ...)', desc: 'Returns TRUE if any argument is TRUE.' },
        NOT: { syntax: 'NOT(logical)', desc: 'Inverts a boolean result.' },
        ROUND: { syntax: 'ROUND(number, digits)', desc: 'Rounds a number.' },
        ABS: { syntax: 'ABS(number)', desc: 'Returns the absolute value.' },
        CONCAT: { syntax: 'CONCAT(text1, [text2], ...)', desc: 'Combines text values.' },
        UPPER: { syntax: 'UPPER(text)', desc: 'Uppercases text.' },
        LOWER: { syntax: 'LOWER(text)', desc: 'Lowercases text.' },
        LEN: { syntax: 'LEN(text)', desc: 'Returns text length.' },
        LEFT: { syntax: 'LEFT(text, [count])', desc: 'Returns leftmost characters.' },
        RIGHT: { syntax: 'RIGHT(text, [count])', desc: 'Returns rightmost characters.' },
        MID: { syntax: 'MID(text, start, count)', desc: 'Returns text from the middle.' },
        TODAY: { syntax: 'TODAY()', desc: 'Returns today’s date.' },
        NOW: { syntax: 'NOW()', desc: 'Returns current date/time.' },
        MEDIAN: { syntax: 'MEDIAN(number1, [number2], ...)', desc: 'Returns the median.' },
        TRIM: { syntax: 'TRIM(text)', desc: 'Removes extra spaces.' },
        SUBSTITUTE: { syntax: 'SUBSTITUTE(text, old_text, new_text)', desc: 'Replaces text inside a string.' },
        TEXT: { syntax: 'TEXT(value)', desc: 'Converts a value to text.' },
        IFERROR: { syntax: 'IFERROR(value, fallback)', desc: 'Returns a fallback when an error occurs.' },
        POWER: { syntax: 'POWER(number, power)', desc: 'Raises a number to a power.' },
        SUMIF: { syntax: 'SUMIF(range, criteria, [sum_range])', desc: 'Sums values meeting a criterion.' },
        COUNTIF: { syntax: 'COUNTIF(range, criteria)', desc: 'Counts values meeting a criterion.' },
        INDEX: { syntax: 'INDEX(range, row_num, [col_num])', desc: 'Returns a value at a row/column position in a range.' },
        MATCH: { syntax: 'MATCH(lookup_value, range, [match_type])', desc: 'Returns the position of a matched value.' },
        VLOOKUP: { syntax: 'VLOOKUP(lookup_value, range, col_index, [exact])', desc: 'Looks up a value in the first column of a range.' },
    };
    const KNOWN_FUNCTIONS = Object.keys(FUNCTION_META);

    function flatten(values) { const out = []; values.forEach(v => Array.isArray(v) ? out.push(...flatten(v)) : out.push(v)); return out; }
    function toNumber(value) { if (typeof value === 'number') return value; if (typeof value === 'boolean') return value ? 1 : 0; if (value === null || value === undefined || value === '') return 0; const n = Number(String(value).replace(/,/g, '')); return Number.isFinite(n) ? n : 0; }
    function colToIndex(col) { let result = 0; for (let i = 0; i < col.length; i++) result = result * 26 + (col.charCodeAt(i) - 64); return result - 1; }
    function indexToCol(index) { let col = ''; let n = index + 1; while (n > 0) { const rem = (n - 1) % 26; col = String.fromCharCode(65 + rem) + col; n = Math.floor((n - 1) / 26); } return col; }
    function splitRef(ref) { const m = /^([A-Z]+)(\d+)$/i.exec(ref || ''); return m ? { col: m[1].toUpperCase(), row: parseInt(m[2], 10) } : null; }
    function refsInRange(range) { const [startRef, endRef] = String(range || '').split(':'); const s = splitRef(startRef), e = splitRef(endRef || startRef); if (!s || !e) return []; const startCol = Math.min(colToIndex(s.col), colToIndex(e.col)); const endCol = Math.max(colToIndex(s.col), colToIndex(e.col)); const startRow = Math.min(s.row, e.row); const endRow = Math.max(s.row, e.row); const refs = []; for (let r = startRow; r <= endRow; r++) for (let c = startCol; c <= endCol; c++) refs.push(`${indexToCol(c)}${r}`); return refs; }

    function buildFunctions(engine) {
        return {
            SUM: (...args) => flatten(args).reduce((sum, v) => sum + toNumber(v), 0),
            AVERAGE: (...args) => { const values = flatten(args).map(toNumber); return values.length ? values.reduce((a,b)=>a+b,0) / values.length : 0; },
            MIN: (...args) => { const values = flatten(args).map(toNumber); return values.length ? Math.min(...values) : 0; },
            MAX: (...args) => { const values = flatten(args).map(toNumber); return values.length ? Math.max(...values) : 0; },
            COUNT: (...args) => flatten(args).filter(v => !Number.isNaN(Number(v)) && v !== '' && v !== null).length,
            COUNTA: (...args) => flatten(args).filter(v => v !== '' && v !== null && v !== undefined).length,
            IF: (cond, yes, no) => cond ? yes : no,
            AND: (...args) => flatten(args).every(Boolean),
            OR: (...args) => flatten(args).some(Boolean),
            NOT: (value) => !value,
            ROUND: (value, places = 0) => { const factor = Math.pow(10, toNumber(places)); return Math.round(toNumber(value) * factor) / factor; },
            ABS: (value) => Math.abs(toNumber(value)),
            CONCAT: (...args) => flatten(args).join(''),
            UPPER: (value) => String(value ?? '').toUpperCase(),
            LOWER: (value) => String(value ?? '').toLowerCase(),
            LEN: (value) => String(value ?? '').length,
            LEFT: (value, n = 1) => String(value ?? '').substring(0, toNumber(n)),
            RIGHT: (value, n = 1) => { const s = String(value ?? ''); const count = toNumber(n); return s.substring(Math.max(0, s.length - count)); },
            MID: (value, start = 1, len = 1) => String(value ?? '').substring(Math.max(0, toNumber(start) - 1), Math.max(0, toNumber(start) - 1) + toNumber(len)),
            TODAY: () => new Date().toLocaleDateString(),
            NOW: () => new Date().toLocaleString(),
            MEDIAN: (...args) => { const values = flatten(args).map(toNumber).sort((a,b)=>a-b); if (!values.length) return 0; const mid = Math.floor(values.length/2); return values.length % 2 ? values[mid] : (values[mid-1] + values[mid])/2; },
            TRIM: (value) => String(value ?? '').trim(),
            SUBSTITUTE: (text, oldText, newText) => String(text ?? '').split(String(oldText ?? '')).join(String(newText ?? '')),
            TEXT: (value) => String(value ?? ''),
            IFERROR: (value, fallback) => String(value).startsWith('#') ? fallback : value,
            POWER: (a, b) => Math.pow(toNumber(a), toNumber(b)),
            SUMIF: (range, criteria, sumRange = null) => { const refs = Array.isArray(range) ? range : refsInRange(String(range)); const sumRefs = sumRange ? (Array.isArray(sumRange) ? sumRange : refsInRange(String(sumRange))) : refs; let sum = 0; refs.forEach((ref, i) => { if (engine.matchesCriteria(engine.evaluateCell(ref), criteria)) sum += toNumber(engine.evaluateCell(sumRefs[i] || ref)); }); return sum; },
            COUNTIF: (range, criteria) => { const refs = Array.isArray(range) ? range : refsInRange(String(range)); return refs.filter(ref => engine.matchesCriteria(engine.evaluateCell(ref), criteria)).length; },
            INDEX: (range, rowNum, colNum = 1) => { const refs = refsInRange(String(range)); const first = splitRef(String(range).split(':')[0]); const second = splitRef(String(range).split(':')[1] || String(range).split(':')[0]); if (!first || !second) return '#REF!'; const width = Math.abs(colToIndex(second.col) - colToIndex(first.col)) + 1; const idx = (toNumber(rowNum) - 1) * width + (toNumber(colNum) - 1); const ref = refs[idx]; return ref ? engine.evaluateCell(ref) : '#REF!'; },
            MATCH: (lookup, range, matchType = 0) => { const vals = refsInRange(String(range)).map(ref => engine.evaluateCell(ref)); if (toNumber(matchType) === 0) return vals.findIndex(v => String(v) === String(lookup)) + 1 || '#N/A'; return '#N/A'; },
            VLOOKUP: (lookup, range, colIndex, exact = true) => { const refs = refsInRange(String(range)); const [start, end] = String(range).split(':').map(splitRef); if (!start || !end) return '#REF!'; const cols = Math.abs(colToIndex(end.col) - colToIndex(start.col)) + 1; for (let i = 0; i < refs.length; i += cols) { const firstRef = refs[i]; if (String(engine.evaluateCell(firstRef)) === String(lookup)) { const matchRef = refs[i + (toNumber(colIndex) - 1)]; return matchRef ? engine.evaluateCell(matchRef) : '#REF!'; } } return exact ? '#N/A' : ''; }
        };
    }

    function FormulaEngine(sheet) { this.sheet = sheet; this.cache = new Map(); this.evaluating = new Set(); this.functions = buildFunctions(this); }
    FormulaEngine.prototype.getCellRaw = function (ref) { return this.sheet?.cells?.[ref]?.raw ?? ''; };
    FormulaEngine.prototype.clearCache = function () { this.cache.clear(); this.evaluating.clear(); };
    FormulaEngine.prototype.getRangeValues = function (range) { return refsInRange(range).map(ref => this.evaluateCell(ref)); };
    FormulaEngine.prototype.matchesCriteria = function(value, criteria) { const c = String(criteria ?? '').trim(); if (/^(>=|<=|<>|>|<|=)/.test(c)) { const parts = /^(>=|<=|<>|>|<|=)(.*)$/.exec(c) || []; const op = parts[1]; const rhs = Number(parts[2]); const lhs = Number(value); if (Number.isFinite(lhs) && Number.isFinite(rhs)) { if (op === '>') return lhs > rhs; if (op === '<') return lhs < rhs; if (op === '>=') return lhs >= rhs; if (op === '<=') return lhs <= rhs; if (op === '=') return lhs === rhs; if (op === '<>') return lhs !== rhs; } } return String(value) === c; };
    FormulaEngine.prototype.evaluateCell = function (ref) { if (this.cache.has(ref)) return this.cache.get(ref); if (this.evaluating.has(ref)) return '#CIRC!'; this.evaluating.add(ref); const raw = this.getCellRaw(ref); let value = raw; if (typeof raw === 'string' && raw.startsWith('=')) value = this.evaluateFormula(raw.slice(1)); this.evaluating.delete(ref); this.cache.set(ref, value); return value; };
    FormulaEngine.prototype.evaluateFormula = function (expr) { try { let jsExpr = expr.trim(); jsExpr = jsExpr.replace(/<>/g, '!='); jsExpr = jsExpr.replace(/&/g, '+'); const rangeTokens = []; jsExpr = jsExpr.replace(/\b([A-Z]+\d+:[A-Z]+\d+)\b/gi, (m) => { const token = `__RANGE_TOKEN_${rangeTokens.length}__`; rangeTokens.push(m.toUpperCase()); return token; }); jsExpr = jsExpr.replace(/\b([A-Z]+\d+)\b/gi, (m) => `__cell("${m.toUpperCase()}")`); rangeTokens.forEach((range, idx) => { jsExpr = jsExpr.replace(`__RANGE_TOKEN_${idx}__`, `__range("${range}")`); }); KNOWN_FUNCTIONS.forEach(fn => { const re = new RegExp(`\\b${fn}\\s*\\(`, 'g'); jsExpr = jsExpr.replace(re, `fn.${fn}(`); }); const evaluator = new Function('fn', '__cell', '__range', `return (${jsExpr});`); return evaluator(this.functions, (ref) => this.evaluateCell(ref), (range) => this.getRangeValues(range)); } catch (e) { return '#ERR!'; } };
    FormulaEngine.prototype.formatValue = function (value, style) { const format = style?.format || 'general'; if (value === null || value === undefined) return ''; if (typeof value === 'string' && value.startsWith('#')) return value; if (format === 'number') { const n = Number(value); return Number.isFinite(n) ? n.toLocaleString(undefined, { maximumFractionDigits: 6 }) : value; } if (format === 'currency') { const n = Number(value); return Number.isFinite(n) ? n.toLocaleString(undefined, { style: 'currency', currency: 'USD' }) : value; } if (format === 'percent') { const n = Number(value); return Number.isFinite(n) ? `${(n * 100).toFixed(2)}%` : value; } if (format === 'date') { const d = new Date(value); return !Number.isNaN(d.getTime()) ? d.toLocaleDateString() : value; } return value; };

    window.SpreadsheetFormulaEngine = { FormulaEngine, splitRef, colToIndex, indexToCol, refsInRange, FUNCTION_META, KNOWN_FUNCTIONS };
})();
