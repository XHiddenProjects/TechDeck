<?php

declare(strict_types=1);
require_once __DIR__ . '/auth.php';

const APP_DATA_DIR = __DIR__ . '/../data/spreadsheets';
const APP_UPLOAD_DIR = __DIR__ . '/../data/uploads';
const APP_PRESENCE_DIR = __DIR__ . '/../data/presence';

function ensure_app_dirs(): void {
    foreach ([APP_DATA_DIR, APP_UPLOAD_DIR, APP_PRESENCE_DIR] as $dir) {
        if (!is_dir($dir)) mkdir($dir, 0775, true);
    }
}

function sanitize_id(string $id): string {
    return preg_replace('/[^a-zA-Z0-9_-]/', '', $id);
}

function workbook_file(string $id): string {
    ensure_app_dirs();
    return APP_DATA_DIR . '/' . sanitize_id($id) . '.json';
}

function presence_file(string $id): string {
    ensure_app_dirs();
    return APP_PRESENCE_DIR . '/' . sanitize_id($id) . '.json';
}

function column_letters(int $index): string {
    $index += 1;
    $letters = '';
    while ($index > 0) {
        $mod = ($index - 1) % 26;
        $letters = chr(65 + $mod) . $letters;
        $index = intdiv($index - $mod - 1, 26);
    }
    return $letters;
}

function default_style(): array {
    return [
        'bold' => false,
        'italic' => false,
        'underline' => false,
        'align' => 'left',
        'fontSize' => 13,
        'color' => '#212529',
        'background' => '#ffffff',
        'format' => 'general',
    ];
}

function default_sheet(string $name = 'Sheet1', int $rows = 120, int $cols = 26): array {
    return [
        'id' => uniqid('sheet_', true),
        'name' => $name,
        'rowCount' => $rows,
        'colCount' => $cols,
        'cells' => new stdClass(),
        'colWidths' => new stdClass(),
        'rowHeights' => new stdClass(),
        'merges' => [],
        'conditionalFormats' => [],
        'hiddenRows' => [],
        'comments' => new stdClass(),
        'objects' => [],
        'freeze' => ['topRow' => 1, 'leftCol' => 1],
    ];
}

function default_workbook_permissions(): array {
    return [];
}

function append_audit(array &$workbook, string $action, string $username, array $details = []): void {
    if (!isset($workbook['auditTrail']) || !is_array($workbook['auditTrail'])) $workbook['auditTrail'] = [];
    $workbook['auditTrail'][] = [
        'at' => gmdate('c'),
        'user' => $username,
        'action' => $action,
        'details' => $details,
    ];
    if (count($workbook['auditTrail']) > 200) $workbook['auditTrail'] = array_slice($workbook['auditTrail'], -200);
}

function normalize_shared_with(array $sharedWith): array {
    $out = [];
    foreach ($sharedWith as $entry) {
        if (is_string($entry)) {
            $out[] = ['username' => $entry, 'role' => 'editor'];
        } elseif (is_array($entry) && !empty($entry['username'])) {
            $role = in_array((string)($entry['role'] ?? 'viewer'), ['viewer', 'editor'], true) ? (string)$entry['role'] : 'viewer';
            $out[] = ['username' => (string)$entry['username'], 'role' => $role];
        }
    }
    return array_values($out);
}

function normalize_workbook(array $workbook): array {
    $workbook['title'] = trim((string)($workbook['title'] ?? 'New Workbook')) ?: 'New Workbook';
    $workbook['owner'] = (string)($workbook['owner'] ?? '');
    $workbook['sharedWith'] = normalize_shared_with(isset($workbook['sharedWith']) && is_array($workbook['sharedWith']) ? $workbook['sharedWith'] : []);
    $workbook['shareToken'] = (string)($workbook['shareToken'] ?? bin2hex(random_bytes(8)));
    $workbook['activeSheet'] = max(0, (int)($workbook['activeSheet'] ?? 0));
    $workbook['revisions'] = isset($workbook['revisions']) && is_array($workbook['revisions']) ? $workbook['revisions'] : [];
    $workbook['auditTrail'] = isset($workbook['auditTrail']) && is_array($workbook['auditTrail']) ? $workbook['auditTrail'] : [];
    $workbook['sheets'] = isset($workbook['sheets']) && is_array($workbook['sheets']) && $workbook['sheets'] ? $workbook['sheets'] : [default_sheet('Sheet1')];

    foreach ($workbook['sheets'] as &$sheet) {
        $sheet['id'] = (string)($sheet['id'] ?? uniqid('sheet_', true));
        $sheet['name'] = trim((string)($sheet['name'] ?? 'Sheet')) ?: 'Sheet';
        $sheet['rowCount'] = max(1, (int)($sheet['rowCount'] ?? 120));
        $sheet['colCount'] = max(1, (int)($sheet['colCount'] ?? 26));
        $sheet['cells'] = isset($sheet['cells']) && is_array($sheet['cells']) ? $sheet['cells'] : [];
        $sheet['colWidths'] = isset($sheet['colWidths']) && is_array($sheet['colWidths']) ? $sheet['colWidths'] : [];
        $sheet['rowHeights'] = isset($sheet['rowHeights']) && is_array($sheet['rowHeights']) ? $sheet['rowHeights'] : [];
        $sheet['merges'] = isset($sheet['merges']) && is_array($sheet['merges']) ? $sheet['merges'] : [];
        $sheet['conditionalFormats'] = isset($sheet['conditionalFormats']) && is_array($sheet['conditionalFormats']) ? $sheet['conditionalFormats'] : [];
        $sheet['hiddenRows'] = isset($sheet['hiddenRows']) && is_array($sheet['hiddenRows']) ? $sheet['hiddenRows'] : [];
        $sheet['comments'] = isset($sheet['comments']) && is_array($sheet['comments']) ? $sheet['comments'] : [];
        $sheet['objects'] = isset($sheet['objects']) && is_array($sheet['objects']) ? $sheet['objects'] : [];
        $sheet['freeze'] = isset($sheet['freeze']) && is_array($sheet['freeze']) ? $sheet['freeze'] : ['topRow' => 1, 'leftCol' => 1];
        foreach ($sheet['cells'] as $ref => &$cell) {
            if (!is_array($cell)) $cell = ['raw' => (string)$cell, 'style' => default_style()];
            $cell['raw'] = (string)($cell['raw'] ?? '');
            $cell['style'] = array_merge(default_style(), is_array($cell['style'] ?? null) ? $cell['style'] : []);
        }
        unset($cell);
    }
    unset($sheet);

    return $workbook;
}

function create_workbook(string $title, string $owner): array {
    $id = uniqid('book_', true);
    $now = gmdate('c');
    $workbook = [
        'id' => $id,
        'title' => trim($title) !== '' ? trim($title) : 'New Workbook',
        'owner' => $owner,
        'sharedWith' => [],
        'shareToken' => bin2hex(random_bytes(8)),
        'createdAt' => $now,
        'updatedAt' => $now,
        'activeSheet' => 0,
        'revisions' => [],
        'auditTrail' => [],
        'sheets' => [default_sheet('Sheet1')],
    ];
    append_audit($workbook, 'create', $owner, ['title' => $workbook['title']]);
    save_workbook($workbook, $owner, 'create');
    return $workbook;
}

function save_workbook(array $workbook, ?string $username = null, string $action = 'save'): bool {
    ensure_app_dirs();
    $workbook = normalize_workbook($workbook);
    $workbook['updatedAt'] = gmdate('c');
    if ($username) append_audit($workbook, $action, $username, []);
    $snapshot = [
        'savedAt' => $workbook['updatedAt'],
        'title' => $workbook['title'],
        'activeSheet' => $workbook['activeSheet'],
        'sheets' => $workbook['sheets'],
    ];
    $workbook['revisions'][] = $snapshot;
    if (count($workbook['revisions']) > 20) $workbook['revisions'] = array_slice($workbook['revisions'], -20);
    return file_put_contents(workbook_file((string)$workbook['id']), json_encode($workbook, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) !== false;
}

function load_workbook(string $id): ?array {
    $path = workbook_file($id);
    if (!is_file($path)) return null;
    $data = json_decode((string)file_get_contents($path), true);
    return is_array($data) ? normalize_workbook($data) : null;
}

function delete_workbook(string $id): bool {
    $path = workbook_file($id);
    return is_file($path) ? unlink($path) : false;
}

function role_for_workbook(array $workbook, string $username): ?string {
    if (($workbook['owner'] ?? '') === $username) return 'owner';
    foreach (($workbook['sharedWith'] ?? []) as $share) {
        if (($share['username'] ?? '') === $username) return (string)($share['role'] ?? 'viewer');
    }
    return null;
}

function user_can_view_workbook(array $workbook, string $username): bool {
    return role_for_workbook($workbook, $username) !== null;
}

function user_can_edit_workbook(array $workbook, string $username): bool {
    $role = role_for_workbook($workbook, $username);
    return in_array($role, ['owner', 'editor'], true);
}

function list_workbooks_for_user(string $username): array {
    ensure_app_dirs();
    $items = [];
    foreach (glob(APP_DATA_DIR . '/*.json') as $file) {
        $data = json_decode((string)file_get_contents($file), true);
        if (!is_array($data)) continue;
        $data = normalize_workbook($data);
        if (!user_can_view_workbook($data, $username)) continue;
        $role = role_for_workbook($data, $username) ?? 'viewer';
        $items[] = [
            'id' => $data['id'] ?? basename($file, '.json'),
            'title' => $data['title'] ?? 'Untitled Workbook',
            'owner' => $data['owner'] ?? '',
            'createdAt' => $data['createdAt'] ?? null,
            'updatedAt' => $data['updatedAt'] ?? null,
            'sheetCount' => isset($data['sheets']) && is_array($data['sheets']) ? count($data['sheets']) : 0,
            'revisionCount' => isset($data['revisions']) && is_array($data['revisions']) ? count($data['revisions']) : 0,
            'shared' => ($data['owner'] ?? '') !== $username,
            'role' => $role,
        ];
    }
    usort($items, fn($a, $b) => strcmp((string)($b['updatedAt'] ?? ''), (string)($a['updatedAt'] ?? '')));
    return $items;
}

function import_csv_workbook(string $tmpPath, string $title, string $owner): array {
    $rows = [];
    if (($handle = fopen($tmpPath, 'r')) !== false) {
        while (($data = fgetcsv($handle)) !== false) $rows[] = $data;
        fclose($handle);
    }
    $maxCols = 26;
    foreach ($rows as $row) $maxCols = max($maxCols, count($row));
    $rowCount = max(count($rows), 120);
    $workbook = create_workbook($title, $owner);
    $sheet = default_sheet('Sheet1', $rowCount, $maxCols);
    $sheet['cells'] = [];
    foreach ($rows as $r => $row) {
        foreach ($row as $c => $value) {
            if ($value === null || $value === '') continue;
            $ref = column_letters($c) . ($r + 1);
            $sheet['cells'][$ref] = ['raw' => (string)$value, 'style' => default_style()];
        }
    }
    $workbook['sheets'] = [$sheet];
    append_audit($workbook, 'import_csv', $owner, ['title' => $title]);
    save_workbook($workbook, $owner, 'import_csv');
    return $workbook;
}

function save_imported_workbook(array $payload, string $owner): array {
    $workbook = normalize_workbook($payload);
    $workbook['id'] = uniqid('book_', true);
    $workbook['owner'] = $owner;
    $workbook['sharedWith'] = [];
    $workbook['shareToken'] = bin2hex(random_bytes(8));
    $workbook['createdAt'] = gmdate('c');
    $workbook['updatedAt'] = gmdate('c');
    $workbook['revisions'] = [];
    $workbook['auditTrail'] = [];
    append_audit($workbook, 'import_workbook', $owner, ['title' => $workbook['title']]);
    save_workbook($workbook, $owner, 'import_workbook');
    return $workbook;
}

function workbook_to_csv(array $workbook, int $sheetIndex = 0): string {
    $sheet = $workbook['sheets'][$sheetIndex] ?? default_sheet();
    $rows = (int)($sheet['rowCount'] ?? 120);
    $cols = (int)($sheet['colCount'] ?? 26);
    $cells = $sheet['cells'] ?? [];
    $out = fopen('php://temp', 'r+');
    for ($r = 1; $r <= $rows; $r++) {
        $line = [];
        for ($c = 0; $c < $cols; $c++) {
            $ref = column_letters($c) . $r;
            $line[] = $cells[$ref]['raw'] ?? '';
        }
        fputcsv($out, $line);
    }
    rewind($out);
    return stream_get_contents($out) ?: '';
}

function save_presence(string $workbookId, string $username, array $payload): bool {
    ensure_app_dirs();
    $path = presence_file($workbookId);
    $data = is_file($path) ? json_decode((string)file_get_contents($path), true) : [];
    if (!is_array($data)) $data = [];
    $data[$username] = [
        'user' => $username,
        'displayName' => (string)($payload['displayName'] ?? $username),
        'selection' => (string)($payload['selection'] ?? 'A1'),
        'ref' => (string)($payload['ref'] ?? 'A1'),
        'color' => (string)($payload['color'] ?? '#0d6efd'),
        'at' => gmdate('c'),
    ];
    return file_put_contents($path, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) !== false;
}

function load_presence(string $workbookId, string $excludeUser = ''): array {
    $path = presence_file($workbookId);
    if (!is_file($path)) return [];
    $data = json_decode((string)file_get_contents($path), true);
    if (!is_array($data)) return [];
    $active = [];
    $cutoff = time() - 20;
    foreach ($data as $username => $entry) {
        $ts = strtotime((string)($entry['at'] ?? '')) ?: 0;
        if ($ts < $cutoff) continue;
        if ($excludeUser !== '' && $username === $excludeUser) continue;
        $active[] = $entry;
    }
    return $active;
}

function save_upload(array $file): array {
    ensure_app_dirs();
    if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) throw new RuntimeException('No uploaded file found.');
    $name = (string)($file['name'] ?? 'upload.bin');
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $allowed = ['png', 'jpg', 'jpeg', 'gif', 'webp', 'mp4', 'webm', 'ogg'];
    if (!in_array($ext, $allowed, true)) throw new RuntimeException('Unsupported file type.');
    $safe = uniqid('media_', true) . '.' . $ext;
    $target = APP_UPLOAD_DIR . '/' . $safe;
    if (!move_uploaded_file($file['tmp_name'], $target)) throw new RuntimeException('Failed to save upload.');
    return [
        'name' => $name,
        'url' => 'data/uploads/' . $safe,
        'type' => in_array($ext, ['mp4', 'webm', 'ogg'], true) ? 'video' : 'image',
    ];
}
