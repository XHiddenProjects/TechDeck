<?php

declare(strict_types=1);
use TechDeck\Users;
include_once dirname(__DIR__,3).'/init.php';
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

const APP_USERS_FILE = __DIR__ . '/../data/users.json';

function ensure_user_store(): void {
    $dir = dirname(APP_USERS_FILE);
    if (!is_dir($dir)) mkdir($dir, 0775, true);
    if (!is_file(APP_USERS_FILE)) {
        file_put_contents(APP_USERS_FILE, json_encode(['users' => []], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    }
}

function load_users(): array {
    ensure_user_store();
    $data = json_decode((string)file_get_contents(APP_USERS_FILE), true);
    return is_array($data) && isset($data['users']) && is_array($data['users']) ? $data['users'] : [];
}

function save_users(array $users): bool {
    ensure_user_store();
    return file_put_contents(APP_USERS_FILE, json_encode(['users' => array_values($users)], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) !== false;
}

function find_user(string $username): ?array {
    $username = strtolower(trim($username));
    foreach (load_users() as $user) {
        if (strtolower((string)($user['username'] ?? '')) === $username) return $user;
    }
    return null;
}

function create_user(string $username, string $displayName, string $password): array {
    $username = trim($username);
    $displayName = trim($displayName) !== '' ? trim($displayName) : $username;
    if ($username === '' || strlen($username) < 3) throw new RuntimeException('Username must be at least 3 characters.');
    if (find_user($username)) throw new RuntimeException('That username already exists.');
    if (strlen($password) < 6) throw new RuntimeException('Password must be at least 6 characters.');
    $users = load_users();
    $user = [
        'id' => uniqid('user_', true),
        'username' => $username,
        'displayName' => $displayName,
        'passwordHash' => password_hash($password, PASSWORD_DEFAULT),
        'createdAt' => gmdate('c'),
    ];
    $users[] = $user;
    save_users($users);
    return $user;
}

function verify_login(string $username, string $password): ?array {
    $user = find_user($username);
    if (!$user) return null;
    return password_verify($password, (string)($user['passwordHash'] ?? '')) ? $user : null;
}

function login_user(array $user): void {
    $_SESSION['user'] = [
        'id' => $user['id'] ?? null,
        'username' => $user['username'] ?? null,
        'displayName' => $user['displayName'] ?? ($user['username'] ?? 'User'),
    ];
}

function logout_user(): void {
   header("Location: ".rtrim(URL,'/').'/submissions/logout.php');
   exit;
}

function current_user(): ?array {
    $users = new Users();
    return ['username'=>$users->getUsername(), 'displayName'=>$users->getUsername()];
}

function require_auth(): array {
    $user = current_user();
    if (!$user) {
        header('Location: '.rtrim(URL,'/').'/auth');
        exit;
    }
    return $user;
}
