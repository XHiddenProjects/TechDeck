document.addEventListener("DOMContentLoaded", () => {
  const editor = document.getElementById("editor");

  function createPage() {
  const page = document.createElement("div");
  page.className = "page";

  const content = document.createElement("div");
  content.className = "page-content";
  content.contentEditable = true;

  // Apply current column setting
  if (typeof currentColumnCount !== "undefined") {
    content.style.columnCount = currentColumnCount;
    content.style.columnGap = "20px";
  }

  page.appendChild(content);
  editor.appendChild(page);

  return page;
}

  function isEmpty(page) {
    return page.innerText.trim() === "";
  }

  function checkOverflow(page) {
  const OVERFLOW_BUFFER = 2;

  // ✅ Clone page to measure true height WITHOUT columns
  const clone = page.cloneNode(true);
  clone.style.visibility = "hidden";
  clone.style.position = "absolute";
  clone.style.columnCount = "1"; // force single column
  clone.style.height = page.clientHeight + "px";
  clone.style.overflow = "hidden";

  document.body.appendChild(clone);

  const isOverflowing = clone.scrollHeight > clone.clientHeight + OVERFLOW_BUFFER;

  document.body.removeChild(clone);

  if (!isOverflowing) return;
  if (isEmpty(page)) return;

  let next = page.nextElementSibling;
  if (!next) next = createPage();

  // Move content character by character
  while (true) {
    const testClone = page.cloneNode(true);
    testClone.style.visibility = "hidden";
    testClone.style.position = "absolute";
    testClone.style.columnCount = "1";
    testClone.style.height = page.clientHeight + "px";
    testClone.style.overflow = "hidden";

    document.body.appendChild(testClone);

    if (testClone.scrollHeight <= testClone.clientHeight + OVERFLOW_BUFFER) {
      document.body.removeChild(testClone);
      break;
    }

    document.body.removeChild(testClone);

    let text = page.innerText;
    if (!text.length) break;

    const lastChar = text.slice(-1);
    page.innerText = text.slice(0, -1);
    next.innerText = lastChar + next.innerText;
  }

  checkOverflow(next);
}

  function cleanupPages() {
    const pages = document.querySelectorAll(".page");

    pages.forEach((page, index) => {
      // Keep first page always
      if (index === 0) return;

      // Remove empty pages
      if (isEmpty(page)) {
        page.remove();
      }
    });
  }

  editor.addEventListener("input", () => {
    requestAnimationFrame(() => {
      const pages = document.querySelectorAll(".page");

      pages.forEach(page => checkOverflow(page));

      // Clean empty pages AFTER overflow handling
      cleanupPages();
    });
  });
});