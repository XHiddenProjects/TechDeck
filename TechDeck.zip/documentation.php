<?php
include_once 'init.php';
use TechDeck\Documentation, TechDeck\Locales, TechDeck\Config;
$lang = new Locales(implode('-',LANGUAGE));
$docs = new Documentation($lang->load('name',false));
$config = new Config();
?>
<!DOCTYPE html>
<html>
    <head>
        <title><?php echo "{$lang->load('name',false)} {$lang->load(['documentation','_title'],false)}";?></title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-LN+7fdVzj6u52u30Kp6M/trliBMCMKTyK833zpbD+pXdCLuTusPj697FH4R/5mcr" crossorigin="anonymous">
        <link rel="stylesheet" href="<?php echo ASSETS_URL?>/css/all.min.css" type="text/css"/>
        <link rel="stylesheet" href="<?php echo THEMES_URL.DS.$config->read('settings','theme').DS."documentation.css";?>" type="text/css"/>
        <link rel="stylesheet" href="<?php echo ASSETS_URL?>/css/prism.min.css" type="text/css"/>
        <link rel="icon" type='image/png' sizes="16x16" href="<?php echo ASSETS_URL.DS."icons".DS."favicon".DS."16.png";?>"/>
        <link rel="icon" type='image/png' sizes="32x32" href="<?php echo ASSETS_URL.DS."icons".DS."favicon".DS."32.png";?>"/>
        <link rel="icon" type='image/png' sizes="48x48" href="<?php echo ASSETS_URL.DS."icons".DS."favicon".DS."48.png";?>"/>
        <link rel="apple-touch-icon" sizes="180x180" href="<?php echo ASSETS_URL.DS."icons".DS."favicon".DS."180.png";?>"/>
        <link rel="manifest" href="<?php echo URL.DS."app.webmanifest";?>"/>
    </head>
    <body>
        <?php
            echo $docs->addSection('overview','Overview')
            ->addSubsection('introduction','Introduction','<i class="fa-solid fa-rocket"></i>')
            ->importContent(DOCUMENTATIONS_PATH.DS.LANGUAGE[0].DS.'intro.md')
            ->publish();
        ?>
        <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" integrity="sha384-ndDqU0Gzau9qJ1lfW4pNLlhNTkCfHzAVBReH9diLvGRem5+R9g2FzA8ZGN954O5Q" crossorigin="anonymous"></script>
        <script src="https://unpkg.com/scrollnav@3.0.1/dist/scrollnav.min.umd.js"></script>
        <script src="<?php echo ASSETS_URL?>/js/documentation.js"></script>
        <script src="<?php echo ASSETS_URL;?>/js/prism.min.js" type="text/javascript"></script>
        
    </body>
</html>