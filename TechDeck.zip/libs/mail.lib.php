<?php
namespace TechDeck;
use TechDeck\Config, TechDeck\Security, TechDeck\Utils;
/**
 * Sends a mail by using smtplib python
 */
class Mail {
    private string $from, $to, $cc, $bcc, $charset, $subject, $body;
    private array $attachments, $headers;
    private bool $isHTML;
    private Config $config;
    private Security $security;
    private Utils $utils;
    public function __construct() {
        $this->from = '';
        $this->to = '';
        $this->cc = '';
        $this->bcc = '';
        $this->attachments = [];
        $this->charset = 'UTF-8';
        $this->isHTML = false;
        $this->headers = ['Content-Type'=>"text/plain; charset=$this->charset"];
        $this->config = new Config();
        $this->security = new Security();
        $this->utils = new Utils();
    }
    /**
     * Sets the from user
     * @param string $email 
     * @param string $name
     * @return Mail
     */
    public function setFrom(string $email, string $name=''): static{
        $this->from = $name ? "$name <$email>" : $email;
        return $this;
    }
    /**
     * Set the primary recipient(s) of the email.
     *
     * @param string|array $to - Single email as string or array of recipients.
     *   Supported formats:
     *   - '<emailaddress>'
     *   - ['email'=>'email','name'=>'name']
     *   - [['email'=>'email1','name'=>'name1'], ['email'=>'email2']]
     * @return static
     */
    public function setTo(string|array $to): static {
        $recipients = [];

        if (\is_string($to)) {
            // Single email string
            $recipients[] = $to;
        } elseif (\is_array($to)) {
            if (isset($to['email'])) {
                // Associative array with email and optional name
                $email = $to['email'];
                $name = $to['name'] ?? '';
                $recipients[] = $name ? "$name <$email>" : $email;
            } else {
                // Array of arrays
                foreach ($to as $recipient) {
                    if (is_array($recipient) && isset($recipient['email'])) {
                        $email = $recipient['email'];
                        $name = $recipient['name'] ?? '';
                        $recipients[] = $name ? "$name <$email>" : $email;
                    }
                }
            }
        }

        $this->to = implode(', ', $recipients);
        return $this;
    }

    /**
     * Add a carbon-copy of the email recipients.
     *
     * @param string|array $cc - Single email as string or array of recipients.
     *   Supported formats:
     *   - '<emailaddress>'
     *   - ['email'=>'email','name'=>'name']
     *   - [['email'=>'email1','name'=>'name1'], ['email'=>'email2']]
     * @return static
     */
    public function setCc(string|array $cc): static {
        $recipients = [];

        if (is_string($cc)) {
            $recipients[] = $cc;
        } elseif (is_array($cc)) {
            if (isset($cc['email'])) {
                $email = $cc['email'];
                $name = $cc['name'] ?? '';
                $recipients[] = $name ? "$name <$email>" : $email;
            } else {
                foreach ($cc as $recipient) {
                    if (is_array($recipient) && isset($recipient['email'])) {
                        $email = $recipient['email'];
                        $name = $recipient['name'] ?? '';
                        $recipients[] = $name ? "$name <$email>" : $email;
                    }
                }
            }
        }

        $this->headers['Cc'] = implode(', ', $recipients);
        return $this;
    }

    /**
     * Add a blind carbon-copy of the email recipients.
     *
     * @param string|array $bcc - Single email as string or array of recipients.
     *   Supported formats:
     *   - '<emailaddress>'
     *   - ['email'=>'email','name'=>'name']
     *   - [['email'=>'email1','name'=>'name1'], ['email'=>'email2']]
     * @return static
     */
    public function setBcc(string|array $bcc): static {
        $recipients = [];

        if (is_string($bcc)) {
            $recipients[] = $bcc;
        } elseif (is_array($bcc)) {
            if (isset($bcc['email'])) {
                $email = $bcc['email'];
                $name = $bcc['name'] ?? '';
                $recipients[] = $name ? "$name <$email>" : $email;
            } else {
                foreach ($bcc as $recipient) {
                    if (is_array($recipient) && isset($recipient['email'])) {
                        $email = $recipient['email'];
                        $name = $recipient['name'] ?? '';
                        $recipients[] = $name ? "$name <$email>" : $email;
                    }
                }
            }
        }

        $this->headers['Bcc'] = implode(', ', $recipients);
        return $this;
    }

    /**
     * Sets the emails character set
     * @param string $charset Charset
     * @return Mail
     */
    public function setCharset(string $charset='UTF-8'): static{
        $this->charset = $charset;
        $this->addHeader('Content-Type',($this->isHTML ? "text/html" : "text/plain")."; charset=$charset");
        return $this;
    }
    /**
     * Adds attachments to your email.
     *
     * @param array $attachments Attachments, 'file_path' or ['path'=>'file_path','name'=>'file_name']
     *                           
     * Example:
     * [
     * '/path/to/file1.pdf',
     *                              
     * ['path' => '/path/to/file2.jpg', 'name' => 'custom_name.jpg']
     * ]
     * @return static
     */
    public function addAttachments(array $attachments): static {
        foreach ($attachments as $attach) {
            if (\is_string($attach)) {
                // Case: string path
                $filePath = $attach;
                $fileName = basename($filePath);
            } elseif (\is_array($attach)) {
                $filePath = $attach['path'];
                $fileName = $attach['name']??basename($filePath);
            } else 
                continue;

            // Save the attachment info
            $this->attachments[] = [
                'path' => $filePath,
                'name' => $fileName
            ];
        }
        return $this;
    }
    /**
     * Sets the email priority
     * @param int $priority Priority value 1 (high), 3 (Normal), 5 (Low)
     * @return Mail
     */
    public function setPriority(int $priority): static{
        if(!\in_array($priority,[1,3,5]))
            throw new \InvalidArgumentException("Priority must be 1 (High), 3 (Normal), or 5 (Low).");
        $this->addHeader('X-Priority',(string)$priority);
        return $this;
    }
    /**
     * Adds a header to the email
     * @param string $key Headers name
     * @param string $value Headers value
     * @return Mail
     */
    public function addHeader(string $key, string $value): static{
        $this->headers[$key] = $value;
        return $this;
    }
    //Generates an email payload
    private function generateEmailPayload(): string{
        // Convert headers array to string format
        $headersString = '';
        foreach ($this->headers as $key => $value) $headersString .= "$key: $value\r\n";
        return json_encode([
            'from'=>$this->from,
            'to'=>$this->to,
            'subject'=>$this->subject,
            'body'=>$this->body,
            'headers'=>$headersString,
            'attachments'=>$this->attachments,
            'host'=>$this->config->read('mail','host'),
            'username'=>$this->config->read('mail','username'),
            'password'=>$this->security->safe_base64_decode($this->config->read('mail','password')),
            'port'=>$this->config->read('mail','port'),
            'encryption'=>$this->config->read('mail','encryption'),
            'isHTML'=>$this->isHTML,
            'charset'=>strtolower($this->charset)
        ],JSON_UNESCAPED_SLASHES);
    }
    /**
     * The body is HTML
     * @param bool $isHTML Toggle to use HTML
     * @return Mail
     */
    public function isHTML(bool $isHTML=false): static{
        $this->isHTML = $isHTML;
        $this->setCharset($this->charset);
        return $this;
    }
    /**
     * Sends an email
     * @param string $subject Subject
     * @param string $body Body
     * @param array $headers Extra headers
     * @return bool|string|null
     */
    public function send(string $subject, string $body, array $headers=[]): bool|string|null{
        if(!empty($headers))
            foreach($headers as $header=>$value) $this->addHeader($header,$value);
        $this->subject = $subject;
        $this->body = $body;
        $payload = $this->generateEmailPayload();
        
        $tmpFile = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'mailer_payload_' . uniqid() . '.json';
        file_put_contents($tmpFile, $payload);

        // Call the Python script
        $command = "python ".BASE.DS."scripts".DS."mailer.py {$tmpFile}";
        $this->utils->setEnv();
        $output = shell_exec($command);
        // Clean up
        @unlink($tmpFile);
        // Optionally handle the output or errors
        return $output;
    }
    /**
     * Returns the senders email
     * @return string Senders email
     */
    public function getFrom(): string{
        return $this->from;
    }
}