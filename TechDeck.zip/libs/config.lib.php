<?php
namespace TechDeck;
include_once dirname(__DIR__).'/init.php';
class Config{
    private string $config;
    /**
     * Creates a config object
     * @param string $name Configuration name
     * @param string $path Path to configuration, leave empty to use DEFAULT config path
     */
    public function __construct(string $name='config',string $path='') {
        $this->config = \defined('CONFIG_PATH') ? CONFIG_PATH.DS."$name.ini" : "$path/".rtrim($name,'/').".ini";
    }
    /**
     * Will return the value based on the conjunctions path of the ini array
     * @param string[] ...$conjunctions Path to select results
     * @return mixed The results of the selected path
     */
    public function read(string ...$conjunctions): mixed {
        // Parse the INI file with sections
        $configData = parse_ini_file($this->config, true);
        
        // Start from the root of the config data
        $current = $configData;

        // Loop through each conjunction to traverse nested array
        foreach ($conjunctions as $conjunction) {
            if (\is_array($current) && \array_key_exists($conjunction, $current)) {
                $current = $current[$conjunction];
            } else {
                // Return null or throw exception if path is invalid
                return null;
            }
        }

        return $current;
    }
    /**
     * Creates a configuration if the config file hasn't been made
     * @param array $data Data to store as a configuration
     * @return bool If the data was successfully created it is TRUE, else FALSE 
     */
    public function create(array $data): bool {
        if (!file_exists($this->config)) {
            $iniContent = '';

            foreach ($data as $key => $value) {
                if (\is_array($value)) {
                    // Create a section
                    $iniContent .= "[$key]\n";
                    foreach ($value as $subKey => $subValue) {
                        $iniContent .= "$subKey = $subValue\n";
                    }
                    $iniContent .= "\n"; // Add a newline between sections
                } else {
                    // No section, simple key-value
                    $iniContent .= "$key = $value\n";
                }
            }

            // Write to the config file
            file_put_contents($this->config, $iniContent);
            return true;
        } else return false;
    }
    /**
    * Update the config file
    * @param array $data Data to update
    * @example 
    * $config->update([
    *     'setting1' => 'value1',
    *     'section1' => [
    *         'key1' => 'new_value',
    *         'key2' => 'new_value2'
    *     ]
    * ]);
    * @return void
    */
    public function update(array $data): void {
        // Load existing configuration
        $configData = [];
        if (file_exists($this->config)) {
            $configData = parse_ini_file($this->config, true);
            if (!\is_array($configData)) {
                $configData = [];
            }
        }

        // Merge new data into existing configuration
        foreach ($data as $key => $value) {
            $configData[$key] = \is_array($value) ? 
                (isset($configData[$key]) && \is_array($configData[$key]) ? array_merge($configData[$key], $value) : $value) 
                : $value;
        }

        // Rebuild the INI content with proper quoting
        $iniContent = '';

        foreach ($configData as $section => $sectionData) {
            if (\is_array($sectionData)) {
                // Section header
                $iniContent .= "[$section]\n";
                foreach ($sectionData as $k => $v) {
                    if (\is_string($v)) {
                        // Quote string values
                        $escapedV = str_replace('"', '\"', $v);
                        $iniContent .= "$k = \"$escapedV\"\n";
                    } elseif (\is_bool($v)) {
                        // Write booleans without quotes
                        $iniContent .= "$k = " . ($v ? 'true' : 'false') . "\n";
                    } elseif (is_numeric($v)) {
                        // Write numbers without quotes
                        $iniContent .= "$k = $v\n";
                    } else {
                        // For other types, cast to string and quote
                        $escapedV = str_replace('"', '\"', (string)$v);
                        $iniContent .= "$k = \"$escapedV\"\n";
                    }
                }
                $iniContent .= "\n"; // Add newline between sections
            } else {
                // Key-value outside sections
                if (is_numeric($sectionData)) {
                    $iniContent .= "$section = $sectionData\n";
                }elseif (\is_bool($sectionData)) {
                    $iniContent .= "$section = " . ($sectionData ? 'true' : 'false') . "\n";
                }elseif (\is_string($sectionData)) {
                    $escapedValue = str_replace('"', '\"', $sectionData);
                    $iniContent .= "$section = \"$escapedValue\"\n";
                } else {
                    $escapedValue = str_replace('"', '\"', (string)$sectionData);
                    $iniContent .= "$section = \"$escapedValue\"\n";
                }
            }
        }

        // Write the new content to the config file
        file_put_contents($this->config, $iniContent);
    }
    /**
     * Removes the config file
     * @return bool TRUE if removed, else FALSE
     */
    public function remove(): bool{
        return @unlink($this->config);
    }
}