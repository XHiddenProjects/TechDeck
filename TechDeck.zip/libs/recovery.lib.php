<?php
namespace TechDeck\Security;
use TechDeck\Config, TechDeck\Database, TechDeck\Users, PDO;
class Recovery{
    private $users, $db, $userId;
    public function __construct() {
        $user = new Users();
        $config = new Config();
        $this->db = new Database($config->read('mysql','host'),
                $config->read('mysql','user'),
            $config->read('mysql','psw'),
        $config->read('mysql','db'));
        $this->userId = $user->getID();
    }
    /**
     * Generate recovery codes
     * @param int $count Number of codes to generate
     * @return array Recovery codes
     */
    public function generate(int $count = 16): array|null {
        //Clear the old codes
        if($this->userId==0) return null;
        $results = $this->db->fetchAll('SELECT * FROM recovery_codes WHERE userId=:userId',['userId'=>$this->userId],PDO::FETCH_ASSOC);
        if(!empty($results)){
            foreach($results as $index=>$result){
                $this->db->delete('recovery_codes',[
                    'user_id'=>(int)$this->userId,
                    'code'=>$result['code']
                ]);
            }
            return $results;
        }else{
            $codes = [];
            for ($i = 0; $i < $count; $i++) {
                // Generate 3 random bytes, convert to hex, then take first 5 characters
                $part1 = substr(bin2hex(random_bytes(3)), 0, 5);
                $part2 = substr(bin2hex(random_bytes(3)), 0, 5);
                $code = "{$part1}-{$part2}";
                $this->db->insert('recovery_codes',[
                    'userId'=>$this->userId,
                    'code'=>$code,
                    'isUsed'=>0,
                    'createdAt'=>date('Y-m-d'),
                    'expireAt'=>date("Y-m-d", strtotime("+1 month"))
                ]);
                $codes[] = $code;
            }
            return $codes;
        }
    }
    /**
     * Verifies the recovery codes
     * @param string $code Recovery key
     * @return bool TRUE if the recovery is used, FALSE if code doesn't exists or has been used
     */
    public function verify(string $code): bool{
        $getCode = $this->db->fetch('SELECT * FROM recovery_codes WHERE userId=:userId AND code=:code',['userId'=>$this->userId,'code'=>$code],PDO::FETCH_ASSOC);
        if($getCode){
            if(!$getCode['isUsed']){
                $this->db->update('recovery_codes',[
                    'isUsed'=>1,
                    'usedAt'=>date('Y-m-d')
                ],[
                    'userId'=>$this->userId,
                    'code'=>$code
                ]);
                return true;
            }else return false;
        }else return false;
    }
    /**
     * Checks if the the codes has expired
     * @return bool TRUE if it has, else false
     */
    public function hasExpired(): bool{
        if($this->userId){
            $results = $this->db->fetch('SELECT * FROM recovery_codes WHERE userId=:userId',['userId'=>$this->userId]);
            return strtotime(date('Y-m-d H:i:s'))>strtotime($results['expireAt']);
        }else return false;
    }
}