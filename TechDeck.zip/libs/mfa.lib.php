<?php
namespace TechDeck\Security;
use TechDeck\Config, TechDeck\Cryptography, TechDeck\Users, TechDeck\Database, PDO, TechDeck\Security;

class MFA {
    private string $label, $issuer, $algo, $secret, $user, $userId;
    private int $digits, $period;
    private Cryptography $crypto;
    private Database $db;
    private Security $security;

    // Store recovery codes in an array for demonstration; in real use, store in database
    private array $recoveryCodes = [];

    /**
     * Creates a Multi-factor authenticator 
     */
    public function __construct() {
        $config = new Config();
        $this->crypto = new Cryptography();
        $user = new Users($_SESSION['temp_user']??'');
        $this->userId = $user->getID();
        $this->user = $user->getUsername();
        $this->label = $config->read('2fa','label');
        $this->issuer = $config->read('2fa','issuer');
        $this->algo = $config->read('2fa','algorithm');
        $this->digits = (int)$config->read('2fa','digits');
        $this->period = (int)$config->read('2fa','period');
        $this->secret = $this->crypto->encode(random_bytes(20),'base32');
        $this->db = new Database($config->read('mysql','host'),
                $config->read('mysql','user'),
            $config->read('mysql','psw'),
        $config->read('mysql','db'));
        $this->security = new Security();
    }

    /**
     * Returns the encoded secret
     */
    public function getSecret(): string {
        return $this->secret;
    }

    /**
     * Returns the TOTP URL
     */
    public function getTOTP(string $secret): string {
        return "otpauth://totp/{$this->issuer}:{$this->user}?secret={$secret}&issuer={$this->issuer}&algorithm={$this->algo}&digits={$this->digits}&period={$this->period}";
    }

    /**
     * Verifies the code (TOTP or recovery code)
     */
    public function verify(string $secret, string $code): bool {

        // Verify TOTP code
        $secretDecoded = $this->crypto->decode($secret, 'base32');
        $time = floor(time() / $this->period);
        $tolerance = 1;

        for ($i = -$tolerance; $i <= $tolerance; $i++) {
            $currentTimeStep = $time + $i;
            $generatedCode = $this->generateTOTP($secretDecoded, $currentTimeStep);
            if ($generatedCode === (int)$code) {
                return true;
            }
        }
        
        if($this->security->recovery('verify',$code)) return true;

        return false;
    }

    /**
     * Generate TOTP code based on secret and time step
     */
    private function generateTOTP(string $secret, int $timeStep): int {
        $timeBytes = pack('N*', 0) . pack('N*', $timeStep);
        $hash = hash_hmac($this->algo, $timeBytes, $secret, true);
        $offset = \ord($hash[19]) & 0xf;
        $code = (
            ((\ord($hash[$offset]) & 0x7f) << 24) |
            ((\ord($hash[$offset + 1]) & 0xff) << 16) |
            ((\ord($hash[$offset + 2]) & 0xff) << 8) |
            \ord($hash[$offset + 3]) & 0xff
        ) % pow(10, $this->digits);
        return (int)$code;
    }

    
    /**
     * Returns the current code
     * @param string $user Get the user current code
     * @return string
     */
    public function getCurrentCode(string $user): string {
        $r = $this->db->fetch("SELECT * FROM mfa WHERE username=:username",['username'=>$user],PDO::FETCH_ASSOC);
            if($r){
            $secretDecoded = $this->crypto->decode($r['2fa_secret'], 'base32');
            $timeStep = floor(time() / $this->period);
            $code = $this->generateTOTP($secretDecoded, $timeStep);
            // Zero-pad the code to 6 digits if necessary
            return str_pad((string)$code, $this->digits, '0', STR_PAD_LEFT);
        }else return '';
    }
}