<?php
declare(strict_types=1);

namespace TechDeck\Security;

/**
 * JSON Web Token (JWT) encoder/decoder
 *
 * Notes:
 * - HS256/384/512 use HMAC with shared secret.
 * - RS256/384/512 and PS256/384/512 use RSA private/public keys (OpenSSL).
 * - ES256/384/512 use ECDSA (OpenSSL).
 * - EdDSA (Ed25519/Ed448) uses libsodium (if available). Set algorithm to 'EdDSA' and provide keys accordingly.
 *
 * For asymmetric algorithms:
 * - Encoding (signing) requires private key.
 * - Decoding (verification) requires public key.
 */
class JWT
{
    private string $secretOrPrivateKey;
    private ?string $publicKey;
    private string $algorithm;

    /** @var array<string,string> */
    private static array $supportedAlgorithms = [
        'HS256' => 'sha256',
        'HS384' => 'sha384',
        'HS512' => 'sha512',
        'RS256' => 'RS256',
        'RS384' => 'RS384',
        'RS512' => 'RS512',
        'ES256' => 'ES256',
        'ES384' => 'ES384',
        'ES512' => 'ES512',
        'PS256' => 'PS256',
        'PS384' => 'PS384',
        'PS512' => 'PS512',
        'EdDSA' => 'EdDSA',
    ];

    /** Default clock skew leeway in seconds */
    private int $leeway;

    /**
     * @param string $key Private key (asymmetric) or shared secret (HMAC)
     * @param string $algorithm One of self::$supportedAlgorithms keys
     * @param string|null $publicKey Public key for verification (required for asymmetric verify)
     * @param int $leeway Clock skew tolerance in seconds
     */
    public function __construct(string $key, string $algorithm = 'HS256', ?string $publicKey = null, int $leeway = 30){
        if (!isset(self::$supportedAlgorithms[$algorithm])) {
            throw new \InvalidArgumentException("Unsupported algorithm: {$algorithm}");
        }

        // Enforce minimum secret length for HMAC algorithms
        if (strpos($algorithm, 'HS') === 0 && strlen($key) < 32) {
            throw new \InvalidArgumentException("Secret key must be at least 256 bits (32 bytes) for {$algorithm}");
        }

        $this->algorithm = $algorithm;
        $this->secretOrPrivateKey = $key;
        $this->publicKey = $publicKey;
        $this->leeway = max(0, $leeway);
    }


    /**
     * Encode a JWT
     *
     * @param array $payload Claims to include in the token (e.g., iss, sub, aud, exp, nbf, iat, jti)
     * @param array $headers Extra header fields (e.g., kid)
     * @param int|null $ttlSeconds Time-to-live in seconds; sets exp = now + ttl
     * @return string JWT (header.payload.signature)
     * @throws \Exception
     */
    public function encode(array $payload, array $headers = [], ?int $ttlSeconds = null): string
    {
        $header = ['alg' => $this->algorithm, 'typ' => 'JWT'] + $headers;

        $now = time();
        $claims = $payload;

        if (!isset($claims['iat'])) {
            $claims['iat'] = $now;
        }
        if ($ttlSeconds !== null) {
            if ($ttlSeconds <= 0) {
                throw new \InvalidArgumentException('ttlSeconds must be a positive integer');
            }
            $claims['exp'] = $now + $ttlSeconds;
        }

        $encodedHeader = $this->base64UrlEncode($this->jsonEncode($header));
        $encodedClaims = $this->base64UrlEncode($this->jsonEncode($claims));
        $unsignedToken = "{$encodedHeader}.{$encodedClaims}";

        $signature = $this->sign($unsignedToken, $this->algorithm);

        return "{$unsignedToken}.{$signature}";
    }

    /**
     * Decode and verify a JWT
     *
     * @param string $token The JWT string
     * @param array $validateClaims Optional expected values for standard claims
     * @return array The claims payload
     * @throws \Exception If the token is invalid or verification fails
     */
    public function decode(string $token, array $validateClaims = []): array
    {
        $parts = explode('.', $token);
        if (count($parts) !== 3) {
            throw new \Exception('Invalid token format');
        }
        [$encodedHeader, $encodedClaims, $signature] = $parts;

        $headerJson = $this->jsonDecode($this->base64UrlDecode($encodedHeader));
        $claimsJson = $this->jsonDecode($this->base64UrlDecode($encodedClaims));

        $algorithm = $headerJson['alg'] ?? '';
        if ($algorithm !== $this->algorithm || !isset(self::$supportedAlgorithms[$algorithm])) {
            throw new \Exception('Invalid or unsupported algorithm');
        }

        if (!$this->verify("{$encodedHeader}.{$encodedClaims}", $signature, $algorithm)) {
            throw new \Exception('Signature verification failed');
        }

        $now = time();
        $leeway = $this->leeway;

        // exp: token is expired if now > exp + leeway
        if (isset($claimsJson['exp']) && $now > ((int)$claimsJson['exp'] + $leeway)) {
            throw new \Exception('Token expired');
        }
        // nbf: token not valid before nbf - leeway
        if (isset($claimsJson['nbf']) && ($now + $leeway) < (int)$claimsJson['nbf']) {
            throw new \Exception('Token not yet valid');
        }
        // iat: allow leeway for clock skew; reject only if iat is too far in the future
        if (isset($claimsJson['iat']) && ($now + $leeway) < (int)$claimsJson['iat']) {
            throw new \Exception('Token issued in the future');
        }

        // Optional claim validations (exact match)
        $this->validateClaimExact($claimsJson, $validateClaims, 'iss', 'Issuer mismatch');
        $this->validateClaimExact($claimsJson, $validateClaims, 'sub', 'Subject mismatch');
        $this->validateClaimExact($claimsJson, $validateClaims, 'aud', 'Audience mismatch');
        $this->validateClaimExact($claimsJson, $validateClaims, 'jti', 'JWT ID mismatch');
        $this->validateClaimExact($claimsJson, $validateClaims, 'typ', 'Type mismatch');

        return $claimsJson;
    }

    /**
     * Sign the token
     *
     * @param string $unsigned header.payload
     * @param string $alg Algorithm
     * @return string Base64URL signature
     * @throws \Exception
     */
    private function sign(string $unsigned, string $alg): string {
        $signature = '';

        if (strpos($alg, 'HS') === 0) {
            $hashAlg = self::$supportedAlgorithms[$alg];
            $signature = hash_hmac($hashAlg, $unsigned, $this->secretOrPrivateKey, true);
        } elseif (strpos($alg, 'RS') === 0 || strpos($alg, 'PS') === 0 || strpos($alg, 'ES') === 0) {
            $privateKey = $this->getOpenSSLPrivateKey($this->secretOrPrivateKey);
            $ok = openssl_sign($unsigned, $signature, $privateKey, $alg);
            if ($ok !== true) {
                throw new \Exception("OpenSSL signing failed for {$alg}");
            }
        } elseif ($alg === 'EdDSA') {
            if (!function_exists('sodium_crypto_sign_detached')) {
                throw new \Exception('EdDSA signing requires libsodium');
            }
            $signature = sodium_crypto_sign_detached($unsigned, $this->secretOrPrivateKey);
        } else {
            throw new \Exception('Unsupported algorithm');
        }

        // ✅ Ensure signature is at least 256 bits (32 bytes)
        if (strlen($signature) < 32) {
            throw new \Exception("Signature length is too short: must be at least 256 bits");
        }

        return $this->base64UrlEncode($signature);
    }


    private function verify(string $unsigned, string $signature, string $alg): bool{
        $decodedSignature = $this->base64UrlDecode($signature);
        if (strpos($alg, 'HS') === 0) {
            $hashAlg = self::$supportedAlgorithms[$alg];
            $expectedSig = hash_hmac($hashAlg, $unsigned, $this->secretOrPrivateKey, true);
            return hash_equals($expectedSig, $decodedSignature);
        }

        if (strpos($alg, 'RS') === 0 || strpos($alg, 'PS') === 0 || strpos($alg, 'ES') === 0) {
            if ($this->publicKey === null) {
                throw new \Exception('Public key required for verification');
            }
            $publicKey = $this->getOpenSSLPublicKey($this->publicKey);
            $result = openssl_verify($unsigned, $decodedSignature, $publicKey, $alg);
            if ($result === -1) {
                throw new \Exception('OpenSSL verification error: ' . openssl_error_string());
            }
            return $result === 1;
        }

        if ($alg === 'EdDSA') {
            if (!function_exists('sodium_crypto_sign_verify_detached')) {
                throw new \Exception('EdDSA verification requires libsodium');
            }
            if ($this->publicKey === null) {
                throw new \Exception('Public key required for verification');
            }
            return sodium_crypto_sign_verify_detached($decodedSignature, $unsigned, $this->publicKey);
        }

        return false;
    }

    /**
     * Base64URL encode
     */
    private function base64UrlEncode(string $data): string{
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    /**
     * Base64URL decode
     */
    private function base64UrlDecode(string $data): string{
        $len = \strlen($data);
        $padLen = ($len % 4) === 0 ? 0 : 4 - ($len % 4);
        if ($padLen > 0) {
            $data .= str_repeat('=', $padLen);
        }
        $decoded = base64_decode(strtr($data, '-_', '+/'), true);
        if ($decoded === false) {
            throw new \Exception('Invalid base64url input');
        }
        return $decoded;
    }

    /**
     * JSON encode with error handling
     *
     * @param mixed $value
     */
    private function jsonEncode($value): string{
        $json = json_encode($value, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
        return $json;
    }

    /**
     * JSON decode with error handling
     *
     * @param string $json
     * @return array
     */
    private function jsonDecode(string $json): array{
        /** @var array $decoded */
        $decoded = json_decode($json, true, 512, JSON_THROW_ON_ERROR);
        if (!is_array($decoded)) {
            throw new \Exception('Invalid JSON payload');
        }
        return $decoded;
    }

    /**
     * Validate exact match for a claim if present in both token and validation array
     *
     * @param array $claims
     * @param array $validate
     * @param string $name
     * @param string $error
     * @throws \Exception
     */
    private function validateClaimExact(array $claims, array $validate, string $name, string $error): void{
        if (\array_key_exists($name, $claims) && \array_key_exists($name, $validate)) {
            if ($claims[$name] !== $validate[$name]) {
                throw new \Exception($error);
            }
        }
    }

    /**
     * Get OpenSSL private key resource from various key formats
     *
     * @param string $key PEM string, path, or string with passphrase delimiter "key|passphrase"
     * @return \OpenSSLAsymmetricKey|resource
     */
    private function getOpenSSLPrivateKey(string $key): bool|\OpenSSLAsymmetricKey{
        // Allow "pem|passphrase" format
        $pem = $key;
        $passphrase = null;

        if (strpos($key, '|') !== false) {
            [$pem, $passphrase] = explode('|', $key, 2);
        }

        // If looks like a file path, try to load contents
        if ($this->looksLikeFilePath($pem) && is_readable($pem)) {
            $pem = file_get_contents($pem);
            if ($pem === false) {
                throw new \Exception('Failed to read private key file');
            }
        }

        $res = openssl_pkey_get_private($pem, $passphrase ?? '');
        if ($res === false) {
            throw new \Exception('Invalid private key');
        }
        return $res;
    }

    /**
     * Get OpenSSL public key resource from various key formats
     *
     * @param string $key PEM string or path
     * @return \OpenSSLAsymmetricKey|resource
     */
    private function getOpenSSLPublicKey(string $key): bool|\OpenSSLAsymmetricKey{
        $pem = $key;

        if ($this->looksLikeFilePath($pem) && is_readable($pem)) {
            $pem = file_get_contents($pem);
            if ($pem === false) {
                throw new \Exception('Failed to read public key file');
            }
        }

        $res = openssl_pkey_get_public($pem);
        if ($res === false) {
            throw new \Exception('Invalid public key');
        }
        return $res;
    }

    /**
     * Basic heuristic to decide if a string is a filepath
     */
    private function looksLikeFilePath(string $s): bool{
        // Absolute or relative paths, or ends with .pem/.key
        return str_starts_with($s, '/') || str_contains($s, DIRECTORY_SEPARATOR) || preg_match('/\.(pem|key)$/i', $s) === 1;
    }
}