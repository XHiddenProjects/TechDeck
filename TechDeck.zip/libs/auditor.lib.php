<?php
namespace TechDeck\Security;
use TechDeck\Security, TechDeck\Config, TechDeck\Database, PDO;
class Auditor{
    private Database $db;
    private Security $security;
    public function __construct() {
        $config = new Config();
        $this->db = new Database($config->read('mysql','host'),
    $config->read('mysql','user'),
    $config->read('mysql','psw'),
    $config->read('mysql','db'));
    $this->security = new Security();
    }
    /**
     * Records an audit to the list
     * @param string $from From IP address
     * @param string $username Targeted Username
     * @param string $risk Security risk: None, Low, Medium, or High
     * @param string $reason The reason of the risk
     * @return void
     */
    public function record(string $from, string $username, string $risk, string $reason): void{
        $this->db->insert('audits',[
            'from_target'=>$this->security->filter($from,Security::FILTER_IPV4),
            'username'=>$this->security->preventXSS($username),
            'risk'=>match(strtolower($risk)){
                'none'=>'None',
                'low'=>'Low',
                'medium'=>'Medium',
                'high'=>'High',
                default=>'None'
            },
            'reason'=>$this->security->preventXSS($reason)
        ]);
    }
    /**
     * Reads the audit records from
     * @param string $username Username to get records from
     * @return array List of audits from the user
     */
    public function read(string $username): array{
        $username = $this->security->preventXSS($username);
        return $this->db->fetchAll("SELECT * FROM audits WHERE username=:username",['username'=>$username],PDO::FETCH_ASSOC);
    }
}