<?php
use TechDeck\Addons,
TechDeck\Locales,
TechDeck\Storage,
TechDeck\URI,
TechDeck\Users,
TechDeck\Network,
TechDeck\Device,
TechDeck\Utils,
TechDeck\Data,
TechDeck\table as Table,
TechDeck\Security,
TechDeck\Files;
use TechDeck\Security\Auditor;
$addon = new Addons(); // Instantiate the concrete subclass
$storage = new Storage();
$users = new Users();
$uri = new URI();
$network = new Network();
$device = new Device();
$utils = new Utils();
$data = new Data();
$security = new Security();
$files = new Files();
$auditor = new Auditor();


if(!$storage->session('TechDeck_auth', action: 'Get')&&!$storage->cookie(name: 'TechDeck_auth',action: 'load')) header('Location: '.URL.DS.'auth');
?>
<!DOCTYPE html>
<html>
    <head>
        <?php
        $lang = new Locales(implode('-',LANGUAGE));
        echo $addon->hook('head');
        echo $addon->hook('css');
        ?>
    </head>
    <body>
        <?php
        echo $addon->hook('beforeMain');
        ?>
        <div class="container-fluid position-relative">
            <div class="d-flex justify-content-between py-2">
                <button class="border-0 bg-transparent fs-2" type="button" data-bs-toggle="offcanvas" data-bs-target="#dashboard-nav" aria-controls="dashboard-navLabel">
                    <i class="fa-solid fa-bars"></i>
                </button>
                <button class="btn btn-danger logout"><i class="fa-solid fa-left-from-bracket"></i> <?php echo $lang->load(['buttons','logout']);?></button>
            </div>
            <div class="offcanvas offcanvas-start" tabindex="-1" id="dashboard-nav" aria-labelledby="dashboard-navLabel">
                <div class="offcanvas-header">
                    <a href="<?=URL;?>/dashboard" class="text-decoration-none text-dark"><h5 class="offcanvas-title" id="dashboard-navLabel"><?php echo $lang->load(['authorization','_dashboard']);?></h5></a>
                    <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>
                <div class="offcanvas-body">
                    <ul class="list-group list-group-flush">
                        <a data-bs-toggle="collapse" href="#tab-dashboard" role="button" aria-expanded="false" aria-controls="tab-dashboard" class="text-decoration-none"><li class="list-group-item list-group-item-action"><i class="fa-solid fa-gauge-high"></i> <?php echo $lang->load(['authorization','_dashboard']);?></li></a>
                        <div class="collapse" id="tab-dashboard">
                            <?php
                        if($users->isAdmin()){
                            ?>
                        <a href="<?=URL;?>/dashboard/analysis" class="text-decoration-none"><li class="list-group-item list-group-item-action"><i class="fa-solid fa-chart-mixed"></i> <?php echo $lang->load(['dashboard','analysis']);?></li></a>
                        <?php
                        }
                        ?>
                        <?php
                        if($users->isAdmin()){
                            ?>
                        <a href="<?=URL;?>/dashboard/config" class="text-decoration-none"><li class="list-group-item list-group-item-action"><i class="fa-solid fa-cogs"></i> <?php echo $lang->load(['dashboard','config','_label']);?></li></a>
                        <?php
                        }
                        ?>
                        <a href="<?=URL;?>/dashboard/support" class="text-decoration-none"><li class="list-group-item list-group-item-action"><i class="fa-solid fa-ticket"></i> <?php echo $lang->load(['support','_title']);?></li></a>
                        <?php
                            if($users->isAdmin()){
                        ?>
                        <a href="<?=URL;?>/dashboard/terminal" class="text-decoration-none"><li class="list-group-item list-group-item-action"><i class="fa-solid fa-square-terminal"></i> <?php echo $lang->load(['terminal','_label']);?></li></a>
                        <?php
                            }
                        ?>
                        </div>
                        <a data-bs-toggle="collapse" href="#tab-devices" role="button" aria-expanded="false" aria-controls="tab-device" class="text-decoration-none"><li class="list-group-item list-group-item-action"><i class="fa-solid fa-computer"></i> <?php echo $lang->load(['devices','_label']);?></li></a>
                        <div class="collapse" id="tab-devices">
                            <?php
                            if($users->isAdmin()){
                            ?>
                                <a href="<?=URL;?>/dashboard/devices" class="text-decoration-none"><li class="list-group-item list-group-item-action"><i class="fa-solid fa-floppy-disks"></i> <?php echo $lang->load(['devices','view_devices']);?></li></a>
                            <?php
                            };
                            ?>
                            <a href="<?=URL;?>/dashboard/devices/register" class="text-decoration-none"><li class="list-group-item list-group-item-action"><i class="fa-solid fa-display-medical"></i> <?php echo $lang->load(['devices','register_device']);?></li></a>
                            <?php
                                if($users->isAdmin()){
                            ?>
                            <a href="<?=URL;?>/dashboard/devices/tracking" class="text-decoration-none"><li class="list-group-item list-group-item-action"><i class="fa-solid fa-location-dot"></i> <?php echo $lang->load(['devices','tracking_device']);?></li></a>
                            <?php
                                }
                            ?>
                        </div>
                        <a href="<?=URL;?>/dashboard/profile" class="text-decoration-none"><li class="list-group-item list-group-item-action"><i class="fa-solid fa-user"></i> <?php echo $lang->load(['profile','_label']);?></li></a>
                        <a href="<?=URL;?>/dashboard/security" class="text-decoration-none"><li class="list-group-item list-group-item-action"><i class="fa-jelly-fill fa-solid fa-lock"></i> <?php echo $lang->load(['security','_label']);?></li></a>
                        <a href="<?=URL;?>/dashboard/apps" class="text-decoration-none"><li class="list-group-item list-group-item-action"><i class="fa-solid fa-grid-2-plus"></i> <?php echo $lang->load(['apps','_label']);?></li></a>
                        <?php echo $addon->hook('dashboard_nav');?>
                    </ul>
                </div>
            </div>
            <?php
                if($uri->match('dashboard')){
            ?>
            <div class="row">
                <div class="col-4">
                    <div wo-clock="true"></div>
                </div>
                <div class="col">
                    <div wo-weather="true"></div>
                </div>
            </div>
            <?php
                if(!$device->isRegistered($device->deviceName())){
                ?>
                <div class="row">
                    <div class="col">
                        <p class="text-dark"><?php echo $lang->load(['users','isNew']);?></p>
                        <a href="./dashboard/devices/register"><button class="btn btn-primary w-100"><?php echo $lang->load(['devices','register_device']);?></button></a>
                    </div>
                </div>
            <?php
                }
            }
            if($uri->match('dashboard/config')){
                if($users->isAdmin()){
            ?>
            <form method="post" novalidate class="config">
                <input type="hidden" name="token" value="<?php echo $security->CSRF();?>"/>
                <h2><?php echo $lang->load(['dashboard','config','settings']);?></h2>
                <div class="row">
                    <div class="col">
                        <label class="form-label" for="config_tz"><?php echo $lang->load(['dates','timezone']);?></label>
                        <select class="form-select" name="config_tz" id="config_tz">
                            <?php
                                foreach(DateTimeZone::listIdentifiers() as $dt)
                                    echo "<option".(strtolower($config->read('settings','timezone'))===strtolower($dt) ? " selected='selected'" : "")." value='$dt'>$dt</option>";
                            ?>
                        </select>
                    </div>
                    <div class="col">
                        <label class="form-label" for="config_lang"><?php echo $lang->load(['users','language']);?></label>
                        <select class="form-select locales-select" name="config_lang" id="config_lang">
                            <?php
                                foreach($lang->list() as $r=>$l){
                                    $u = explode('-',$l);
                                    echo "<option data-region='{$u[1]}' data-lang='{$u[0]}' value='".implode('-',$u)."'></option>";
                                }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <label class="form-label" for="config_charset"><?php echo $lang->load(['dashboard','config','charset']);?></label>
                        <select class="form-select" name="config_charset" id="config_charset">
                            <?php
                                $charset = [
                                    'UTF-8',
                                    'ISO-8859-1',
                                    'ISO-8859-2',
                                    'ISO-8859-3',
                                    'ISO-8859-4',
                                    'ISO-8859-5',
                                    'ISO-8859-6',
                                    'ISO-8859-7',
                                    'ISO-8859-8',
                                    'ISO-8859-8-I',
                                    'ISO-8859-10',
                                    'ISO-8859-13',
                                    'ISO-8859-14',
                                    'ISO-8859-15',
                                    'windows-1250',
                                    'windows-1251',
                                    'windows-1252',
                                    'windows-1253',
                                    'windows-1254',
                                    'windows-1255',
                                    'windows-1256',
                                    'KOI8-R',
                                    'GBK',
                                    'GB2312',
                                    'Big5',
                                    'Shift_JIS',
                                    'EUC-JP',
                                    'EUC-KR',
                                    'ISO-2022-JP',
                                    'ISO-2022-KR',
                                    'UTF-16'
                                ];
                                foreach($charset as $char)
                                    echo "<option".(strtolower($config->read('settings','charset'))===strtolower($char) ? " selected='selected'" : "")." value='$char'>$char</option>";
                            ?>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <label class="form-label" for="config_theme"><?php echo $lang->load(['dashboard','theme']);?></label>
                        <select class="form-select" name="config_theme" id="config_theme">
                            <?php
                                foreach($files->scan(THEMES_PATH) as $f){
                                    echo "<option".(strtolower($config->read('settings','theme'))===strtolower($f) ? " selected='selected'" : "")." value='$f'>$f</option>";
                                }
                            ?>
                        </select>
                    </div>
                </div>
                <hr/>
                <h2><?php echo $lang->load(['mail','_label']);?></h2>
                <div class="row">
                    <div class="col">
                        <label for="mail_host" class="form-label"><?php echo $lang->load(['mail','smtp_host']);?></label>
                        <input type="text" value="<?php echo $config->read('mail','host');?>" class="form-control" name="mail_host" id="mail_host"/>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <label for="mail_username" class="form-label"><?php echo $lang->load(['mail','smtp_username']);?></label>
                        <input type="text" class="form-control" value="<?php echo $config->read('mail','username');?>" name="mail_username" id="mail_username"/>
                    </div> 
                    <div class="col">
                        <label for="mail_password" class="form-label"><?php echo $lang->load(['mail','smtp_password']);?></label>
                        <input type="password" class="form-control" name="mail_password" id="mail_password" value="<?php echo $config->read('mail','password') ? $security->safe_base64_decode($config->read('mail','password')) : '';?>"/>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <label for="mail_encryption" class="form-label"><?php echo $lang->load(['mail','smtp_encryption']);?></label>
                        <select class="form-select" name="mail_encryption" id="mail_encryption">
                            <option<?php echo strtolower($config->read('mail','encryption'))==='ssl' ? " selected='selected'" :"";?> value="SSL">SSL</option>
                            <option<?php echo strtolower($config->read('mail','encryption'))==='tls' ? " selected='selected'" :"";?> value="TLS">TLS</option>
                        </select>
                    </div>
                    <div class="col">
                        <label for="mail_port" class="form-label"><?php echo $lang->load(['mail','smtp_port']);?></label>
                        <input type="number"  class="form-control" name="mail_port" id="mail_port" value="<?php echo $config->read('mail','port');?>"/>
                    </div>
                    <div class="col">
                        <label for="mail_domain" class="form-label"><?php echo $lang->load(['domain']);?> <i class="fa-solid fa-question-circle" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-html="true" data-bs-title="<?php echo $lang->load(['help','mail_domain']);?>"></i></label>
                        <input type="text"  class="form-control" name="mail_domain" id="mail_domain" value="<?php echo $config->read('mail','domain');?>"/>
                    </div>
                </div>
                <button class="btn btn-success mt-3 w-100" type="submit"><?php echo $lang->load(['buttons','save']);?></button>
                <button class="btn btn-primary mt-3 w-100 testMailBtn" type="button"><?php echo $lang->load(['mail','test_mail']);?></button>
            </form>
            <?php
                }
            }
            if($uri->match('dashboard/analysis')){
                if($users->isAdmin()){
                ?>
                <div class="analysis-charts overflow-auto">
                    <h2 class="text-center"><?php echo $lang->load('service');?></h2>
                    <div class="d-flex flex-wrap">
                        <div class="users-count-chart"></div>
                    </div>
                    <h2 class="text-center border-2 border-top border-secondary"><?php echo "{$lang->load(['hardware','_label'])}";?></h2>
                    <div class="d-flex flex-wrap">
                        <div class="cpu-chart"></div>
                        <div class="memory-chart"></div>
                    </div>
                    <div class="d-flex flex-wrap">
                        <div class="battery mb-1">
                            <h3 class="text-center"><?php echo $lang->load(['hardware','battery']);?></h3>
                            <p class="battery-percent text-center fw-bold"></p>
                            <div class="battery-head"></div>
                            <div class="battery-body">
                                <div class="charge">
                                    <i class="fa-solid fa-bolt-lightning"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <h2 class="text-center border-2 border-top border-secondary"><?php echo $lang->load(['internet','_label']);?></h2>
                    <div class="d-flex flex-wrap">
                        <div class="internet-information d-flex flex-wrap justify-content-center align-items-center">
                            <table class="table table-striped w-100 table-hover">
                                <thead>
                                    <tr>
                                        <th><?php echo $lang->load(['information']);?></th>
                                        <th><?php echo $lang->load(['results']);?></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        foreach($network->checkInternetConnection() as $label=>$result){
                                            if($label==='isWireless'||$label==='connected'||$label==='connection_secured')
                                                $result = (int)$result==0 ? '<i class="fa-solid fa-x" style="color: #ff0000;"></i>' : '<i class="fa-solid fa-check" style="color: #00ff00;"></i>';
                                            if($label==='latency') 
                                                $result = round($result,2)."ms";
                                            if($label==='connection_name') 
                                                $result = "<span data-spoiler>$result</span>";
                                            echo "<tr>
                                            <td>{$lang->load(['internet',$label])}</td>
                                            <td>$result</td>
                                            </tr>";
                                        }
                                    ?>
                                </tbody>
                            </table>
                            <div class="downloadIndicator"></div>
                            <div class="uploadIndicator"></div>
                        </div>
                    </div>
                </div>
            <?php
                }
            }
            if($uri->match("dashboard/support")){
                if($users->isAdmin()||$users->isModerator()){
                ?>
            <div class="row supportDesk-container">
                <div class="col-md-6 border border-bottom-2 border-end-md pb-1 pe-md-1 border-top-0">
                    <div class="row gap-0">
                        <div class="col-6">
                            <img class="mt-1" width="39" src="<?php echo ASSETS_URL;?>/images/tickets/hold-tickets.png" alt="hold-tickets">
                            <h2 class="mt-2 mb-1 fw-normal desk-onHold-label">0 <span class="avg-status">0%</span></h2>
                            <h6 class="mb-0"><?php echo $lang->load(['support','desk','on_hold']);?></h6>
                        </div>
                        <div class="col-6 d-flex align-items-center px-0">
                            <div class="desk-chart on_hold-chart"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 ps-md-1 pb-1 pt-1 pt-md-0 border border-bottom-1 border-bottom-md-0 border-start-md-0 border-top-0">
                    <div class="row gap-0">
                        <div class="col-6">
                            <img class="mt-1" width="39" src="<?php echo ASSETS_URL;?>/images/tickets/open-tickets.png" alt="open-tickets">
                            <h2 class="mt-2 mb-1 fw-normal desk-openTickets-label">0 <span class="avg-status">0%</span></h2>
                            <h6 class="mb-0"><?php echo $lang->load(['support','desk','open_tickets']);?></h6>
                        </div>
                        <div class="col-6 d-flex align-items-center px-0">
                            <div class="desk-chart open_tickets"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 border border-bottom-0 border-bottom border-md-0 border-end-md pt-1 pe-md-1 pb-1 pb-md-0">
                    <div class="row gap-0">
                        <div class="col-6">
                            <img class="mt-1" width="39" src="<?php echo ASSETS_URL;?>/images/tickets/due-tickets.png" alt="due-tickets">
                            <h2 class="mt-2 mb-1 fw-normal desk-dtt-label">0 <span class="avg-status">0%</span></h2>
                            <h6 class="mb-0"><?php echo $lang->load(['support','desk','due_tickets_today']);?></h6>
                        </div>
                        <div class="col-6 d-flex align-items-center px-0">
                            <div class="desk-chart due_tickets_today"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 ps-md-1 pt-1 border border-top-1 border-bottom-0">
                    <div class="row gap-0">
                        <div class="col-6">
                            <img class="mt-1" width="39" src="<?php echo ASSETS_URL;?>/images/tickets/unassigned.png" alt="unassigned">
                            <h2 class="mt-2 mb-1 fw-normal desk-unassigned-label">0 <span class="avg-status">0%</span></h2>
                            <h6 class="mb-0"><?php echo $lang->load(['support','desk','unassigned']);?></h6>
                        </div>
                        <div class="col-6 d-flex align-items-center px-0">
                            <div class="desk-chart unassigned"></div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="unassigned-priorities"></div>
                </div>
            </div>
            <?php
                }
            echo "<table id=\"supportTickets-table\">
                <thead>
                    <tr>
                        <th>{$lang->load(['support','ticket_id'])}</th>
                        <th>{$lang->load(['support','subject'])}</th>
                        <th>{$lang->load(['support','description'])}</th>
                        <th>{$lang->load(['support','status','_label'])}</th>
                        <th>{$lang->load(['support','issue_category'])}</th>
                        <th>{$lang->load(['support','priority','_label'])}</th>
                        <th>{$lang->load(['support','created_at'])}</th>
                        <th>{$lang->load(['support','assigned_to'])}</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>";?>
                <a href="./support/create"><button class="btn btn-success mt-3 w-100"><i class="fa-solid fa-ticket"></i> <?php echo $lang->load(['support','create_ticket']);?></button></a>
            <?php
            }
            if($uri->match('dashboard/support/create')){
            ?>
            <form method="post" novalidate class="createTicketForm" enctype="multipart/form-data">
                <div class="alert alert-danger error-msg"><?php echo $lang->load(['errors','emptyInput']);?></div>
                <input type="hidden" name="main" value="<?php echo $security->safe_base64_encode(URL)?>"/>
                <div class="row">
                    <div class="col">
                        <label for="ticket-subject"><?php echo $lang->load(['support','subject']);?></label>
                        <input type="text" class="form-control" id="ticket-subject" name="ticket-subject"/>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <label for="ticket-description"><?php echo $lang->load(['support','description']);?></label>
                        <textarea class="form-control" id="ticket-description" name="ticket-description"></textarea>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <label for="ticket-attachments"><?php echo $lang->load('attachments',false);?></label>
                        <div class="attachment-manager">
                            <input type="file" multiple class="form-control" accept="image/*" name="ticket-attachments[]" id="ticket-attachments">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <label for="ticket-category"><?php echo $lang->load(['support','issue_category'],false);?></label>
                        <select class="form-select" id="ticket-category" name="ticket-category">
                            <?php
                                $categories = $data->toArray('tickets_categories');
                                foreach($categories['Category'] as $idx=>$category){
                                    $name = $category['@attributes']['name'];
                                    $title = $category['@attributes']['title'];
                                    echo "<option value='".strtolower($name)."'>$title</option>";
                                }
                            ?>
                        </select>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <button name="createTicketSubmit" class="btn btn-success w-100 mt-2"><?php echo $lang->load(['support','create_ticket']);?></button>
                    </div>
                </div>
            </form>
            <?php
            }
            if($uri->match('dashboard/support/read')){
                $ticket = new Table\SupportTickets();
                $info = $ticket->getTicket($_GET['ticket']);
                $uname = $users->getUserByID($info['user_id']);
            ?>
                <div class="ticket-container">
                    <div class="ticket-title">
                        <p class="ticket-subject"><?php echo $info['subject'];?></p>
                        <p class="ticket-author"><?php echo $uname['first_name'].' '.($uname['middle_name'].' '??'').$uname['last_name'];?></p>
                    </div>
                    <div class="ticket-description">
                        <p><?php echo $security->preventXSS($info['description']);?></p>
                    </div>
                    <div class="ticket-attachments">
                        <p class="ticket-attachments-label"><?php echo $lang->load('attachments');?></p>
                        <div class="ticket-attachments-gallery">
                            <?php
                                foreach(json_decode($info['attachments'],true) as $attachments){
                                    $alt = explode('/',$attachments);
                                    echo "<img loading='lazy' src='$attachments' alt='".preg_replace('/\..*$/','',end($alt))."'/>";
                                }
                            ?>
                        </div>
                    </div>
                    <hr class="border-4"/>
                    <div class="ticket-footer">
                        <form method="post" enctype="multipart/form-data" class="ticket-form">
                            <input type="hidden" name="token" value="<?php echo $security->CSRF()?>"/>
                            <input type="hidden" name="ticket_id" value="<?php echo $_GET['ticket'];?>"/>
                            <input type="hidden" name="main" value="<?PHP echo $security->safe_base64_encode(URL);?>"/>
                            <div>
                                <label for="ticket-priority"><?php echo $lang->load(['support','priority','_label']);?></label>
                                <select class="form-select" id="ticket-priority" name="ticket-priority">
                                    <option value="low"<?php echo $info['priority']==='low' ? ' selected="selected"' : '';?>><?php echo $lang->load(['support','priority','low']);?></option>
                                    <option value="medium"<?php echo $info['priority']==='medium' ? ' selected="selected"' : '';?>><?php echo $lang->load(['support','priority','medium']);?></option>
                                    <option value="high"<?php echo $info['priority']==='high' ? ' selected="selected"' : '';?>><?php echo $lang->load(['support','priority','high']);?></option>
                                    <option value="urgent"<?php echo $info['priority']==='urgent' ? ' selected="selected"' : '';?>><?php echo $lang->load(['support','priority','urgent']);?></option>
                                </select>
                            </div>
                            <div>
                                <label for="ticket-status"><?php echo $lang->load(['support','status','_label']);?></label>
                                <select class="form-select" id="ticket-status" name="ticket-status">
                                    <option value="open"<?php echo $info['status']==='open' ? ' selected="selected"' : '';?>><?php echo $lang->load(['support','status','open']);?></option>
                                    <option value="on_hold"<?php echo $info['status']==='on_hold' ? ' selected="selected"' : '';?>><?php echo $lang->load(['support','status','on_hold']);?></option>
                                    <option value="in_progress"<?php echo $info['status']==='in_progress' ? ' selected="selected"' : '';?>><?php echo $lang->load(['support','status','in_progress']);?></option>
                                    <option value="closed"<?php echo $info['status']==='closed' ? ' selected="selected"' : '';?>><?php echo $lang->load(['support','status','closed']);?></option>
                                    <option value="resolved"<?php echo $info['status']==='resolved' ? ' selected="selected"' : '';?>><?php echo $lang->load(['support','status','resolved']);?></option>
                                </select>
                            </div>
                            <div>
                                <label for="assigned_to"><?php echo $lang->load(['support','assigned_to']);?></label>
                                <input type="text" id="assigned_to" name="assigned_to" class="form-control" data-select="assignment-user" value="<?php echo isset($info['assigned_to'])&&!empty($info['assigned_to']) ? implode(',',json_decode($info['assigned_to'],true)):'';?>">
                                <div class="assignment-user">
                                    <?php
                                        foreach($users->list() as $users)
                                            echo "<div class='select-options' tabindex='0'>{$users['username']}</div>";
                                    ?>
                                </div>
                            </div>
                            <button class="btn btn-success mt-2 w-100"><i class="fa-solid fa-floppy-disk"></i> <?php echo $lang->load(['buttons','save']);?></button>
                            <a href="../support"><button class="btn btn-primary mt-2 w-100" type="button"><?php echo $lang->load(['buttons','back']);?></button></a>
                        </form>
                    </div>
                </div>
            <?php
            }
            if($uri->match('dashboard/devices')){
                if($users->isAdmin()||$users->hasPermission('help_desk')){
            ?>
            <div class="device-list">
                <?php
                    foreach($device->getRegisterDevices() as $devices){
                        $icon = match (true) {
                            preg_match('/linux/i',$devices['os'])==1=>'https://cdn-icons-png.flaticon.com/512/6124/6124995.png',
                            preg_match('/windows/i',$devices['os'])==1=>'https://cdn-icons-png.flaticon.com/512/270/270831.png',
                            preg_match('/mac|macOS/i',$devices['os'])==1=>'https://cdn-icons-png.flaticon.com/512/2/2235.png',
                            default=>''
                        };
                        $deviceIcon = match(true){
                            preg_match('/desktop/i',$devices['type'])==1=>'https://cdn-icons-png.flaticon.com/512/25/25240.png',
                            preg_match('/tablet/i',$devices['type'])==1=>'https://cdn-icons-png.flaticon.com/512/0/319.png',
                            preg_match('/mobile/i',$devices['type'])==1=>'https://cdn-icons-png.flaticon.com/512/0/191.png',
                            default=>''
                        };
                        $isActive = match(strtolower($devices['status'])){
                            'activated'=>'data-device-status="activated"',
                            'deactivate'=>'data-device-status="deactivate"',
                            default=>''
                        };
                        echo "<div class='p-2 rounded d-flex flex-column my-2 text-bg-light'>
                            <h3>{$devices['name']}</h3>
                            <div class='device_os w-100'>
                                <button class='btn btn-secondary w-100 mt-2' type='button' data-bs-toggle='collapse' data-bs-target='#deviceOS' aria-expanded='false' aria-controls='deviceOS'>{$lang->load(['devices','device_os'])}</button>
                                <div class='collapse' id='deviceOS'>
                                    <div class='card card-body align-items-center'>
                                        <img src='$icon' alt='{$devices['os']}' class='device_icon'/>
                                        <p class='text-dark'>{$lang->load(['devices','device_os'])}: {$devices['os']}</p>
                                        <p class='text-dark'>{$lang->load(['devices','device_os_platform'])}: {$devices['os_platform']}</p>
                                    </div>
                                </div>
                            </div>
                            <div class='device_type w-100'>
                                <button class='btn btn-secondary w-100 mt-2' type='button' data-bs-toggle='collapse' data-bs-target='#deviceInfo' aria-expanded='false' aria-controls='deviceInfo'>{$lang->load(['devices','device_info'])}</button>
                                <div class='collapse' id='deviceInfo'>
                                    <div class='card card-body align-items-center'>
                                    <div class='position-relative'>
                                        <img src='$deviceIcon' alt='{$devices['type']}' class='device_icon'/>
                                        <span {$isActive}></span>
                                    </div>
                                        <p class='text-dark'>{$lang->load(['devices','device_name'])}: {$devices['name']}</p>
                                        <p class='text-dark'>{$lang->load(['devices','device_manufacturer'])}: {$devices['manufacturer']}</p>
                                        <p class='text-dark'>{$lang->load(['devices','device_brand'])}: ".($devices['brand']!=='' ? $devices['brand'] : 'N/A')."</p>
                                        <p class='text-dark'>{$lang->load(['devices','device_model'])}: ".($devices['model']!=='' ? $devices['model'] : 'N/A')."</p>
                                        <p class='text-dark' data-no-select data-spoiler-inline>{$lang->load('mac_address')}: <span data-spoiler>{$devices['mac_address']}</span></p>
                                        <p class='text-dark' data-no-select data-spoiler-inline>{$lang->load('ip_address')}: <span data-spoiler>{$devices['ip_address']}</span></p>
                                    </div>
                                </div>
                            </div>
                            <div class='device_identification w-100'>
                                <button class='btn btn-secondary w-100 mt-2' type='button' data-bs-toggle='collapse' data-bs-target='#deviceIdentity' aria-expanded='false' aria-controls='deviceIdentity'>{$lang->load(['devices','device_identity'])}</button>
                                <div class='collapse' id='deviceIdentity'>
                                    <div class='card card-body align-items-center'>
                                        <p class='text-dark' data-no-select data-spoiler-inline>{$lang->load(['devices','device_serial'])}: <span data-spoiler>{$devices['serial_number']}</span></p>
                                        <p class='text-dark'>{$lang->load(['devices','device_asset'])}: {$devices['asset_tag']}</p>
                                        <p class='text-dark'>{$lang->load(['users','username'])}: {$devices['device_username']}</p>
                                    </div>
                                </div>
                            </div>";
                            if($device->isActivated($devices['name'])){
                                echo "<div class='device_actions w-100'>
                                <button class='btn btn-secondary w-100 mt-2' type='button' data-bs-toggle='collapse' data-bs-target='#deviceActions' aria-expanded='false' aria-controls='deviceActions'>{$lang->load(['devices','device_actions'])}</button>
                                <div class='collapse' id='deviceActions'>
                                    <div class='card card-body align-items-center'>
                                        <div class='btn-group'>
                                            <button class='btn btn-danger btn-lg' device-manager-action='powerOff' data-device-name='".$security->safe_base64_encode($devices['name'])."'>{$lang->load(['devices','actions','power_off'])}</button>
                                            <button class='btn btn-primary btn-lg' device-manager-action='ping' data-device-name='".$security->safe_base64_encode($devices['name'])."'>{$lang->load(['network','ping','_label'])}</button>
                                            <button class='btn btn-secondary btn-lg' device-manager-action='reboot' data-device-name='".$security->safe_base64_encode($devices['name'])."'>{$lang->load(['devices','actions','reboot'])}</button>
                                        </div>
                                        <div class='text-bg-light device-results w-100 mt-1 p-1 rounded'></div>
                                    </div>
                                </div>
                            </div>";
                            }
                            if($devices['status']==='deactivate')
                                echo "<button type='button' class='btn btn-danger mt-2 deviceManagerBtn' data-device-activate='".$security->safe_base64_encode($devices['name'])."'><i class='fa-solid fa-power-off'></i> {$lang->load(['devices','activate_device'])}</button>";
                            else
                                echo "<button type='button' class='btn btn-success mt-2 deviceManagerBtn' data-device-deactivate='".$security->safe_base64_encode($devices['name'])."'><i class='fa-solid fa-power-off'></i> {$lang->load(['devices','deactivate_device'])}</button>";
                        echo "</div>";
                    }
                ?>
            </div>
            <?php
                }
            }
            if($uri->match('dashboard/devices/register')){
                $deviceType = $device->is('mobile') ? 'mobile' : ($device->is('tablet') ? 'tablet' : ($device->is('desktop') ? 'desktop' : 'unknown'))
            ?>
                <div class="device-information">
                    <form class="deviceRegister" method="post" enctype="multipart/form-data">
                        <div class="alert alert-danger d-none"></div>
                        <input type="hidden" value="<?php echo $security->CSRF();?>" name="token"/>
                        <div class="row">
                            <div class="col">
                                <label for="deviceName"><?php echo $lang->load(['devices','device_name']);?></label>
                                <input type="text" readonly name="deviceName" id="deviceName" class="form-control disabled" value="<?php echo $device->deviceName();?>">
                            </div>
                            <div class="col">
                                <label for="deviceType"><?php echo $lang->load(['devices','device_type']);?></label>
                                <select class="form-select disabled" readonly name="deviceType" id="deviceType">
                                    <option <?php echo $deviceType==='desktop'?'selected="selected" ' : '';?>value="desktop"><?php echo $lang->load(['devices','desktop']);?></option>
                                    <option <?php echo $deviceType==='mobile'?'selected="selected" ' : '';?>value="mobile"><?php echo $lang->load(['devices','mobile']);?></option>
                                    <option <?php echo $deviceType==='tablet'?'selected="selected" ' : '';?>value="tablet"><?php echo $lang->load(['devices','tablet']);?></option>
                                    <option <?php echo $deviceType==='unknown'?'selected="selected" ' : '';?>value="tablet"><?php echo $lang->load(['unknown']);?></option>
                                </select>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="deviceBrand"><?php echo $lang->load(['devices','device_brand']);?></label>
                                <input type="text" name="deviceBrand" id="deviceBrand" class="form-control" value="<?php echo $device->deviceBrand();?>">
                            </div>
                            <div class="col">
                                <label for="deviceOS"><?php echo $lang->load(['devices','device_os']);?></label>
                                <input type="text" name="deviceOS" readonly id="deviceOS" class="form-control disabled" value="<?php echo $device->getOs('name');?>">
                            </div>
                            <div class="col">
                                <label for="deviceOSPlatform"><?php echo $lang->load(['devices','device_os_platform']);?></label>
                                <input type="text" name="deviceOSPlatform" readonly id="deviceOSPlatform" class="form-control disabled" value="<?php echo $device->getOs('platform');?>">
                            </div>
                            <div class="col">
                                <label for="deviceModel"><?php echo $lang->load(['devices','device_model']);?></label>
                                <input type="text" name="deviceModel" id="deviceModel" class="form-control" value="<?php echo $device->deviceModel();?>">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="deviceManufacturer"><?php echo $lang->load(['devices','device_manufacturer']);?></label>
                                <input type="text" readonly name="deviceManufacturer" id="deviceManufacturer" class="form-control disabled" value="<?php echo $device->getManufacturer()?>">
                            </div>
                            <div class="col">
                                <label for="deviceSerial"><?php echo $lang->load(['devices','device_serial']);?></label>
                                <input type="text" readonly name="deviceSerial" id="deviceSerial" class="form-control disabled" value="<?php echo $device->getSerial()?>">
                            </div>
                            <div class="col position-relative">
                                <i class="fa-solid fa-rotate randomAssetTag"></i>
                                <label for="deviceAsset"><?php echo $lang->load(['devices','device_asset']);?> <i class="fa-solid fa-circle-question" data-bs-toggle="tooltip" data-bs-placement="top" data-bs-title="<?php echo $lang->load(['help','asset_tag']);?>"></i></label>
                                <input type="text" name="deviceAsset" id="deviceAsset" class="form-control" data-asset-tag>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="purchaseDate"><?php echo $lang->load(['devices','purchase_date']);?></label>
                                <input type="date" name="purchaseDate" id="purchaseDate" class="form-control">
                            </div>
                            <div class="col">
                                <label for="warrantyExpiry"><?php echo $lang->load(['devices','warranty_expiry']);?></label>
                                <input type="date" name="warrantyExpiry" id="warrantyExpiry" class="form-control">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col">
                                <label for="deviceIP"><?php echo $lang->load('ip_address');?></label>
                                <input type="text" readonly name="deviceIP" id="deviceIP" class="form-control disabled" value="<?php echo $users->getIP();?>">
                            </div>
                            <div class="col">
                                <label for="deviceMAC"><?php echo $lang->load('mac_address');?></label>
                                <input type="text" readonly name="deviceMAC" id="deviceMAC" class="form-control disabled" value="<?php echo $device->macAddress();?>">
                            </div>
                            <div class="col">
                                <label for="deviceUser"><?php echo $lang->load(['users','username']);?></label>
                                <input type="text" readonly name="deviceUser" id="deviceUser" class="form-control disabled" value="<?php echo $device->getDeviceUsername();?>">
                            </div>
                            <div class="col">
                                <label for="deviceLocation"><?php echo $lang->load(['devices','device_location']);?></label>
                                <input type="text" readonly name="deviceLocation" id="deviceLocation" class="form-control disabled">
                            </div>
                        </div>
                        <button type="submit" class="btn btn-success mt-2 w-100 fs-4"><i class="fa-solid fa-floppy-disk"></i> <?php echo $lang->load(['buttons','save'])?></button>
                    </form>
                </div>
            <?php
            }
            if($uri->match('dashboard/terminal')){
                if($users->isAdmin()){
            ?> 
            <div class="terminal container-fluid" terminal-type="gnome" terminal-theme="default">
                <div class="d-flex">
                    <select class="form-select terminal-type-select" name="terminal-type">
                        <optgroup label="<?php echo $lang->load(['terminal','terminal_type']);?>">
                            <option value="gnome">GNOME</option>
                            <option value="powershell">Powershell</option>
                            <option value="cmd">Command Prompt</option>
                            <option value="macOS">macOS</option>
                            <option value="iTerm2">iTerm2</option>
                        </optgroup>
                    </select>
                    <select class="form-select terminal-theme-select ms-2" name="terminal-theme">
                        <optgroup style="max-height:65px;" label="<?php echo $lang->load(['terminal','terminal_theme']);?>">
                            <option value="default" selected="selected"><?php echo $lang->load('default')?></option>
                            <option value="solarized_light"><?php echo $lang->load(['terminal','themes','solarized_light']);?></option>
                            <option value="solarized_dark"><?php echo $lang->load(['terminal','themes','solarized_dark']);?></option>
                            <option value="dracula"><?php echo $lang->load(['terminal','themes','dracula']);?></option>
                            <option value="monokai"><?php echo $lang->load(['terminal','themes','monokai']);?></option>
                            <option value="ocean_breeze"><?php echo $lang->load(['terminal','themes','ocean_breeze']);?></option>
                            <option value="mint_fresh"><?php echo $lang->load(['terminal','themes','mint_fresh']);?></option>
                            <option value="midnight_sky"><?php echo $lang->load(['terminal','themes','midnight_sky']);?></option>
                            <option value="deep_forest"><?php echo $lang->load(['terminal','themes','deep_forest']);?></option>
                            <option value="rose_quartz"><?php echo $lang->load(['terminal','themes','rose_quartz']);?></option>
                            <option value="cherry_blossom"><?php echo $lang->load(['terminal','themes','cherry_blossom']);?></option>
                            <option value="golden_hour"><?php echo $lang->load(['terminal','themes','golden_hour']);?></option>
                            <option value="maroon_magic"><?php echo $lang->load(['terminal','themes','maroon_magic']);?></option>
                            <option value="graphite_gray"><?php echo $lang->load(['terminal','themes','graphite_gray']);?></option>
                        </optgroup>
                    </select>
                </div>
                <div class="terminal-history">
                    <div class="terminal-input" data-terminal-user="<?php echo get_current_user()?>" data-terminal-host="<?php echo php_uname('n')?>" data-terminal-cwd="<?php echo getcwd();?>">
                        <span class="currentInfo"></span>
                        <span class="cmd"></span>
                    </div>
                </div>
            </div>
            <?php
                }
            }
            if($uri->match('dashboard/devices/tracking')){
                if($users->isAdmin()){
            ?>
            <div id="device-map"></div>
            <?php
                }
            }
            if($uri->match('dashboard/profile')){
                $userRequest = explode('=',$uri->getQuery($_SERVER['REQUEST_URI']));
                $u = new Users($userRequest[1]??'');
            ?>
            <?php
                if(!isset($userRequest[1])){
            ?>
            <div class="modal fade" id="profileEdit" tabindex="-1" aria-labelledby="profileEditLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <form method="post" novalidate class="profileEditor">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h1 class="modal-title fs-5" id="profileEditLabel"><?php echo $lang->load(['profile','edit_profile'])?></h1>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p class="text-muted"><?php echo $lang->load(['profile','profile_note']);?></p>
                                
                                    <input name="token" value="<?php echo $security->CSRF();?>" type="hidden"/>
                                    <div class="row">
                                        <div class="col">
                                            <label for="fname"><?php echo $lang->load(['users','first_name']);?></label>
                                            <input name="fname" type="text" id="fname" autocomplete="off" class="form-control"/>
                                        </div>
                                        <div class="col">
                                            <label for="mname"><?php echo $lang->load(['users','middle_name']);?></label>
                                            <input name="mname" type="text" id="mname" autocomplete="off" class="form-control"/>
                                        </div>
                                        <div class="col">
                                            <label for="lname"><?php echo $lang->load(['users','last_name']);?></label>
                                            <input name="lname" type="text" id="lname" autocomplete="off" class="form-control"/>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col">
                                            <label for="phone"><?php echo $lang->load(['users','phone']);?></label>
                                            <input name="phone" id="phone" type="tel" autocomplete="off" class="form-control"/>
                                        </div>
                                        <div class="col">
                                            <label for="bio"><?php echo $lang->load(['users','bio']);?></label>
                                            <textarea name="bio" id="bio" autocomplete="off" class="form-control"></textarea>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo $lang->load(['buttons','close'])?></button>
                                <button type="submit" class="btn btn-primary"><?php echo $lang->load(['buttons','save'])?></button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <?php
                }
            ?>
            <div class="card d-block mx-auto" style="width: 38rem;">
                <div class="card-header">
                    <h5 class="card-title text-center"><?php echo $u->getUsername();?></h5>
                    <div class="position-relative profile-icon-container">
                        <span data-user-status="<?php echo $u->getStatus();?>"></span>
                        <img loading="lazy" class="d-block mx-auto pfp<?php if(!isset($userRequest[1])) echo " change-pfp";?>" src="<?php echo $u->getProfilePicture();?>" alt="<?php echo $u->getUsername();?>"/>
                        <?php if(!isset($userRequest[1])) echo "<input type='file' accept='image/*' name='uploadPfp' style='width:0;border:0;height:0;opacity:0;'/>";?>
                    </div>
                    <?php echo $addon->hook('profile_header');?>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <p class="text-dark fw-bold"><?php echo $lang->load(['users','fullName']);?></p>
                            <p class="text-dark"><?php echo implode(' ',$u->getFullName());?></p>
                        </div>
                        <div class="col">
                            <p class="text-dark fw-bold"><?php echo $lang->load(['users','language']);?></p>
                            <p class="locales-display text-dark"><?php echo trim($u->getLanguage(true));?></p>
                        </div>
                        <div class="col">
                            <p class="text-dark fw-bold"><?php echo $lang->load(['users','account_joined']);?></p>
                            <p class="text-dark" dt-format="date"><?php echo $u->joined();?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <p class="text-dark fw-bold"><?php echo $lang->load(['users','email']);?></p>
                            <p class="text-dark"><?php echo $u->getEmail();?></p>
                        </div>
                        <div class="col">
                            <p class="text-dark fw-bold"><?php echo $lang->load(['users','phone']);?></p>
                            <p class="text-dark"><a class="link-primary" href="tel:<?php $ph=$u->getPhone(); echo $ph;?>"><?php echo $ph;?></a></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <p class="text-dark fw-bold"><?php echo $lang->load(['users','last_activity']);?></p>
                            <p class="text-dark" dt-format="datetime"><?php echo $u->lastActive();?></p>
                        </div>
                        <div class="col">
                            <p class="text-dark fw-bold"><?php echo $lang->load(['users','bio']);?></p>
                            <p class="text-dark"><?php echo $u->getBio();?></p>
                        </div>
                    </div>
                    <?php echo $addon->hook('profile_body');?>
                </div>
                <div class="card-footer">
                    <?php
                        if(!isset($userRequest[1])){
                    ?>
                        <button type="button" data-bs-toggle="modal" data-bs-target="#profileEdit" class="btn btn-primary mx-auto d-block"><?php echo $lang->load(['profile','edit_profile']);?></button>
                    <?php
                        }
                        echo $addon->hook('profile_footer');
                    ?>
                </div>
            </div>
            <?php
            }
            if($uri->match('dashboard/security')){
            ?>
            <div class="security-container slider-card">
                <div class="row">
                    <div class="col my-1">
                        <a class="text-decoration-none link-secondary" href="./security/login">
                            <div class="card" style="width: 18rem;">
                                <div class="selection-grid"></div>
                                <div class="card-body text-center fs-2">
                                    <i class="fa-solid fa-user-key"></i>
                                    <h2><?php echo $lang->load(['security','user_login']);?></h2>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col my-1">
                        <a class="text-decoration-none link-secondary" href="./security/logs">
                            <div class="card" style="width: 18rem;">
                                <div class="selection-grid"></div>
                                <div class="card-body text-center fs-2">
                                    <i class="fa-solid fa-scroll"></i>
                                    <h2><?php echo $lang->load(['security','logs']);?></h2>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col my-1">
                        <a class="text-decoration-none link-secondary" href="./security/audits">
                            <div class="card" style="width: 18rem;">
                                <div class="selection-grid"></div>
                                <div class="card-body text-center fs-2">
                                    <i class="fa-solid fa-memo"></i>
                                    <h2><?php echo $lang->load(['security','audit']);?></h2>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col my-1">
                        <a class="text-decoration-none link-secondary" href="./security/code">
                            <div class="card" style="width: 18rem;">
                                <div class="selection-grid"></div>
                                <div class="card-body text-center fs-2">
                                    <i class="fa-solid fa-code"></i>
                                    <h2><?php echo $lang->load(['security','code']);?></h2>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
            <?php
            }
            if($uri->match('dashboard/security/login')){
            ?>
            <button class="btn btn-outline-secondary w-100" type="button" data-bs-toggle="collapse" data-bs-target="#changePasswordTab" aria-expanded="false" aria-controls="changePasswordTab"><?php echo $lang->load(['security','change_password']);?></button>
            <div class="collapse mb-2" id="changePasswordTab">
                <div class="card">
                    <div class="card-body">
                        <form method="post" novalidate class="securityPasswordChange" enctype="multipart/form-data">
                            <div class="alert alert-danger d-none"></div>
                            <input type="hidden" value="<?php echo $security->CSRF();?>" name="token"/>
                            <div class="row">
                                <div class="col">
                                    <label class="form-label" for="new_password"><?php echo $lang->load(['users','new_password']);?></label>
                                    <input type="password" class="form-control" name="new_password" id="new_password" data-password-tools="true" data-password-length="12" data-password-measure="true" data-password-use="lowercase,uppercase,numbers,symbols" data-password-no="copy,paste,select" required/>
                                    <span class="error-msg alert alert-danger"><?php echo $lang->load(['errors','emptyInput']);?></span>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <label class="form-label" for="confirm_new_password"><?php echo $lang->load(['users','confirm_new_password']);?></label>
                                    <input type="password" class="form-control" data-password-tools="true" data-password-use="lowercase,uppercase,numbers,symbols" data-password-noGen data-password-no="copy,paste,select" name="confirm_new_password" id="confirm_new_password" required/>
                                    <span class="error-msg alert alert-danger"><?php echo $lang->load(['errors','emptyInput']);?></span>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <button type="submit" class="btn btn-success w-100 mt-3"><i class="fa-solid fa-floppy-disk"></i> <?php echo $lang->load(['buttons','save']);?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <button class="btn btn-outline-secondary w-100 my-1" type="button" data-bs-toggle="collapse" data-bs-target="#change2FA" aria-expanded="false" aria-controls="change2FA"><?php echo $lang->load(['security','mfa','_label']);?></button>
            <div class="collapse" id="change2FA">
                <div class="card">
                    <div class="card-body">
                        <form method="post" novalidate class="security2FA">
                            <input type="hidden" value="<?php echo $security->CSRF();?>" name="token"/>
                            <div class="row">
                                <div class="col">
                                    <p class="form-label"><?php echo $lang->load(['security','mfa','enable_2fa']);?></p>
                                    <div id="mfaSwitch"<?php echo $users->mfaEnabled() ? ' data-selected="true"':'';?>></div>
                                </div>
                                <div class="col">
                                    <label class="form-label" for="mfa_method"><?php echo $lang->load(['security','mfa','2fa_method']);?></label>
                                    <select class="form-select" name="mfa_method" id="mfa_method">
                                        <?php
                                            foreach($users->list2FAMethods() as $methods)
                                                echo "<option".(hash_equals($methods,$users->getMFAMethod()) ? " selected='selected'" : '')." value='$methods'>".ucwords(preg_replace('/_/',' ',$methods))."</option>";
                                        ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col">
                                    <ul class="list-group">
                                        <li class="list-group-item list-group-item-secondary"><?php echo $lang->load(['security','mfa','2fa_method']).$lang->load('plural');?></li>
                                        <li class="list-group-item list-group-item-dark">
                                            <div class="d-flex flex-column">
                                                <div class="fs-4 fw-bold">
                                                    <div class="d-flex justify-content-between">
                                                        <div>
                                                            <i class="fa-regular fa-mobile"></i>
                                                            <?php echo $lang->load(['security','mfa','authenticator_app'])?>
                                                            <?php
                                                                if($users->has2FAMethodEnabled('authenticator_app')){
                                                            ?>
                                                            <span class="badge badge-success"><?php echo $lang->load('confirmed');?></span>
                                                            <?php
                                                                }
                                                            ?>
                                                        </div>
                                                        <button class="btn btn-secondary" type="button" data-target-value="authenticator_app" data-bs-toggle="modal" data-bs-target="#authorizedAccount"><?php echo $users->has2FAMethodEnabled('authenticator_app') ? $lang->load(['buttons','edit']) : $lang->load(['buttons','add'])?></button>
                                                    </div>
                                                </div>
                                                <p class="text-muted mfa-info"><?php echo $lang->load(['security','mfa','authenticator_app_info'])?></p>
                                            </div>
                                            <?php
                                                if($storage->session('is_authorized',null,'get')&&hash_equals('authenticator_app',$storage->session('is_authorized',null,'get'))){
                                                    ?>
                                                    <div class="authorization_card justify-self-center w-75">
                                                        <div class="qr-code justify-self-center"></div>
                                                        <input type="text" name="secret" class="form-control" value="<?php echo $users->get2FASecret();?>"/>
                                                        <label class="form-label" for="mfaCode"><?php echo $lang->load(['security','mfa','enterMFACode']);?></label>
                                                        <input type="number" class="form-control text-center" autofocus placeholder="000000" name="mfaCode" id="mfaCode"/>
                                                        <button name="activateAuthenticatorApp" class="mfa-submit btn btn-success w-100" type="submit"><?php echo $lang->load(['buttons','save']);?></button>
                                                    </div>
                                            <?php
                                                }
                                            ?>
                                        </li>
                                        <li class="list-group-item list-group-item-dark">
                                            <div class="d-flex flex-column">
                                                <div class="fs-4 fw-bold">
                                                    <div class="d-flex justify-content-between">
                                                        <div>
                                                            <i class="fa-light fa-envelope"></i>
                                                            <?php echo $lang->load(['users','email'])?>
                                                            <span class="badge badge-danger"><?php echo $lang->load(['security','less_secured']);?></span>
                                                            <?php
                                                                if($users->has2FAMethodEnabled('mail')){
                                                            ?>
                                                            <span class="badge badge-success"><?php echo $lang->load('confirmed');?></span>
                                                            <?php
                                                                }
                                                            ?>
                                                        </div>
                                                        <button class="btn btn-secondary" data-target-value="mail" data-bs-toggle="modal" data-bs-target="#authorizedAccount" type="button"><?php echo $users->has2FAMethodEnabled('mail') ? $lang->load(['buttons','edit']) : $lang->load(['buttons','add'])?></button>
                                                    </div>
                                                    
                                                </div>
                                                <p class="text-muted mfa-info"><?php echo $lang->load(['security','mfa','email_info'])?></p>
                                            </div>
                                        </li>
                                        <li class="list-group-item list-group-item-secondary"><?php echo $lang->load(['security','mfa','recovery_options'])?></li>
                                        <li class="list-group-item list-group-item-dark">
                                            <div class="d-flex flex-column">
                                                <div class="fs-4 fw-bold">
                                                    <div class="d-flex justify-content-between">
                                                        <div>
                                                            <i class="fa-light fa-key"></i>
                                                            <?php echo $lang->load(['security','mfa','recovery_codes'])?>
                                                            <?php
                                                                if($users->has2FAMethodEnabled('authenticator_app')){
                                                            ?>
                                                            <span class="badge badge-success"><?php echo $lang->load('viewed');?></span>
                                                            <?php
                                                                }
                                                            ?>
                                                        </div>
                                                        <button class="btn btn-secondary" type="button" data-target-value="view_recovery" data-bs-toggle="modal" data-bs-target="#authorizedAccount"><?php echo $lang->load(['buttons','view'])?></button>
                                                    </div>
                                                </div>
                                                <p class="text-muted mfa-info"><?php echo $lang->load(['security','mfa','recovery_codes_info'])?></p>
                                            </div>
                                        </li>
                                        <?php
                                        if($storage->session('is_authorized',null,'get')&&hash_equals('view_recovery',$storage->session('is_authorized',null,'get'))){
                                        ?>
                                        <li class="list-group-item list-group-item-light">
                                            <?php
                                                $keys = $users->listRecoveryKeys();
                                                $len = count($keys);
                                                $firstHalf = array_slice($keys, 0, intval($len/2));
                                                $secondHalf = array_slice($keys,intval($len/2));
                                            ?>
                                            <div class="row recovery-keys">
                                                <div class="col">
                                                    <ul class="recovery-key-list">
                                                    <?php
                                                        foreach($firstHalf as $fh=>$k) echo "<li>{$k['code']}</li>";
                                                    ?>
                                                    </ul>
                                                </div>
                                                <div class="col">
                                                    <ul class="recovery-key-list">
                                                    <?php
                                                        foreach($secondHalf as $sh=>$k) echo "<li>{$k['code']}</li>";
                                                    ?>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="d-flex justify-content-center mt-2">
                                                <button type="button" class="btn btn-outline-secondary mx-2 recovery-action" data-recovery-action="download"><?php echo $lang->load(['buttons','download']);?> <i class="fa-light fa-download"></i></button>
                                                <button type="button" class="btn btn-outline-secondary mx-2 recovery-action" data-recovery-action="print"><?php echo $lang->load(['buttons','print']);?> <i class="fa-light fa-print"></i></button>
                                                <button type="button" class="btn btn-outline-secondary mx-2 recovery-action" data-recovery-action="copy"><?php echo $lang->load(['buttons','copy']);?> <i class="fa-light fa-copy"></i></button>
                                            </div>
                                        </li>
                                        <?php
                                        }
                                        ?>
                                    </ul>
                                </div>
                            </div>
                        </form>
                        <div class="modal fade" id="authorizedAccount" tabindex="-1" aria-labelledby="authorizedAccountLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <form method="post" enctype="multipart/form-data">
                                        <input type="hidden" name="target"/>
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="authorizedAccountLabel"><?php echo $lang->load(['security','authorize_account']);?></h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <label class="form-label"><?php echo $lang->load(['users','password'])?></label>
                                            <input class="form-control" name="authPsw" type="password"/>
                                        </div>
                                        <div class="modal-footer">
                                            <button name="authorizedAccess" type="submit" class="btn btn-success"><?php echo $lang->load(['buttons','authorize']);?></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <button class="btn btn-outline-secondary w-100" type="button" data-bs-toggle="collapse" data-bs-target="#sso" aria-expanded="false" aria-controls="ssoTab"><?php echo $lang->load(['security','sso']);?></button>
            <div class="collapse mb-2" id="sso">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <h2><?php echo $lang->load(['sso','facial_recognition']);?></h2>
                                <div id="facial-picture-outline"></div>
                                <button id="facial-recognition-btn" class="btn btn-outline-primary"><?php echo $lang->load(['buttons','take_picture']);?></button>
                                <button id="facial-recognition-delete-btn" class="btn btn-outline-danger"><?php echo $lang->load(['buttons','delete_picture']);?></button>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <?php
            }
            if($uri->match('dashboard/security/audits')){
            ?>
            <table class="audits-table table cell-border compact table-striped">
                <thead>
                    <tr>
                        <th><?php echo $lang->load(['security','audits','from_target']);?></th>
                        <th><?php echo $lang->load(['security','audits','risk']);?></th>
                        <th><?php echo $lang->load(['reason']);?></th>
                        <th><?php echo $lang->load(['security','audits','audited_on']);?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach($auditor->read($users->getUsername()) as $i=>$d){
                        echo "<tr>
                            <td>{$d['from_target']}</td>
                            <td>{$d['risk']}</td>
                            <td>{$d['reason']}</td>
                            <td>{$d['audited_date']}</td>
                        </tr>";
                    }
                    ?>
                </tbody>
            </table>
            <?php
            }
            if($uri->match('dashboard/apps')){
            ?>
            <div class="row apps-office-application slider-card">
                <h3 class="text-center"><?=$lang->load(['apps','_longName'])?></h3>
                <div class="col">
                    <a class="text-decoration-none link-secondary" href="<?=APPLICATION_URL?>/forms">
                        <div class="card" style="width: 25rem;">
                            <div class="selection-grid"></div>
                            <img src="<?=ASSETS_URL?>/icons/form.png" width="82" height="82" class="d-block mx-auto mt-1" alt="ForumX-icon">
                            <div class="card-body">
                                <h5 class="card-title"><?=$lang->load(['apps','applications','forms','_label'])?></h5>
                                <p><?=$lang->load(['apps','applications','forms','_description'])?></p>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <?php
            }
            ?>
        </div>
        <?php
        echo $addon->hook('afterMain');?>
        <footer><?php echo $addon->hook('footer');?></footer>
        <?php
        echo $addon->hook('scripts');
        if($storage->session('is_authorized',null,'get')){
            if(hash_equals('authenticator_app',$storage->session('is_authorized',null,'get'))){
        ?>
        <script>
            const mfa = new Scanner(document.querySelector('.qr-code'));
            const qr = mfa.createScanner('qrcode')
            .setData(`<?php echo preg_replace('/&algorithm=.*/','',$security->MFA($users->get2FASecret()))?>`)
            .customize();
            qr.setWidth(150);
            qr.setHeight(150);
            mfa.generate();
        </script>
        <?php
            }
            $storage->session('is_authorized',null,'Delete');
        }
        ?>
    </body>
</html>
<?php
if(isset($_POST['authorizedAccess'])){
    $psw = $_POST['authPsw'];
    $target = $_POST['target'];
    if($users->checkPassword($psw)){
        if(hash_equals('authenticator_app',strtolower($target))){
            $storage->session('is_authorized','authenticator_app');
            echo '<script>window.open(`${BASE}/dashboard/security/login`,`_self`);</script>';
        }elseif(hash_equals('view_recovery',strtolower($target))){
            $storage->session('is_authorized','view_recovery');
            echo '<script>window.open(`${BASE}/dashboard/security/login`,`_self`);</script>';
        }elseif(hash_equals('mail',strtolower($target))){
            $storage->session('is_authorized','mail');
            $users->add2FAMethod('mail');
            echo '<script>window.open(`${BASE}/dashboard/security/login`,`_self`);</script>';
        }else echo '<script>window.open(`${BASE}/dashboard/security/login?no_method=true`,`_self`)</script>';
    }else echo '<script>window.open(`${BASE}/dashboard/security/login?authorized=false`,`_self`)</script>';
}

if(isset($_POST['activateAuthenticatorApp'])){
    $code = $security->filter($_POST['mfaCode'],Security::FILTER_INT);
    $token = $_POST['token'];
    $secret = $_POST['secret']; 
    if($security->CSRF('verify',$token)){
        if($security->MFA($secret,$code,'VERIFY')){
            $users->add2FAMethod('authenticator_app');
            $users->addMFA($secret);
            echo '<script>window.open(`${BASE}/dashboard/security/login`,`_self`)</script>';
        } else echo '<script>window.open(`${BASE}/dashboard/security/login?activated=false`,`_self`)</script>';
    }else echo '<script>window.open(`${BASE}/dashboard/security/login?activated=false`,`_self`)</script>';
}

?>