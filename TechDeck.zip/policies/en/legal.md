# Legal Notice for TechDeck

_Last Updated: 10.12.2025_

This Legal Notice applies to the use, distribution, and contribution to the TechDeck project, an open-source administrative, network, and server tools suite intended for use on personalized devices and localhost servers.


## 1. License and Intellectual Property

- **License:** TechDeck is distributed under the [GNU Affero General Public License v3.0 (AGPL‑3.0)](https://github.com/XHiddenProjects/TechDeck/blob/master/LICENSE). This license permits free use, modification, and distribution, provided that any modified versions made available over a network also share their source code under the same license.
- **Intellectual Property:** All intellectual property rights related to TechDeck remain with the original authors and contributors unless explicitly transferred through a written agreement.

## 2. Compliance with Laws

- Users agree to use TechDeck in compliance with all applicable local, national, and international laws and regulations.
- Unauthorized use of TechDeck for illegal activities is strictly prohibited.

## 3. Disclaimers and Limitation of Liability

- TechDeck is provided "as-is" without warranties of any kind, express or implied.
- The authors and contributors are not responsible for any damages, data loss, or legal issues arising from the use or misuse of TechDeck.

## 4. No Warranty for International Use

- While TechDeck is designed for local and personal use, users outside the intended scope are responsible for ensuring compliance with their local laws.
- The project maintainers do not guarantee compliance or suitability for use in jurisdictions with specific legal requirements.

## 5. Indemnification

- Users agree to indemnify and hold harmless the authors and contributors from any claims, damages, or liabilities resulting from their use, modification, or distribution of TechDeck.

## 6. Governing Law and Jurisdiction

- This legal notice shall be governed by and construed in accordance with the laws of _United States_.
- Any legal actions or disputes arising out of or relating to this Legal Notice or TechDeck shall be exclusively brought in the federal or state courts located in Ohio.

## 7. Changes to Legal Notice

- This Legal Notice may be updated periodically. Your continued use of TechDeck constitutes acceptance of these updates.