# Terms and Conditions for TechDeck

_Last Updated: 10.12.2025_

Welcome to TechDeck! By using or deploying this software, you agree to the following terms and conditions.


## 1. License and Usage

- **License:** TechDeck is an open-source project released under the [GNU Affero General Public License v3.0 (AGPL‑3.0)](https://github.com/XHiddenProjects/TechDeck/blob/master/LICENSE). This license allows free use, modification, and distribution, provided that any modified versions made available over a network also share their source code under the same license.
- **Usage:** You may use TechDeck for personal or organizational purposes, including on local devices and servers, as long as you comply with the AGPL‑3.0 terms.
- **Scope:** This software is primarily intended for deployment on personal devices and localhost servers. If you host or provide TechDeck as a network service, you must make the corresponding source code available to all users who interact with it.

## 2. Account Control

- TechDeck does not include or manage user accounts or authentication.
- All account management is your responsibility; TechDeck does not have control over user accounts or data security.

## 3. Limitations

- TechDeck is provided "as-is" without warranties of any kind.
- The authors are not responsible for any data loss, security issues, or damages resulting from the use of TechDeck.

## 4. Privacy and Data Security

- Since TechDeck is used on a local device and localhost server, it does not collect or transmit user data.
- Users are responsible for securing their own systems and data.

## 5. Contributions

- Contributions to TechDeck are welcome. Please submit pull requests or issues on the project's repository.
- By contributing, you agree that your contributions may be licensed under the project's license.

## 6. Miscellaneous

- This terms and conditions document is subject to change without notice.
- Use of TechDeck signifies your agreement to these terms.

---
**Contact:**  
For questions or support, please visit [https://github.com/XHiddenProjects/TechDeck](https://github.com/XHiddenProjects/TechDeck).