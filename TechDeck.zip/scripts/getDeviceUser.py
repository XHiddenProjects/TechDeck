import os
import platform

# Determine the current operating system
def get_logged_in_user():
    # Check for Unix-like systems (Linux, macOS)
    if platform.system() in ['Linux', 'Darwin']:  # Darwin is macOS
        output = os.popen('who').read()
    # Check for Windows
    elif platform.system() == 'Windows':
        output = os.popen('query user').read()
    else:
        return "Unsupported Operating System"

    # Process the output
    users = output.split('\n')
    
    # Find the first user entry after the header
    for i in range(len(users)):
        if users[i].strip() and platform.system() in ['Linux','Darwin']:  # Ignore the header and check for non-empty
            username = users[i].split()[0]  # Get the first word, which should be the username
            print(username.strip())
            break  # Exit after finding the first user
        elif users[i].strip() and i > 0 and platform.system()=='Windows':  # Ignore the header and check for non-empty
            username = users[i].split()[0].replace(">","")  # Get the first word, which should be the username
            print(username.strip())
            break  # Exit after finding the first user
# Call the function
get_logged_in_user()