
#!/usr/bin/env python3
import smtplib
import sys
import json
import os
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

def load_payload(arg: str) -> dict:
    """
    Load the email payload from either a JSON file path or a raw JSON string.
    - If `arg` points to a file, read and parse JSON from that file.
    - Otherwise, treat `arg` as a raw JSON string.
    """
    # Strip outer quotes that some shells may include
    arg = arg.strip()
    if (arg.startswith('"') and arg.endswith('"')) or (arg.startswith("'") and arg.endswith("'")):
        arg = arg[1:-1]

    # If it's a file path, load the JSON from file
    if os.path.isfile(arg):
        with open(arg, 'r', encoding='utf-8') as f:
            return json.load(f)

    # Otherwise, parse as raw JSON string
    return json.loads(arg)

def parse_headers(headers):
    """
    Convert headers into a dictionary.
    Supports either:
      - dict: returned as-is
      - string with lines like 'Key: Value\\r\\nAnother-Key: Another-Value\\r\\n'
    """
    if not headers:
        return {}

    if isinstance(headers, dict):
        return headers

    if isinstance(headers, str):
        hdrs = {}
        # splitlines() will handle \r\n or \n
        for line in headers.splitlines():
            line = line.strip()
            if not line:
                continue
            if ':' in line:
                k, v = line.split(':', 1)
                hdrs[k.strip()] = v.strip()
        return hdrs

    return {}

def main():
    # Expect exactly one argument: JSON string OR path to JSON file
    if len(sys.argv) != 2:
        print("Usage: python3 mailer.py <json_payload | path_to_payload.json>")
        sys.exit(1)

    arg = sys.argv[1]

    try:
        # Load payload (from file or string)
        email_data = load_payload(arg)

        # Extract fields
        sender = email_data.get('from', '')
        recipients = email_data.get('to', '')
        subject = email_data.get('subject', '')
        body = email_data.get('body', '')
        headers = email_data.get('headers', '')
        attachments = email_data.get('attachments', [])
        host = email_data.get('host', '')
        username = email_data.get('username', '')
        password = email_data.get('password', '')
        port = int(email_data.get('port', 0) or 0)
        encryption = str(email_data.get('encryption', '') or '').lower()
        is_html = bool(email_data.get('isHTML', False))
        charset = email_data.get('charset', 'UTF-8')

        # Normalize recipients: list or comma-separated string
        if isinstance(recipients, list):
            recipients_list = recipients
            recipients_str = ', '.join(recipients)
        else:
            recipients_str = recipients
            recipients_list = [r.strip() for r in recipients.split(',') if r.strip()]

        # Create message container
        msg = MIMEMultipart()
        msg['From'] = sender
        msg['To'] = recipients_str
        msg['Subject'] = subject

        # Add custom headers
        for k, v in parse_headers(headers).items():
            # Avoid overriding From/To/Subject
            if k.lower() not in {'from', 'to', 'subject'}:
                msg[k] = v

        # Attach email body
        msg.attach(MIMEText(body, 'html' if is_html else 'plain', charset))

        # Attach files
        for attach_dict in attachments:
            if not isinstance(attach_dict, dict):
                continue
            file_path = attach_dict.get('path')
            filename = attach_dict.get('name', os.path.basename(file_path or ''))
            if file_path and os.path.isfile(file_path):
                with open(file_path, 'rb') as f:
                    part = MIMEBase('application', 'octet-stream')
                    part.set_payload(f.read())
                    encoders.encode_base64(part)
                    part.add_header('Content-Disposition', f'attachment; filename="{filename}"')
                    msg.attach(part)
            else:
                print(f"Attachment not found or invalid: {file_path}")

        # Establish SMTP connection
        try:
            if encryption == 'ssl' or port == 465:
                server = smtplib.SMTP_SSL(host, port)
            else:
                server = smtplib.SMTP(host, port)
                server.ehlo()
                if encryption in ('starttls', 'tls') or port == 587:
                    server.starttls()
                    server.ehlo()
            server.set_debuglevel(1)
        except Exception as e:
            print(f"Failed to connect to SMTP server: {e}")
            sys.exit(1)

        # Login if credentials provided
        if username and password:
            try:
                server.login(username, password)
            except smtplib.SMTPException as e:
                print(f"Login failed: {e}")
                server.quit()
                sys.exit(1)

        # Send email
        try:
            server.sendmail(sender, recipients_list, msg.as_string())
            print("Email sent successfully.")
        except smtplib.SMTPException as e:
            print(f"Failed to send email: {e}")
        finally:
            server.quit()

    except json.JSONDecodeError as e:
        print(f"Invalid JSON payload: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"Unexpected error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()