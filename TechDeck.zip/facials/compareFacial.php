
<?php
header('Content-Type: application/json; charset=utf-8');

// Helper: read JSON body if present
function getJsonBody(): ?array {
    $contentType = isset($_SERVER['CONTENT_TYPE']) ? trim($_SERVER['CONTENT_TYPE']) : '';
    // Some servers put content type in HTTP_CONTENT_TYPE
    if ($contentType === '' && isset($_SERVER['HTTP_CONTENT_TYPE'])) 
        $contentType = trim($_SERVER['HTTP_CONTENT_TYPE']);
    if (stripos($contentType, 'application/json') !== false) {
        $raw = file_get_contents('php://input');
        if ($raw !== false && $raw !== '') {
            $data = json_decode($raw, true);
            if (json_last_error() === JSON_ERROR_NONE) {
                return $data;
            }
        }
    }
    return null;
}

// 1) Try JSON body (POST with application/json)
$data = getJsonBody();

// 2) Fallback to POST form fields
if ($data === null && !empty($_POST)) {
    $data = $_POST;
}

// 3) Fallback to GET query params
if ($data === null && !empty($_GET)) {
    $data = $_GET;
}

// Validate input
if (!is_array($data) || !isset($data['username'])) {
    echo json_encode(['error' => 'Username is required']);
    exit;
}

// Sanitize username: allow only letters, numbers, underscore, hyphen
$username = preg_replace('/[^A-Za-z0-9_\-]/', '', (string)$data['username']);
if ($username === '') {
    echo json_encode(['error' => 'Invalid username']);
    exit;
}

$imageFile = "$username.png";

// Directory where images are stored (same folder as this script)
$directory = __DIR__; // change if your images live elsewhere, e.g., dirname(__DIR__) . '/facials'
$filePath  = "$directory/$imageFile";

if (file_exists($filePath)) {
    echo json_encode([$imageFile], JSON_UNESCAPED_SLASHES);
} else {
    echo json_encode(['error' => 'Image not found']);
}
