<?php
header("Content-Type: application/json; charset=utf-8");
use TechDeck\Security, TechDeck\Users;
include_once dirname(__DIR__)."/libs/security.lib.php";
include_once dirname(__DIR__)."/libs/config.lib.php";
include_once dirname(__DIR__)."/libs/users.lib.php";
$security = new Security();
$user = new Users();
$data = json_decode(file_get_contents('php://input'), true);
// Example data URL (replace this with your actual data URL)
$dataUrl = $data['image']; // truncated for example

// Specify the folder where you want to save the image
$folderPath = dirname(__DIR__).'/facials/';

// Generate a unique filename
$filename = "{$user->getUsername()}.png";
$filePath = "$folderPath$filename";

// Extract base64 data from the data URL
if (preg_match('/^data:image\/\w+;base64,/', $dataUrl)) {
    // Ensure proper padding
    $base64Data = preg_replace('/^data:image\/\w+;base64,/', '', $dataUrl);
    $base64Data = str_replace(' ', '+', $base64Data);
    $padding = strlen($base64Data) % 4;
    if ($padding > 0)
        $base64Data .= str_repeat('=', 4 - $padding);
    $imageData = base64_decode($base64Data);

    
    if (!$imageData) 
        die('Base64 decode failed.');
    
    
    // Save the decoded image data to a file
    file_put_contents($filePath, $imageData);
    echo json_encode(['success'=>true],JSON_UNESCAPED_SLASHES);
} else echo json_encode(['success'=>false],JSON_UNESCAPED_SLASHES);