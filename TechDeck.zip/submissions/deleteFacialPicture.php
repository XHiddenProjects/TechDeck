<?php
use TechDeck\Users;
header('Content-Type: application/json; charset=utf-8');
$p = dirname(__DIR__).'/libs';
foreach(array_diff(scandir($p),['.','..']) as $f) if(is_file("$p/$f")) include_once "$p/$f";
$users = new Users();
$path = dirname(__DIR__).DIRECTORY_SEPARATOR.'facials'.DIRECTORY_SEPARATOR.$users->getUsername().".png";
$msg = file_exists($path) ? ['success'=>@unlink($path)] : ['success'=>false];
echo json_encode($msg,JSON_UNESCAPED_SLASHES);