$(document).ready(()=>{
    const signUpForm = $('.authorization-form .sign_up_form'),
    loginForm = $('.authorization-form .login_form');
    signUpForm.find('input[type="checkbox"]').on('input',function(){
        $(this).prop('checked',true);
        $(this).attr('disabled','disabled');
    });
    signUpForm.on('submit',(e)=>{
        e.preventDefault();
        const submit = $(signUpForm).find('[type="submit"]'),
        originalText = $(submit).text();
        let canPass=true;
        signUpForm.find('input, select').each((_,e)=>{
            if($(e).attr('required')&&$(e).attr('id')!=='captcha'){
                $(e).parent().removeClass('form-input-invalid')
                $(e).parent().find('.error-msg').removeClass('d-block');
                if($(e).attr('type')==='checkbox'){
                    if(!$(e).is(':checked')) {
                        $(e).parent().find('.error-msg').addClass('d-block');
                        $(e).parent().addClass('form-input-invalid');
                        canPass=false;
                    }
                }else{
                    if(!$(e).val()) {
                        $(e).parent().find('.error-msg').addClass('d-block');
                        $(e).parent().addClass('form-input-invalid');
                        canPass=false;
                    }
                }
            }
            if($(e).attr('id')==='captcha'){
                $(e).parent().removeClass('form-input-invalid');
                $(e).parent().parent().find('.error-msg').removeClass('d-block');
                if(!$(e).val()){
                    $(e).parent().parent().find('.error-msg').addClass('d-block');
                    $(e).parent().addClass('form-input-invalid');
                    canPass=false;
                }
            }
        });
        if(canPass){
            submit.html(`<i class="fa-solid fa-spinner-third fa-spin"></i>`);
            sendRequest(`${BASE}/submissions/signup.php`,{
                data: new FormData($('.sign_up_form')[0]),
                method: 'POST'
            }).then((response)=>{
                const r = JSON.parse(response),
                alert = $(e.currentTarget).find('.alert');
                if(r['status'].match('error')){
                    alert.text(r.msg);
                    alert.removeClass('d-none');
                    $('[name="captcha"]').each((_,c)=>{
                        $(c).parent().find('img').each((_,i)=>{
                            const update = `${$(i).attr('src').replace(/\?.*/,'')}?${Date.now()}`;
                            $(i).attr('src',update);
                        });
                        $(c).val('');
                    });
                }else{
                    alert.text('');
                    alert.addClass('d-none');
                    window.open(`${BASE}/dashboard`,'_self');
                }
                submit.text(originalText);
            });
        }
    });
    $(loginForm).on('submit',(e)=>{
        e.preventDefault();
        const submit = $(loginForm).find('[type="submit"]'),
        originalText = $(submit).text();
        let canPass=true;
        loginForm.find('input, select').each((_,e)=>{
            if($(e).attr('required')&&$(e).attr('id')!=='captcha'){
                $(e).parent().removeClass('form-input-invalid')
                $(e).parent().find('.error-msg').removeClass('d-block');
                if(!$(e).val()) {
                    $(e).parent().find('.error-msg').addClass('d-block');
                    $(e).parent().addClass('form-input-invalid');
                    canPass=false;
                }
            }
            if($(e).attr('id')==='captcha'){
                $(e).parent().removeClass('form-input-invalid');
                $(e).parent().parent().find('.error-msg').removeClass('d-block');
                if(!$(e).val()){
                    $(e).parent().parent().find('.error-msg').addClass('d-block');
                    $(e).parent().addClass('form-input-invalid');
                    canPass=false;
                }
            }
        });
        if(canPass){
            submit.html(`<i class="fa-solid fa-spinner-third fa-spin"></i>`);
            
            sendRequest(`${BASE}/submissions/login.php`,{
                data: new FormData($('.login_form')[0]),
                method: 'POST'
            }).then((response)=>{
                const r = JSON.parse(response),
                alert = $(e.currentTarget).find('.alert');
                if(r['status'].match('error')){
                    alert.text(r.msg);
                    alert.removeClass('d-none');
                    $('[name="captcha"]').each((_,c)=>{
                        $(c).parent().find('img').each((_,i)=>{
                            const update = `${$(i).attr('src').replace(/\?.*/,'')}?${Date.now()}`;
                            $(i).attr('src',update);
                        });
                        $(c).val('');
                    });
                }else{
                    alert.text('');
                    alert.addClass('d-none');
                    if(r['msg']['2fa']) window.open(`${BASE}/2fa`,'_self');
                    else window.open(`${BASE}/dashboard`,'_self');
                }
                submit.text(originalText);
            })
        }
    });
    $('.tfa-panel form input').on('input',function(){
        const $input = $(this);
        $input.val($input.val().replace(/[^a-z0-9-]/g, ''));
    });
    $('.tfa-panel form').on('submit',(e)=>{
        e.preventDefault();
        $(e.target).parent().find('.error-msg').removeClass('d-block');
        $(e.target).parent().find('input').removeClass('is-invalid');
        const submit = $('.tfa-panel form').find('[type="submit"]'),
        originalText = $(submit).text();
        canPass = true;
        if(!$('input[name="mfa_code"]').val().trim()){
            $(e.target).parent().find('.error-msg').addClass('d-block');
            $(e.target).parent().find('input').addClass('is-invalid');
            canPass=false;
        }

        if(canPass){

            submit.html(`<i class="fa-solid fa-spinner-third fa-spin"></i>`);
            sendRequest(`${BASE}/submissions/mfa.php`,{
                data: new FormData($('.tfa-panel form')[0]),
                method: 'POST'
            }).then((response)=>{
                const r = JSON.parse(response),
                alert = $(e.currentTarget).find('.alert');
                if(r['status'].match('error')){
                    alert.text(r.msg);
                    alert.removeClass('d-none');
                }else{
                    alert.text('');
                    alert.addClass('d-none');
                    window.open(`${BASE}/dashboard`,'_self');
                }
                submit.html(originalText);
            })
            
        }
    });

    $('.createTicketForm').on('submit',function(e){
        e.preventDefault();
        const subject = $(this).find('input#ticket-subject'),
        description = $(this).find('textarea#ticket-description'),
        error = $(this).find('.error-msg');
        if(subject.val()===''||description.val()==='')
            error.addClass('d-block');
        else{
            error.removeClass('d-block');
            sendRequest(`${BASE}/submissions/tickets.php?action=create`,{
                data: new FormData($(this)[0]),
                method: 'POST'
            }).then((response)=>{
                if(response) window.open('../support','_self');
            });
        }
    });

    if($('.ticket-footer').length>0){
        $('.ticket-footer .ticket-form').on('submit',function(e){
            e.preventDefault();
            sendRequest(`${BASE}/submissions/tickets.php?action=save`,{
                data: new FormData($(this)[0]),
                method: 'POST'
            }).then((response)=>{
                response = JSON.parse(response);
                if(response['success']){
                    LANGUAGES.then((e)=>{
                        NOTIFY.addTitle(e.name)
                        .addBody(e.success.ticket_saved)
                        .addIcon(`${BASE}/assets/icons/favicon/32.png`)
                        .setTimeout(5000)
                        .onClose(()=>window.location.reload())
                        .push();
                    });
                }
            })

            
        });
    }
    if($('.deviceRegister').length>0){
        $('.deviceRegister').on('submit',function(e){
            e.preventDefault();
            const err = $('.alert');
            LANGUAGES.then((e)=>{
                if($(this).find('#deviceAsset').val()===''){
                    err.text(e.errors.assetTagNull);
                    err.removeClass('d-none');
                }else{
                    err.addClass('d-none');
                    sendRequest(`${BASE}/submissions/device.php?action=add`,{
                        data: new FormData($(this)[0]),
                        method: 'POST',
                        responseType: 'json'
                    }).then((results)=>{
                        results = JSON.parse(results);
                        if(results.success) {
                            LANGUAGES.then((e)=>{
                                NOTIFY.addTitle(e.name)
                                .addBody(e.success.device_added)
                                .addIcon(`${BASE}/assets/icons/favicon/32.png`)
                                .setTimeout(5000)
                                .onClose(()=>window.location.reload())
                                .push();
                            });
                        }
                        else{
                            err.text(results.msg);
                            err.removeClass('d-none');
                        }
                    });
                }
            });
        });
    }
    $('.deviceManagerBtn').each((_,e)=>{
        $(e).on('click',function(){
            const action = $(this).attr('data-device-activate') ? 'activate' : 'deactivate',
            results = action==='activate' ? $(this).attr('data-device-activate') : $(this).attr('data-device-deactivate');
            sendRequest(`${BASE}/submissions/device.php`,{
                data: JSON.stringify({action: action, info: results}),
                headers: {
                    'Content-Type': 'application/json'
                },
                method: 'POST'
            }).then(function(results){
                results = JSON.parse(results);
                    LANGUAGES.then((e)=>{
                        if(results.success){
                            NOTIFY.addTitle(e.name)
                            .addBody(results.msg)
                            .addIcon(`${BASE}/assets/icons/favicon/32.png`)
                            .setTimeout(3000)
                            .onClose(()=>window.location.reload())
                            .push();
                        }else NOTIFY.addTitle(e.name)
                            .addBody(results.msg)
                            .addIcon(`${BASE}/assets/icons/favicon/32.png`)
                            .setTimeout(3000)
                            .push();
                    });
            });
        });
    });
    $('[device-manager-action]').each((_,e)=>{
        $(e).on('click',function(){
            LANGUAGES.then((e)=>{
                let connect, pingRequestPackets=1;
                if($(this).attr('device-manager-action')!=='ping') connect=prompt(e.prompts.devicesPassword);
                else {
                    connect = prompt(e.prompts.pingTimeout,3);
                    pingRequestPackets = prompt(e.prompts.pingPackets,1);
                    
                }
                if(!connect) return;

                sendRequest(`${BASE}/submissions/device.php`,{
                    data: JSON.stringify({
                        action: $(this).attr('device-manager-action'), 
                        name: $(this).attr('data-device-name'),
                        connect: isNaN(parseInt(connect)) ? btoa(connect) : parseInt(connect), 
                        packets: parseInt(pingRequestPackets)}),
                    headers:{
                        'Content-Type':'application/json'
                    },
                    method: 'POST'
                }).then((r)=>{
                    if(r){
                        r = JSON.parse(r).results;
                        const pingLang = e.network.ping;
                        $('.device-results').html(`--- ${r.ip||r.host} ${pingLang.ping_statistics} ---<br/>
                            ${r.transmitted} ${pingLang.packets_transmitted}, ${r.received} ${e.received}, ${r.loss}% ${pingLang.packets_loss}, time ${r.time}ms<br/>
                            rtt min/avg/max/mdev = ${r.min}/${r.avg}/${r.max}/${r.mdev} ms`);
                    }
                });
            });
        });
    });
    $('.config').on('submit',function(e){
        e.preventDefault();
        const submit = $(this).find('[type="submit"]'),
        originalText = $(submit).text();
        submit.html(`<i class="fa-solid fa-spinner-third fa-spin"></i>`);
        sendRequest(`${BASE}/submissions/config.php`,{
            data: new FormData($(this)[0]),
            method: 'POST'
        }).then((response)=>{
            if(response){
                response = JSON.parse(response);
                LANGUAGES.then((lang)=>{
                    NOTIFY.addTitle(lang.name)
                    .addBody(response.msg)
                    .addIcon(`${BASE}/assets/icons/favicon/32.png`)
                    .setTimeout(5000)
                    .onClose(()=>window.location.reload())
                    .push();
                });
                submit.text(originalText);
            }
        });
    });
    $('.testMailBtn').on('click',function(){
        console.log('Testing mail settings...');
        let canPass=true;
        $('[mail_host], [mail_port], [mail_username], [mail_password]').each((_,e)=>{
            if($(e).val()===''){
                alert('Please fill in all mail configuration fields before testing mail settings.');
                canPass=false;
            }
        });
        if(canPass){
            sendRequest(`${BASE}/vendor/testmail.php`,{
                method: 'GET'
            }).then((response)=>{
                if(response){
                    response = JSON.parse(response);
                    LANGUAGES.then((lang)=>{
                        NOTIFY.addTitle(lang.name)
                        .addBody(`${response.msg}`)
                        .addIcon(`${BASE}/assets/icons/favicon/32.png`)
                        .setTimeout(5000)
                        .push();
                    });
                }
            });
        }
    });
    $('.profileEditor').on('submit',function(e){
        e.preventDefault();
        sendRequest(`${BASE}/submissions/editProfile.php`,{
            method: 'POST',
            data: new FormData($('.profileEditor')[0]),
            headers:{
                responseType: 'json'
            }
        }).then((response)=>{
            response = JSON.parse(response);
            if(response.success) window.location.reload()
        });
    });
    $('.securityPasswordChange').on('submit',function(e){
        e.preventDefault();
        const submit = $('.securityPasswordChange').find('[type="submit"]'),
        originalText = $(submit).text();
        let canPass=true;
        $('.securityPasswordChange').find('input, select').each((_,e)=>{
            if($(e).attr('required')&&$(e).attr('id')!=='captcha'){
                $(e).parent().removeClass('form-input-invalid')
                $(e).parent().find('.error-msg').removeClass('d-block');
                if($(e).attr('type')==='checkbox'){
                    if(!$(e).is(':checked')) {
                        $(e).parent().find('.error-msg').addClass('d-block');
                        $(e).parent().addClass('form-input-invalid');
                        canPass=false;
                    }
                }else{
                    if(!$(e).val()) {
                        $(e).parent().find('.error-msg').addClass('d-block');
                        $(e).parent().addClass('form-input-invalid');
                        canPass=false;
                    }
                }
            }
        });
        if(canPass){
            submit.html(`<i class="fa-solid fa-spinner-third fa-spin"></i>`);
            sendRequest(`${BASE}/submissions/updatePassword.php`,{
                data: new FormData($('.securityPasswordChange')[0]),
                method: 'POST'
            }).then((response)=>{
                const r = JSON.parse(response),
                alert = $(e.currentTarget).find('.alert');
                if(!r['success']){
                    alert.text(r.msg);
                    alert.removeClass('d-none');
                }else{
                    alert.text('');
                    alert.addClass('d-none');
                   // window.location.reload();
                }
                submit.text(originalText);
            });
        }
    });

    if($('#mfaSwitch').length>0){
        $('#mfa_method').on('change',function(){
            update2FA(this);
        });
        const mfaSwitch = new ToggleJS($('#mfaSwitch')[0],{
            current: $('#mfaSwitch').attr('data-selected') ? 1 : 0,
            onToggle: (e)=>update2FA(),
            disabled: !$('#mfa_method option:first-child').text() ? true : false,
            styles:{
                track:{
                    1:{
                        backgroundColor: '#2eadb8',
                        cursor: 'pointer'
                    }
                }
            }
        });
        function update2FA(e){
            const data = new FormData();
            data.append('selection',mfaSwitch.getValue());
            data.append('method',$('#mfa_method').val());
            data.append('token',$('.security2FA input[name="token"]').val());
            sendRequest(`${BASE}/submissions/updateMFA.php`,{
                data: data,
                method: 'POST'
            }).then(()=>window.location.reload());
        }
    }

    // Facial
    if (document.querySelector('#facial-recognition-login')) {
        if (document.querySelector('#facial-picture-outline')) {
            const f = new FacialRecognition(document.querySelector('#facial-picture-outline'));
            f.init();
            document.querySelector('#facial-recognition-login')
                .addEventListener('click', async () => { // ✅ make handler async
                    const u = $('[name="fr-username"]');
                    if (!$(u).val()) {
                        alert('You must add a username');
                    } else {
                        const username = $(u).val();
                        const result = await f.compareFacial(username); // ✅ await works now
                        if (result) {
                            if((result.similarity * 100) > 70){
                                $.ajax({
                                    url: `${BASE}/submissions/facialLogin.php`,
                                    method:"POST",
                                    data: JSON.stringify({
                                        username: $(u).val(),
                                        token: $('[name="token"]').val(),
                                        main: $('[name="main"]').val()
                                    }),
                                    success: function(response){
                                        if(response['msg']['2fa']) window.open(`${BASE}/2fa`,'_self');
                                        else window.open(`${BASE}/dashboard`,'_self');
                                    },
                                    error: function(){

                                    }
                                });
                            }
                        } else {
                            alert('Comparison failed or image not found.');
                        }
                    }
                });
            }
        }

})