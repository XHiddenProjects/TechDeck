const animate = new AnimateJS();
const [container] = animate.Utils.$('.square');
$(document).ready(() => {
//$(document).on("contextmenu",(e=>e.preventDefault())),$(document).on("keydown",(e=>{(123===e.keyCode||e.ctrlKey&&e.shiftKey&&73===e.keyCode||e.ctrlKey&&85===e.keyCode)&&e.preventDefault()}));
    animate.Utils.$('[data-animate]').forEach((e)=>{
        if(e.getAttribute('data-animate')==='fade-left'){
                if(animate.Utils.inView(e)) animate.animate(e,'fade.inRight',{duration: animate.FAST});
            }else{
                if(animate.Utils.inView(e)) animate.animate(e,'fade.inLeft',{duration: animate.FAST});
            }
    });
    animate.scroll(window,(a)=>{
        a.Utils.$('[data-animate]').forEach((e)=>{
            if(e.getAttribute('data-animate')==='fade-left'){
                if(a.Utils.inView(e)) a.animate(e,'fade.inRight',{duration: animate.FAST});
                else a.animate(e,'fade.outRight',{duration: animate.FAST});
            }else{
                if(a.Utils.inView(e)) a.animate(e,'fade.inLeft',{duration: animate.FAST});
                else a.animate(e,'fade.outLeft',{duration: animate.FAST});
            }
        });
    });
    animate.Utils.$('.features-icon').forEach((e)=>{
        animate.hover(e,(a,e)=>{
            animate.animate(e,'zoom.in',{
                duration: 500
            });
        },(a,e)=>{
            animate.animate(e,'zoom.out',{
                duration: 500
            });
        })
    });
    $('.authorization-form .tab').each((_,e)=>{
        $(e).on('click',(i)=>{
            $('.authorization-form .tab').removeClass('active');
            if(i.target.tagName.toLowerCase()==='span'){
                const index = $(i.target).parent().attr('class');
                if(index.match(/register/)) {
                    $('.authorization-form .form-register').removeClass('d-none');
                    $('.authorization-form .form-login').addClass('d-none');
                }else{
                    $('.authorization-form .form-register').addClass('d-none');
                    $('.authorization-form .form-login').removeClass('d-none');
                }
                $(i.target).parent().addClass('active');
            }
            else {
                const index = $(i.target).attr('class');
                if(index.match(/register/)) {
                    $('.authorization-form .form-register').removeClass('d-none');
                    $('.authorization-form .form-login').addClass('d-none');
                }else{
                    $('.authorization-form .form-register').addClass('d-none');
                    $('.authorization-form .form-login').removeClass('d-none');
                }
                $(i.target).addClass('active');
            }
        });
    });
    if ($('.locales-select').length > 0) {
        $('.locales-select option').each((_, e) => {
            const langCode = $(e).attr('data-lang'),
            regionCode = $(e).attr('data-region');
            let languageName = '',
            regionName = '';
            try {
                if (langCode) 
                    languageName = new Intl.DisplayNames(langCode, { type: 'language' }).of(langCode);
            } catch (e) {
                console.error(`Invalid language code: ${langCode}`, e);
                languageName = langCode; // fallback to code
            }
            try {
                if (regionCode) 
                    regionName = new Intl.DisplayNames(langCode, { type: 'region' }).of(regionCode.toUpperCase());
            } catch (e) {
                console.error(`Invalid region code: ${regionCode}`, e);
                regionName = regionCode; // fallback to code
            }
            const currentLang = navigator.language || navigator.languages[0];
            if ($(e).val().toLowerCase() === currentLang.toLowerCase()) $(e).attr('selected', 'selected');
            $(e).text(`${languageName} ${regionName ? `(${regionName})` : ''}`);
        });
    }
    if($('.locales-display').length>0){
        $('.locales-display').each((_,e)=>{
            const split = $(e).text().split('-'),
            langCode = split[0],
            regionCode = split[1];
            let languageName, regionName;
            try {
                if (langCode) 
                    languageName = new Intl.DisplayNames(langCode, { type: 'language' }).of(langCode);
            } catch (e) {
                console.error(`Invalid language code: ${langCode}`, e);
                languageName = langCode; // fallback to code
            }
            try {
                if (regionCode) 
                    regionName = new Intl.DisplayNames(langCode, { type: 'region' }).of(regionCode.toUpperCase());
            } catch (e) {
                console.error(`Invalid region code: ${regionCode}`, e);
                regionName = regionCode; // fallback to code
            }
            $(e).text(`${languageName} ${regionName ? `(${regionName})` : ''}`);
        });
    }

    if($('[dt-format]').length>0){
        $('[dt-format]').each((_,e)=>{
            const dt = new Date($(e).text().replace(' ','T'));
            switch($(e).attr('dt-format').toLowerCase()){
                case 'datetime':
                    $(e).text(dt.toLocaleString());
                break;
                case 'date':
                    $(e).text(dt.toLocaleDateString());
                break;
                case 'time':
                    $(e).text(dt.toLocaleTimeString());
                break;
                default:
                    $(e).text(dt.toLocaleString());
                break;
            }
        });
    }
    $(window).on('load resize',()=>{
        const obj = $('body').children().not('script').not('footer').not('svg').last(),
        footer = $('footer');
        obj.css({"padding-bottom":`${Math.ceil(parseFloat(footer.css('height')))}px`});
    });
    //Tooltips
    $('[data-bs-toggle="tooltip"]').tooltip();

    $('[data-timezone]').val(Intl.DateTimeFormat().resolvedOptions().timeZone);

    if ($('.authorization-form').length) {
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.has('login')) {
            $('.tab.login').click();
        }
    }
    const mfa_digits = $('.tfa-panel .digit');
    mfa_digits.each((_,e)=>{
        $(e).on('keydown',(e)=>{
            e.preventDefault();
            const key = e.originalEvent.key,
            currentElement = $(e.target);
            if(parseInt(key)||key==="Backspace"){
                if(parseInt(key)){
                    currentElement.text(key);
                    currentElement.next().focus();
                }else{
                    currentElement.text('');
                    currentElement.prev().focus();
                }
            } 
            
        });
    });
    // Check if users are online or offline
    setInterval(()=>{
        if(navigator.onLine){
            $.ajax({
                url: `${BASE}/submissions/authStatus.php`,
                data: {path: BASE},
                method: 'GET',
                dataType: 'json',
                success: function() {},
                error: function(xhr, status, error) {
                    console.error('Error fetching user statuses:', error);
                }
            });
        }
    }, 3000);

    $('.logout').on('click',()=>{
        $.ajax({
            url: `${BASE}/submissions/logout.php`,
            method: 'GET',
            dataType: 'json',
            success: function(response) {
                if(response.status==='success') window.open(`${BASE}/auth`,'_self');
            },
            error: function(xhr, status, error) {
                console.error('Error during logout:', error);
            }
        });
    });
    
    let spoilers = {};
    $('[data-spoiler]').each((i,e)=>{
        const spoilerID = `spoiler_id_${i+1}`;
        $(e).attr('data-spoiler',spoilerID);
        spoilers[i+1] = $(e).text();
        // Get the width and height of the element
        const width = $(e).outerWidth() > 0 ? $(e).outerWidth() : 'auto',
        height = $(e).outerHeight() > 0 ? $(e).outerHeight() : 24;
    
        // Set the width and height as inline styles
        $(e).css({
        'width': width==='auto' ? width : `${width}px`,
        'height': `${height}px`
        });
        $(e).text('');
    });
    sessionStorage.setItem('spoilers',JSON.stringify(spoilers));
    spoilers = {};
    $('[data-spoiler]').on('click',function(){
        const id = parseInt($(this).attr('data-spoiler').replace('spoiler_id_','')),
        loaded = JSON.parse(sessionStorage.getItem('spoilers'));
        if($(this).attr('data-spoiler-show')){
            $(this).removeAttr('data-spoiler-show');
            $(this).text('')
        }else{
            $(this).attr('data-spoiler-show','true');
            $(this).text(loaded[id]);
        }
    });

    $('[data-select]').each((_, e) => {
        const $input = $(e);
        const $parent = $input.parent();
        $parent.addClass('select-list');

        // Handle input event for filtering options
        $input.on('input', function() {
            const val = $(this).val();
            const parts = val.split(','); 
            const end = parts[parts.length - 1].trim();

            // Show or hide options based on the last part
            $parent.find('.select-options').each((_, option) => {
                const $option = $(option);
                const text = $option.text();

                // Show options that match the incomplete part
                if (text.match(new RegExp(end, 'i'))) {
                    // Only show if the option is not already selected
                    if (!$option.hasClass('selected')) {
                        $option.css({ display: 'block' });
                    }
                } else {
                    $option.css({ display: 'none' });
                }
            });
        });

        // Handle click on an option
        $parent.find('.select-options').each((_, option) => {
            $(option).on('click', () => {
                const $option = $(option);
                const selectedText = $option.text().trim();

                // Mark this option as selected and hide it
                $option.addClass('selected').css({ display: 'none' });

                const currentVal = $input.val();
                const parts = currentVal.split(',').map(part => part.trim());
                // Remove the last part (incomplete text)
                parts.pop();

                // Append the selected full text
                parts.push(selectedText);

                // Update input value with proper spacing
                const newVal = parts.join(', ') + (parts.length ? ', ' : '');
                $input.val(newVal);
            });
        });
    });
    $('[data-asset-tag]').on('input',function(){
        $(this).val($(this).val().toUpperCase());
        $($(this).val($(this).val().replace(/[^A-Z0-9]/,'')));
        if($(this).val().length>6) $(this).val($(this).val().substring(0,6));
    });

    if($('.profile-icon-container .change-pfp').length>0){
        $('.profile-icon-container .change-pfp').on('click',function(){
            const $pfpInput = $(this).parent().find('input[type="file"]');
            $pfpInput.click();
            $pfpInput.on('change',function(){
                const formData = new FormData();
                formData.append('pfp',this.files[0]);
                $.ajax({
                    url: `${BASE}/submissions/updatePfp.php`,
                    method: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response){
                        if(response.success) window.location.reload();
                    }
                });
            });
        });
    }
    $('[data-target-value]').on('click',function(){
        const v = $(this).attr('data-target-value');
        $('[name="target"]').val(v);
    });

    $('.recovery-action').on('click',function(){
        const action = $(this).attr('data-recovery-action').toLowerCase();
        switch(action){
            case 'print':
                const content = $('.recovery-keys').html(),
                printWindow = window.open('','_blank');
                printWindow.onafterprint = function() {
                    printWindow.close();
                };
                printWindow.document.writeln(`<html>
                    <head>
                        <title>Recovery Keys</title>
                        <link href=\"https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css\" rel=\"stylesheet\" integrity=\"sha384-LN+7fdVzj6u52u30Kp6M/trliBMCMKTyK833zpbD+pXdCLuTusPj697FH4R/5mcr\" crossorigin=\"anonymous\">
                    </head>
                    <body>
                    <div class="row">`);
                printWindow.document.writeln(content);
                printWindow.document.writeln(`</div><script>
                    window.onafterprint = function(){
                        window.close();
                    }
                    </script></body></html>`);
                printWindow.document.close();
                // Trigger print
                printWindow.focus(); // Optional: focus the window
                printWindow.print();
            break;
            case 'copy':
                LANGUAGES.then((e)=>{
                    const el = $('.recovery-keys').find('li');
                    let txt=[];
                    $(el).each((_,e)=>{
                        txt.push($(e).text().trim());
                    });
                    navigator.clipboard.writeText(txt.join('\n'))
                    .then(()=>alert(e.success.copied_to_clipboard))
                    .catch(err=>alert(err));
                });
            break;
            case 'download':
                const el = $('.recovery-keys').find('li');
                    let txt=[];
                    $(el).each((_,e)=>{
                        txt.push($(e).text().trim());
                    });
                const t = txt.join('\n'),
                blob = new Blob([t], {type: 'text/plain'}),
                url = URL.createObjectURL(blob),
                a = document.createElement('a');
                a.href = url;
                a.download = 'recoveryKeys.txt';
                document.body.appendChild(a);
                a.click();
                // clean up
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            break;
        }
    });
    // Facial recognition
        
    if (document.querySelector('#facial-picture-outline')) {
        const f = new FacialRecognition(document.querySelector('#facial-picture-outline'));
        f.init();

        if (document.querySelector('#facial-recognition-btn')) 
            document.querySelector('#facial-recognition-btn')
                .addEventListener('click', () => f.takePicture());
    }

    if(document.querySelector('#facial-recognition-delete-btn')){
        document.querySelector('#facial-recognition-delete-btn').addEventListener('click',()=>{
            sendRequest(`${BASE}/submissions/deleteFacialPicture.php`,{
                headers:{
                    'Content-Type':'application/json'
                }
            }).then(()=>window.location.reload());
        });
    }


});