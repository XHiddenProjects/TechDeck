//AI.js
/* =========================================================================================
 * CNN: Compares images/videos and computes a similarity score.
 * Features:
 *  - Supports Image/Canvas/ImageBitmap, Blob/File/ArrayBuffer, and URL(string) sources.
 *  - Video comparison by sampling frames across duration.
 *  - Computes metrics: MSE, PSNR, SSIM, Histogram Intersection, pHash.
 *  - Returns a weighted aggregate similarity in [0..1] + per-metric details.
 * =======================================================================================*/
const CNN = class {
  /**
   * @param {Object} [options]
   * @param {number} [options.targetSize=256] - Square target dimension (px) for analysis.
   * @param {'contain'|'cover'} [options.resizeMode='contain'] - Canvas fitting strategy.
   * @param {boolean} [options.grayscale=true] - Convert to grayscale before metrics.
   * @param {Object} [options.weights] - Metric weights; keys: mse, psnr, ssim, hist, phash.
   * @param {number} [options.videoFrameSamples=12] - Number of frames to sample when comparing videos.
   * @param {number} [options.maxPSNR=60] - Upper bound to normalize PSNR (dB) into [0..1].
   */
  constructor(options = {}) {
    this.targetSize = options.targetSize ?? 256;
    this.resizeMode = options.resizeMode ?? 'contain';
    this.grayscale = options.grayscale ?? true;
    this.videoFrameSamples = options.videoFrameSamples ?? 12;
    this.maxPSNR = options.maxPSNR ?? 60;
    this.weights = Object.assign(
      { mse: 1, psnr: 1, ssim: 2, hist: 1, phash: 2 },
      options.weights ?? {}
    );
    // Reusable offscreen canvas
    this._canvas = document.createElement('canvas');
    this._ctx = this._canvas.getContext('2d', { willReadFrequently: true });
  }

  /** Top-level compare function. Detects image vs video and routes accordingly. */
  async compare(a, b) {
    const aKind = await this._detectKind(a);
    const bKind = await this._detectKind(b);
    if (aKind !== bKind) {
      // If kinds differ (e.g., image vs video), try to compare first video frames to the image.
      // Practical fallback rather than hard failing.
      if (aKind === 'video' && bKind === 'image') {
        return this._compareVideoToImage(a, b);
      } else if (aKind === 'image' && bKind === 'video') {
        const res = await this._compareVideoToImage(b, a);
        return res; // swap perspective
      }
      throw new Error('Unsupported: sources are of different kinds and no fallback applied');
    }
    return aKind === 'video'
      ? this._compareVideos(a, b)
      : this._compareImages(a, b);
  }

  /* --------------------------- Loading Helpers --------------------------- */
  async _detectKind(src) {
    const el = await this._materializeSource(src);
    if (el instanceof HTMLVideoElement) return 'video';
    return 'image';
  }

  async _materializeSource(src) {
    // Already an element?
    if (
      (src instanceof HTMLImageElement) ||
      (src instanceof HTMLCanvasElement) ||
      (typeof ImageBitmap !== 'undefined' && src instanceof ImageBitmap)
    ) {
      return src;
    }
    if (src instanceof HTMLVideoElement) return src;

    // Blob/File/ArrayBuffer/URL string
    if (src instanceof Blob) {
      if (src.type.startsWith('video/')) return await this._loadVideoFromBlob(src);
      return await this._loadImageFromBlob(src);
    }
    if (src instanceof ArrayBuffer) {
      const blob = new Blob([src]);
      return await this._materializeSource(blob);
    }
    if (typeof src === 'string') {
      // Heuristic by extension; attempt video by common extensions else image
      const lower = src.toLowerCase();
      if (lower.match(/\.(mp4|webm|ogg|mov)$/)) {
        return await this._loadVideoFromURL(src);
      }
      return await this._loadImageFromURL(src);
    }
    throw new Error('Unsupported source type');
  }

  async _loadImageFromURL(url) {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.decoding = 'async';
    img.src = url;
    await img.decode().catch(() => new Promise((res, rej) => {
      img.onload = () => res();
      img.onerror = (e) => rej(e);
    }));
    return img;
  }

  async _loadImageFromBlob(blob) {
    const url = URL.createObjectURL(blob);
    try {
      const img = await this._loadImageFromURL(url);
      return img;
    } finally {
      URL.revokeObjectURL(url);
    }
  }

  async _loadVideoFromURL(url) {
    const video = document.createElement('video');
    video.crossOrigin = 'anonymous';
    video.src = url;
    video.muted = true; // allows autoplay seeking on some browsers
    await this._awaitVideoReady(video);
    return video;
  }

  async _loadVideoFromBlob(blob) {
    const url = URL.createObjectURL(blob);
    try {
      const video = await this._loadVideoFromURL(url);
      return video;
    } finally {
      URL.revokeObjectURL(url);
    }
  }

  _awaitVideoReady(video) {
    return new Promise((resolve, reject) => {
      const onReady = () => { cleanup(); resolve(); };
      const onError = (e) => { cleanup(); reject(e); };
      const cleanup = () => {
        video.removeEventListener('loadeddata', onReady);
        video.removeEventListener('error', onError);
      };
      if (video.readyState >= 2) return resolve();
      video.addEventListener('loadeddata', onReady);
      video.addEventListener('error', onError);
    });
  }

  /* ----------------------------- Canvas/Resize --------------------------- */
  _drawToCanvas(source) {
    // Determine intrinsic size
    let sw, sh;
    if ((source instanceof HTMLImageElement) || (source instanceof HTMLVideoElement)) {
      sw = source.videoWidth || source.naturalWidth || source.width;
      sh = source.videoHeight || source.naturalHeight || source.height;
    } else if (source instanceof HTMLCanvasElement) {
      sw = source.width; sh = source.height;
    } else if (typeof ImageBitmap !== 'undefined' && source instanceof ImageBitmap) {
      sw = source.width; sh = source.height;
    } else {
      throw new Error('Unsupported source for canvas draw');
    }

    // Target canvas size
    const tw = this.targetSize, th = this.targetSize;
    this._canvas.width = tw;
    this._canvas.height = th;

    // Compute fit rect
    const srcAspect = sw / sh;
    const dstAspect = tw / th;
    let dw, dh;
    if (this.resizeMode === 'cover'
        ? (srcAspect < dstAspect)
        : (srcAspect > dstAspect)) {
      // match width
      dw = tw;
      dh = tw / srcAspect;
    } else {
      // match height
      dh = th;
      dw = th * srcAspect;
    }
    const dx = (tw - dw) / 2;
    const dy = (th - dh) / 2;

    // Clear & draw
    this._ctx.clearRect(0, 0, tw, th);
    this._ctx.drawImage(source, dx, dy, dw, dh);
    return this._ctx.getImageData(0, 0, tw, th);
  }

  _toGrayscale(imageData) {
    const { data, width, height } = imageData;
    const gray = new Float32Array(width * height);
    for (let i = 0, p = 0; i < data.length; i += 4, p++) {
      const r = data[i], g = data[i + 1], b = data[i + 2];
      // Rec. 709 luminance
      gray[p] = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    }
    return { gray, width, height };
  }

  // --- Helpers to support optional grayscale ---
  _ensureGrayOrColor(imageData) {
    // If grayscale option is on, produce gray; else return color view + on-demand gray builder
    if (this.grayscale) {
      const g = this._toGrayscale(imageData);
      return { mode: 'gray', gray: g.gray, width: g.width, height: g.height, imageData };
    }
    // Provide a facade for color access and a lazy luminance builder when needed
    const { data, width, height } = imageData;
    const getLuminance = () => {
      const gray = new Float32Array(width * height);
      for (let i = 0, p = 0; i < data.length; i += 4, p++) {
        const r = data[i], g = data[i + 1], b = data[i + 2];
        gray[p] = 0.2126 * r + 0.7152 * g + 0.0722 * b;
      }
      return gray;
    };
    return { mode: 'color', imageData, width, height, getLuminance };
  }

  /* ------------------------------- Metrics ------------------------------- */
  _mse(grayA, grayB) {
    let mse = 0;
    for (let i = 0; i < grayA.length; i++) {
      const d = grayA[i] - grayB[i];
      mse += d * d;
    }
    mse /= grayA.length;
    // Normalize to [0..1] by max possible (255^2)
    const nmse = mse / (255 * 255);
    return { mse, nmse, similarity: Math.max(0, 1 - nmse) };
  }

  // --- Color-aware MSE over RGB channels (average of per-channel MSEs) ---
  _mseColor(imageDataA, imageDataB) {
    const a = imageDataA.data, b = imageDataB.data;
    let mseR = 0, mseG = 0, mseB = 0, pixels = a.length / 4;
    for (let i = 0; i < a.length; i += 4) {
      const dR = a[i]   - b[i];
      const dG = a[i+1] - b[i+1];
      const dB = a[i+2] - b[i+2];
      mseR += dR * dR;
      mseG += dG * dG;
      mseB += dB * dB;
    }
    mseR /= pixels; mseG /= pixels; mseB /= pixels;
    const mse = (mseR + mseG + mseB) / 3;
    const nmse = mse / (255 * 255);
    return { mse, nmse, similarity: Math.max(0, 1 - nmse) };
  }

  _psnr(mse) {
    if (mse === 0) return { psnr: this.maxPSNR, similarity: 1 };
    const psnr = 10 * Math.log10((255 * 255) / mse);
    const similarity = Math.max(0, Math.min(1, psnr / this.maxPSNR));
    return { psnr, similarity };
  }

  _stats(gray) {
    let mean = 0;
    for (let i = 0; i < gray.length; i++) mean += gray[i];
    mean /= gray.length;

    let varSum = 0;
    for (let i = 0; i < gray.length; i++) {
      const d = gray[i] - mean;
      varSum += d * d;
    }
    const variance = varSum / gray.length;
    return { mean, variance };
  }

  _cov(grayA, meanA, grayB, meanB) {
    let cov = 0;
    for (let i = 0; i < grayA.length; i++) {
      cov += (grayA[i] - meanA) * (grayB[i] - meanB);
    }
    return cov / grayA.length;
  }

  _ssim(grayA, grayB) {
    // Global SSIM approximation
    const { mean: muX, variance: sigmaX2 } = this._stats(grayA);
    const { mean: muY, variance: sigmaY2 } = this._stats(grayB);
    const sigmaXY = this._cov(grayA, muX, grayB, muY);
    const L = 255;
    const k1 = 0.01, k2 = 0.03;
    const C1 = (k1 * L) ** 2;
    const C2 = (k2 * L) ** 2;
    const numerator = (2 * muX * muY + C1) * (2 * sigmaXY + C2);
    const denominator = (muX*muX + muY*muY + C1) * (sigmaX2 + sigmaY2 + C2);
    let ssim = numerator / denominator;
    // Bound to [0..1]
    ssim = Math.max(0, Math.min(1, ssim));
    return { ssim, similarity: ssim };
  }

  // --- Color-aware SSIM: compute per-channel SSIM and average ---
  _statsColorChannel(imageData, channelIndex) {
    const d = imageData.data;
    let mean = 0;
    const pixels = d.length / 4;
    for (let i = channelIndex; i < d.length; i += 4) mean += d[i];
    mean /= pixels;

    let varSum = 0;
    for (let i = channelIndex; i < d.length; i += 4) {
      const diff = d[i] - mean;
      varSum += diff * diff;
    }
    const variance = varSum / pixels;
    return { mean, variance };
  }

  _covColorChannel(imgA, meanA, imgB, meanB, channelIndex) {
    const a = imgA.data, b = imgB.data;
    let cov = 0, pixels = a.length / 4;
    for (let i = channelIndex; i < a.length; i += 4) {
      cov += (a[i] - meanA) * (b[i] - meanB);
    }
    return cov / pixels;
  }

  _ssimColor(imageDataA, imageDataB) {
    const L = 255, k1 = 0.01, k2 = 0.03;
    const C1 = (k1 * L) ** 2;
    const C2 = (k2 * L) ** 2;

    const ssimForChannel = (ch) => {
      const { mean: muX, variance: sigmaX2 } = this._statsColorChannel(imageDataA, ch);
      const { mean: muY, variance: sigmaY2 } = this._statsColorChannel(imageDataB, ch);
      const sigmaXY = this._covColorChannel(imageDataA, muX, imageDataB, muY, ch);
      const numerator = (2 * muX * muY + C1) * (2 * sigmaXY + C2);
      const denominator = (muX*muX + muY*muY + C1) * (sigmaX2 + sigmaY2 + C2);
      const v = numerator / denominator;
      return Math.max(0, Math.min(1, v));
    };

    const sR = ssimForChannel(0);
    const sG = ssimForChannel(1);
    const sB = ssimForChannel(2);
    const ssim = (sR + sG + sB) / 3;
    return { ssim, similarity: ssim };
  }

  _histIntersection(imageDataA, imageDataB, bins = 32) {
    const histA = new Float32Array(bins);
    const histB = new Float32Array(bins);
    const push = (data, hist) => {
      for (let i = 0; i < data.length; i += 4) {
        // grayscale bin for simplicity (fast, robust)
        const g = 0.2126*data[i] + 0.7152*data[i+1] + 0.0722*data[i+2];
        const idx = Math.min(bins - 1, Math.floor(g / (256 / bins)));
        hist[idx]++;
      }
    };
    push(imageDataA.data, histA);
    push(imageDataB.data, histB);

    let intersection = 0, sumA = 0, sumB = 0;
    for (let i = 0; i < bins; i++) {
      intersection += Math.min(histA[i], histB[i]);
      sumA += histA[i];
      sumB += histB[i];
    }
    const denom = Math.max(sumA, sumB, 1);
    const similarity = intersection / denom; // [0..1]
    return { similarity, intersection, denom };
  }

  // Accept either a precomputed gray buffer OR an ImageData to derive luminance
  _pHash(grayOrImage, width, height) {
    let gray, w = width, h = height;

    if (grayOrImage instanceof Float32Array) {
      gray = grayOrImage;
    } else {
      const imageData = grayOrImage; // ImageData
      const { data } = imageData;
      gray = new Float32Array(w * h);
      for (let i = 0, p = 0; i < data.length; i += 4, p++) {
        gray[p] = 0.2126*data[i] + 0.7152*data[i+1] + 0.0722*data[i+2];
      }
    }

    // Resize to 32x32 then DCT, then 8x8 top-left
    const N = 32, K = 8;

    // Put grayscale into an ImageData so we can draw/scale via canvas
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = N; tempCanvas.height = N;
    const ctx = tempCanvas.getContext('2d', { willReadFrequently: true });

    const imgData = ctx.createImageData(w, h);
    for (let i = 0, p = 0; i < imgData.data.length; i += 4, p++) {
      const g = Math.max(0, Math.min(255, gray[p]));
      imgData.data[i] = g; imgData.data[i+1] = g; imgData.data[i+2] = g; imgData.data[i+3] = 255;
    }
    const srcCanvas = document.createElement('canvas');
    srcCanvas.width = w; srcCanvas.height = h;
    const sctx = srcCanvas.getContext('2d', { willReadFrequently: true });
    sctx.putImageData(imgData, 0, 0);
    ctx.drawImage(srcCanvas, 0, 0, N, N);
    const resized = ctx.getImageData(0, 0, N, N);

    // Build grayscale array for DCT input
    const block = new Float32Array(N * N);
    for (let i = 0, p = 0; i < resized.data.length; i += 4, p++) {
      block[p] = resized.data[i]; // already grayscale
    }
    const dct = this._dct2(block, N);

    // Compute mean of top-left 8x8 excluding DC (0,0)
    let sum = 0, count = 0;
    for (let u = 0; u < K; u++) {
      for (let v = 0; v < K; v++) {
        if (u === 0 && v === 0) continue;
        sum += dct[u*N + v]; count++;
      }
    }
    const mean = sum / Math.max(1, count);

    // Build 64-bit hash (as array of 64 bits)
    const bits = [];
    for (let u = 0; u < K; u++) {
      for (let v = 0; v < K; v++) {
        if (u === 0 && v === 0) continue;
        bits.push(dct[u*N + v] > mean ? 1 : 0);
      }
    }
    // pad with DC comparison to mean for 64th bit
    bits.push(dct[0] > mean ? 1 : 0);
    return bits;
  }

  _dct2(block, N) {
    // Simple 2D DCT (naive, O(N^4) but N is small for pHash)
    const out = new Float32Array(N * N);
    const c = (x) => (x === 0 ? Math.sqrt(1/N) : Math.sqrt(2/N));
    for (let u = 0; u < N; u++) {
      for (let v = 0; v < N; v++) {
        let sum = 0;
        for (let x = 0; x < N; x++) {
          for (let y = 0; y < N; y++) {
            sum += block[x*N + y] *
              Math.cos(((2*x + 1) * u * Math.PI) / (2 * N)) *
              Math.cos(((2*y + 1) * v * Math.PI) / (2 * N));
          }
        }
        out[u*N + v] = c(u) * c(v) * sum;
      }
    }
    return out;
  }

  _hamming(aBits, bBits) {
    const n = Math.min(aBits.length, bBits.length);
    let dist = 0;
    for (let i = 0; i < n; i++) if (aBits[i] !== bBits[i]) dist++;
    dist += Math.abs(aBits.length - bBits.length); // if lengths differ
    return dist;
  }

  /* --------------------------- Image Comparison -------------------------- */
  async _compareImages(a, b) {
    const srcA = await this._materializeSource(a);
    const srcB = await this._materializeSource(b);
    const dataA = this._drawToCanvas(srcA);
    const dataB = this._drawToCanvas(srcB);

    const A = this._ensureGrayOrColor(dataA);
    const B = this._ensureGrayOrColor(dataB);
    // MSE + PSNR
    const mseRes = (A.mode === 'gray')
      ? this._mse(A.gray, B.gray)
      : this._mseColor(A.imageData, B.imageData);

    const psnrRes = this._psnr(mseRes.mse);

    // SSIM
    const ssimRes = (A.mode === 'gray')
      ? this._ssim(A.gray, B.gray)
      : this._ssimColor(A.imageData, B.imageData);

    // Histogram Intersection (uses original ImageData)
    const histRes = this._histIntersection(dataA, dataB);

    // pHash: luminance-based (use provided gray if available; else derive from ImageData)
    const phA = (A.mode === 'gray')
      ? this._pHash(A.gray, dataA.width, dataA.height)
      : this._pHash(A.imageData, dataA.width, dataA.height);

    const phB = (B.mode === 'gray')
      ? this._pHash(B.gray, dataB.width, dataB.height)
      : this._pHash(B.imageData, dataB.width, dataB.height);

    const hamming = this._hamming(phA, phB);
    const phashSim = Math.max(0, 1 - (hamming / 64));

    const metrics = {
      mse: mseRes.similarity,
      psnr: psnrRes.similarity,
      ssim: ssimRes.similarity,
      hist: histRes.similarity,
      phash: phashSim
    };

    const similarity = this._weightedAggregate(metrics);
    return { similarity, metrics, kind: 'image' };
  }

  _weightedAggregate(metrics) {
    let wsum = 0, acc = 0;
    for (const key of Object.keys(this.weights)) {
      const w = this.weights[key] ?? 0;
      if (w <= 0) continue;
      const v = metrics[key] ?? 0;
      acc += w * v;
      wsum += w;
    }
    return wsum > 0 ? acc / wsum : 0;
  }

  /* --------------------------- Video Comparison -------------------------- */
  async _compareVideos(a, b) {
    const videoA = await this._materializeSource(a);
    const videoB = await this._materializeSource(b);
    const framesA = await this._sampleVideoFrames(videoA, this.videoFrameSamples);
    const framesB = await this._sampleVideoFrames(videoB, this.videoFrameSamples);
    const n = Math.min(framesA.length, framesB.length);
    let aggSimilarity = 0;
    const details = [];
    for (let i = 0; i < n; i++) {
      const { similarity, metrics } = await this._compareImages(framesA[i], framesB[i]);
      aggSimilarity += similarity;
      details.push(metrics);
    }
    const similarity = n > 0 ? aggSimilarity / n : 0;
    return { similarity, metricsPerFrame: details, kind: 'video' };
  }

  async _sampleVideoFrames(video, samples) {
    await this._awaitVideoReady(video);
    const duration = video.duration || 0;
    if (!duration || !isFinite(duration)) {
      // Fallback: single current frame
      return [video];
    }

    const timestamps = [];
    // Sample from 10% to 90% to avoid blank first/last frames
    const start = duration * 0.1, end = duration * 0.9;
    const step = (end - start) / Math.max(1, (samples - 1));
    for (let i = 0; i < samples; i++) timestamps.push(start + i * step);

    const frames = [];
    for (const t of timestamps) {
      await this._seekVideo(video, t);
      const frameData = this._drawToCanvas(video);
      // Convert ImageData back into a pseudo-image source for reuse
      const frameCanvas = document.createElement('canvas');
      frameCanvas.width = frameData.width;
      frameCanvas.height = frameData.height;
      const ctx = frameCanvas.getContext('2d', { willReadFrequently: true });
      ctx.putImageData(frameData, 0, 0);
      frames.push(frameCanvas);
    }
    return frames;
  }

  _seekVideo(video, time) {
    return new Promise((resolve, reject) => {
      const onSeeked = () => { cleanup(); resolve(); };
      const onError = (e) => { cleanup(); reject(e); };
      const cleanup = () => {
        video.removeEventListener('seeked', onSeeked);
        video.removeEventListener('error', onError);
      };
      video.addEventListener('seeked', onSeeked);
      video.addEventListener('error', onError);
      video.currentTime = Math.min(Math.max(0, time), video.duration || 0);
    });
  }

  /* ------------------------- Video-to-Image Fallback --------------------- */
  async _compareVideoToImage(videoSrc, imageSrc) {
    const video = await this._materializeSource(videoSrc);
    const image = await this._materializeSource(imageSrc);
    const frames = await this._sampleVideoFrames(video, this.videoFrameSamples);
    let best = 0;
    let bestMetrics = null;
    for (const f of frames) {
      const { similarity, metrics } = await this._compareImages(f, image);
      if (similarity > best) {
        best = similarity;
        bestMetrics = metrics;
      }
    }
    return { similarity: best, metrics: bestMetrics || {}, kind: 'video-image' };
  }
};
//

class FacialRecognition {
    constructor(el = document.body, width = 640, height = 480, config={}) {
        this.el = el;
        this.width = width;
        this.height = height;
        this.container = document.createElement('div');
        this.container.classList.add('fr-container');
        this.container.style.position = 'relative';
        // Create video element
        this.videoElement = document.createElement('video');
        this.videoElement.id = 'facial-video';
        this.videoElement.className = 'facial-video';

        // Create canvas element
        this.canvasElement = document.createElement('canvas');
        this.canvasElement.id = 'facial-canvas';
        this.canvasElement.className = 'facial-canvas';
        this.videoElement.width = width;
        this.videoElement.height = height;
        this.canvasElement.width = width;
        this.canvasElement.height = height;
        this.canvasElement.style.width = `${width}px`;
        this.canvasElement.style.height = `${height}px`;

        this.errorElement = document.createElement('div');
        this.errorElement.classList.add('video-player-error');
        this.errorElement.setAttribute('style',`width:${width}px;height:${height}px;`);

        this.context = this.canvasElement.getContext('2d');
        if(!this.container.querySelector('#facial-video'))this.container.appendChild(this.videoElement);
        this.errorElement.style.top = `${this.videoElement.offsetTop}px`;
        if(!this.container.querySelector('.video-player-error')) this.container.appendChild(this.errorElement);
        if(!this.el.querySelector('.fr-container')) this.el.appendChild(this.container);
    }

    /**
     * Initializes the facial recognition process.
     */
    init() {
        if (!this.checkSupport()) return;

        navigator.mediaDevices.getUserMedia({ video: true }).then(stream => {
          this.videoElement.srcObject = stream;
          this.videoElement.play();
          this.recognitionLoop();
          sessionStorage.setItem('recognitionActive', true);
        }).catch(error => {
          console.error('Error accessing webcam:', error);
          sessionStorage.setItem('recognitionActive', false);
          this.errorElement.innerText = error;
          this.errorElement.style.display = 'block';
        });
    }

    /**
     * Main recognition loop: captures frames and processes them.
     */
    recognitionLoop() {
        const isActive = sessionStorage.getItem('recognitionActive') === 'true';
        if (!isActive) return;

        this.context.drawImage(this.videoElement, 0, 0, this.canvasElement.width, this.canvasElement.height);
        // Placeholder: Call your facial recognition library here

        requestAnimationFrame(() => this.recognitionLoop());
    }

    /**
     * Stops the recognition and webcam stream.
     */
    stop() {
        sessionStorage.setItem('recognitionActive', 'false');

        if (this.videoElement.srcObject) {
            const tracks = this.videoElement.srcObject.getTracks();
            tracks.forEach(track => track.stop());
        }
        this.videoElement.srcObject = null;
        this.context.clearRect(0, 0, this.canvasElement.width, this.canvasElement.height);
        // Optionally, remove or hide the canvas
        if (this.el.contains(this.canvasElement)) {
            this.el.removeChild(this.canvasElement);
        }
        // Save state
    }

    /**
     * Toggles recognition on/off.
     */
    toggleRecognition() {
        const isActive = sessionStorage.getItem('recognitionActive') === 'true';
        if (isActive) {
            this.stop();
        } else {
            this.init();
        }
    }

    /**
     * Checks for webcam support.
     */
    checkSupport() {
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            console.error('Webcam access is not supported in this browser.');
            return false;
        }
        return true;
    }
    /**
     * Compares the current facial image with stored images.
     * @returns {Array} Array of comparison results or empty array if no images found.
     */
    async compareFacial(username) {
        // 1) Fetch stored image
        let storedImg;
        try {
            const response = await $.ajax({
                url: `${BASE}/facials/compareFacial.php`,
                type: 'POST',
                contentType: 'application/json',
                dataType: 'json',
                data: JSON.stringify({ username })
            });
            if (response.error) {
                console.error('Server error:', response.error);
                return null;
            }
            const imageUrl = `${BASE}/facials/${response[0]}`;
            storedImg = await new Promise((resolve, reject) => {
                const img = new Image();
                img.crossOrigin = 'anonymous';
                img.onload = () => resolve(img);
                img.onerror = (e) => reject(e);
                img.src = imageUrl;
            });
        } catch (error) {
            console.error('Failed to fetch stored facial image:', error);
            return null;
        }
        // Dummy landmark detection function
        const detectFaceLandmarks = (canvas) => {
            return new Promise((resolve) => {
                const centerX = this.canvasElement.width / 2;
                const centerY = this.canvasElement.height / 2;
                const radius = Math.min(this.canvasElement.width, this.canvasElement.height) / 3;
                const points = [];
                const numPoints = 20;
                for (let i = 0; i < numPoints; i++) {
                    const angle = (Math.PI * 2 / numPoints) * i;
                    points.push({
                        x: centerX + radius * Math.cos(angle),
                        y: centerY + radius * Math.sin(angle)
                    });
                }
                resolve(points);
            });
        };
        // 2) Detect face landmarks for current frame
        const points = await detectFaceLandmarks(); // Replace with real detection
        const xs = points.map(p => p.x);
        const ys = points.map(p => p.y);
        const minX = Math.min(...xs), maxX = Math.max(...xs);
        const minY = Math.min(...ys), maxY = Math.max(...ys);
        const padding = 10;

        const cropX = Math.max(0, minX - padding);
        const cropY = Math.max(0, minY - padding);
        const cropWidth = Math.min(this.canvasElement.width - cropX, maxX - minX + 2 * padding);
        const cropHeight = Math.min(this.canvasElement.height - cropY, maxY - minY + 2 * padding);

        // 3) Create transparent canvas for webcam face
        const faceCanvas = document.createElement('canvas');
        faceCanvas.width = cropWidth;
        faceCanvas.height = cropHeight;
        const faceCtx = faceCanvas.getContext('2d');
        faceCtx.clearRect(0, 0, cropWidth, cropHeight);
        faceCtx.drawImage(this.videoElement, cropX, cropY, cropWidth, cropHeight, 0, 0, cropWidth, cropHeight);

        // 4) Create transparent canvas for stored image
        const storedCanvas = document.createElement('canvas');
        storedCanvas.width = storedImg.width;
        storedCanvas.height = storedImg.height;
        const storedCtx = storedCanvas.getContext('2d');
        storedCtx.clearRect(0, 0, storedImg.width, storedImg.height);
        storedCtx.drawImage(storedImg, 0, 0);

        // Optional: If you have landmarks for storedImg, crop similarly

        // 5) Compare cropped transparent canvases
        try {
            const cnn = new CNN({ targetSize: 100, grayscale: true, resizeMode: 'cover' });
            console.log(faceCanvas,storedCanvas);
            const result = await cnn.compare(faceCanvas, storedCanvas);
            return result;
        } catch (error) {
            console.error('Failed to compare facial:', error);
            return null;
        }
    }


  /**
   * Helper: draw `source` into `ctx` (canvas width/height) using a contain/cover fit.
   * Mirrors CNN._drawToCanvas logic so both sources are pre-normalized consistently.
   */
  _drawFitted(source, ctx, tw, th, mode = 'contain') {
    // Determine intrinsic size of source
    let sw, sh;
    if (source instanceof HTMLVideoElement) {
      sw = source.videoWidth;
      sh = source.videoHeight;
    } else if (source instanceof HTMLImageElement) {
      sw = source.naturalWidth || source.width;
      sh = source.naturalHeight || source.height;
    } else if (source instanceof HTMLCanvasElement || (typeof ImageBitmap !== 'undefined' && source instanceof ImageBitmap)) {
      sw = source.width;
      sh = source.height;
    } else {
      throw new Error('Unsupported source for fitted draw');
    }

    // Compute fit rect (contain/cover)
    const srcAspect = sw / sh;
    const dstAspect = tw / th;
    let dw, dh;
    const useCover = mode === 'cover';
    if (useCover ? (srcAspect < dstAspect) : (srcAspect > dstAspect)) {
      // match width
      dw = tw;
      dh = tw / srcAspect;
    } else {
      // match height
      dh = th;
      dw = th * srcAspect;
    }
    const dx = (tw - dw) / 2;
    const dy = (th - dh) / 2;

    ctx.clearRect(0, 0, tw, th);
    ctx.drawImage(source, dx, dy, dw, dh);
  }



    /**
     * Shows face outline with pixel points.
     */
    showFacePixel() {
        const drawFaceOutline = (points) => {
            this.context.clearRect(0, 0, this.canvasElement.width, this.canvasElement.height);
            this.context.drawImage(this.videoElement, 0, 0, this.canvasElement.width, this.canvasElement.height);

            if (points && points.length > 0) {
                this.context.strokeStyle = 'red';
                this.context.lineWidth = 2;

                // Calculate center and radius from points for a circle
                const xs = points.map(p => p.x);
                const ys = points.map(p => p.y);
                const centerX = xs.reduce((a, b) => a + b, 0) / xs.length;
                const centerY = ys.reduce((a, b) => a + b, 0) / ys.length;
                const radius = Math.max(
                    ...points.map(p => Math.hypot(p.x - centerX, p.y - centerY))
                );

                // Draw a circle
                this.context.beginPath();
                this.context.arc(centerX, centerY, radius, 0, Math.PI * 2);
                this.context.stroke();
            }
        };

        

        // Dummy landmark detection function
        const detectFaceLandmarks = (canvas) => {
            return new Promise((resolve) => {
                const centerX = this.canvasElement.width / 2;
                const centerY = this.canvasElement.height / 2;
                const radius = Math.min(this.canvasElement.width, this.canvasElement.height) / 3;
                const points = [];
                const numPoints = 20;
                for (let i = 0; i < numPoints; i++) {
                    const angle = (Math.PI * 2 / numPoints) * i;
                    points.push({
                        x: centerX + radius * Math.cos(angle),
                        y: centerY + radius * Math.sin(angle)
                    });
                }
                resolve(points);
            });
        };
        const processFrame = () => {
            this.context.drawImage(this.videoElement, 0, 0, this.canvasElement.width, this.canvasElement.height);

            // Replace with actual face landmark detection
            detectFaceLandmarks(this.canvasElement).then((landmarks) => {
                drawFaceOutline(landmarks);
            }).catch(err => {
                console.error('Face detection error:', err);
            });
            setTimeout(()=>{
                requestAnimationFrame(processFrame);
            },0);
            
        };

        // Start processing
        processFrame();
    }

    /**
     * Takes a picture and saves it via AJAX.
     */
    takePicture() {
        if (sessionStorage.getItem('recognitionActive') !== 'true') {
            console.error('Facial recognition is not active.');
            return;
        }

        // Detect face landmarks to get face points
        const detectFaceLandmarks = () => {
            const centerX = this.canvasElement.width / 2;
            const centerY = this.canvasElement.height / 2;
            const radius = Math.min(this.canvasElement.width, this.canvasElement.height) / 3;
            const points = [];
            const numPoints = 20;
            for (let i = 0; i < numPoints; i++) {
                const angle = (Math.PI * 2 / numPoints) * i;
                points.push({
                    x: centerX + radius * Math.cos(angle),
                    y: centerY + radius * Math.sin(angle)
                });
            }
            return Promise.resolve(points);
        };

        detectFaceLandmarks().then(points => {
            // Calculate bounding box
            const xs = points.map(p => p.x);
            const ys = points.map(p => p.y);
            const minX = Math.min(...xs);
            const maxX = Math.max(...xs);
            const minY = Math.min(...ys);
            const maxY = Math.max(...ys);

            const padding = 10;
            const cropX = Math.max(0, minX - padding);
            const cropY = Math.max(0, minY - padding);
            const cropWidth = Math.min(this.canvasElement.width - cropX, maxX - minX + 2 * padding);
            const cropHeight = Math.min(this.canvasElement.height - cropY, maxY - minY + 2 * padding);

            // Clear the canvas to remove the red circle
            this.context.clearRect(0, 0, this.canvasElement.width, this.canvasElement.height);

            // Draw the current video frame onto the cleared canvas
            this.context.drawImage(this.videoElement, 0, 0, this.canvasElement.width, this.canvasElement.height);

            // Create a temporary canvas for the face crop
            const tempCanvas = document.createElement('canvas');
            tempCanvas.width = cropWidth;
            tempCanvas.height = cropHeight;
            const tempCtx = tempCanvas.getContext('2d');

            // Draw the face region onto the temporary canvas
            tempCtx.drawImage(
                this.canvasElement,
                cropX, cropY, cropWidth, cropHeight,
                0, 0, cropWidth, cropHeight
            );

            // Get the data URL of the face image
            const faceImageData = tempCanvas.toDataURL('image/png');

            // Send via AJAX
            $.ajax({
                url: `${BASE}/facials/savePicture.php`,
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ image: faceImageData }),
                success: function(response) {
                    console.log('Face image saved successfully.');
                    alert('Face image saved successfully.');
                },
                error: function(xhr, status, error) {
                    console.error('Failed to save face image:', error);
                    alert('Failed to save face image:', error);
                }
            });
        }).catch(err => {
            console.error('Error detecting face for capture:', err);
        });
    }

    /**
     * Load state from sessionStorage (if needed)
     */
    static loadFromSession() {
        const stateStr = sessionStorage.getItem('facialRecognitionState');
        if (!stateStr) return null;
        const state = JSON.parse(stateStr);
        return state;
    }
}